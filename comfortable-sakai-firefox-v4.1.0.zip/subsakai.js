/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/mustache/mustache.js":
/*!*******************************************!*\
  !*** ./node_modules/mustache/mustache.js ***!
  \*******************************************/
/***/ (function(module) {

(function (global, factory) {
   true ? module.exports = factory() :
  0;
}(this, (function () { 'use strict';

  /*!
   * mustache.js - Logic-less {{mustache}} templates with JavaScript
   * http://github.com/janl/mustache.js
   */

  var objectToString = Object.prototype.toString;
  var isArray = Array.isArray || function isArrayPolyfill (object) {
    return objectToString.call(object) === '[object Array]';
  };

  function isFunction (object) {
    return typeof object === 'function';
  }

  /**
   * More correct typeof string handling array
   * which normally returns typeof 'object'
   */
  function typeStr (obj) {
    return isArray(obj) ? 'array' : typeof obj;
  }

  function escapeRegExp (string) {
    return string.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');
  }

  /**
   * Null safe way of checking whether or not an object,
   * including its prototype, has a given property
   */
  function hasProperty (obj, propName) {
    return obj != null && typeof obj === 'object' && (propName in obj);
  }

  /**
   * Safe way of detecting whether or not the given thing is a primitive and
   * whether it has the given property
   */
  function primitiveHasOwnProperty (primitive, propName) {
    return (
      primitive != null
      && typeof primitive !== 'object'
      && primitive.hasOwnProperty
      && primitive.hasOwnProperty(propName)
    );
  }

  // Workaround for https://issues.apache.org/jira/browse/COUCHDB-577
  // See https://github.com/janl/mustache.js/issues/189
  var regExpTest = RegExp.prototype.test;
  function testRegExp (re, string) {
    return regExpTest.call(re, string);
  }

  var nonSpaceRe = /\S/;
  function isWhitespace (string) {
    return !testRegExp(nonSpaceRe, string);
  }

  var entityMap = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
    '/': '&#x2F;',
    '`': '&#x60;',
    '=': '&#x3D;'
  };

  function escapeHtml (string) {
    return String(string).replace(/[&<>"'`=\/]/g, function fromEntityMap (s) {
      return entityMap[s];
    });
  }

  var whiteRe = /\s*/;
  var spaceRe = /\s+/;
  var equalsRe = /\s*=/;
  var curlyRe = /\s*\}/;
  var tagRe = /#|\^|\/|>|\{|&|=|!/;

  /**
   * Breaks up the given `template` string into a tree of tokens. If the `tags`
   * argument is given here it must be an array with two string values: the
   * opening and closing tags used in the template (e.g. [ "<%", "%>" ]). Of
   * course, the default is to use mustaches (i.e. mustache.tags).
   *
   * A token is an array with at least 4 elements. The first element is the
   * mustache symbol that was used inside the tag, e.g. "#" or "&". If the tag
   * did not contain a symbol (i.e. {{myValue}}) this element is "name". For
   * all text that appears outside a symbol this element is "text".
   *
   * The second element of a token is its "value". For mustache tags this is
   * whatever else was inside the tag besides the opening symbol. For text tokens
   * this is the text itself.
   *
   * The third and fourth elements of the token are the start and end indices,
   * respectively, of the token in the original template.
   *
   * Tokens that are the root node of a subtree contain two more elements: 1) an
   * array of tokens in the subtree and 2) the index in the original template at
   * which the closing tag for that section begins.
   *
   * Tokens for partials also contain two more elements: 1) a string value of
   * indendation prior to that tag and 2) the index of that tag on that line -
   * eg a value of 2 indicates the partial is the third tag on this line.
   */
  function parseTemplate (template, tags) {
    if (!template)
      return [];
    var lineHasNonSpace = false;
    var sections = [];     // Stack to hold section tokens
    var tokens = [];       // Buffer to hold the tokens
    var spaces = [];       // Indices of whitespace tokens on the current line
    var hasTag = false;    // Is there a {{tag}} on the current line?
    var nonSpace = false;  // Is there a non-space char on the current line?
    var indentation = '';  // Tracks indentation for tags that use it
    var tagIndex = 0;      // Stores a count of number of tags encountered on a line

    // Strips all whitespace tokens array for the current line
    // if there was a {{#tag}} on it and otherwise only space.
    function stripSpace () {
      if (hasTag && !nonSpace) {
        while (spaces.length)
          delete tokens[spaces.pop()];
      } else {
        spaces = [];
      }

      hasTag = false;
      nonSpace = false;
    }

    var openingTagRe, closingTagRe, closingCurlyRe;
    function compileTags (tagsToCompile) {
      if (typeof tagsToCompile === 'string')
        tagsToCompile = tagsToCompile.split(spaceRe, 2);

      if (!isArray(tagsToCompile) || tagsToCompile.length !== 2)
        throw new Error('Invalid tags: ' + tagsToCompile);

      openingTagRe = new RegExp(escapeRegExp(tagsToCompile[0]) + '\\s*');
      closingTagRe = new RegExp('\\s*' + escapeRegExp(tagsToCompile[1]));
      closingCurlyRe = new RegExp('\\s*' + escapeRegExp('}' + tagsToCompile[1]));
    }

    compileTags(tags || mustache.tags);

    var scanner = new Scanner(template);

    var start, type, value, chr, token, openSection;
    while (!scanner.eos()) {
      start = scanner.pos;

      // Match any text between tags.
      value = scanner.scanUntil(openingTagRe);

      if (value) {
        for (var i = 0, valueLength = value.length; i < valueLength; ++i) {
          chr = value.charAt(i);

          if (isWhitespace(chr)) {
            spaces.push(tokens.length);
            indentation += chr;
          } else {
            nonSpace = true;
            lineHasNonSpace = true;
            indentation += ' ';
          }

          tokens.push([ 'text', chr, start, start + 1 ]);
          start += 1;

          // Check for whitespace on the current line.
          if (chr === '\n') {
            stripSpace();
            indentation = '';
            tagIndex = 0;
            lineHasNonSpace = false;
          }
        }
      }

      // Match the opening tag.
      if (!scanner.scan(openingTagRe))
        break;

      hasTag = true;

      // Get the tag type.
      type = scanner.scan(tagRe) || 'name';
      scanner.scan(whiteRe);

      // Get the tag value.
      if (type === '=') {
        value = scanner.scanUntil(equalsRe);
        scanner.scan(equalsRe);
        scanner.scanUntil(closingTagRe);
      } else if (type === '{') {
        value = scanner.scanUntil(closingCurlyRe);
        scanner.scan(curlyRe);
        scanner.scanUntil(closingTagRe);
        type = '&';
      } else {
        value = scanner.scanUntil(closingTagRe);
      }

      // Match the closing tag.
      if (!scanner.scan(closingTagRe))
        throw new Error('Unclosed tag at ' + scanner.pos);

      if (type == '>') {
        token = [ type, value, start, scanner.pos, indentation, tagIndex, lineHasNonSpace ];
      } else {
        token = [ type, value, start, scanner.pos ];
      }
      tagIndex++;
      tokens.push(token);

      if (type === '#' || type === '^') {
        sections.push(token);
      } else if (type === '/') {
        // Check section nesting.
        openSection = sections.pop();

        if (!openSection)
          throw new Error('Unopened section "' + value + '" at ' + start);

        if (openSection[1] !== value)
          throw new Error('Unclosed section "' + openSection[1] + '" at ' + start);
      } else if (type === 'name' || type === '{' || type === '&') {
        nonSpace = true;
      } else if (type === '=') {
        // Set the tags for the next time around.
        compileTags(value);
      }
    }

    stripSpace();

    // Make sure there are no open sections when we're done.
    openSection = sections.pop();

    if (openSection)
      throw new Error('Unclosed section "' + openSection[1] + '" at ' + scanner.pos);

    return nestTokens(squashTokens(tokens));
  }

  /**
   * Combines the values of consecutive text tokens in the given `tokens` array
   * to a single token.
   */
  function squashTokens (tokens) {
    var squashedTokens = [];

    var token, lastToken;
    for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
      token = tokens[i];

      if (token) {
        if (token[0] === 'text' && lastToken && lastToken[0] === 'text') {
          lastToken[1] += token[1];
          lastToken[3] = token[3];
        } else {
          squashedTokens.push(token);
          lastToken = token;
        }
      }
    }

    return squashedTokens;
  }

  /**
   * Forms the given array of `tokens` into a nested tree structure where
   * tokens that represent a section have two additional items: 1) an array of
   * all tokens that appear in that section and 2) the index in the original
   * template that represents the end of that section.
   */
  function nestTokens (tokens) {
    var nestedTokens = [];
    var collector = nestedTokens;
    var sections = [];

    var token, section;
    for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
      token = tokens[i];

      switch (token[0]) {
        case '#':
        case '^':
          collector.push(token);
          sections.push(token);
          collector = token[4] = [];
          break;
        case '/':
          section = sections.pop();
          section[5] = token[2];
          collector = sections.length > 0 ? sections[sections.length - 1][4] : nestedTokens;
          break;
        default:
          collector.push(token);
      }
    }

    return nestedTokens;
  }

  /**
   * A simple string scanner that is used by the template parser to find
   * tokens in template strings.
   */
  function Scanner (string) {
    this.string = string;
    this.tail = string;
    this.pos = 0;
  }

  /**
   * Returns `true` if the tail is empty (end of string).
   */
  Scanner.prototype.eos = function eos () {
    return this.tail === '';
  };

  /**
   * Tries to match the given regular expression at the current position.
   * Returns the matched text if it can match, the empty string otherwise.
   */
  Scanner.prototype.scan = function scan (re) {
    var match = this.tail.match(re);

    if (!match || match.index !== 0)
      return '';

    var string = match[0];

    this.tail = this.tail.substring(string.length);
    this.pos += string.length;

    return string;
  };

  /**
   * Skips all text until the given regular expression can be matched. Returns
   * the skipped string, which is the entire tail if no match can be made.
   */
  Scanner.prototype.scanUntil = function scanUntil (re) {
    var index = this.tail.search(re), match;

    switch (index) {
      case -1:
        match = this.tail;
        this.tail = '';
        break;
      case 0:
        match = '';
        break;
      default:
        match = this.tail.substring(0, index);
        this.tail = this.tail.substring(index);
    }

    this.pos += match.length;

    return match;
  };

  /**
   * Represents a rendering context by wrapping a view object and
   * maintaining a reference to the parent context.
   */
  function Context (view, parentContext) {
    this.view = view;
    this.cache = { '.': this.view };
    this.parent = parentContext;
  }

  /**
   * Creates a new context using the given view with this context
   * as the parent.
   */
  Context.prototype.push = function push (view) {
    return new Context(view, this);
  };

  /**
   * Returns the value of the given name in this context, traversing
   * up the context hierarchy if the value is absent in this context's view.
   */
  Context.prototype.lookup = function lookup (name) {
    var cache = this.cache;

    var value;
    if (cache.hasOwnProperty(name)) {
      value = cache[name];
    } else {
      var context = this, intermediateValue, names, index, lookupHit = false;

      while (context) {
        if (name.indexOf('.') > 0) {
          intermediateValue = context.view;
          names = name.split('.');
          index = 0;

          /**
           * Using the dot notion path in `name`, we descend through the
           * nested objects.
           *
           * To be certain that the lookup has been successful, we have to
           * check if the last object in the path actually has the property
           * we are looking for. We store the result in `lookupHit`.
           *
           * This is specially necessary for when the value has been set to
           * `undefined` and we want to avoid looking up parent contexts.
           *
           * In the case where dot notation is used, we consider the lookup
           * to be successful even if the last "object" in the path is
           * not actually an object but a primitive (e.g., a string, or an
           * integer), because it is sometimes useful to access a property
           * of an autoboxed primitive, such as the length of a string.
           **/
          while (intermediateValue != null && index < names.length) {
            if (index === names.length - 1)
              lookupHit = (
                hasProperty(intermediateValue, names[index])
                || primitiveHasOwnProperty(intermediateValue, names[index])
              );

            intermediateValue = intermediateValue[names[index++]];
          }
        } else {
          intermediateValue = context.view[name];

          /**
           * Only checking against `hasProperty`, which always returns `false` if
           * `context.view` is not an object. Deliberately omitting the check
           * against `primitiveHasOwnProperty` if dot notation is not used.
           *
           * Consider this example:
           * ```
           * Mustache.render("The length of a football field is {{#length}}{{length}}{{/length}}.", {length: "100 yards"})
           * ```
           *
           * If we were to check also against `primitiveHasOwnProperty`, as we do
           * in the dot notation case, then render call would return:
           *
           * "The length of a football field is 9."
           *
           * rather than the expected:
           *
           * "The length of a football field is 100 yards."
           **/
          lookupHit = hasProperty(context.view, name);
        }

        if (lookupHit) {
          value = intermediateValue;
          break;
        }

        context = context.parent;
      }

      cache[name] = value;
    }

    if (isFunction(value))
      value = value.call(this.view);

    return value;
  };

  /**
   * A Writer knows how to take a stream of tokens and render them to a
   * string, given a context. It also maintains a cache of templates to
   * avoid the need to parse the same template twice.
   */
  function Writer () {
    this.templateCache = {
      _cache: {},
      set: function set (key, value) {
        this._cache[key] = value;
      },
      get: function get (key) {
        return this._cache[key];
      },
      clear: function clear () {
        this._cache = {};
      }
    };
  }

  /**
   * Clears all cached templates in this writer.
   */
  Writer.prototype.clearCache = function clearCache () {
    if (typeof this.templateCache !== 'undefined') {
      this.templateCache.clear();
    }
  };

  /**
   * Parses and caches the given `template` according to the given `tags` or
   * `mustache.tags` if `tags` is omitted,  and returns the array of tokens
   * that is generated from the parse.
   */
  Writer.prototype.parse = function parse (template, tags) {
    var cache = this.templateCache;
    var cacheKey = template + ':' + (tags || mustache.tags).join(':');
    var isCacheEnabled = typeof cache !== 'undefined';
    var tokens = isCacheEnabled ? cache.get(cacheKey) : undefined;

    if (tokens == undefined) {
      tokens = parseTemplate(template, tags);
      isCacheEnabled && cache.set(cacheKey, tokens);
    }
    return tokens;
  };

  /**
   * High-level method that is used to render the given `template` with
   * the given `view`.
   *
   * The optional `partials` argument may be an object that contains the
   * names and templates of partials that are used in the template. It may
   * also be a function that is used to load partial templates on the fly
   * that takes a single argument: the name of the partial.
   *
   * If the optional `config` argument is given here, then it should be an
   * object with a `tags` attribute or an `escape` attribute or both.
   * If an array is passed, then it will be interpreted the same way as
   * a `tags` attribute on a `config` object.
   *
   * The `tags` attribute of a `config` object must be an array with two
   * string values: the opening and closing tags used in the template (e.g.
   * [ "<%", "%>" ]). The default is to mustache.tags.
   *
   * The `escape` attribute of a `config` object must be a function which
   * accepts a string as input and outputs a safely escaped string.
   * If an `escape` function is not provided, then an HTML-safe string
   * escaping function is used as the default.
   */
  Writer.prototype.render = function render (template, view, partials, config) {
    var tags = this.getConfigTags(config);
    var tokens = this.parse(template, tags);
    var context = (view instanceof Context) ? view : new Context(view, undefined);
    return this.renderTokens(tokens, context, partials, template, config);
  };

  /**
   * Low-level method that renders the given array of `tokens` using
   * the given `context` and `partials`.
   *
   * Note: The `originalTemplate` is only ever used to extract the portion
   * of the original template that was contained in a higher-order section.
   * If the template doesn't use higher-order sections, this argument may
   * be omitted.
   */
  Writer.prototype.renderTokens = function renderTokens (tokens, context, partials, originalTemplate, config) {
    var buffer = '';

    var token, symbol, value;
    for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
      value = undefined;
      token = tokens[i];
      symbol = token[0];

      if (symbol === '#') value = this.renderSection(token, context, partials, originalTemplate, config);
      else if (symbol === '^') value = this.renderInverted(token, context, partials, originalTemplate, config);
      else if (symbol === '>') value = this.renderPartial(token, context, partials, config);
      else if (symbol === '&') value = this.unescapedValue(token, context);
      else if (symbol === 'name') value = this.escapedValue(token, context, config);
      else if (symbol === 'text') value = this.rawValue(token);

      if (value !== undefined)
        buffer += value;
    }

    return buffer;
  };

  Writer.prototype.renderSection = function renderSection (token, context, partials, originalTemplate, config) {
    var self = this;
    var buffer = '';
    var value = context.lookup(token[1]);

    // This function is used to render an arbitrary template
    // in the current context by higher-order sections.
    function subRender (template) {
      return self.render(template, context, partials, config);
    }

    if (!value) return;

    if (isArray(value)) {
      for (var j = 0, valueLength = value.length; j < valueLength; ++j) {
        buffer += this.renderTokens(token[4], context.push(value[j]), partials, originalTemplate, config);
      }
    } else if (typeof value === 'object' || typeof value === 'string' || typeof value === 'number') {
      buffer += this.renderTokens(token[4], context.push(value), partials, originalTemplate, config);
    } else if (isFunction(value)) {
      if (typeof originalTemplate !== 'string')
        throw new Error('Cannot use higher-order sections without the original template');

      // Extract the portion of the original template that the section contains.
      value = value.call(context.view, originalTemplate.slice(token[3], token[5]), subRender);

      if (value != null)
        buffer += value;
    } else {
      buffer += this.renderTokens(token[4], context, partials, originalTemplate, config);
    }
    return buffer;
  };

  Writer.prototype.renderInverted = function renderInverted (token, context, partials, originalTemplate, config) {
    var value = context.lookup(token[1]);

    // Use JavaScript's definition of falsy. Include empty arrays.
    // See https://github.com/janl/mustache.js/issues/186
    if (!value || (isArray(value) && value.length === 0))
      return this.renderTokens(token[4], context, partials, originalTemplate, config);
  };

  Writer.prototype.indentPartial = function indentPartial (partial, indentation, lineHasNonSpace) {
    var filteredIndentation = indentation.replace(/[^ \t]/g, '');
    var partialByNl = partial.split('\n');
    for (var i = 0; i < partialByNl.length; i++) {
      if (partialByNl[i].length && (i > 0 || !lineHasNonSpace)) {
        partialByNl[i] = filteredIndentation + partialByNl[i];
      }
    }
    return partialByNl.join('\n');
  };

  Writer.prototype.renderPartial = function renderPartial (token, context, partials, config) {
    if (!partials) return;
    var tags = this.getConfigTags(config);

    var value = isFunction(partials) ? partials(token[1]) : partials[token[1]];
    if (value != null) {
      var lineHasNonSpace = token[6];
      var tagIndex = token[5];
      var indentation = token[4];
      var indentedValue = value;
      if (tagIndex == 0 && indentation) {
        indentedValue = this.indentPartial(value, indentation, lineHasNonSpace);
      }
      var tokens = this.parse(indentedValue, tags);
      return this.renderTokens(tokens, context, partials, indentedValue, config);
    }
  };

  Writer.prototype.unescapedValue = function unescapedValue (token, context) {
    var value = context.lookup(token[1]);
    if (value != null)
      return value;
  };

  Writer.prototype.escapedValue = function escapedValue (token, context, config) {
    var escape = this.getConfigEscape(config) || mustache.escape;
    var value = context.lookup(token[1]);
    if (value != null)
      return (typeof value === 'number' && escape === mustache.escape) ? String(value) : escape(value);
  };

  Writer.prototype.rawValue = function rawValue (token) {
    return token[1];
  };

  Writer.prototype.getConfigTags = function getConfigTags (config) {
    if (isArray(config)) {
      return config;
    }
    else if (config && typeof config === 'object') {
      return config.tags;
    }
    else {
      return undefined;
    }
  };

  Writer.prototype.getConfigEscape = function getConfigEscape (config) {
    if (config && typeof config === 'object' && !isArray(config)) {
      return config.escape;
    }
    else {
      return undefined;
    }
  };

  var mustache = {
    name: 'mustache.js',
    version: '4.2.0',
    tags: [ '{{', '}}' ],
    clearCache: undefined,
    escape: undefined,
    parse: undefined,
    render: undefined,
    Scanner: undefined,
    Context: undefined,
    Writer: undefined,
    /**
     * Allows a user to override the default caching strategy, by providing an
     * object with set, get and clear methods. This can also be used to disable
     * the cache by setting it to the literal `undefined`.
     */
    set templateCache (cache) {
      defaultWriter.templateCache = cache;
    },
    /**
     * Gets the default or overridden caching object from the default writer.
     */
    get templateCache () {
      return defaultWriter.templateCache;
    }
  };

  // All high-level mustache.* functions use this writer.
  var defaultWriter = new Writer();

  /**
   * Clears all cached templates in the default writer.
   */
  mustache.clearCache = function clearCache () {
    return defaultWriter.clearCache();
  };

  /**
   * Parses and caches the given template in the default writer and returns the
   * array of tokens it contains. Doing this ahead of time avoids the need to
   * parse templates on the fly as they are rendered.
   */
  mustache.parse = function parse (template, tags) {
    return defaultWriter.parse(template, tags);
  };

  /**
   * Renders the `template` with the given `view`, `partials`, and `config`
   * using the default writer.
   */
  mustache.render = function render (template, view, partials, config) {
    if (typeof template !== 'string') {
      throw new TypeError('Invalid template! Template should be a "string" ' +
                          'but "' + typeStr(template) + '" was given as the first ' +
                          'argument for mustache#render(template, view, partials)');
    }

    return defaultWriter.render(template, view, partials, config);
  };

  // Export the escaping function so that the user may override it.
  // See https://github.com/janl/mustache.js/issues/244
  mustache.escape = escapeHtml;

  // Export these mainly for testing, but also for advanced usage.
  mustache.Scanner = Scanner;
  mustache.Context = Context;
  mustache.Writer = Writer;

  return mustache;

})));


/***/ }),

/***/ "./src/content_script.ts":
/*!*******************************!*\
  !*** ./src/content_script.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.loadAndMergeAssignmentList = exports.mergedAssignmentListNoMemo = exports.mergedAssignmentList = exports.courseIDList = void 0;
var storage_1 = __webpack_require__(/*! ./storage */ "./src/storage.ts");
var network_1 = __webpack_require__(/*! ./network */ "./src/network.ts");
var minisakai_1 = __webpack_require__(/*! ./minisakai */ "./src/minisakai.ts");
var favorites_1 = __webpack_require__(/*! ./favorites */ "./src/favorites.ts");
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
var settings_1 = __webpack_require__(/*! ./settings */ "./src/settings.ts");
/**
 * Load old assignments/quizzes from storage and fetch new assignments/quizzes from Sakai.
 * @param {Config} config
 * @param {CourseSiteInfo[]} courseSiteInfos
 * @param {boolean} useAssignmentCache
 * @param {boolean} useQuizCache
 */
function loadAndMergeAssignmentList(config, courseSiteInfos, useAssignmentCache, useQuizCache) {
    return __awaiter(this, void 0, void 0, function () {
        var oldAssignmentList, _a, oldQuizList, _b, newAssignmentList, newQuizList, pendingList, _i, courseSiteInfos_1, i, result, _c, result_1, k, pendingList, _d, courseSiteInfos_2, i, result, _e, result_2, k, mergedQuizList, memoList, _f;
        return __generator(this, function (_g) {
            switch (_g.label) {
                case 0:
                    _a = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_AssignmentList")];
                case 1:
                    oldAssignmentList = _a.apply(void 0, [_g.sent()]);
                    _b = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_QuizList")];
                case 2:
                    oldQuizList = _b.apply(void 0, [_g.sent()]);
                    newAssignmentList = [];
                    newQuizList = [];
                    if (!useAssignmentCache) return [3 /*break*/, 3];
                    newAssignmentList = oldAssignmentList;
                    return [3 /*break*/, 6];
                case 3:
                    console.log("Fetching assignments...");
                    pendingList = [];
                    // Add course sites to fetch-pending list
                    for (_i = 0, courseSiteInfos_1 = courseSiteInfos; _i < courseSiteInfos_1.length; _i++) {
                        i = courseSiteInfos_1[_i];
                        pendingList.push(network_1.getAssignmentByCourseID(config.baseURL, i.courseID));
                    }
                    return [4 /*yield*/, Promise.allSettled(pendingList)];
                case 4:
                    result = _g.sent();
                    for (_c = 0, result_1 = result; _c < result_1.length; _c++) {
                        k = result_1[_c];
                        if (k.status === "fulfilled")
                            newAssignmentList.push(k.value);
                    }
                    // Update assignment fetch timestamp
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_AssignmentFetchTime", utils_1.nowTime)];
                case 5:
                    // Update assignment fetch timestamp
                    _g.sent();
                    config.fetchedTime.assignment = utils_1.nowTime;
                    _g.label = 6;
                case 6:
                    // Compare assignments with old ones
                    exports.mergedAssignmentListNoMemo = utils_1.compareAndMergeAssignmentList(oldAssignmentList, newAssignmentList);
                    exports.mergedAssignmentList = utils_1.compareAndMergeAssignmentList(oldAssignmentList, newAssignmentList);
                    if (!useQuizCache) return [3 /*break*/, 7];
                    if (typeof oldQuizList !== "undefined") {
                        newQuizList = oldQuizList;
                    }
                    return [3 /*break*/, 10];
                case 7:
                    console.log("Fetching quizzes...");
                    pendingList = [];
                    // Add course sites to fetch-pending list
                    for (_d = 0, courseSiteInfos_2 = courseSiteInfos; _d < courseSiteInfos_2.length; _d++) {
                        i = courseSiteInfos_2[_d];
                        pendingList.push(network_1.getQuizFromCourseID(config.baseURL, i.courseID));
                    }
                    return [4 /*yield*/, Promise.allSettled(pendingList)];
                case 8:
                    result = _g.sent();
                    for (_e = 0, result_2 = result; _e < result_2.length; _e++) {
                        k = result_2[_e];
                        if (k.status === "fulfilled")
                            newQuizList.push(k.value);
                    }
                    // Update assignment fetch timestamp
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_QuizFetchTime", utils_1.nowTime)];
                case 9:
                    // Update assignment fetch timestamp
                    _g.sent();
                    config.fetchedTime.quiz = utils_1.nowTime;
                    _g.label = 10;
                case 10:
                    mergedQuizList = utils_1.compareAndMergeAssignmentList(oldQuizList, newQuizList);
                    // Merge assignments and quizzes
                    exports.mergedAssignmentList = utils_1.mergeIntoAssignmentList(exports.mergedAssignmentList, mergedQuizList);
                    _f = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_MemoList")];
                case 11:
                    memoList = _f.apply(void 0, [_g.sent()]);
                    // Merge memos
                    exports.mergedAssignmentList = utils_1.sortAssignmentList(utils_1.mergeIntoAssignmentList(exports.mergedAssignmentList, memoList));
                    // Save assignments and quizzes to local storage
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_AssignmentList", exports.mergedAssignmentListNoMemo)];
                case 12:
                    // Save assignments and quizzes to local storage
                    _g.sent();
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_QuizList", mergedQuizList)];
                case 13:
                    _g.sent();
                    return [2 /*return*/, exports.mergedAssignmentList];
            }
        });
    });
}
exports.loadAndMergeAssignmentList = loadAndMergeAssignmentList;
/**
 * Load course site IDs
 */
function loadCourseIDList() {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    exports.courseIDList = network_1.getCourseIDList();
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_CourseInfo", exports.courseIDList)];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
function updateReadFlag() {
    return __awaiter(this, void 0, void 0, function () {
        var updatedAssignmentList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    updatedAssignmentList = utils_1.updateIsReadFlag(exports.mergedAssignmentListNoMemo);
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_AssignmentList", updatedAssignmentList)];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
function main() {
    return __awaiter(this, void 0, void 0, function () {
        var config;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!utils_1.isLoggedIn()) return [3 /*break*/, 8];
                    minisakai_1.createMiniSakaiBtn();
                    return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    return [4 /*yield*/, loadCourseIDList()];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, loadAndMergeAssignmentList(config, exports.courseIDList, utils_1.isUsingCache(config.fetchedTime.assignment, config.cacheInterval.assignment), utils_1.isUsingCache(config.fetchedTime.quiz, config.cacheInterval.quiz))];
                case 3:
                    exports.mergedAssignmentList = _a.sent();
                    return [4 /*yield*/, favorites_1.addFavoritedCourseSites(config.baseURL)];
                case 4:
                    _a.sent();
                    return [4 /*yield*/, minisakai_1.displayMiniSakai(exports.mergedAssignmentList, exports.courseIDList)];
                case 5:
                    _a.sent();
                    return [4 /*yield*/, minisakai_1.createFavoritesBarNotification(exports.courseIDList, exports.mergedAssignmentList)];
                case 6:
                    _a.sent();
                    return [4 /*yield*/, updateReadFlag()];
                case 7:
                    _a.sent();
                    _a.label = 8;
                case 8: return [2 /*return*/];
            }
        });
    });
}
main();


/***/ }),

/***/ "./src/dom.ts":
/*!********************!*\
  !*** ./src/dom.ts ***!
  \********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.appendChildAll = exports.cloneElem = exports.createElem = exports.addAttributes = exports.SettingsDom = exports.hamburger = exports.assignmentDiv = exports.miniSakai = void 0;
var eventListener_1 = __webpack_require__(/*! ./eventListener */ "./src/eventListener.ts");
/**
 * Create DOM elements
 */
function createElem(tag, dict, eventListener) {
    var elem = document.createElement(tag);
    addAttributes(elem, dict, eventListener);
    return elem;
}
exports.createElem = createElem;
/**
 * Clone DOM elements
 */
function cloneElem(elem, dict, eventListener) {
    var clone = elem.cloneNode(true);
    addAttributes(clone, dict, eventListener);
    return clone;
}
exports.cloneElem = cloneElem;
/**
 * Add attributes to DOM elements
 */
function addAttributes(elem, dict, eventListener) {
    for (var key in dict) {
        if (key === "style")
            elem[key].display = dict[key];
        else {
            // @ts-ignore
            elem[key] = dict[key];
        }
    }
    for (var key in eventListener) {
        elem.addEventListener(key, eventListener[key]);
    }
    return elem;
}
exports.addAttributes = addAttributes;
/**
 * Append all elements as child of 1st arg
 */
function appendChildAll(to, arr) {
    for (var obj in arr) {
        to.appendChild(arr[obj]);
    }
    return to;
}
exports.appendChildAll = appendChildAll;
exports.miniSakai = createElem("div", { id: "miniSakai" });
exports.miniSakai.classList.add("cs-minisakai", "cs-tab");
exports.assignmentDiv = createElem("div", { className: "cs-assignment-tab" });
exports.hamburger = createElem("div", { className: "cs-loading" }, { click: eventListener_1.toggleMiniSakai });
// eslint-disable-next-line @typescript-eslint/no-namespace
var SettingsDom;
(function (SettingsDom) {
    SettingsDom.mainDiv = createElem("div", { className: "cp-settings" });
    SettingsDom.div = createElem("div");
    SettingsDom.p = createElem("p", { className: "cp-settings-text" });
    SettingsDom.label = createElem("label");
    SettingsDom.toggleBtn = createElem("input", { type: "checkbox" });
    SettingsDom.resetBtn = createElem("input", { type: "button" });
    SettingsDom.stringBox = createElem("input", { type: "color", className: "cp-settings-inputbox" });
    SettingsDom.inputBox = createElem("input", { type: "number", className: "cp-settings-inputbox" });
    SettingsDom.span = createElem("span", { className: "cs-toggle-slider round" });
})(SettingsDom || (SettingsDom = {}));
exports.SettingsDom = SettingsDom;


/***/ }),

/***/ "./src/eventListener.ts":
/*!******************************!*\
  !*** ./src/eventListener.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.editFavoritesMessage = exports.deleteMemo = exports.updateSettings = exports.addMemo = exports.toggleFinishedFlag = exports.toggleMemoBox = exports.toggleSettingsTab = exports.toggleAssignmentTab = exports.toggleMiniSakai = void 0;
var dom_1 = __webpack_require__(/*! ./dom */ "./src/dom.ts");
var storage_1 = __webpack_require__(/*! ./storage */ "./src/storage.ts");
var model_1 = __webpack_require__(/*! ./model */ "./src/model.ts");
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
var content_script_1 = __webpack_require__(/*! ./content_script */ "./src/content_script.ts");
var settings_1 = __webpack_require__(/*! ./settings */ "./src/settings.ts");
var minisakai_1 = __webpack_require__(/*! ./minisakai */ "./src/minisakai.ts");
var toggle = false;
/**
 * Change visibility of miniSakai
 */
function toggleMiniSakai() {
    var _a;
    if (toggle) {
        // Hide miniSakai
        dom_1.miniSakai.style.width = "0px";
        (_a = document.getElementById("cs-cover")) === null || _a === void 0 ? void 0 : _a.remove();
    }
    else {
        // Display miniSakai
        dom_1.miniSakai.style.width = "300px";
        var cover = document.createElement("div");
        cover.id = "cs-cover";
        document.getElementsByTagName("body")[0].appendChild(cover);
        cover.onclick = toggleMiniSakai;
    }
    toggle = !toggle;
}
exports.toggleMiniSakai = toggleMiniSakai;
/**
 * Change visibility of Assignment tab
 */
function toggleAssignmentTab() {
    var assignmentTab = document.querySelector(".cs-assignment-tab");
    assignmentTab.style.display = "";
    var settingsTab = document.querySelector(".cs-settings-tab");
    settingsTab.style.display = "none";
    var addMemoButton = document.querySelector("#cs-add-memo-btn");
    addMemoButton.style.display = "";
    var assignmentFetchedTime = document.querySelector(".cs-assignment-time");
    assignmentFetchedTime.style.display = "";
    var quizFetchedTime = document.querySelector(".cs-quiz-time");
    quizFetchedTime.style.display = "";
}
exports.toggleAssignmentTab = toggleAssignmentTab;
/**
 * Change visibility of Settings tab
 */
function toggleSettingsTab() {
    var assignmentTab = document.querySelector(".cs-assignment-tab");
    assignmentTab.style.display = "none";
    var settingsTab = document.querySelector(".cs-settings-tab");
    settingsTab.style.display = "";
    var addMemoButton = document.querySelector("#cs-add-memo-btn");
    addMemoButton.style.display = "none";
    var assignmentFetchedTime = document.querySelector(".cs-assignment-time");
    assignmentFetchedTime.style.display = "none";
    var quizFetchedTime = document.querySelector(".cs-quiz-time");
    quizFetchedTime.style.display = "none";
}
exports.toggleSettingsTab = toggleSettingsTab;
/**
 * Change visibility of Memo box
 */
function toggleMemoBox() {
    var addMemoBox = document.querySelector(".addMemoBox");
    var toggleStatus = addMemoBox.style.display;
    if (toggleStatus === "") {
        addMemoBox.style.display = "none";
    }
    else {
        addMemoBox.style.display = "";
    }
}
exports.toggleMemoBox = toggleMemoBox;
/**
 * Toggle finished checkbox for assignment/quiz
 */
function toggleFinishedFlag(event) {
    return __awaiter(this, void 0, void 0, function () {
        var assignmentID, assignmentList, _a, _b, _c, updatedAssignmentList, _i, assignmentList_1, assignment, updatedAssignmentEntries, _d, _e, assignmentEntry, isFinished, isQuiz;
        return __generator(this, function (_f) {
            switch (_f.label) {
                case 0:
                    assignmentID = event.target.id;
                    if (!(assignmentID[0] === "m")) return [3 /*break*/, 2];
                    _a = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_MemoList")];
                case 1:
                    assignmentList = _a.apply(void 0, [_f.sent()]);
                    return [3 /*break*/, 6];
                case 2:
                    if (!(assignmentID[0] === "q")) return [3 /*break*/, 4];
                    _b = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_QuizList")];
                case 3:
                    assignmentList = _b.apply(void 0, [_f.sent()]);
                    return [3 /*break*/, 6];
                case 4:
                    _c = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_AssignmentList")];
                case 5:
                    assignmentList = _c.apply(void 0, [_f.sent()]);
                    _f.label = 6;
                case 6:
                    updatedAssignmentList = [];
                    for (_i = 0, assignmentList_1 = assignmentList; _i < assignmentList_1.length; _i++) {
                        assignment = assignmentList_1[_i];
                        updatedAssignmentEntries = [];
                        for (_d = 0, _e = assignment.assignmentEntries; _d < _e.length; _d++) {
                            assignmentEntry = _e[_d];
                            if (assignmentEntry.assignmentID === assignmentID) {
                                isFinished = assignmentEntry.isFinished;
                                isQuiz = false;
                                if (typeof assignmentEntry.isQuiz !== "undefined")
                                    isQuiz = assignmentEntry.isQuiz;
                                updatedAssignmentEntries.push(new model_1.AssignmentEntry(assignmentEntry.assignmentID, assignmentEntry.assignmentTitle, assignmentEntry.dueDateTimestamp, assignmentEntry.closeDateTimestamp, assignmentEntry.isMemo, !isFinished, isQuiz, assignmentEntry.assignmentDetail));
                            }
                            else {
                                updatedAssignmentEntries.push(assignmentEntry);
                            }
                        }
                        updatedAssignmentList.push(new model_1.Assignment(assignment.courseSiteInfo, updatedAssignmentEntries, assignment.isRead));
                    }
                    if (!(assignmentID[0] === "m")) return [3 /*break*/, 8];
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_MemoList", updatedAssignmentList)];
                case 7:
                    _f.sent();
                    return [3 /*break*/, 12];
                case 8:
                    if (!(assignmentID[0] === "q")) return [3 /*break*/, 10];
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_QuizList", updatedAssignmentList)];
                case 9:
                    _f.sent();
                    return [3 /*break*/, 12];
                case 10: return [4 /*yield*/, storage_1.saveToLocalStorage("CS_AssignmentList", updatedAssignmentList)];
                case 11:
                    _f.sent();
                    _f.label = 12;
                case 12: return [4 /*yield*/, redrawFavoritesBar(content_script_1.courseIDList, true)];
                case 13:
                    _f.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.toggleFinishedFlag = toggleFinishedFlag;
/**
 * Update Settings parameter
 */
function updateSettings(event, type) {
    return __awaiter(this, void 0, void 0, function () {
        var settingsID, settingsValue, config, CSsettings, colorList, _i, colorList_1, k, q;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    settingsID = event.target.id;
                    settingsValue = event.target.value;
                    return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    CSsettings = config.CSsettings;
                    // Type of Settings
                    switch (type) {
                        case "check":
                            settingsValue = event.target.checked;
                            break;
                        case "number":
                            settingsValue = parseInt(event.target.value);
                            break;
                        case "string":
                            break;
                    }
                    if (type === "reset") {
                        colorList = [
                            "topColorDanger", "topColorWarning", "topColorSuccess",
                            "miniColorDanger", "miniColorWarning", "miniColorSuccess"
                        ];
                        for (_i = 0, colorList_1 = colorList; _i < colorList_1.length; _i++) {
                            k = colorList_1[_i];
                            // @ts-ignore
                            CSsettings[k] = settings_1.DefaultSettings[k];
                            q = document.getElementById(k);
                            if (q) {
                                // @ts-ignore
                                q.value = settings_1.DefaultSettings[k];
                            }
                        }
                    }
                    else {
                        // @ts-ignore
                        CSsettings[settingsID] = settingsValue;
                    }
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_Settings", CSsettings)];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, redrawFavoritesBar(content_script_1.courseIDList, true)];
                case 3:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.updateSettings = updateSettings;
/**
 * Add Memo to miniSakai and save.
 */
function addMemo() {
    return __awaiter(this, void 0, void 0, function () {
        var selectedIdx, courseID, memoTitle, memoDueDateTimestamp, memoList, memoEntry, memo, idx, assignmentList, quizList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    selectedIdx = document.querySelector(".todoLecName").selectedIndex;
                    courseID = document.querySelector(".todoLecName").options[selectedIdx].id;
                    memoTitle = document.querySelector(".todoContent").value;
                    memoDueDateTimestamp = new Date(document.querySelector(".todoDue").value).getTime() / 1000;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_MemoList")];
                case 1:
                    memoList = _a.sent();
                    memoEntry = new model_1.AssignmentEntry(utils_1.genUniqueID("m"), memoTitle, memoDueDateTimestamp, memoDueDateTimestamp, true, false, false, "");
                    memo = new model_1.Assignment(new model_1.CourseSiteInfo(courseID, courseID), [memoEntry], true);
                    if (typeof memoList !== "undefined" && memoList.length > 0) {
                        memoList = utils_1.convertArrayToAssignment(memoList);
                        idx = memoList.findIndex(function (oldMemo) {
                            return oldMemo.courseSiteInfo.courseID === courseID;
                        });
                        if (idx !== -1) {
                            memoList[idx].assignmentEntries.push(memoEntry);
                        }
                        else {
                            memoList.push(memo);
                        }
                    }
                    else {
                        memoList = [memo];
                    }
                    storage_1.saveToLocalStorage("CS_MemoList", memoList);
                    assignmentList = utils_1.mergeIntoAssignmentList(content_script_1.mergedAssignmentListNoMemo, memoList);
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_QuizList")];
                case 2:
                    quizList = _a.sent();
                    redrawMiniSakai();
                    return [4 /*yield*/, minisakai_1.displayMiniSakai(utils_1.mergeIntoAssignmentList(assignmentList, quizList), content_script_1.courseIDList)];
                case 3:
                    _a.sent();
                    return [4 /*yield*/, redrawFavoritesBar(content_script_1.courseIDList, true)];
                case 4:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.addMemo = addMemo;
/**
 * Delete Memo from miniSakai and storage.
 */
function deleteMemo(event) {
    return __awaiter(this, void 0, void 0, function () {
        var memoID, memoList, _a, deletedMemoList, _i, memoList_1, memo, memoEntries, _b, _c, memoEntry, assignmentList, quizList;
        return __generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    memoID = event.target.id;
                    _a = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_MemoList")];
                case 1:
                    memoList = _a.apply(void 0, [_d.sent()]);
                    deletedMemoList = [];
                    for (_i = 0, memoList_1 = memoList; _i < memoList_1.length; _i++) {
                        memo = memoList_1[_i];
                        memoEntries = [];
                        for (_b = 0, _c = memo.assignmentEntries; _b < _c.length; _b++) {
                            memoEntry = _c[_b];
                            if (memoEntry.assignmentID !== memoID)
                                memoEntries.push(memoEntry);
                        }
                        deletedMemoList.push(new model_1.Assignment(memo.courseSiteInfo, memoEntries, memo.isRead));
                    }
                    storage_1.saveToLocalStorage("CS_MemoList", deletedMemoList);
                    assignmentList = utils_1.mergeIntoAssignmentList(content_script_1.mergedAssignmentListNoMemo, deletedMemoList);
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_QuizList")];
                case 2:
                    quizList = _d.sent();
                    redrawMiniSakai();
                    return [4 /*yield*/, minisakai_1.displayMiniSakai(utils_1.mergeIntoAssignmentList(assignmentList, quizList), content_script_1.courseIDList)];
                case 3:
                    _d.sent();
                    return [4 /*yield*/, redrawFavoritesBar(content_script_1.courseIDList, true)];
                case 4:
                    _d.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.deleteMemo = deleteMemo;
/**
 * Edit default message of favorites tab.
 */
function editFavoritesMessage() {
    return __awaiter(this, void 0, void 0, function () {
        var message, lectureTabs, lectureTabsCount, i;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: 
                // Wait 200ms until jQuery finished generating message.
                return [4 /*yield*/, new Promise(function (r) { return setTimeout(r, 200); })];
                case 1:
                    // Wait 200ms until jQuery finished generating message.
                    _a.sent();
                    try {
                        message = document.getElementsByClassName("favorites-max-marker")[0];
                        message.innerHTML = "<i class=\"fa fa-bell warning-icon\"></i>" + chrome.runtime.getManifest().name + "\u306B\u3088\u3063\u3066\u304A\u6C17\u306B\u5165\u308A\u767B\u9332\u3057\u305F<br>\u30B5\u30A4\u30C8\u304C\u5168\u3066\u30D0\u30FC\u306B\u8FFD\u52A0\u3055\u308C\u307E\u3057\u305F\u3002";
                        lectureTabs = document.getElementsByClassName("fav-sites-entry");
                        lectureTabsCount = lectureTabs.length;
                        for (i = 0; i < lectureTabsCount; i++) {
                            lectureTabs[i].classList.remove("site-favorite-is-past-max");
                        }
                    }
                    catch (e) {
                        console.log("could not edit message");
                    }
                    return [2 /*return*/];
            }
        });
    });
}
exports.editFavoritesMessage = editFavoritesMessage;
/**
 * Redraw favorites bar
 * @param {CourseSiteInfo[]} courseIDList
 * @param {boolean} useCache
 */
function redrawFavoritesBar(courseIDList, useCache) {
    return __awaiter(this, void 0, void 0, function () {
        var config, newAssignmentList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    minisakai_1.deleteFavoritesBarNotification();
                    return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    return [4 /*yield*/, content_script_1.loadAndMergeAssignmentList(config, courseIDList, useCache, useCache)];
                case 2:
                    newAssignmentList = _a.sent();
                    return [4 /*yield*/, minisakai_1.createFavoritesBarNotification(courseIDList, newAssignmentList)];
                case 3:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
/**
 * Redraw miniSakai
 */
function redrawMiniSakai() {
    while (dom_1.miniSakai.firstChild) {
        dom_1.miniSakai.removeChild(dom_1.miniSakai.firstChild);
    }
    while (dom_1.assignmentDiv.firstChild) {
        dom_1.assignmentDiv.removeChild(dom_1.assignmentDiv.firstChild);
    }
    dom_1.miniSakai.remove();
    dom_1.assignmentDiv.remove();
}


/***/ }),

/***/ "./src/favorites.ts":
/*!**************************!*\
  !*** ./src/favorites.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.addFavoritedCourseSites = void 0;
var eventListener_1 = __webpack_require__(/*! ./eventListener */ "./src/eventListener.ts");
/**
 * Limit maximum number of course sites
 * @type {int}
 */
var MAX_FAVORITES = 20;
function getSiteIdAndHrefSiteNameMap() {
    var sites = document.querySelectorAll(".fav-sites-entry");
    var map = new Map();
    sites.forEach(function (site) {
        var _a, _b, _c;
        var siteId = (_a = site.querySelector(".site-favorite-btn")) === null || _a === void 0 ? void 0 : _a.getAttribute("data-site-id");
        if (siteId == null)
            return;
        var href = ((_b = site.querySelector(".fav-title")) === null || _b === void 0 ? void 0 : _b.childNodes[1]).href;
        var title = ((_c = site.querySelector(".fav-title")) === null || _c === void 0 ? void 0 : _c.childNodes[1]).title;
        map.set(siteId, { href: href, title: title });
    });
    return map;
}
/**
 * Check if current site-id is given site-id
 * @param {string} siteId
 */
function isCurrentSite(siteId) {
    var currentSiteIdM = window.location.href.match(/https?:\/\/[^\/]+\/portal\/site\/([^\/]+)/);
    if (currentSiteIdM == null)
        return false;
    return currentSiteIdM[1] == siteId;
}
/**
 * Get hrefs of sites in favorite bar
 */
function getCurrentFavoritesSite() {
    var topnav = document.querySelector("#topnav");
    if (topnav == null)
        return new Array();
    var sites = topnav.querySelectorAll(".Mrphs-sitesNav__menuitem");
    var hrefs = [];
    for (var _i = 0, _a = Array.from(sites); _i < _a.length; _i++) {
        var site = _a[_i];
        var href = site.getElementsByClassName("link-container")[0].href;
        hrefs.push(href);
    }
    return hrefs;
}
/**
 * Add course sites to favorites bar (more than Sakai config)
 * @param {string} baseURL
 */
function addFavoritedCourseSites(baseURL) {
    var _a;
    var topnav = document.querySelector("#topnav");
    if (topnav == null)
        return new Promise(function (resolve, reject) { return resolve(); });
    var request = new XMLHttpRequest();
    request.open("GET", baseURL + "/portal/favorites/list");
    request.responseType = "json";
    (_a = document.querySelector(".organizeFavorites")) === null || _a === void 0 ? void 0 : _a.addEventListener("click", eventListener_1.editFavoritesMessage);
    return new Promise(function (resolve, reject) {
        request.addEventListener("load", function (e) {
            var res = request.response;
            if (res == null) {
                console.log("failed to fetch favorites list");
                reject();
            }
            var favorites = res.favoriteSiteIds;
            var sitesInfo = getSiteIdAndHrefSiteNameMap();
            var currentFavoriteSite = getCurrentFavoritesSite();
            var _loop_1 = function (favorite) {
                // skip if favorite is the current site
                if (isCurrentSite(favorite))
                    return "continue";
                var siteInfo = sitesInfo.get(favorite);
                if (siteInfo == undefined)
                    return "continue";
                var href = siteInfo.href;
                var title = siteInfo.title;
                // skip if the site is already shown
                if (currentFavoriteSite.find(function (c) { return c == href; }) != null)
                    return "continue";
                var li = document.createElement("li");
                li.classList.add("Mrphs-sitesNav__menuitem");
                var anchor = document.createElement("a");
                anchor.classList.add("link-container");
                anchor.href = href;
                anchor.title = title;
                var span = document.createElement("span");
                span.innerText = title;
                anchor.appendChild(span);
                li.appendChild(anchor);
                topnav.appendChild(li);
            };
            for (var _i = 0, _a = favorites.slice(0, MAX_FAVORITES); _i < _a.length; _i++) {
                var favorite = _a[_i];
                _loop_1(favorite);
            }
            resolve();
        });
        request.send();
    });
}
exports.addFavoritedCourseSites = addFavoritedCourseSites;


/***/ }),

/***/ "./src/minisakai.ts":
/*!**************************!*\
  !*** ./src/minisakai.ts ***!
  \**************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createFavoritesBarNotification = exports.deleteFavoritesBarNotification = exports.displayMiniSakai = exports.createMiniSakai = exports.createMiniSakaiBtn = exports.createMiniSakaiGeneralized = void 0;
var model_1 = __webpack_require__(/*! ./model */ "./src/model.ts");
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
var dom_1 = __webpack_require__(/*! ./dom */ "./src/dom.ts");
var eventListener_1 = __webpack_require__(/*! ./eventListener */ "./src/eventListener.ts");
// @ts-ignore
var mustache_1 = __importDefault(__webpack_require__(/*! mustache */ "./node_modules/mustache/mustache.js"));
var settings_1 = __webpack_require__(/*! ./settings */ "./src/settings.ts");
/**
 * Create a button to open miniSakai
 */
function createMiniSakaiBtn() {
    var topbar = document.getElementById("mastLogin");
    try {
        topbar === null || topbar === void 0 ? void 0 : topbar.appendChild(dom_1.hamburger);
    }
    catch (e) {
        console.log("could not launch miniSakai.");
    }
}
exports.createMiniSakaiBtn = createMiniSakaiBtn;
/**
 * Using template engine to generate miniSakai list.
 */
function createMiniSakaiGeneralized(root, assignmentList, courseSiteInfos, subset, insertionProcess) {
    return __awaiter(this, void 0, void 0, function () {
        var config, assignmentFetchedTimeString, quizFetchedTimeString, courseSiteList, courseIDMap, dangerElements, warningElements, successElements, otherElements, lateSubmitElements, sortElements, noAssignmentImg, assignmentCnt, _i, assignmentList_1, assignment, templateVars;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    assignmentFetchedTimeString = utils_1.formatTimestamp(config.fetchedTime.assignment);
                    quizFetchedTimeString = utils_1.formatTimestamp(config.fetchedTime.quiz);
                    courseSiteList = [];
                    courseIDMap = utils_1.createCourseIDMap(courseSiteInfos);
                    dangerElements = [];
                    warningElements = [];
                    successElements = [];
                    otherElements = [];
                    lateSubmitElements = [];
                    // iterate over courseSite
                    assignmentList.forEach(function (assignment) {
                        var courseName = courseIDMap.get(assignment.courseSiteInfo.courseID);
                        // iterate over assignment entries
                        assignment.assignmentEntries.forEach(function (assignmentEntry) {
                            var daysUntilDue = utils_1.getDaysUntil(utils_1.nowTime, assignmentEntry.getDueDateTimestamp * 1000);
                            var displayAssignmentEntry = new model_1.DisplayAssignmentEntry(assignment.courseSiteInfo.courseID, assignmentEntry.assignmentID, assignmentEntry.assignmentTitle, assignmentEntry.dueDateTimestamp, assignmentEntry.closeDateTimestamp, assignmentEntry.isFinished, assignmentEntry.isQuiz, assignmentEntry.isMemo);
                            var displayAssignment = new model_1.DisplayAssignment([displayAssignmentEntry], courseName, assignment.getTopSite());
                            var appendElement = function (courseName, displayAssignments) {
                                var courseNameMap = displayAssignments.map(function (e) { return e.courseName; });
                                if (courseNameMap.includes(courseName)) {
                                    var idx = courseNameMap.indexOf(courseName);
                                    displayAssignments[idx].assignmentEntries.push(displayAssignmentEntry);
                                    displayAssignments[idx].assignmentEntries.sort(function (a, b) {
                                        return a.getDueDateTimestamp - b.getDueDateTimestamp;
                                    });
                                }
                                else {
                                    displayAssignments.push(displayAssignment);
                                }
                            };
                            // Append elements according to due date category
                            switch (daysUntilDue) {
                                case "due24h":
                                    appendElement(courseName, dangerElements);
                                    break;
                                case "due5d":
                                    appendElement(courseName, warningElements);
                                    break;
                                case "due14d":
                                    appendElement(courseName, successElements);
                                    break;
                                case "dueOver14d":
                                    appendElement(courseName, otherElements);
                                    break;
                                case "duePassed":
                                    // eslint-disable-next-line no-case-declarations
                                    var showLateSubmitAssignment = config.CSsettings ? config.CSsettings.getDisplayLateSubmitAssignment : false;
                                    if (showLateSubmitAssignment && utils_1.getDaysUntil(utils_1.nowTime, assignmentEntry.getCloseDateTimestamp * 1000) !== "duePassed") {
                                        appendElement(courseName, lateSubmitElements);
                                    }
                                    break;
                            }
                        });
                        courseSiteList.push(new model_1.CourseSiteInfo(assignment.courseSiteInfo.courseID, courseName));
                    });
                    sortElements = function (elements, isLateSubmission) {
                        if (isLateSubmission === void 0) { isLateSubmission = false; }
                        elements.sort(function (a, b) {
                            var timestamp;
                            if (isLateSubmission) {
                                timestamp = function (o) { return Math.min.apply(Math, o.assignmentEntries.map(function (p) { return p.getCloseDateTimestamp; })); };
                            }
                            else {
                                timestamp = function (o) { return Math.min.apply(Math, o.assignmentEntries.map(function (p) { return p.getDueDateTimestamp; })); };
                            }
                            return timestamp(a) - timestamp(b);
                        });
                        return elements;
                    };
                    noAssignmentImg = null;
                    assignmentCnt = 0;
                    if (assignmentList.length !== 0) {
                        for (_i = 0, assignmentList_1 = assignmentList; _i < assignmentList_1.length; _i++) {
                            assignment = assignmentList_1[_i];
                            assignmentCnt += assignment.assignmentEntries.length;
                        }
                    }
                    if (assignmentList.length === 0 || assignmentCnt === 0) {
                        noAssignmentImg = {
                            img: chrome.runtime.getURL("img/noAssignment.png"),
                        };
                    }
                    templateVars = {
                        fetchedTime: {
                            assignment: assignmentFetchedTimeString,
                            quiz: quizFetchedTimeString,
                        },
                        miniSakaiLogo: chrome.runtime.getURL("img/logo.png"),
                        VERSION: config.version,
                        subset: subset,
                        noAssignment: noAssignmentImg,
                        elements: {
                            danger: sortElements(dangerElements),
                            warning: sortElements(warningElements),
                            success: sortElements(successElements),
                            other: sortElements(otherElements),
                            lateSubmit: sortElements(lateSubmitElements, true),
                        },
                        display: {
                            danger: dangerElements.length > 0,
                            warning: warningElements.length > 0,
                            success: successElements.length > 0,
                            other: otherElements.length > 0,
                            lateSubmit: lateSubmitElements.length > 0,
                        },
                        titles: {
                            assignmentTab: chrome.i18n.getMessage("tab_assignments"),
                            settingsTab: chrome.i18n.getMessage("tab_settings"),
                            assignmentFetchedTime: chrome.i18n.getMessage("assignment_acquisition_date"),
                            quizFetchedTime: chrome.i18n.getMessage("testquiz_acquisition_date"),
                            due24h: chrome.i18n.getMessage("due24h"),
                            due5d: chrome.i18n.getMessage("due5d"),
                            due14d: chrome.i18n.getMessage("due14d"),
                            dueOver14d: chrome.i18n.getMessage("dueOver14d"),
                            duePassed: chrome.i18n.getMessage("duePassed"),
                            noAssignment: chrome.i18n.getMessage("no_available_assignments"),
                        },
                        todoBox: {
                            courseName: chrome.i18n.getMessage("todo_box_course_name"),
                            memoLabel: chrome.i18n.getMessage("todo_box_memo"),
                            dueDate: chrome.i18n.getMessage("todo_box_due_date"),
                            addBtnLabel: chrome.i18n.getMessage("todo_box_add"),
                            courseSiteList: courseSiteList,
                        },
                        badge: {
                            memo: chrome.i18n.getMessage("memo"),
                            quiz: chrome.i18n.getMessage("quiz"),
                        },
                    };
                    // Load mustache
                    fetch(chrome.runtime.getURL("views/minisakai.mustache"))
                        .then(function (res) { return res.text(); })
                        .then(function (template) {
                        var rendered = mustache_1.default.render(template, templateVars);
                        insertionProcess(rendered);
                        registerEventHandlers(root);
                        if (!subset)
                            createSettingsTab(root);
                        initState(root);
                    });
                    return [2 /*return*/];
            }
        });
    });
}
exports.createMiniSakaiGeneralized = createMiniSakaiGeneralized;
/**
 * Insert miniSakai into Sakai.
 */
function createMiniSakai(assignmentList, courseSiteInfos) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, createMiniSakaiGeneralized(dom_1.miniSakai, assignmentList, courseSiteInfos, false, function (rendered) {
                        dom_1.miniSakai.innerHTML = rendered;
                        var parent = document.getElementById("pageBody");
                        var ref = document.getElementById("toolMenuWrap");
                        parent === null || parent === void 0 ? void 0 : parent.insertBefore(dom_1.miniSakai, ref);
                    })];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.createMiniSakai = createMiniSakai;
/**
 * Initialize Settings tab.
 */
function createSettingsTab(root) {
    return __awaiter(this, void 0, void 0, function () {
        var config;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    createSettingItem(root, chrome.i18n.getMessage('settings_color_checked_item'), config.CSsettings.getDisplayCheckedAssignment, "displayCheckedAssignment");
                    createSettingItem(root, chrome.i18n.getMessage('settings_display_late_submit_assignment'), config.CSsettings.getDisplayLateSubmitAssignment, "displayLateSubmitAssignment");
                    createSettingItem(root, chrome.i18n.getMessage('settings_assignment_cache'), config.CSsettings.getAssignmentCacheInterval, "assignmentCacheInterval");
                    createSettingItem(root, chrome.i18n.getMessage('settings_quizzes_cache'), config.CSsettings.getQuizCacheInterval, "quizCacheInterval");
                    createSettingItem(root, chrome.i18n.getMessage('settings_colors_hour', ['Tab Bar', '24']), config.CSsettings.getTopColorDanger, "topColorDanger");
                    createSettingItem(root, chrome.i18n.getMessage('settings_colors_day', ['Tab Bar', '5']), config.CSsettings.getTopColorWarning, "topColorWarning");
                    createSettingItem(root, chrome.i18n.getMessage('settings_colors_day', ['Tab Bar', '14']), config.CSsettings.getTopColorSuccess, "topColorSuccess");
                    createSettingItem(root, chrome.i18n.getMessage('settings_colors_hour', ['miniPandA', '24']), config.CSsettings.getMiniColorDanger, "miniColorDanger");
                    createSettingItem(root, chrome.i18n.getMessage('settings_colors_day', ['miniPandA', '5']), config.CSsettings.getMiniColorWarning, "miniColorWarning");
                    createSettingItem(root, chrome.i18n.getMessage('settings_colors_day', ['miniPandA', '14']), config.CSsettings.getMiniColorSuccess, "miniColorSuccess");
                    createSettingItem(root, chrome.i18n.getMessage("settings_reset_colors"), "reset", "reset");
                    // @ts-ignore
                    root.querySelector(".cs-settings-tab").style.display = "none";
                    return [2 /*return*/];
            }
        });
    });
}
/**
 * Create Settings tab item.
 */
function createSettingItem(root, itemDescription, value, id, display) {
    if (display === void 0) { display = true; }
    var settingsDiv = root.querySelector(".cs-settings-tab");
    if (settingsDiv == null) {
        console.log(".cs-settings-tab not found");
        return;
    }
    var mainDiv = dom_1.SettingsDom.mainDiv.cloneNode(true);
    var label = dom_1.SettingsDom.label.cloneNode(true);
    var p = dom_1.SettingsDom.p.cloneNode(true);
    p.innerText = itemDescription;
    if (!display)
        mainDiv.style.display = "none";
    var settingItem;
    var span = dom_1.SettingsDom.span.cloneNode(true);
    switch (typeof value) {
        case "boolean":
            label.classList.add("cs-toggle-btn");
            settingItem = dom_1.cloneElem(dom_1.SettingsDom.toggleBtn, { checked: value, id: id }, { "change": function (res) { eventListener_1.updateSettings(res, "check"); } });
            break;
        case "number":
            settingItem = dom_1.cloneElem(dom_1.SettingsDom.inputBox, { value: value, id: id }, { "change": function (res) { eventListener_1.updateSettings(res, "number"); } });
            break;
        case "string":
            if (id === "reset") {
                settingItem = dom_1.cloneElem(dom_1.SettingsDom.resetBtn, { value: value, id: id }, { "click": function (res) { eventListener_1.updateSettings(res, "reset"); } });
            }
            else {
                settingItem = dom_1.cloneElem(dom_1.SettingsDom.stringBox, { value: value, id: id }, { "change": function (res) { eventListener_1.updateSettings(res, "string"); } });
            }
            break;
        default:
            break;
    }
    if (typeof value === "boolean")
        dom_1.appendChildAll(label, [settingItem, span]);
    else
        dom_1.appendChildAll(label, [settingItem]);
    dom_1.appendChildAll(mainDiv, [p, label]);
    settingsDiv.appendChild(mainDiv);
}
/**
 * Add event listener to each Settings item
 */
function registerEventHandlers(root) {
    var _a, _b, _c, _d, _e;
    (_a = root.querySelector("#assignmentTab")) === null || _a === void 0 ? void 0 : _a.addEventListener("click", function () { return eventListener_1.toggleAssignmentTab(); });
    (_b = root.querySelector("#settingsTab")) === null || _b === void 0 ? void 0 : _b.addEventListener("click", function () { return eventListener_1.toggleSettingsTab(); });
    root.querySelectorAll(".cs-checkbox").forEach(function (c) { return c.addEventListener("change", function (e) { return eventListener_1.toggleFinishedFlag(e); }); });
    (_c = root.querySelector("#close_btn")) === null || _c === void 0 ? void 0 : _c.addEventListener("click", function () { return eventListener_1.toggleMiniSakai(); });
    (_d = root.querySelector("#cs-add-memo-btn")) === null || _d === void 0 ? void 0 : _d.addEventListener("click", function () { return eventListener_1.toggleMemoBox(); });
    (_e = root.querySelector("#todo-add")) === null || _e === void 0 ? void 0 : _e.addEventListener("click", function () { return eventListener_1.addMemo(); });
    root.querySelectorAll(".cs-del-memo-btn").forEach(function (b) { return b.addEventListener("click", function (e) { return eventListener_1.deleteMemo(e); }); });
}
/**
 * Initialize states
 */
function initState(root) {
    // @ts-ignore
    root.querySelector("#assignmentTab").checked = true;
    // @ts-ignore
    root.querySelector(".todoDue").value = new Date(new Date().toISOString().substr(0, 16) + "-10:00")
        .toISOString()
        .substr(0, 16);
}
/**
 * Display miniSakai
 */
function displayMiniSakai(mergedAssignmentList, courseSiteInfos) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, createMiniSakai(mergedAssignmentList, courseSiteInfos)];
                case 1:
                    _a.sent();
                    utils_1.miniSakaiReady();
                    return [2 /*return*/];
            }
        });
    });
}
exports.displayMiniSakai = displayMiniSakai;
/**
 * Add notification badge for new Assignment/Quiz
 */
function createFavoritesBarNotification(courseSiteInfos, assignmentList) {
    return __awaiter(this, void 0, void 0, function () {
        var config, defaultTab, defaultTabCount, _i, courseSiteInfos_1, courseSiteInfo, _loop_1, j;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    defaultTab = document.querySelectorAll(".Mrphs-sitesNav__menuitem");
                    defaultTabCount = Object.keys(defaultTab).length;
                    for (_i = 0, courseSiteInfos_1 = courseSiteInfos; _i < courseSiteInfos_1.length; _i++) {
                        courseSiteInfo = courseSiteInfos_1[_i];
                        _loop_1 = function (j) {
                            // @ts-ignore
                            var courseID = defaultTab[j].getElementsByClassName("link-container")[0].href.match("(https?://[^/]+)/portal/site-?[a-z]*/([^/]+)")[2];
                            var q = assignmentList.findIndex(function (assignment) {
                                return assignment.courseSiteInfo.courseID === courseID;
                            });
                            if (q !== -1) {
                                var closestTime = (config.CSsettings.displayCheckedAssignment) ? assignmentList[q].closestDueDateTimestamp : assignmentList[q].closestDueDateTimestampExcludeFinished;
                                if (!assignmentList[q].isRead && closestTime !== -1) {
                                    defaultTab[j].classList.add("cs-notification-badge");
                                }
                                var daysUntilDue = utils_1.getDaysUntil(utils_1.nowTime, closestTime * 1000);
                                var aTagCount = defaultTab[j].getElementsByTagName("a").length;
                                switch (daysUntilDue) {
                                    case "due24h":
                                        defaultTab[j].classList.add("cs-tab-danger");
                                        for (var i = 0; i < aTagCount; i++) {
                                            defaultTab[j].getElementsByTagName("a")[i].classList.add("cs-tab-danger");
                                        }
                                        break;
                                    case "due5d":
                                        defaultTab[j].classList.add("cs-tab-warning");
                                        for (var i = 0; i < aTagCount; i++) {
                                            defaultTab[j].getElementsByTagName("a")[i].classList.add("cs-tab-warning");
                                        }
                                        break;
                                    case "due14d":
                                        defaultTab[j].classList.add("cs-tab-success");
                                        for (var i = 0; i < aTagCount; i++) {
                                            defaultTab[j].getElementsByTagName("a")[i].classList.add("cs-tab-success");
                                        }
                                        break;
                                    case "dueOver14d":
                                        defaultTab[j].classList.add("cs-tab-other");
                                        for (var i = 0; i < aTagCount; i++) {
                                            defaultTab[j].getElementsByTagName("a")[i].classList.add("cs-tab-other");
                                        }
                                        break;
                                }
                            }
                        };
                        for (j = 2; j < defaultTabCount; j++) {
                            _loop_1(j);
                        }
                    }
                    return [4 /*yield*/, overrideCSSColor()];
                case 2:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.createFavoritesBarNotification = createFavoritesBarNotification;
/**
 * Delete notification badge for new Assignment/Quiz
 */
function deleteFavoritesBarNotification() {
    var classlist = ["cs-notification-badge", "cs-tab-danger", "cs-tab-warning", "cs-tab-success"];
    for (var _i = 0, classlist_1 = classlist; _i < classlist_1.length; _i++) {
        var c = classlist_1[_i];
        var q = document.querySelectorAll("." + c);
        // @ts-ignore
        for (var _a = 0, q_1 = q; _a < q_1.length; _a++) {
            var _1 = q_1[_a];
            _1.classList.remove("" + c);
            _1.style = "";
        }
    }
}
exports.deleteFavoritesBarNotification = deleteFavoritesBarNotification;
/**
 * Override CSS of favorites bar and miniSakai.
 */
function overrideCSSColor() {
    return __awaiter(this, void 0, void 0, function () {
        var config, overwriteborder, overwritebackground;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    overwriteborder = function (className, color) {
                        var element = document.getElementsByClassName(className);
                        for (var i = 0; i < element.length; i++) {
                            var elem = element[i];
                            var attr = "solid 2px " + color;
                            elem.style["border-top"] = attr;
                            elem.style["border-left"] = attr;
                            elem.style["border-bottom"] = attr;
                            elem.style["border-right"] = attr;
                        }
                    };
                    overwritebackground = function (className, color) {
                        var element = document.getElementsByClassName(className);
                        for (var i = 0; i < element.length; i++) {
                            var elem = element[i];
                            elem.setAttribute("style", "background:" + color + "!important");
                        }
                    };
                    // Overwrite colors
                    overwritebackground("cs-course-danger", config.CSsettings.getMiniColorDanger);
                    overwritebackground("cs-course-warning", config.CSsettings.getMiniColorWarning);
                    overwritebackground("cs-course-success", config.CSsettings.getMiniColorSuccess);
                    overwritebackground("cs-tab-danger", config.CSsettings.getTopColorDanger);
                    overwritebackground("cs-tab-warning", config.CSsettings.getTopColorWarning);
                    overwritebackground("cs-tab-success", config.CSsettings.getTopColorSuccess);
                    overwriteborder("cs-assignment-danger", config.CSsettings.getMiniColorDanger);
                    overwriteborder("cs-assignment-warning", config.CSsettings.getMiniColorWarning);
                    overwriteborder("cs-assignment-success", config.CSsettings.getMiniColorSuccess);
                    overwriteborder("cs-tab-danger", config.CSsettings.getTopColorDanger);
                    overwriteborder("cs-tab-warning", config.CSsettings.getTopColorWarning);
                    overwriteborder("cs-tab-success", config.CSsettings.getTopColorSuccess);
                    return [2 /*return*/];
            }
        });
    });
}


/***/ }),

/***/ "./src/model.ts":
/*!**********************!*\
  !*** ./src/model.ts ***!
  \**********************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DisplayAssignment = exports.DisplayAssignmentEntry = exports.CourseSiteInfo = exports.Assignment = exports.AssignmentEntry = void 0;
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
var MAX_TIMESTAMP = 99999999999999;
var AssignmentEntry = /** @class */ (function () {
    function AssignmentEntry(assignmentID, assignmentTitle, dueDateTimestamp, closeDateTimestamp, isMemo, isFinished, isQuiz, assignmentDetail, assignmentPage) {
        this.assignmentID = assignmentID;
        this.assignmentTitle = assignmentTitle;
        this.assignmentDetail = assignmentDetail;
        this.dueDateTimestamp = dueDateTimestamp;
        this.closeDateTimestamp = closeDateTimestamp;
        this.isMemo = isMemo;
        this.isFinished = isFinished;
        this.isQuiz = isQuiz;
        this.assignmentPage = assignmentPage;
    }
    Object.defineProperty(AssignmentEntry.prototype, "getDueDateTimestamp", {
        get: function () {
            return this.dueDateTimestamp ? this.dueDateTimestamp : MAX_TIMESTAMP;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(AssignmentEntry.prototype, "getCloseDateTimestamp", {
        get: function () {
            return this.closeDateTimestamp ? this.closeDateTimestamp : MAX_TIMESTAMP;
        },
        enumerable: false,
        configurable: true
    });
    return AssignmentEntry;
}());
exports.AssignmentEntry = AssignmentEntry;
var Assignment = /** @class */ (function () {
    function Assignment(courseSiteInfo, assignmentEntries, isRead) {
        this.courseSiteInfo = courseSiteInfo;
        this.assignmentEntries = assignmentEntries;
        this.isRead = isRead;
    }
    Object.defineProperty(Assignment.prototype, "closestDueDateTimestamp", {
        get: function () {
            if (this.assignmentEntries.length == 0)
                return -1;
            var min = MAX_TIMESTAMP;
            for (var _i = 0, _a = this.assignmentEntries; _i < _a.length; _i++) {
                var entry = _a[_i];
                if (min > entry.getDueDateTimestamp && entry.getDueDateTimestamp * 1000 >= utils_1.nowTime) {
                    min = entry.getDueDateTimestamp;
                }
            }
            if (min === MAX_TIMESTAMP)
                min = -1;
            return min;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Assignment.prototype, "closestDueDateTimestampExcludeFinished", {
        // 完了済み以外からclosestTimeを取得する
        get: function () {
            if (this.assignmentEntries.length == 0)
                return -1;
            var min = MAX_TIMESTAMP;
            var excludeCount = 0;
            for (var _i = 0, _a = this.assignmentEntries; _i < _a.length; _i++) {
                var entry = _a[_i];
                if (entry.isFinished) {
                    excludeCount++;
                    continue;
                }
                if (min > entry.getDueDateTimestamp && entry.getDueDateTimestamp * 1000 >= utils_1.nowTime) {
                    min = entry.getDueDateTimestamp;
                }
            }
            if (excludeCount === this.assignmentEntries.length)
                min = -1;
            if (min === MAX_TIMESTAMP)
                min = -1;
            return min;
        },
        enumerable: false,
        configurable: true
    });
    Assignment.prototype.getTopSite = function () {
        for (var _i = 0, _a = this.assignmentEntries; _i < _a.length; _i++) {
            var entry = _a[_i];
            if (entry.assignmentPage != null)
                return entry.assignmentPage;
        }
        return "";
    };
    return Assignment;
}());
exports.Assignment = Assignment;
var CourseSiteInfo = /** @class */ (function () {
    function CourseSiteInfo(courseID, courseName) {
        this.courseID = courseID;
        this.courseName = courseName;
    }
    return CourseSiteInfo;
}());
exports.CourseSiteInfo = CourseSiteInfo;
var DisplayAssignmentEntry = /** @class */ (function (_super) {
    __extends(DisplayAssignmentEntry, _super);
    function DisplayAssignmentEntry(courseID, assignmentID, assignmentTitle, dueDateTimestamp, closeDateTimestamp, isFinished, isQuiz, isMemo) {
        var _this = _super.call(this, assignmentID, assignmentTitle, dueDateTimestamp, closeDateTimestamp, isMemo, isFinished, isQuiz) || this;
        _this.courseID = courseID;
        return _this;
    }
    DisplayAssignmentEntry.getTimeRemain = function (remainTimestamp) {
        var day = Math.floor(remainTimestamp / (3600 * 24));
        var hours = Math.floor((remainTimestamp - day * 3600 * 24) / 3600);
        var minutes = Math.floor((remainTimestamp - (day * 3600 * 24 + hours * 3600)) / 60);
        return [day.toString(), hours.toString(), minutes.toString()];
    };
    DisplayAssignmentEntry.createTimeString = function (timestamp) {
        if (!timestamp)
            return chrome.i18n.getMessage("due_not_set");
        var timeRemain = DisplayAssignmentEntry.getTimeRemain((timestamp * 1000 - utils_1.nowTime) / 1000);
        return chrome.i18n.getMessage("remain_time", [timeRemain[0], timeRemain[1], timeRemain[2]]);
    };
    DisplayAssignmentEntry.createDateString = function (timestamp) {
        if (!timestamp)
            return "----/--/--";
        var date = new Date(timestamp * 1000);
        return date.toLocaleDateString() + " " + date.getHours() + ":" + ("00" + date.getMinutes()).slice(-2);
    };
    Object.defineProperty(DisplayAssignmentEntry.prototype, "remainTimeString", {
        get: function () {
            return DisplayAssignmentEntry.createTimeString(this.dueDateTimestamp);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(DisplayAssignmentEntry.prototype, "remainCloseTimeString", {
        get: function () {
            return DisplayAssignmentEntry.createTimeString(this.closeDateTimestamp);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(DisplayAssignmentEntry.prototype, "dueDateString", {
        get: function () {
            return DisplayAssignmentEntry.createDateString(this.dueDateTimestamp);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(DisplayAssignmentEntry.prototype, "dueCloseDateString", {
        get: function () {
            return DisplayAssignmentEntry.createDateString(this.closeDateTimestamp);
        },
        enumerable: false,
        configurable: true
    });
    return DisplayAssignmentEntry;
}(AssignmentEntry));
exports.DisplayAssignmentEntry = DisplayAssignmentEntry;
var DisplayAssignment = /** @class */ (function () {
    function DisplayAssignment(assignmentEntries, courseName, coursePage) {
        this.assignmentEntries = assignmentEntries;
        this.courseName = courseName;
        this.coursePage = coursePage;
    }
    return DisplayAssignment;
}());
exports.DisplayAssignment = DisplayAssignment;


/***/ }),

/***/ "./src/network.ts":
/*!************************!*\
  !*** ./src/network.ts ***!
  \************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getQuizFromCourseID = exports.getAssignmentByCourseID = exports.getCourseIDList = exports.getBaseURL = void 0;
var model_1 = __webpack_require__(/*! ./model */ "./src/model.ts");
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
/**
 * Get base URL of Sakai.
 */
function getBaseURL() {
    var baseURL = "";
    var match = location.href.match("(https?://[^/]+)/portal");
    if (match) {
        baseURL = match[1];
    }
    return baseURL;
}
exports.getBaseURL = getBaseURL;
/**
 * Fetch course site IDs.
 */
function getCourseIDList() {
    var elementCollection = document.getElementsByClassName("fav-sites-entry");
    var elements = Array.prototype.slice.call(elementCollection);
    var result = [];
    for (var _i = 0, elements_1 = elements; _i < elements_1.length; _i++) {
        var elem = elements_1[_i];
        var lectureInfo = new model_1.CourseSiteInfo("", "");
        var lecture = elem.getElementsByTagName("div")[0].getElementsByTagName("a")[0];
        var m = lecture.href.match("(https?://[^/]+)/portal/site-?[a-z]*/([^/]+)");
        if (m && m[2][0] !== "~") {
            lectureInfo.courseID = m[2];
            lectureInfo.courseName = lecture.title;
            result.push(lectureInfo);
        }
    }
    return result;
}
exports.getCourseIDList = getCourseIDList;
/**
 * Fetch assignments from Sakai REST API.
 * @param {string} baseURL
 * @param {string} courseID
 */
function getAssignmentByCourseID(baseURL, courseID) {
    var _this = this;
    var queryURL = baseURL + "/direct/assignment/site/" + courseID + ".json";
    return new Promise(function (resolve, reject) {
        fetch(queryURL, { cache: "no-cache" })
            .then(function (response) { return __awaiter(_this, void 0, void 0, function () {
            var res, courseSiteInfo, assignmentEntries;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!response.ok) return [3 /*break*/, 2];
                        return [4 /*yield*/, response.json()];
                    case 1:
                        res = _a.sent();
                        courseSiteInfo = new model_1.CourseSiteInfo(courseID, courseID);
                        assignmentEntries = convJsonToAssignmentEntries(res, baseURL, courseID);
                        resolve(new model_1.Assignment(courseSiteInfo, assignmentEntries, false));
                        return [3 /*break*/, 3];
                    case 2:
                        reject("Request failed: " + response.status);
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        }); })
            .catch(function (err) { return console.error(err); }); // Error: Request failed: 404
    });
}
exports.getAssignmentByCourseID = getAssignmentByCourseID;
/**
 * Fetch quizzes from Sakai REST API.
 * @param {string} baseURL
 * @param {string} courseID
 */
function getQuizFromCourseID(baseURL, courseID) {
    var _this = this;
    var queryURL = baseURL + "/direct/sam_pub/context/" + courseID + ".json";
    return new Promise(function (resolve, reject) {
        fetch(queryURL, { cache: "no-cache" })
            .then(function (response) { return __awaiter(_this, void 0, void 0, function () {
            var res, courseSiteInfo, assignmentEntries;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!response.ok) return [3 /*break*/, 2];
                        return [4 /*yield*/, response.json()];
                    case 1:
                        res = _a.sent();
                        courseSiteInfo = new model_1.CourseSiteInfo(courseID, courseID);
                        assignmentEntries = convJsonToQuizEntries(res, baseURL, courseID);
                        resolve(new model_1.Assignment(courseSiteInfo, assignmentEntries, false));
                        return [3 /*break*/, 3];
                    case 2:
                        reject("Request failed: " + response.status);
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        }); })
            .catch(function (err) { return console.error(err); }); // Error: Request failed: 404
    });
}
exports.getQuizFromCourseID = getQuizFromCourseID;
/**
 * Convert json response to AssignmentEntries.
 * @param data
 * @param baseURL
 * @param siteID
 */
function convJsonToAssignmentEntries(data, baseURL, siteID) {
    var assignment_collection = data.assignment_collection;
    return assignment_collection
        .filter(function (json) { return json.closeTime.epochSecond * 1000 >= utils_1.nowTime; })
        .map(function (json) {
        var assignmentID = json.id;
        var assignmentTitle = json.title;
        var assignmentDetail = json.instructions;
        var dueDateTimestamp = json.dueTime.epochSecond ? json.dueTime.epochSecond : null;
        var closeDateTimestamp = json.closeTime.epochSecond ? json.closeTime.epochSecond : null;
        var entry = new model_1.AssignmentEntry(assignmentID, assignmentTitle, dueDateTimestamp, closeDateTimestamp, false, false, false, assignmentDetail);
        entry.assignmentPage = baseURL + "/portal/site/" + siteID;
        return entry;
    });
}
/**
 * Convert json response to QuizEntries.
 * @param data
 * @param baseURL
 * @param siteID
 */
function convJsonToQuizEntries(data, baseURL, siteID) {
    return data.sam_pub_collection
        .filter(function (json) { return json.startDate < utils_1.nowTime && (json.dueDate >= utils_1.nowTime || json.dueDate == null); })
        .map(function (json) {
        var quizID = "q" + json.publishedAssessmentId;
        var quizTitle = json.title;
        var quizDetail = "";
        var quizDueEpoch = json.dueDate ? json.dueDate / 1000 : null;
        var entry = new model_1.AssignmentEntry(quizID, quizTitle, quizDueEpoch, quizDueEpoch, false, false, true, quizDetail);
        entry.assignmentPage = baseURL + "/portal/site/" + siteID;
        return entry;
    });
}


/***/ }),

/***/ "./src/settings.ts":
/*!*************************!*\
  !*** ./src/settings.ts ***!
  \*************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.loadConfigs = exports.loadSettings = exports.DefaultSettings = exports.Settings = void 0;
var storage_1 = __webpack_require__(/*! ./storage */ "./src/storage.ts");
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
var network_1 = __webpack_require__(/*! ./network */ "./src/network.ts");
var Settings = /** @class */ (function () {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    function Settings() {
    }
    Object.defineProperty(Settings.prototype, "getAssignmentCacheInterval", {
        get: function () {
            return this.assignmentCacheInterval ? this.assignmentCacheInterval : DefaultSettings.assignmentCacheInterval;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getQuizCacheInterval", {
        get: function () {
            return this.quizCacheInterval ? this.quizCacheInterval : DefaultSettings.quizCacheInterval;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getDisplayCheckedAssignment", {
        get: function () {
            return this.displayCheckedAssignment !== undefined
                ? this.displayCheckedAssignment
                : DefaultSettings.displayCheckedAssignment;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getDisplayLateSubmitAssignment", {
        get: function () {
            return this.displayLateSubmitAssignment !== undefined
                ? this.displayLateSubmitAssignment
                : DefaultSettings.displayLateSubmitAssignment;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getTopColorDanger", {
        get: function () {
            return this.topColorDanger ? this.topColorDanger : DefaultSettings.topColorDanger;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getTopColorWarning", {
        get: function () {
            return this.topColorWarning ? this.topColorWarning : DefaultSettings.topColorWarning;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getTopColorSuccess", {
        get: function () {
            return this.topColorSuccess ? this.topColorSuccess : DefaultSettings.topColorSuccess;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getMiniColorDanger", {
        get: function () {
            return this.miniColorDanger ? this.miniColorDanger : DefaultSettings.miniColorDanger;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getMiniColorWarning", {
        get: function () {
            return this.miniColorWarning ? this.miniColorWarning : DefaultSettings.miniColorWarning;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getMiniColorSuccess", {
        get: function () {
            return this.miniColorSuccess ? this.miniColorSuccess : DefaultSettings.miniColorSuccess;
        },
        enumerable: false,
        configurable: true
    });
    return Settings;
}());
exports.Settings = Settings;
var DefaultSettings = /** @class */ (function (_super) {
    __extends(DefaultSettings, _super);
    function DefaultSettings() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    DefaultSettings.assignmentCacheInterval = 120;
    DefaultSettings.quizCacheInterval = 600;
    DefaultSettings.displayCheckedAssignment = true;
    DefaultSettings.displayLateSubmitAssignment = false;
    DefaultSettings.topColorDanger = "#f78989";
    DefaultSettings.topColorWarning = "#fdd783";
    DefaultSettings.topColorSuccess = "#8bd48d";
    DefaultSettings.miniColorDanger = "#e85555";
    DefaultSettings.miniColorWarning = "#d7aa57";
    DefaultSettings.miniColorSuccess = "#62b665";
    return DefaultSettings;
}(Settings));
exports.DefaultSettings = DefaultSettings;
function loadSettings() {
    return __awaiter(this, void 0, void 0, function () {
        var settingsArr, CSsettings;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_Settings")];
                case 1:
                    settingsArr = _a.sent();
                    CSsettings = utils_1.convertArrayToSettings(settingsArr);
                    CSsettings.displayCheckedAssignment = CSsettings.getDisplayCheckedAssignment;
                    return [2 /*return*/, CSsettings];
            }
        });
    });
}
exports.loadSettings = loadSettings;
/**
 * Load configurations from local storage
 */
function loadConfigs() {
    return __awaiter(this, void 0, void 0, function () {
        var baseURL, VERSION, CSsettings, assignmentCacheInterval, quizCacheInterval, assignmentFetchedTime, quizFetchedTime;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    baseURL = network_1.getBaseURL();
                    VERSION = chrome.runtime.getManifest().version;
                    return [4 /*yield*/, loadSettings()];
                case 1:
                    CSsettings = _a.sent();
                    CSsettings.displayCheckedAssignment = CSsettings.getDisplayCheckedAssignment;
                    assignmentCacheInterval = CSsettings.getAssignmentCacheInterval;
                    quizCacheInterval = CSsettings.getQuizCacheInterval;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_AssignmentFetchTime", "undefined")];
                case 2:
                    assignmentFetchedTime = _a.sent();
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_QuizFetchTime", "undefined")];
                case 3:
                    quizFetchedTime = _a.sent();
                    return [2 /*return*/, {
                            baseURL: baseURL,
                            version: VERSION,
                            CSsettings: CSsettings,
                            cacheInterval: {
                                assignment: assignmentCacheInterval,
                                quiz: quizCacheInterval,
                            },
                            fetchedTime: {
                                assignment: assignmentFetchedTime,
                                quiz: quizFetchedTime,
                            },
                        }];
            }
        });
    });
}
exports.loadConfigs = loadConfigs;


/***/ }),

/***/ "./src/storage.ts":
/*!************************!*\
  !*** ./src/storage.ts ***!
  \************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getKeys = exports.saveToLocalStorage = exports.loadFromLocalStorage2 = exports.loadFromLocalStorage = void 0;
/**
 * Get all keys in local storage
 */
function getKeys() {
    return new Promise(function (resolve, reject) {
        chrome.storage.local.get(null, function (keys) {
            resolve(Object.keys(keys));
        });
    });
}
exports.getKeys = getKeys;
/**
 * Load from local storage
 * @param {string} key
 * @param {string} ifUndefinedType Can specify response type if result was undefined
 */
function loadFromLocalStorage(key, ifUndefinedType) {
    if (ifUndefinedType === void 0) { ifUndefinedType = "array"; }
    var baseURL = window.location.hostname;
    return new Promise(function (resolve, reject) {
        chrome.storage.local.get(baseURL, function (items) {
            if (typeof items[baseURL] === "undefined" || typeof items[baseURL][key] === "undefined") {
                var res = void 0;
                switch (ifUndefinedType) {
                    case "number":
                        res = 0;
                        break;
                    case "string":
                        res = "";
                        break;
                    case "undefined":
                        res = undefined;
                        break;
                    default:
                        res = [];
                        break;
                }
                resolve(res);
            }
            else
                resolve(items[baseURL][key]);
        });
    });
}
exports.loadFromLocalStorage = loadFromLocalStorage;
/**
 * Load from local storage
 * FOR SubSakai since it might not be executed in SakaiLMS.
 * @param {string} baseURL
 * @param {string} key
 */
function loadFromLocalStorage2(baseURL, key) {
    return new Promise(function (resolve, reject) {
        chrome.storage.local.get(baseURL, function (items) {
            if (typeof items[baseURL] === "undefined" || typeof items[baseURL][key] === "undefined") {
                resolve([]);
            }
            else
                resolve(items[baseURL][key]);
        });
    });
}
exports.loadFromLocalStorage2 = loadFromLocalStorage2;
/**
 * Save to local storage
 * @param {string} key
 * @param {any} value
 */
function saveToLocalStorage(key, value) {
    var baseURL = window.location.hostname;
    var entity = {};
    entity[key] = value;
    return new Promise(function (resolve, reject) {
        chrome.storage.local.get(baseURL, function (items) {
            var _a;
            if (typeof items[baseURL] === "undefined") {
                items[baseURL] = {};
            }
            items[baseURL][key] = value;
            chrome.storage.local.set((_a = {}, _a[baseURL] = items[baseURL], _a), function () {
                resolve("saved");
            });
        });
    });
}
exports.saveToLocalStorage = saveToLocalStorage;


/***/ }),

/***/ "./src/subsakai.ts":
/*!*************************!*\
  !*** ./src/subsakai.ts ***!
  \*************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var storage_1 = __webpack_require__(/*! ./storage */ "./src/storage.ts");
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
var minisakai_1 = __webpack_require__(/*! ./minisakai */ "./src/minisakai.ts");
var subSakaiRoot = document.querySelector("#sub-sakai");
/**
 * Update subSakai to latest info
 */
function updateSubSakai(root) {
    return __awaiter(this, void 0, void 0, function () {
        var hostname, mergedAssignmentList, assignmentList, _a, quizList, _b, assignmentMemoList, _c, courseIDs;
        return __generator(this, function (_d) {
            switch (_d.label) {
                case 0: return [4 /*yield*/, storage_1.getKeys()];
                case 1:
                    hostname = (_d.sent())[0];
                    _a = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage2(hostname, "CS_AssignmentList")];
                case 2:
                    assignmentList = _a.apply(void 0, [_d.sent()]);
                    _b = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage2(hostname, "CS_QuizList")];
                case 3:
                    quizList = _b.apply(void 0, [_d.sent()]);
                    _c = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage2(hostname, "CS_MemoList")];
                case 4:
                    assignmentMemoList = _c.apply(void 0, [_d.sent()]);
                    return [4 /*yield*/, storage_1.loadFromLocalStorage2(hostname, "CS_CourseInfo")];
                case 5:
                    courseIDs = (_d.sent());
                    mergedAssignmentList = utils_1.mergeIntoAssignmentList(assignmentList, quizList);
                    mergedAssignmentList = utils_1.mergeIntoAssignmentList(mergedAssignmentList, assignmentMemoList);
                    mergedAssignmentList = utils_1.sortAssignmentList(mergedAssignmentList);
                    return [4 /*yield*/, minisakai_1.createMiniSakaiGeneralized(root, mergedAssignmentList, courseIDs, true, function (rendered) {
                            console.log(rendered);
                            root.innerHTML = rendered;
                        })];
                case 6:
                    _d.sent();
                    return [2 /*return*/];
            }
        });
    });
}
function addSubSakaiToPopup() {
    if (subSakaiRoot == null)
        return null;
    return subSakaiRoot;
}
/**
 * Initialize subSakai
 */
function initSubSakai() {
    return __awaiter(this, void 0, void 0, function () {
        var root, _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    root = addSubSakaiToPopup();
                    _a = root;
                    if (!_a) return [3 /*break*/, 2];
                    return [4 /*yield*/, updateSubSakai(root)];
                case 1:
                    _a = (_b.sent());
                    _b.label = 2;
                case 2:
                    _a;
                    return [2 /*return*/];
            }
        });
    });
}
initSubSakai();


/***/ }),

/***/ "./src/utils.ts":
/*!**********************!*\
  !*** ./src/utils.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.sortAssignmentList = exports.mergeIntoAssignmentList = exports.genUniqueID = exports.isUsingCache = exports.compareAndMergeAssignmentList = exports.convertArrayToAssignment = exports.convertArrayToSettings = exports.miniSakaiReady = exports.isLoggedIn = exports.formatTimestamp = exports.createCourseIDMap = exports.getDaysUntil = exports.updateIsReadFlag = exports.getSiteCourseID = exports.getLoggedInInfoFromScript = exports.nowTime = void 0;
var model_1 = __webpack_require__(/*! ./model */ "./src/model.ts");
var settings_1 = __webpack_require__(/*! ./settings */ "./src/settings.ts");
exports.nowTime = new Date().getTime();
/**
 * Calculate category of assignment due date
 * @param {number} dt1 standard time
 * @param {number} dt2 target time
 */
function getDaysUntil(dt1, dt2) {
    var diff = (dt2 - dt1) / 1000;
    diff /= 3600 * 24;
    var category;
    if (diff > 0 && diff <= 1) {
        category = "due24h";
    }
    else if (diff > 1 && diff <= 5) {
        category = "due5d";
    }
    else if (diff > 5 && diff <= 14) {
        category = "due14d";
    }
    else if (diff > 14) {
        category = "dueOver14d";
    }
    else {
        category = "duePassed";
    }
    return category;
}
exports.getDaysUntil = getDaysUntil;
/**
 * Format timestamp for displaying
 * @param {number | undefined} timestamp
 */
function formatTimestamp(timestamp) {
    var date = new Date(timestamp ? timestamp : exports.nowTime);
    return (date.toLocaleDateString() +
        " " +
        date.getHours() +
        ":" +
        ("00" + date.getMinutes()).slice(-2) +
        ":" +
        ("00" + date.getSeconds()).slice(-2));
}
exports.formatTimestamp = formatTimestamp;
/**
 * Creates a Map of courseID and course name.
 * @param {CourseSiteInfo[]} courseSiteInfos
 */
function createCourseIDMap(courseSiteInfos) {
    var courseIDMap = new Map();
    for (var _i = 0, courseSiteInfos_1 = courseSiteInfos; _i < courseSiteInfos_1.length; _i++) {
        var courseSiteInfo = courseSiteInfos_1[_i];
        var courseName = void 0;
        if (courseSiteInfo.courseName === undefined)
            courseName = "";
        else
            courseName = courseSiteInfo.courseName;
        courseIDMap.set(courseSiteInfo.courseID, courseName);
    }
    return courseIDMap;
}
exports.createCourseIDMap = createCourseIDMap;
var getLoggedInInfoFromScript = function () {
    return Array.from(document.getElementsByTagName("script"));
};
exports.getLoggedInInfoFromScript = getLoggedInInfoFromScript;
/**
 * Check if user is loggend in to Sakai.
 */
function isLoggedIn() {
    var scripts = exports.getLoggedInInfoFromScript();
    var loggedIn = false;
    for (var _i = 0, scripts_1 = scripts; _i < scripts_1.length; _i++) {
        var script = scripts_1[_i];
        if (script.text.match('"loggedIn": true'))
            loggedIn = true;
    }
    return loggedIn;
}
exports.isLoggedIn = isLoggedIn;
/**
 * Get courseID of current site.
 */
var getSiteCourseID = function (url) {
    var _a;
    var courseID;
    var reg = new RegExp("(https?://[^/]+)/portal/site/([^/]+)");
    if (url.match(reg)) {
        courseID = (_a = url.match(reg)) === null || _a === void 0 ? void 0 : _a[2];
    }
    return courseID;
};
exports.getSiteCourseID = getSiteCourseID;
/**
 * Update new-assignment notification flags.
 * @param {Assignment[]} assignmentList
 */
var updateIsReadFlag = function (assignmentList) {
    var courseID = exports.getSiteCourseID(location.href);
    var updatedAssignmentList = [];
    // TODO: Review this process
    if (courseID && courseID.length >= 17) {
        for (var _i = 0, assignmentList_1 = assignmentList; _i < assignmentList_1.length; _i++) {
            var assignment = assignmentList_1[_i];
            if (assignment.courseSiteInfo.courseID === courseID) {
                updatedAssignmentList.push(new model_1.Assignment(assignment.courseSiteInfo, assignment.assignmentEntries, true));
            }
            else {
                updatedAssignmentList.push(assignment);
            }
        }
    }
    else {
        updatedAssignmentList = assignmentList;
    }
    return updatedAssignmentList;
};
exports.updateIsReadFlag = updateIsReadFlag;
/**
 * Change loading icon to hamburger button.
 */
function miniSakaiReady() {
    var loadingIcon = document.getElementsByClassName("cs-loading")[0];
    var hamburgerIcon = document.createElement("img");
    hamburgerIcon.src = chrome.runtime.getURL("img/miniSakaiBtn.png");
    hamburgerIcon.className = "cs-minisakai-btn";
    loadingIcon.className = "cs-minisakai-btn-div";
    loadingIcon.append(hamburgerIcon);
}
exports.miniSakaiReady = miniSakaiReady;
/**
 * Convert array to Settings class
 * @param {any} arr
 */
function convertArrayToSettings(arr) {
    var settings = new settings_1.Settings();
    settings.assignmentCacheInterval = arr.assignmentCacheInterval;
    settings.quizCacheInterval = arr.quizCacheInterval;
    settings.displayCheckedAssignment = arr.displayCheckedAssignment;
    settings.displayLateSubmitAssignment = arr.displayLateSubmitAssignment;
    settings.topColorDanger = arr.topColorDanger;
    settings.topColorWarning = arr.topColorWarning;
    settings.topColorSuccess = arr.topColorSuccess;
    settings.miniColorDanger = arr.miniColorDanger;
    settings.miniColorWarning = arr.miniColorWarning;
    settings.miniColorSuccess = arr.miniColorSuccess;
    return settings;
}
exports.convertArrayToSettings = convertArrayToSettings;
/**
 * Convert array to Assignment class
 * @param {any} arr
 */
function convertArrayToAssignment(arr) {
    var assignmentList = [];
    for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
        var i = arr_1[_i];
        var assignmentEntries = [];
        for (var _a = 0, _b = i.assignmentEntries; _a < _b.length; _a++) {
            var e = _b[_a];
            var entry = new model_1.AssignmentEntry(e.assignmentID, e.assignmentTitle, e.dueDateTimestamp, e.closeDateTimestamp, e.isMemo, e.isFinished, e.isQuiz, e.assignmentDetail);
            entry.assignmentPage = e.assignmentPage;
            if (entry.getCloseDateTimestamp * 1000 > exports.nowTime)
                assignmentEntries.push(entry);
        }
        assignmentList.push(new model_1.Assignment(new model_1.CourseSiteInfo(i.courseSiteInfo.courseID, i.courseSiteInfo.courseName), assignmentEntries, i.isRead));
    }
    return assignmentList;
}
exports.convertArrayToAssignment = convertArrayToAssignment;
/**
 * Compare old and new AssignmentList and merge them.
 * @param {Assignment[]} oldAssignmentiList
 * @param {Assignment[]} newAssignmentList
 */
function compareAndMergeAssignmentList(oldAssignmentiList, newAssignmentList) {
    var mergedAssignmentList = [];
    var _loop_1 = function (newAssignment) {
        var idx = oldAssignmentiList.findIndex(function (oldAssignment) {
            return oldAssignment.courseSiteInfo.courseID === newAssignment.courseSiteInfo.courseID;
        });
        // If this courseID is **NOT** in oldAssignmentList:
        if (idx === -1) {
            // Since this course site has a first assignment, set isRead flags to false.
            var isRead = newAssignment.assignmentEntries.length === 0;
            // Sort and add this to AssignmentList
            newAssignment.assignmentEntries.sort(function (a, b) {
                return a.getDueDateTimestamp - b.getDueDateTimestamp;
            });
            mergedAssignmentList.push(new model_1.Assignment(newAssignment.courseSiteInfo, newAssignment.assignmentEntries, isRead));
        }
        // If this courseID **IS** in oldAssignmentList:
        else {
            // Take over isRead flag
            var isRead = oldAssignmentiList[idx].isRead;
            // Just in case if AssignmentList is empty, set flag to true
            if (newAssignment.assignmentEntries.length === 0)
                isRead = true;
            var mergedAssignmentEntries = [];
            var _loop_2 = function (newAssignmentEntry) {
                // Find if this new assignment is in old AssignmentList
                var oldAssignment = oldAssignmentiList[idx];
                var q = oldAssignment.assignmentEntries.findIndex(function (oldAssignmentEntry) {
                    return oldAssignmentEntry.assignmentID === newAssignmentEntry.assignmentID;
                });
                // If there is same assignmentID, update it.
                if (q === -1) {
                    // Set isRead flag to false since there might be some updates in assignment.
                    isRead = false;
                    mergedAssignmentEntries.push(newAssignmentEntry);
                }
                // If there is not, create a new AssignmentEntry for the course site.
                else {
                    var entry = new model_1.AssignmentEntry(newAssignmentEntry.assignmentID, newAssignmentEntry.assignmentTitle, newAssignmentEntry.dueDateTimestamp, newAssignmentEntry.closeDateTimestamp, newAssignmentEntry.isMemo, oldAssignment.assignmentEntries[q].isFinished, newAssignmentEntry.isQuiz, newAssignmentEntry.assignmentDetail);
                    entry.assignmentPage = newAssignmentEntry.assignmentPage;
                    mergedAssignmentEntries.push(entry);
                }
            };
            for (var _a = 0, _b = newAssignment.assignmentEntries; _a < _b.length; _a++) {
                var newAssignmentEntry = _b[_a];
                _loop_2(newAssignmentEntry);
            }
            // Sort AssignmentList
            mergedAssignmentEntries.sort(function (a, b) {
                return a.getDueDateTimestamp - b.getDueDateTimestamp;
            });
            mergedAssignmentList.push(new model_1.Assignment(newAssignment.courseSiteInfo, mergedAssignmentEntries, isRead));
        }
    };
    // Merge Assignments based on newAssignmentList
    for (var _i = 0, newAssignmentList_1 = newAssignmentList; _i < newAssignmentList_1.length; _i++) {
        var newAssignment = newAssignmentList_1[_i];
        _loop_1(newAssignment);
    }
    return mergedAssignmentList;
}
exports.compareAndMergeAssignmentList = compareAndMergeAssignmentList;
/**
 * Merge Assignments, Quizzes, Memos together.
 * @param {Assignment[]} targetAssignmentList
 * @param {Assignment[]} newAssignmentList
 */
function mergeIntoAssignmentList(targetAssignmentList, newAssignmentList) {
    var mergedAssignmentList = [];
    for (var _i = 0, targetAssignmentList_1 = targetAssignmentList; _i < targetAssignmentList_1.length; _i++) {
        var assignment = targetAssignmentList_1[_i];
        mergedAssignmentList.push(new model_1.Assignment(assignment.courseSiteInfo, assignment.assignmentEntries, assignment.isRead));
    }
    var _loop_3 = function (newAssignment) {
        var idx = targetAssignmentList.findIndex(function (assignment) {
            return newAssignment.courseSiteInfo.courseID === assignment.courseSiteInfo.courseID;
        });
        var mergedAssignment = mergedAssignmentList[idx];
        if (idx !== -1) {
            mergedAssignment.assignmentEntries = mergedAssignment.assignmentEntries.concat(newAssignment.assignmentEntries);
        }
        else {
            mergedAssignmentList.push(new model_1.Assignment(newAssignment.courseSiteInfo, newAssignment.assignmentEntries, true));
        }
    };
    for (var _a = 0, newAssignmentList_2 = newAssignmentList; _a < newAssignmentList_2.length; _a++) {
        var newAssignment = newAssignmentList_2[_a];
        _loop_3(newAssignment);
    }
    return mergedAssignmentList;
}
exports.mergeIntoAssignmentList = mergeIntoAssignmentList;
/**
 * Function for sorting Assignments
 * @param {Assignment[]} assignmentList
 */
function sortAssignmentList(assignmentList) {
    return Array.from(assignmentList).sort(function (a, b) {
        if (a.closestDueDateTimestamp > b.closestDueDateTimestamp)
            return 1;
        if (a.closestDueDateTimestamp < b.closestDueDateTimestamp)
            return -1;
        return 0;
    });
}
exports.sortAssignmentList = sortAssignmentList;
/**
 * Decides whether to use cache
 * @param {number | undefined} fetchedTime
 * @param {number} cacheInterval
 */
function isUsingCache(fetchedTime, cacheInterval) {
    if (fetchedTime)
        return (exports.nowTime - fetchedTime) / 1000 <= cacheInterval;
    else
        return false;
}
exports.isUsingCache = isUsingCache;
/**
 * Generate unique ID
 * @param {string} prefix
 */
function genUniqueID(prefix) {
    return prefix + new Date().getTime().toString(16) + Math.floor(123456 * Math.random()).toString(16);
}
exports.genUniqueID = genUniqueID;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/subsakai.ts");
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3Vic2FrYWkuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFDQSxFQUFFLEtBQTREO0FBQzlELEVBQUUsQ0FDc0Q7QUFDeEQsQ0FBQyxzQkFBc0I7O0FBRXZCO0FBQ0EsZ0NBQWdDLFdBQVc7QUFDM0M7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxvQ0FBb0M7QUFDcEM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGVBQWU7QUFDZixjQUFjO0FBQ2QsY0FBYztBQUNkLGdCQUFnQjtBQUNoQixlQUFlO0FBQ2YsZ0JBQWdCO0FBQ2hCLGdCQUFnQjtBQUNoQixnQkFBZ0I7QUFDaEI7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQjtBQUN0QiwyQkFBMkI7O0FBRTNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0MsU0FBUztBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkI7QUFDM0IsMkJBQTJCO0FBQzNCLDJCQUEyQjtBQUMzQiwyQkFBMkIsZ0JBQWdCLE1BQU07QUFDakQsMkJBQTJCO0FBQzNCLDJCQUEyQjtBQUMzQiwyQkFBMkI7O0FBRTNCO0FBQ0Esd0JBQXdCLE9BQU87QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsMERBQTBEO0FBQzFEOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0Esb0RBQW9ELGlCQUFpQjtBQUNyRTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSxvQkFBb0I7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsUUFBUSx1Q0FBdUM7QUFDL0M7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsK0NBQStDLGVBQWU7QUFDOUQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsK0NBQStDLGVBQWU7QUFDOUQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLFVBQVU7QUFDVjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtFQUFrRSxXQUFXLFVBQVUsU0FBUyxLQUFLLG9CQUFvQjtBQUN6SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLCtDQUErQyxlQUFlO0FBQzlEO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBLGtEQUFrRCxpQkFBaUI7QUFDbkU7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBLE1BQU07QUFDTjtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLHdCQUF3QjtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZUFBZSxNQUFNO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQSxDQUFDOzs7Ozs7Ozs7Ozs7QUNud0JZO0FBQ2I7QUFDQSw0QkFBNEIsK0RBQStELGlCQUFpQjtBQUM1RztBQUNBLG9DQUFvQyxNQUFNLCtCQUErQixZQUFZO0FBQ3JGLG1DQUFtQyxNQUFNLG1DQUFtQyxZQUFZO0FBQ3hGLGdDQUFnQztBQUNoQztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsY0FBYyw2QkFBNkIsMEJBQTBCLGNBQWMscUJBQXFCO0FBQ3hHLGlCQUFpQixvREFBb0QscUVBQXFFLGNBQWM7QUFDeEosdUJBQXVCLHNCQUFzQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0M7QUFDeEMsbUNBQW1DLFNBQVM7QUFDNUMsbUNBQW1DLFdBQVcsVUFBVTtBQUN4RCwwQ0FBMEMsY0FBYztBQUN4RDtBQUNBLDhHQUE4RyxPQUFPO0FBQ3JILGlGQUFpRixpQkFBaUI7QUFDbEcseURBQXlELGdCQUFnQixRQUFRO0FBQ2pGLCtDQUErQyxnQkFBZ0IsZ0JBQWdCO0FBQy9FO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQSxVQUFVLFlBQVksYUFBYSxTQUFTLFVBQVU7QUFDdEQsb0NBQW9DLFNBQVM7QUFDN0M7QUFDQTtBQUNBLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RCxrQ0FBa0MsR0FBRyxrQ0FBa0MsR0FBRyw0QkFBNEIsR0FBRyxvQkFBb0I7QUFDN0gsZ0JBQWdCLG1CQUFPLENBQUMsbUNBQVc7QUFDbkMsZ0JBQWdCLG1CQUFPLENBQUMsbUNBQVc7QUFDbkMsa0JBQWtCLG1CQUFPLENBQUMsdUNBQWE7QUFDdkMsa0JBQWtCLG1CQUFPLENBQUMsdUNBQWE7QUFDdkMsY0FBYyxtQkFBTyxDQUFDLCtCQUFTO0FBQy9CLGlCQUFpQixtQkFBTyxDQUFDLHFDQUFZO0FBQ3JDO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxrQkFBa0I7QUFDN0IsV0FBVyxTQUFTO0FBQ3BCLFdBQVcsU0FBUztBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzRUFBc0UsK0JBQStCO0FBQ3JHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9EQUFvRCxzQkFBc0I7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0Isa0NBQWtDO0FBQ3RELG9CQUFvQiw0QkFBNEI7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0VBQXNFLCtCQUErQjtBQUNyRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvREFBb0Qsc0JBQXNCO0FBQzFFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsNEJBQTRCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsNEJBQTRCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLG9CQUFvQjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiw0QkFBNEI7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBOzs7Ozs7Ozs7Ozs7QUN6TmE7QUFDYiw4Q0FBNkMsRUFBRSxhQUFhLEVBQUM7QUFDN0Qsc0JBQXNCLEdBQUcsaUJBQWlCLEdBQUcsa0JBQWtCLEdBQUcscUJBQXFCLEdBQUcsbUJBQW1CLEdBQUcsaUJBQWlCLEdBQUcscUJBQXFCLEdBQUcsaUJBQWlCO0FBQzdLLHNCQUFzQixtQkFBTyxDQUFDLCtDQUFpQjtBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEIsaUJBQWlCLHVCQUF1QixpQkFBaUI7QUFDekQ7QUFDQSxxQkFBcUIsdUJBQXVCLGdDQUFnQztBQUM1RSxpQkFBaUIsdUJBQXVCLHlCQUF5QixJQUFJLHdDQUF3QztBQUM3RztBQUNBO0FBQ0E7QUFDQSw4Q0FBOEMsMEJBQTBCO0FBQ3hFO0FBQ0Esc0NBQXNDLCtCQUErQjtBQUNyRTtBQUNBLGtEQUFrRCxrQkFBa0I7QUFDcEUsaURBQWlELGdCQUFnQjtBQUNqRSxrREFBa0Qsa0RBQWtEO0FBQ3BHLGlEQUFpRCxtREFBbUQ7QUFDcEcsNENBQTRDLHFDQUFxQztBQUNqRixDQUFDLGtDQUFrQztBQUNuQyxtQkFBbUI7Ozs7Ozs7Ozs7OztBQ25FTjtBQUNiO0FBQ0EsNEJBQTRCLCtEQUErRCxpQkFBaUI7QUFDNUc7QUFDQSxvQ0FBb0MsTUFBTSwrQkFBK0IsWUFBWTtBQUNyRixtQ0FBbUMsTUFBTSxtQ0FBbUMsWUFBWTtBQUN4RixnQ0FBZ0M7QUFDaEM7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLGNBQWMsNkJBQTZCLDBCQUEwQixjQUFjLHFCQUFxQjtBQUN4RyxpQkFBaUIsb0RBQW9ELHFFQUFxRSxjQUFjO0FBQ3hKLHVCQUF1QixzQkFBc0I7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDO0FBQ3hDLG1DQUFtQyxTQUFTO0FBQzVDLG1DQUFtQyxXQUFXLFVBQVU7QUFDeEQsMENBQTBDLGNBQWM7QUFDeEQ7QUFDQSw4R0FBOEcsT0FBTztBQUNySCxpRkFBaUYsaUJBQWlCO0FBQ2xHLHlEQUF5RCxnQkFBZ0IsUUFBUTtBQUNqRiwrQ0FBK0MsZ0JBQWdCLGdCQUFnQjtBQUMvRTtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0EsVUFBVSxZQUFZLGFBQWEsU0FBUyxVQUFVO0FBQ3RELG9DQUFvQyxTQUFTO0FBQzdDO0FBQ0E7QUFDQSw4Q0FBNkMsRUFBRSxhQUFhLEVBQUM7QUFDN0QsNEJBQTRCLEdBQUcsa0JBQWtCLEdBQUcsc0JBQXNCLEdBQUcsZUFBZSxHQUFHLDBCQUEwQixHQUFHLHFCQUFxQixHQUFHLHlCQUF5QixHQUFHLDJCQUEyQixHQUFHLHVCQUF1QjtBQUNyTyxZQUFZLG1CQUFPLENBQUMsMkJBQU87QUFDM0IsZ0JBQWdCLG1CQUFPLENBQUMsbUNBQVc7QUFDbkMsY0FBYyxtQkFBTyxDQUFDLCtCQUFTO0FBQy9CLGNBQWMsbUJBQU8sQ0FBQywrQkFBUztBQUMvQix1QkFBdUIsbUJBQU8sQ0FBQyxpREFBa0I7QUFDakQsaUJBQWlCLG1CQUFPLENBQUMscUNBQVk7QUFDckMsa0JBQWtCLG1CQUFPLENBQUMsdUNBQWE7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvRUFBb0UsOEJBQThCO0FBQ2xHO0FBQ0E7QUFDQSx3RUFBd0UsZ0JBQWdCO0FBQ3hGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhEQUE4RCx5QkFBeUI7QUFDdkY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0Esc0JBQXNCO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELHdCQUF3QjtBQUNoRjtBQUNBO0FBQ0Esa0VBQWtFLGdCQUFnQjtBQUNsRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdFQUFnRSw0QkFBNEI7QUFDNUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxzQkFBc0I7QUFDMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSw0QkFBNEI7QUFDNUI7QUFDQTtBQUNBLFdBQVcsa0JBQWtCO0FBQzdCLFdBQVcsU0FBUztBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDelphO0FBQ2IsOENBQTZDLEVBQUUsYUFBYSxFQUFDO0FBQzdELCtCQUErQjtBQUMvQixzQkFBc0IsbUJBQU8sQ0FBQywrQ0FBaUI7QUFDL0M7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsMEJBQTBCO0FBQ3BELEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2QyxnQkFBZ0I7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELG1CQUFtQjtBQUMzRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0REFBNEQsbUJBQW1CO0FBQy9FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUVBQXFFLGdCQUFnQjtBQUNyRjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLEtBQUs7QUFDTDtBQUNBLCtCQUErQjs7Ozs7Ozs7Ozs7O0FDekdsQjtBQUNiO0FBQ0EsNEJBQTRCLCtEQUErRCxpQkFBaUI7QUFDNUc7QUFDQSxvQ0FBb0MsTUFBTSwrQkFBK0IsWUFBWTtBQUNyRixtQ0FBbUMsTUFBTSxtQ0FBbUMsWUFBWTtBQUN4RixnQ0FBZ0M7QUFDaEM7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLGNBQWMsNkJBQTZCLDBCQUEwQixjQUFjLHFCQUFxQjtBQUN4RyxpQkFBaUIsb0RBQW9ELHFFQUFxRSxjQUFjO0FBQ3hKLHVCQUF1QixzQkFBc0I7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDO0FBQ3hDLG1DQUFtQyxTQUFTO0FBQzVDLG1DQUFtQyxXQUFXLFVBQVU7QUFDeEQsMENBQTBDLGNBQWM7QUFDeEQ7QUFDQSw4R0FBOEcsT0FBTztBQUNySCxpRkFBaUYsaUJBQWlCO0FBQ2xHLHlEQUF5RCxnQkFBZ0IsUUFBUTtBQUNqRiwrQ0FBK0MsZ0JBQWdCLGdCQUFnQjtBQUMvRTtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0EsVUFBVSxZQUFZLGFBQWEsU0FBUyxVQUFVO0FBQ3RELG9DQUFvQyxTQUFTO0FBQzdDO0FBQ0E7QUFDQTtBQUNBLDZDQUE2QztBQUM3QztBQUNBLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RCxzQ0FBc0MsR0FBRyxzQ0FBc0MsR0FBRyx3QkFBd0IsR0FBRyx1QkFBdUIsR0FBRywwQkFBMEIsR0FBRyxrQ0FBa0M7QUFDdE0sY0FBYyxtQkFBTyxDQUFDLCtCQUFTO0FBQy9CLGNBQWMsbUJBQU8sQ0FBQywrQkFBUztBQUMvQixZQUFZLG1CQUFPLENBQUMsMkJBQU87QUFDM0Isc0JBQXNCLG1CQUFPLENBQUMsK0NBQWlCO0FBQy9DO0FBQ0EsaUNBQWlDLG1CQUFPLENBQUMscURBQVU7QUFDbkQsaUJBQWlCLG1CQUFPLENBQUMscUNBQVk7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwRkFBMEYsc0JBQXNCO0FBQ2hIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUM7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0EsMkRBQTJEO0FBQzNEO0FBQ0E7QUFDQTtBQUNBLDJEQUEyRCxtRUFBbUUsaUNBQWlDO0FBQy9KO0FBQ0E7QUFDQSwyREFBMkQsbUVBQW1FLCtCQUErQjtBQUM3SjtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3RUFBd0UsOEJBQThCO0FBQ3RHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0EsK0NBQStDLG9CQUFvQjtBQUNuRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5RUFBeUUsd0JBQXdCLElBQUksMkJBQTJCLGlEQUFpRDtBQUNqTDtBQUNBO0FBQ0Esd0VBQXdFLHNCQUFzQixJQUFJLDJCQUEyQixrREFBa0Q7QUFDL0s7QUFDQTtBQUNBO0FBQ0EsNEVBQTRFLHNCQUFzQixJQUFJLDBCQUEwQixpREFBaUQ7QUFDakw7QUFDQTtBQUNBLDZFQUE2RSxzQkFBc0IsSUFBSSwyQkFBMkIsa0RBQWtEO0FBQ3BMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnSUFBZ0ksK0NBQStDO0FBQy9LLDhIQUE4SCw2Q0FBNkM7QUFDM0ssaUVBQWlFLG1EQUFtRCwrQ0FBK0MsSUFBSTtBQUN2Syw0SEFBNEgsMkNBQTJDO0FBQ3ZLLGtJQUFrSSx5Q0FBeUM7QUFDM0ssMkhBQTJILG1DQUFtQztBQUM5SixxRUFBcUUsa0RBQWtELHVDQUF1QyxJQUFJO0FBQ2xLO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLHdCQUF3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNFQUFzRSwrQkFBK0I7QUFDckc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELGVBQWU7QUFDdkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdEQUF3RCxlQUFlO0FBQ3ZFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3REFBd0QsZUFBZTtBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELGVBQWU7QUFDdkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLHFCQUFxQjtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLHNDQUFzQztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOENBQThDLHlCQUF5QjtBQUN2RTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MsaUJBQWlCO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxvQkFBb0I7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0Msb0JBQW9CO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDs7Ozs7Ozs7Ozs7O0FDdGVhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsZUFBZSxnQkFBZ0Isc0NBQXNDLGtCQUFrQjtBQUN2Riw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCO0FBQ3hCO0FBQ0E7QUFDQSxDQUFDO0FBQ0QsOENBQTZDLEVBQUUsYUFBYSxFQUFDO0FBQzdELHlCQUF5QixHQUFHLDhCQUE4QixHQUFHLHNCQUFzQixHQUFHLGtCQUFrQixHQUFHLHVCQUF1QjtBQUNsSSxjQUFjLG1CQUFPLENBQUMsK0JBQVM7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLENBQUM7QUFDRCx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBEQUEwRCxnQkFBZ0I7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMERBQTBELGdCQUFnQjtBQUMxRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxzREFBc0QsZ0JBQWdCO0FBQ3RFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNELGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Qsc0JBQXNCO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxDQUFDO0FBQ0QsOEJBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNELHlCQUF5Qjs7Ozs7Ozs7Ozs7O0FDdExaO0FBQ2I7QUFDQSw0QkFBNEIsK0RBQStELGlCQUFpQjtBQUM1RztBQUNBLG9DQUFvQyxNQUFNLCtCQUErQixZQUFZO0FBQ3JGLG1DQUFtQyxNQUFNLG1DQUFtQyxZQUFZO0FBQ3hGLGdDQUFnQztBQUNoQztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsY0FBYyw2QkFBNkIsMEJBQTBCLGNBQWMscUJBQXFCO0FBQ3hHLGlCQUFpQixvREFBb0QscUVBQXFFLGNBQWM7QUFDeEosdUJBQXVCLHNCQUFzQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0M7QUFDeEMsbUNBQW1DLFNBQVM7QUFDNUMsbUNBQW1DLFdBQVcsVUFBVTtBQUN4RCwwQ0FBMEMsY0FBYztBQUN4RDtBQUNBLDhHQUE4RyxPQUFPO0FBQ3JILGlGQUFpRixpQkFBaUI7QUFDbEcseURBQXlELGdCQUFnQixRQUFRO0FBQ2pGLCtDQUErQyxnQkFBZ0IsZ0JBQWdCO0FBQy9FO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQSxVQUFVLFlBQVksYUFBYSxTQUFTLFVBQVU7QUFDdEQsb0NBQW9DLFNBQVM7QUFDN0M7QUFDQTtBQUNBLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RCwyQkFBMkIsR0FBRywrQkFBK0IsR0FBRyx1QkFBdUIsR0FBRyxrQkFBa0I7QUFDNUcsY0FBYyxtQkFBTyxDQUFDLCtCQUFTO0FBQy9CLGNBQWMsbUJBQU8sQ0FBQywrQkFBUztBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNENBQTRDLHdCQUF3QjtBQUNwRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQixtQkFBbUI7QUFDN0Msd0NBQXdDO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUyxJQUFJO0FBQ2Isb0NBQW9DLDRCQUE0QixHQUFHO0FBQ25FLEtBQUs7QUFDTDtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLG1CQUFtQjtBQUM3Qyx3Q0FBd0M7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTLElBQUk7QUFDYixvQ0FBb0MsNEJBQTRCLEdBQUc7QUFDbkUsS0FBSztBQUNMO0FBQ0EsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyw4REFBOEQ7QUFDaEc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyx1R0FBdUc7QUFDekk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7Ozs7Ozs7Ozs7O0FDckxhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsZUFBZSxnQkFBZ0Isc0NBQXNDLGtCQUFrQjtBQUN2Riw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCO0FBQ3hCO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQSw0QkFBNEIsK0RBQStELGlCQUFpQjtBQUM1RztBQUNBLG9DQUFvQyxNQUFNLCtCQUErQixZQUFZO0FBQ3JGLG1DQUFtQyxNQUFNLG1DQUFtQyxZQUFZO0FBQ3hGLGdDQUFnQztBQUNoQztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsY0FBYyw2QkFBNkIsMEJBQTBCLGNBQWMscUJBQXFCO0FBQ3hHLGlCQUFpQixvREFBb0QscUVBQXFFLGNBQWM7QUFDeEosdUJBQXVCLHNCQUFzQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0M7QUFDeEMsbUNBQW1DLFNBQVM7QUFDNUMsbUNBQW1DLFdBQVcsVUFBVTtBQUN4RCwwQ0FBMEMsY0FBYztBQUN4RDtBQUNBLDhHQUE4RyxPQUFPO0FBQ3JILGlGQUFpRixpQkFBaUI7QUFDbEcseURBQXlELGdCQUFnQixRQUFRO0FBQ2pGLCtDQUErQyxnQkFBZ0IsZ0JBQWdCO0FBQy9FO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQSxVQUFVLFlBQVksYUFBYSxTQUFTLFVBQVU7QUFDdEQsb0NBQW9DLFNBQVM7QUFDN0M7QUFDQTtBQUNBLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RCxtQkFBbUIsR0FBRyxvQkFBb0IsR0FBRyx1QkFBdUIsR0FBRyxnQkFBZ0I7QUFDdkYsZ0JBQWdCLG1CQUFPLENBQUMsbUNBQVc7QUFDbkMsY0FBYyxtQkFBTyxDQUFDLCtCQUFTO0FBQy9CLGdCQUFnQixtQkFBTyxDQUFDLG1DQUFXO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLENBQUM7QUFDRCxnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0QsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSxvQkFBb0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QjtBQUM3Qix5QkFBeUI7QUFDekI7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0EsbUJBQW1COzs7Ozs7Ozs7Ozs7QUNwTk47QUFDYiw4Q0FBNkMsRUFBRSxhQUFhLEVBQUM7QUFDN0QsZUFBZSxHQUFHLDBCQUEwQixHQUFHLDZCQUE2QixHQUFHLDRCQUE0QjtBQUMzRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkI7QUFDQTtBQUNBLHNDQUFzQztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLDRCQUE0QjtBQUM1QjtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSw2QkFBNkI7QUFDN0I7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLEtBQUs7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkNBQTZDO0FBQzdDO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSwwQkFBMEI7Ozs7Ozs7Ozs7OztBQ3hGYjtBQUNiO0FBQ0EsNEJBQTRCLCtEQUErRCxpQkFBaUI7QUFDNUc7QUFDQSxvQ0FBb0MsTUFBTSwrQkFBK0IsWUFBWTtBQUNyRixtQ0FBbUMsTUFBTSxtQ0FBbUMsWUFBWTtBQUN4RixnQ0FBZ0M7QUFDaEM7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLGNBQWMsNkJBQTZCLDBCQUEwQixjQUFjLHFCQUFxQjtBQUN4RyxpQkFBaUIsb0RBQW9ELHFFQUFxRSxjQUFjO0FBQ3hKLHVCQUF1QixzQkFBc0I7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDO0FBQ3hDLG1DQUFtQyxTQUFTO0FBQzVDLG1DQUFtQyxXQUFXLFVBQVU7QUFDeEQsMENBQTBDLGNBQWM7QUFDeEQ7QUFDQSw4R0FBOEcsT0FBTztBQUNySCxpRkFBaUYsaUJBQWlCO0FBQ2xHLHlEQUF5RCxnQkFBZ0IsUUFBUTtBQUNqRiwrQ0FBK0MsZ0JBQWdCLGdCQUFnQjtBQUMvRTtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0EsVUFBVSxZQUFZLGFBQWEsU0FBUyxVQUFVO0FBQ3RELG9DQUFvQyxTQUFTO0FBQzdDO0FBQ0E7QUFDQSw4Q0FBNkMsRUFBRSxhQUFhLEVBQUM7QUFDN0QsZ0JBQWdCLG1CQUFPLENBQUMsbUNBQVc7QUFDbkMsY0FBYyxtQkFBTyxDQUFDLCtCQUFTO0FBQy9CLGtCQUFrQixtQkFBTyxDQUFDLHVDQUFhO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQTs7Ozs7Ozs7Ozs7O0FDOUdhO0FBQ2IsOENBQTZDLEVBQUUsYUFBYSxFQUFDO0FBQzdELDBCQUEwQixHQUFHLCtCQUErQixHQUFHLG1CQUFtQixHQUFHLG9CQUFvQixHQUFHLHFDQUFxQyxHQUFHLGdDQUFnQyxHQUFHLDhCQUE4QixHQUFHLHNCQUFzQixHQUFHLGtCQUFrQixHQUFHLHVCQUF1QixHQUFHLHlCQUF5QixHQUFHLG9CQUFvQixHQUFHLHdCQUF3QixHQUFHLHVCQUF1QixHQUFHLGlDQUFpQyxHQUFHLGVBQWU7QUFDM2IsY0FBYyxtQkFBTyxDQUFDLCtCQUFTO0FBQy9CLGlCQUFpQixtQkFBTyxDQUFDLHFDQUFZO0FBQ3JDLGVBQWU7QUFDZjtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQjtBQUNwQjtBQUNBO0FBQ0EsV0FBVyxvQkFBb0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0EsV0FBVyxrQkFBa0I7QUFDN0I7QUFDQTtBQUNBO0FBQ0EsMERBQTBELCtCQUErQjtBQUN6RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMENBQTBDLHVCQUF1QjtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQSxXQUFXLGNBQWM7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNERBQTRELDhCQUE4QjtBQUMxRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEI7QUFDQTtBQUNBLFdBQVcsS0FBSztBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBLFdBQVcsS0FBSztBQUNoQjtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MsbUJBQW1CO0FBQ3JEO0FBQ0E7QUFDQSxtREFBbUQsZ0JBQWdCO0FBQ25FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDO0FBQ2hDO0FBQ0E7QUFDQSxXQUFXLGNBQWM7QUFDekIsV0FBVyxjQUFjO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtRUFBbUUsZ0JBQWdCO0FBQ25GO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhEQUE4RCxpQ0FBaUM7QUFDL0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQztBQUNyQztBQUNBO0FBQ0EsV0FBVyxjQUFjO0FBQ3pCLFdBQVcsY0FBYztBQUN6QjtBQUNBO0FBQ0E7QUFDQSxvRUFBb0Usb0NBQW9DO0FBQ3hHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOERBQThELGlDQUFpQztBQUMvRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQSxXQUFXLGNBQWM7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBO0FBQ0EsV0FBVyxvQkFBb0I7QUFDL0IsV0FBVyxRQUFRO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CO0FBQ3BCO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUI7Ozs7Ozs7VUNoVG5CO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7Ozs7VUV0QkE7VUFDQTtVQUNBO1VBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jb21mb3J0YWJsZS1wYW5kYS8uL25vZGVfbW9kdWxlcy9tdXN0YWNoZS9tdXN0YWNoZS5qcyIsIndlYnBhY2s6Ly9jb21mb3J0YWJsZS1wYW5kYS8uL3NyYy9jb250ZW50X3NjcmlwdC50cyIsIndlYnBhY2s6Ly9jb21mb3J0YWJsZS1wYW5kYS8uL3NyYy9kb20udHMiLCJ3ZWJwYWNrOi8vY29tZm9ydGFibGUtcGFuZGEvLi9zcmMvZXZlbnRMaXN0ZW5lci50cyIsIndlYnBhY2s6Ly9jb21mb3J0YWJsZS1wYW5kYS8uL3NyYy9mYXZvcml0ZXMudHMiLCJ3ZWJwYWNrOi8vY29tZm9ydGFibGUtcGFuZGEvLi9zcmMvbWluaXNha2FpLnRzIiwid2VicGFjazovL2NvbWZvcnRhYmxlLXBhbmRhLy4vc3JjL21vZGVsLnRzIiwid2VicGFjazovL2NvbWZvcnRhYmxlLXBhbmRhLy4vc3JjL25ldHdvcmsudHMiLCJ3ZWJwYWNrOi8vY29tZm9ydGFibGUtcGFuZGEvLi9zcmMvc2V0dGluZ3MudHMiLCJ3ZWJwYWNrOi8vY29tZm9ydGFibGUtcGFuZGEvLi9zcmMvc3RvcmFnZS50cyIsIndlYnBhY2s6Ly9jb21mb3J0YWJsZS1wYW5kYS8uL3NyYy9zdWJzYWthaS50cyIsIndlYnBhY2s6Ly9jb21mb3J0YWJsZS1wYW5kYS8uL3NyYy91dGlscy50cyIsIndlYnBhY2s6Ly9jb21mb3J0YWJsZS1wYW5kYS93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9jb21mb3J0YWJsZS1wYW5kYS93ZWJwYWNrL2JlZm9yZS1zdGFydHVwIiwid2VicGFjazovL2NvbWZvcnRhYmxlLXBhbmRhL3dlYnBhY2svc3RhcnR1cCIsIndlYnBhY2s6Ly9jb21mb3J0YWJsZS1wYW5kYS93ZWJwYWNrL2FmdGVyLXN0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIChnbG9iYWwsIGZhY3RvcnkpIHtcbiAgdHlwZW9mIGV4cG9ydHMgPT09ICdvYmplY3QnICYmIHR5cGVvZiBtb2R1bGUgIT09ICd1bmRlZmluZWQnID8gbW9kdWxlLmV4cG9ydHMgPSBmYWN0b3J5KCkgOlxuICB0eXBlb2YgZGVmaW5lID09PSAnZnVuY3Rpb24nICYmIGRlZmluZS5hbWQgPyBkZWZpbmUoZmFjdG9yeSkgOlxuICAoZ2xvYmFsID0gZ2xvYmFsIHx8IHNlbGYsIGdsb2JhbC5NdXN0YWNoZSA9IGZhY3RvcnkoKSk7XG59KHRoaXMsIChmdW5jdGlvbiAoKSB7ICd1c2Ugc3RyaWN0JztcblxuICAvKiFcbiAgICogbXVzdGFjaGUuanMgLSBMb2dpYy1sZXNzIHt7bXVzdGFjaGV9fSB0ZW1wbGF0ZXMgd2l0aCBKYXZhU2NyaXB0XG4gICAqIGh0dHA6Ly9naXRodWIuY29tL2phbmwvbXVzdGFjaGUuanNcbiAgICovXG5cbiAgdmFyIG9iamVjdFRvU3RyaW5nID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZztcbiAgdmFyIGlzQXJyYXkgPSBBcnJheS5pc0FycmF5IHx8IGZ1bmN0aW9uIGlzQXJyYXlQb2x5ZmlsbCAob2JqZWN0KSB7XG4gICAgcmV0dXJuIG9iamVjdFRvU3RyaW5nLmNhbGwob2JqZWN0KSA9PT0gJ1tvYmplY3QgQXJyYXldJztcbiAgfTtcblxuICBmdW5jdGlvbiBpc0Z1bmN0aW9uIChvYmplY3QpIHtcbiAgICByZXR1cm4gdHlwZW9mIG9iamVjdCA9PT0gJ2Z1bmN0aW9uJztcbiAgfVxuXG4gIC8qKlxuICAgKiBNb3JlIGNvcnJlY3QgdHlwZW9mIHN0cmluZyBoYW5kbGluZyBhcnJheVxuICAgKiB3aGljaCBub3JtYWxseSByZXR1cm5zIHR5cGVvZiAnb2JqZWN0J1xuICAgKi9cbiAgZnVuY3Rpb24gdHlwZVN0ciAob2JqKSB7XG4gICAgcmV0dXJuIGlzQXJyYXkob2JqKSA/ICdhcnJheScgOiB0eXBlb2Ygb2JqO1xuICB9XG5cbiAgZnVuY3Rpb24gZXNjYXBlUmVnRXhwIChzdHJpbmcpIHtcbiAgICByZXR1cm4gc3RyaW5nLnJlcGxhY2UoL1tcXC1cXFtcXF17fSgpKis/LixcXFxcXFxeJHwjXFxzXS9nLCAnXFxcXCQmJyk7XG4gIH1cblxuICAvKipcbiAgICogTnVsbCBzYWZlIHdheSBvZiBjaGVja2luZyB3aGV0aGVyIG9yIG5vdCBhbiBvYmplY3QsXG4gICAqIGluY2x1ZGluZyBpdHMgcHJvdG90eXBlLCBoYXMgYSBnaXZlbiBwcm9wZXJ0eVxuICAgKi9cbiAgZnVuY3Rpb24gaGFzUHJvcGVydHkgKG9iaiwgcHJvcE5hbWUpIHtcbiAgICByZXR1cm4gb2JqICE9IG51bGwgJiYgdHlwZW9mIG9iaiA9PT0gJ29iamVjdCcgJiYgKHByb3BOYW1lIGluIG9iaik7XG4gIH1cblxuICAvKipcbiAgICogU2FmZSB3YXkgb2YgZGV0ZWN0aW5nIHdoZXRoZXIgb3Igbm90IHRoZSBnaXZlbiB0aGluZyBpcyBhIHByaW1pdGl2ZSBhbmRcbiAgICogd2hldGhlciBpdCBoYXMgdGhlIGdpdmVuIHByb3BlcnR5XG4gICAqL1xuICBmdW5jdGlvbiBwcmltaXRpdmVIYXNPd25Qcm9wZXJ0eSAocHJpbWl0aXZlLCBwcm9wTmFtZSkge1xuICAgIHJldHVybiAoXG4gICAgICBwcmltaXRpdmUgIT0gbnVsbFxuICAgICAgJiYgdHlwZW9mIHByaW1pdGl2ZSAhPT0gJ29iamVjdCdcbiAgICAgICYmIHByaW1pdGl2ZS5oYXNPd25Qcm9wZXJ0eVxuICAgICAgJiYgcHJpbWl0aXZlLmhhc093blByb3BlcnR5KHByb3BOYW1lKVxuICAgICk7XG4gIH1cblxuICAvLyBXb3JrYXJvdW5kIGZvciBodHRwczovL2lzc3Vlcy5hcGFjaGUub3JnL2ppcmEvYnJvd3NlL0NPVUNIREItNTc3XG4gIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vamFubC9tdXN0YWNoZS5qcy9pc3N1ZXMvMTg5XG4gIHZhciByZWdFeHBUZXN0ID0gUmVnRXhwLnByb3RvdHlwZS50ZXN0O1xuICBmdW5jdGlvbiB0ZXN0UmVnRXhwIChyZSwgc3RyaW5nKSB7XG4gICAgcmV0dXJuIHJlZ0V4cFRlc3QuY2FsbChyZSwgc3RyaW5nKTtcbiAgfVxuXG4gIHZhciBub25TcGFjZVJlID0gL1xcUy87XG4gIGZ1bmN0aW9uIGlzV2hpdGVzcGFjZSAoc3RyaW5nKSB7XG4gICAgcmV0dXJuICF0ZXN0UmVnRXhwKG5vblNwYWNlUmUsIHN0cmluZyk7XG4gIH1cblxuICB2YXIgZW50aXR5TWFwID0ge1xuICAgICcmJzogJyZhbXA7JyxcbiAgICAnPCc6ICcmbHQ7JyxcbiAgICAnPic6ICcmZ3Q7JyxcbiAgICAnXCInOiAnJnF1b3Q7JyxcbiAgICBcIidcIjogJyYjMzk7JyxcbiAgICAnLyc6ICcmI3gyRjsnLFxuICAgICdgJzogJyYjeDYwOycsXG4gICAgJz0nOiAnJiN4M0Q7J1xuICB9O1xuXG4gIGZ1bmN0aW9uIGVzY2FwZUh0bWwgKHN0cmluZykge1xuICAgIHJldHVybiBTdHJpbmcoc3RyaW5nKS5yZXBsYWNlKC9bJjw+XCInYD1cXC9dL2csIGZ1bmN0aW9uIGZyb21FbnRpdHlNYXAgKHMpIHtcbiAgICAgIHJldHVybiBlbnRpdHlNYXBbc107XG4gICAgfSk7XG4gIH1cblxuICB2YXIgd2hpdGVSZSA9IC9cXHMqLztcbiAgdmFyIHNwYWNlUmUgPSAvXFxzKy87XG4gIHZhciBlcXVhbHNSZSA9IC9cXHMqPS87XG4gIHZhciBjdXJseVJlID0gL1xccypcXH0vO1xuICB2YXIgdGFnUmUgPSAvI3xcXF58XFwvfD58XFx7fCZ8PXwhLztcblxuICAvKipcbiAgICogQnJlYWtzIHVwIHRoZSBnaXZlbiBgdGVtcGxhdGVgIHN0cmluZyBpbnRvIGEgdHJlZSBvZiB0b2tlbnMuIElmIHRoZSBgdGFnc2BcbiAgICogYXJndW1lbnQgaXMgZ2l2ZW4gaGVyZSBpdCBtdXN0IGJlIGFuIGFycmF5IHdpdGggdHdvIHN0cmluZyB2YWx1ZXM6IHRoZVxuICAgKiBvcGVuaW5nIGFuZCBjbG9zaW5nIHRhZ3MgdXNlZCBpbiB0aGUgdGVtcGxhdGUgKGUuZy4gWyBcIjwlXCIsIFwiJT5cIiBdKS4gT2ZcbiAgICogY291cnNlLCB0aGUgZGVmYXVsdCBpcyB0byB1c2UgbXVzdGFjaGVzIChpLmUuIG11c3RhY2hlLnRhZ3MpLlxuICAgKlxuICAgKiBBIHRva2VuIGlzIGFuIGFycmF5IHdpdGggYXQgbGVhc3QgNCBlbGVtZW50cy4gVGhlIGZpcnN0IGVsZW1lbnQgaXMgdGhlXG4gICAqIG11c3RhY2hlIHN5bWJvbCB0aGF0IHdhcyB1c2VkIGluc2lkZSB0aGUgdGFnLCBlLmcuIFwiI1wiIG9yIFwiJlwiLiBJZiB0aGUgdGFnXG4gICAqIGRpZCBub3QgY29udGFpbiBhIHN5bWJvbCAoaS5lLiB7e215VmFsdWV9fSkgdGhpcyBlbGVtZW50IGlzIFwibmFtZVwiLiBGb3JcbiAgICogYWxsIHRleHQgdGhhdCBhcHBlYXJzIG91dHNpZGUgYSBzeW1ib2wgdGhpcyBlbGVtZW50IGlzIFwidGV4dFwiLlxuICAgKlxuICAgKiBUaGUgc2Vjb25kIGVsZW1lbnQgb2YgYSB0b2tlbiBpcyBpdHMgXCJ2YWx1ZVwiLiBGb3IgbXVzdGFjaGUgdGFncyB0aGlzIGlzXG4gICAqIHdoYXRldmVyIGVsc2Ugd2FzIGluc2lkZSB0aGUgdGFnIGJlc2lkZXMgdGhlIG9wZW5pbmcgc3ltYm9sLiBGb3IgdGV4dCB0b2tlbnNcbiAgICogdGhpcyBpcyB0aGUgdGV4dCBpdHNlbGYuXG4gICAqXG4gICAqIFRoZSB0aGlyZCBhbmQgZm91cnRoIGVsZW1lbnRzIG9mIHRoZSB0b2tlbiBhcmUgdGhlIHN0YXJ0IGFuZCBlbmQgaW5kaWNlcyxcbiAgICogcmVzcGVjdGl2ZWx5LCBvZiB0aGUgdG9rZW4gaW4gdGhlIG9yaWdpbmFsIHRlbXBsYXRlLlxuICAgKlxuICAgKiBUb2tlbnMgdGhhdCBhcmUgdGhlIHJvb3Qgbm9kZSBvZiBhIHN1YnRyZWUgY29udGFpbiB0d28gbW9yZSBlbGVtZW50czogMSkgYW5cbiAgICogYXJyYXkgb2YgdG9rZW5zIGluIHRoZSBzdWJ0cmVlIGFuZCAyKSB0aGUgaW5kZXggaW4gdGhlIG9yaWdpbmFsIHRlbXBsYXRlIGF0XG4gICAqIHdoaWNoIHRoZSBjbG9zaW5nIHRhZyBmb3IgdGhhdCBzZWN0aW9uIGJlZ2lucy5cbiAgICpcbiAgICogVG9rZW5zIGZvciBwYXJ0aWFscyBhbHNvIGNvbnRhaW4gdHdvIG1vcmUgZWxlbWVudHM6IDEpIGEgc3RyaW5nIHZhbHVlIG9mXG4gICAqIGluZGVuZGF0aW9uIHByaW9yIHRvIHRoYXQgdGFnIGFuZCAyKSB0aGUgaW5kZXggb2YgdGhhdCB0YWcgb24gdGhhdCBsaW5lIC1cbiAgICogZWcgYSB2YWx1ZSBvZiAyIGluZGljYXRlcyB0aGUgcGFydGlhbCBpcyB0aGUgdGhpcmQgdGFnIG9uIHRoaXMgbGluZS5cbiAgICovXG4gIGZ1bmN0aW9uIHBhcnNlVGVtcGxhdGUgKHRlbXBsYXRlLCB0YWdzKSB7XG4gICAgaWYgKCF0ZW1wbGF0ZSlcbiAgICAgIHJldHVybiBbXTtcbiAgICB2YXIgbGluZUhhc05vblNwYWNlID0gZmFsc2U7XG4gICAgdmFyIHNlY3Rpb25zID0gW107ICAgICAvLyBTdGFjayB0byBob2xkIHNlY3Rpb24gdG9rZW5zXG4gICAgdmFyIHRva2VucyA9IFtdOyAgICAgICAvLyBCdWZmZXIgdG8gaG9sZCB0aGUgdG9rZW5zXG4gICAgdmFyIHNwYWNlcyA9IFtdOyAgICAgICAvLyBJbmRpY2VzIG9mIHdoaXRlc3BhY2UgdG9rZW5zIG9uIHRoZSBjdXJyZW50IGxpbmVcbiAgICB2YXIgaGFzVGFnID0gZmFsc2U7ICAgIC8vIElzIHRoZXJlIGEge3t0YWd9fSBvbiB0aGUgY3VycmVudCBsaW5lP1xuICAgIHZhciBub25TcGFjZSA9IGZhbHNlOyAgLy8gSXMgdGhlcmUgYSBub24tc3BhY2UgY2hhciBvbiB0aGUgY3VycmVudCBsaW5lP1xuICAgIHZhciBpbmRlbnRhdGlvbiA9ICcnOyAgLy8gVHJhY2tzIGluZGVudGF0aW9uIGZvciB0YWdzIHRoYXQgdXNlIGl0XG4gICAgdmFyIHRhZ0luZGV4ID0gMDsgICAgICAvLyBTdG9yZXMgYSBjb3VudCBvZiBudW1iZXIgb2YgdGFncyBlbmNvdW50ZXJlZCBvbiBhIGxpbmVcblxuICAgIC8vIFN0cmlwcyBhbGwgd2hpdGVzcGFjZSB0b2tlbnMgYXJyYXkgZm9yIHRoZSBjdXJyZW50IGxpbmVcbiAgICAvLyBpZiB0aGVyZSB3YXMgYSB7eyN0YWd9fSBvbiBpdCBhbmQgb3RoZXJ3aXNlIG9ubHkgc3BhY2UuXG4gICAgZnVuY3Rpb24gc3RyaXBTcGFjZSAoKSB7XG4gICAgICBpZiAoaGFzVGFnICYmICFub25TcGFjZSkge1xuICAgICAgICB3aGlsZSAoc3BhY2VzLmxlbmd0aClcbiAgICAgICAgICBkZWxldGUgdG9rZW5zW3NwYWNlcy5wb3AoKV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzcGFjZXMgPSBbXTtcbiAgICAgIH1cblxuICAgICAgaGFzVGFnID0gZmFsc2U7XG4gICAgICBub25TcGFjZSA9IGZhbHNlO1xuICAgIH1cblxuICAgIHZhciBvcGVuaW5nVGFnUmUsIGNsb3NpbmdUYWdSZSwgY2xvc2luZ0N1cmx5UmU7XG4gICAgZnVuY3Rpb24gY29tcGlsZVRhZ3MgKHRhZ3NUb0NvbXBpbGUpIHtcbiAgICAgIGlmICh0eXBlb2YgdGFnc1RvQ29tcGlsZSA9PT0gJ3N0cmluZycpXG4gICAgICAgIHRhZ3NUb0NvbXBpbGUgPSB0YWdzVG9Db21waWxlLnNwbGl0KHNwYWNlUmUsIDIpO1xuXG4gICAgICBpZiAoIWlzQXJyYXkodGFnc1RvQ29tcGlsZSkgfHwgdGFnc1RvQ29tcGlsZS5sZW5ndGggIT09IDIpXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCB0YWdzOiAnICsgdGFnc1RvQ29tcGlsZSk7XG5cbiAgICAgIG9wZW5pbmdUYWdSZSA9IG5ldyBSZWdFeHAoZXNjYXBlUmVnRXhwKHRhZ3NUb0NvbXBpbGVbMF0pICsgJ1xcXFxzKicpO1xuICAgICAgY2xvc2luZ1RhZ1JlID0gbmV3IFJlZ0V4cCgnXFxcXHMqJyArIGVzY2FwZVJlZ0V4cCh0YWdzVG9Db21waWxlWzFdKSk7XG4gICAgICBjbG9zaW5nQ3VybHlSZSA9IG5ldyBSZWdFeHAoJ1xcXFxzKicgKyBlc2NhcGVSZWdFeHAoJ30nICsgdGFnc1RvQ29tcGlsZVsxXSkpO1xuICAgIH1cblxuICAgIGNvbXBpbGVUYWdzKHRhZ3MgfHwgbXVzdGFjaGUudGFncyk7XG5cbiAgICB2YXIgc2Nhbm5lciA9IG5ldyBTY2FubmVyKHRlbXBsYXRlKTtcblxuICAgIHZhciBzdGFydCwgdHlwZSwgdmFsdWUsIGNociwgdG9rZW4sIG9wZW5TZWN0aW9uO1xuICAgIHdoaWxlICghc2Nhbm5lci5lb3MoKSkge1xuICAgICAgc3RhcnQgPSBzY2FubmVyLnBvcztcblxuICAgICAgLy8gTWF0Y2ggYW55IHRleHQgYmV0d2VlbiB0YWdzLlxuICAgICAgdmFsdWUgPSBzY2FubmVyLnNjYW5VbnRpbChvcGVuaW5nVGFnUmUpO1xuXG4gICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDAsIHZhbHVlTGVuZ3RoID0gdmFsdWUubGVuZ3RoOyBpIDwgdmFsdWVMZW5ndGg7ICsraSkge1xuICAgICAgICAgIGNociA9IHZhbHVlLmNoYXJBdChpKTtcblxuICAgICAgICAgIGlmIChpc1doaXRlc3BhY2UoY2hyKSkge1xuICAgICAgICAgICAgc3BhY2VzLnB1c2godG9rZW5zLmxlbmd0aCk7XG4gICAgICAgICAgICBpbmRlbnRhdGlvbiArPSBjaHI7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5vblNwYWNlID0gdHJ1ZTtcbiAgICAgICAgICAgIGxpbmVIYXNOb25TcGFjZSA9IHRydWU7XG4gICAgICAgICAgICBpbmRlbnRhdGlvbiArPSAnICc7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgdG9rZW5zLnB1c2goWyAndGV4dCcsIGNociwgc3RhcnQsIHN0YXJ0ICsgMSBdKTtcbiAgICAgICAgICBzdGFydCArPSAxO1xuXG4gICAgICAgICAgLy8gQ2hlY2sgZm9yIHdoaXRlc3BhY2Ugb24gdGhlIGN1cnJlbnQgbGluZS5cbiAgICAgICAgICBpZiAoY2hyID09PSAnXFxuJykge1xuICAgICAgICAgICAgc3RyaXBTcGFjZSgpO1xuICAgICAgICAgICAgaW5kZW50YXRpb24gPSAnJztcbiAgICAgICAgICAgIHRhZ0luZGV4ID0gMDtcbiAgICAgICAgICAgIGxpbmVIYXNOb25TcGFjZSA9IGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBNYXRjaCB0aGUgb3BlbmluZyB0YWcuXG4gICAgICBpZiAoIXNjYW5uZXIuc2NhbihvcGVuaW5nVGFnUmUpKVxuICAgICAgICBicmVhaztcblxuICAgICAgaGFzVGFnID0gdHJ1ZTtcblxuICAgICAgLy8gR2V0IHRoZSB0YWcgdHlwZS5cbiAgICAgIHR5cGUgPSBzY2FubmVyLnNjYW4odGFnUmUpIHx8ICduYW1lJztcbiAgICAgIHNjYW5uZXIuc2Nhbih3aGl0ZVJlKTtcblxuICAgICAgLy8gR2V0IHRoZSB0YWcgdmFsdWUuXG4gICAgICBpZiAodHlwZSA9PT0gJz0nKSB7XG4gICAgICAgIHZhbHVlID0gc2Nhbm5lci5zY2FuVW50aWwoZXF1YWxzUmUpO1xuICAgICAgICBzY2FubmVyLnNjYW4oZXF1YWxzUmUpO1xuICAgICAgICBzY2FubmVyLnNjYW5VbnRpbChjbG9zaW5nVGFnUmUpO1xuICAgICAgfSBlbHNlIGlmICh0eXBlID09PSAneycpIHtcbiAgICAgICAgdmFsdWUgPSBzY2FubmVyLnNjYW5VbnRpbChjbG9zaW5nQ3VybHlSZSk7XG4gICAgICAgIHNjYW5uZXIuc2NhbihjdXJseVJlKTtcbiAgICAgICAgc2Nhbm5lci5zY2FuVW50aWwoY2xvc2luZ1RhZ1JlKTtcbiAgICAgICAgdHlwZSA9ICcmJztcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhbHVlID0gc2Nhbm5lci5zY2FuVW50aWwoY2xvc2luZ1RhZ1JlKTtcbiAgICAgIH1cblxuICAgICAgLy8gTWF0Y2ggdGhlIGNsb3NpbmcgdGFnLlxuICAgICAgaWYgKCFzY2FubmVyLnNjYW4oY2xvc2luZ1RhZ1JlKSlcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmNsb3NlZCB0YWcgYXQgJyArIHNjYW5uZXIucG9zKTtcblxuICAgICAgaWYgKHR5cGUgPT0gJz4nKSB7XG4gICAgICAgIHRva2VuID0gWyB0eXBlLCB2YWx1ZSwgc3RhcnQsIHNjYW5uZXIucG9zLCBpbmRlbnRhdGlvbiwgdGFnSW5kZXgsIGxpbmVIYXNOb25TcGFjZSBdO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdG9rZW4gPSBbIHR5cGUsIHZhbHVlLCBzdGFydCwgc2Nhbm5lci5wb3MgXTtcbiAgICAgIH1cbiAgICAgIHRhZ0luZGV4Kys7XG4gICAgICB0b2tlbnMucHVzaCh0b2tlbik7XG5cbiAgICAgIGlmICh0eXBlID09PSAnIycgfHwgdHlwZSA9PT0gJ14nKSB7XG4gICAgICAgIHNlY3Rpb25zLnB1c2godG9rZW4pO1xuICAgICAgfSBlbHNlIGlmICh0eXBlID09PSAnLycpIHtcbiAgICAgICAgLy8gQ2hlY2sgc2VjdGlvbiBuZXN0aW5nLlxuICAgICAgICBvcGVuU2VjdGlvbiA9IHNlY3Rpb25zLnBvcCgpO1xuXG4gICAgICAgIGlmICghb3BlblNlY3Rpb24pXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbm9wZW5lZCBzZWN0aW9uIFwiJyArIHZhbHVlICsgJ1wiIGF0ICcgKyBzdGFydCk7XG5cbiAgICAgICAgaWYgKG9wZW5TZWN0aW9uWzFdICE9PSB2YWx1ZSlcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuY2xvc2VkIHNlY3Rpb24gXCInICsgb3BlblNlY3Rpb25bMV0gKyAnXCIgYXQgJyArIHN0YXJ0KTtcbiAgICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ25hbWUnIHx8IHR5cGUgPT09ICd7JyB8fCB0eXBlID09PSAnJicpIHtcbiAgICAgICAgbm9uU3BhY2UgPSB0cnVlO1xuICAgICAgfSBlbHNlIGlmICh0eXBlID09PSAnPScpIHtcbiAgICAgICAgLy8gU2V0IHRoZSB0YWdzIGZvciB0aGUgbmV4dCB0aW1lIGFyb3VuZC5cbiAgICAgICAgY29tcGlsZVRhZ3ModmFsdWUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHN0cmlwU3BhY2UoKTtcblxuICAgIC8vIE1ha2Ugc3VyZSB0aGVyZSBhcmUgbm8gb3BlbiBzZWN0aW9ucyB3aGVuIHdlJ3JlIGRvbmUuXG4gICAgb3BlblNlY3Rpb24gPSBzZWN0aW9ucy5wb3AoKTtcblxuICAgIGlmIChvcGVuU2VjdGlvbilcbiAgICAgIHRocm93IG5ldyBFcnJvcignVW5jbG9zZWQgc2VjdGlvbiBcIicgKyBvcGVuU2VjdGlvblsxXSArICdcIiBhdCAnICsgc2Nhbm5lci5wb3MpO1xuXG4gICAgcmV0dXJuIG5lc3RUb2tlbnMoc3F1YXNoVG9rZW5zKHRva2VucykpO1xuICB9XG5cbiAgLyoqXG4gICAqIENvbWJpbmVzIHRoZSB2YWx1ZXMgb2YgY29uc2VjdXRpdmUgdGV4dCB0b2tlbnMgaW4gdGhlIGdpdmVuIGB0b2tlbnNgIGFycmF5XG4gICAqIHRvIGEgc2luZ2xlIHRva2VuLlxuICAgKi9cbiAgZnVuY3Rpb24gc3F1YXNoVG9rZW5zICh0b2tlbnMpIHtcbiAgICB2YXIgc3F1YXNoZWRUb2tlbnMgPSBbXTtcblxuICAgIHZhciB0b2tlbiwgbGFzdFRva2VuO1xuICAgIGZvciAodmFyIGkgPSAwLCBudW1Ub2tlbnMgPSB0b2tlbnMubGVuZ3RoOyBpIDwgbnVtVG9rZW5zOyArK2kpIHtcbiAgICAgIHRva2VuID0gdG9rZW5zW2ldO1xuXG4gICAgICBpZiAodG9rZW4pIHtcbiAgICAgICAgaWYgKHRva2VuWzBdID09PSAndGV4dCcgJiYgbGFzdFRva2VuICYmIGxhc3RUb2tlblswXSA9PT0gJ3RleHQnKSB7XG4gICAgICAgICAgbGFzdFRva2VuWzFdICs9IHRva2VuWzFdO1xuICAgICAgICAgIGxhc3RUb2tlblszXSA9IHRva2VuWzNdO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNxdWFzaGVkVG9rZW5zLnB1c2godG9rZW4pO1xuICAgICAgICAgIGxhc3RUb2tlbiA9IHRva2VuO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHNxdWFzaGVkVG9rZW5zO1xuICB9XG5cbiAgLyoqXG4gICAqIEZvcm1zIHRoZSBnaXZlbiBhcnJheSBvZiBgdG9rZW5zYCBpbnRvIGEgbmVzdGVkIHRyZWUgc3RydWN0dXJlIHdoZXJlXG4gICAqIHRva2VucyB0aGF0IHJlcHJlc2VudCBhIHNlY3Rpb24gaGF2ZSB0d28gYWRkaXRpb25hbCBpdGVtczogMSkgYW4gYXJyYXkgb2ZcbiAgICogYWxsIHRva2VucyB0aGF0IGFwcGVhciBpbiB0aGF0IHNlY3Rpb24gYW5kIDIpIHRoZSBpbmRleCBpbiB0aGUgb3JpZ2luYWxcbiAgICogdGVtcGxhdGUgdGhhdCByZXByZXNlbnRzIHRoZSBlbmQgb2YgdGhhdCBzZWN0aW9uLlxuICAgKi9cbiAgZnVuY3Rpb24gbmVzdFRva2VucyAodG9rZW5zKSB7XG4gICAgdmFyIG5lc3RlZFRva2VucyA9IFtdO1xuICAgIHZhciBjb2xsZWN0b3IgPSBuZXN0ZWRUb2tlbnM7XG4gICAgdmFyIHNlY3Rpb25zID0gW107XG5cbiAgICB2YXIgdG9rZW4sIHNlY3Rpb247XG4gICAgZm9yICh2YXIgaSA9IDAsIG51bVRva2VucyA9IHRva2Vucy5sZW5ndGg7IGkgPCBudW1Ub2tlbnM7ICsraSkge1xuICAgICAgdG9rZW4gPSB0b2tlbnNbaV07XG5cbiAgICAgIHN3aXRjaCAodG9rZW5bMF0pIHtcbiAgICAgICAgY2FzZSAnIyc6XG4gICAgICAgIGNhc2UgJ14nOlxuICAgICAgICAgIGNvbGxlY3Rvci5wdXNoKHRva2VuKTtcbiAgICAgICAgICBzZWN0aW9ucy5wdXNoKHRva2VuKTtcbiAgICAgICAgICBjb2xsZWN0b3IgPSB0b2tlbls0XSA9IFtdO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICcvJzpcbiAgICAgICAgICBzZWN0aW9uID0gc2VjdGlvbnMucG9wKCk7XG4gICAgICAgICAgc2VjdGlvbls1XSA9IHRva2VuWzJdO1xuICAgICAgICAgIGNvbGxlY3RvciA9IHNlY3Rpb25zLmxlbmd0aCA+IDAgPyBzZWN0aW9uc1tzZWN0aW9ucy5sZW5ndGggLSAxXVs0XSA6IG5lc3RlZFRva2VucztcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICBjb2xsZWN0b3IucHVzaCh0b2tlbik7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5lc3RlZFRva2VucztcbiAgfVxuXG4gIC8qKlxuICAgKiBBIHNpbXBsZSBzdHJpbmcgc2Nhbm5lciB0aGF0IGlzIHVzZWQgYnkgdGhlIHRlbXBsYXRlIHBhcnNlciB0byBmaW5kXG4gICAqIHRva2VucyBpbiB0ZW1wbGF0ZSBzdHJpbmdzLlxuICAgKi9cbiAgZnVuY3Rpb24gU2Nhbm5lciAoc3RyaW5nKSB7XG4gICAgdGhpcy5zdHJpbmcgPSBzdHJpbmc7XG4gICAgdGhpcy50YWlsID0gc3RyaW5nO1xuICAgIHRoaXMucG9zID0gMDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgdGFpbCBpcyBlbXB0eSAoZW5kIG9mIHN0cmluZykuXG4gICAqL1xuICBTY2FubmVyLnByb3RvdHlwZS5lb3MgPSBmdW5jdGlvbiBlb3MgKCkge1xuICAgIHJldHVybiB0aGlzLnRhaWwgPT09ICcnO1xuICB9O1xuXG4gIC8qKlxuICAgKiBUcmllcyB0byBtYXRjaCB0aGUgZ2l2ZW4gcmVndWxhciBleHByZXNzaW9uIGF0IHRoZSBjdXJyZW50IHBvc2l0aW9uLlxuICAgKiBSZXR1cm5zIHRoZSBtYXRjaGVkIHRleHQgaWYgaXQgY2FuIG1hdGNoLCB0aGUgZW1wdHkgc3RyaW5nIG90aGVyd2lzZS5cbiAgICovXG4gIFNjYW5uZXIucHJvdG90eXBlLnNjYW4gPSBmdW5jdGlvbiBzY2FuIChyZSkge1xuICAgIHZhciBtYXRjaCA9IHRoaXMudGFpbC5tYXRjaChyZSk7XG5cbiAgICBpZiAoIW1hdGNoIHx8IG1hdGNoLmluZGV4ICE9PSAwKVxuICAgICAgcmV0dXJuICcnO1xuXG4gICAgdmFyIHN0cmluZyA9IG1hdGNoWzBdO1xuXG4gICAgdGhpcy50YWlsID0gdGhpcy50YWlsLnN1YnN0cmluZyhzdHJpbmcubGVuZ3RoKTtcbiAgICB0aGlzLnBvcyArPSBzdHJpbmcubGVuZ3RoO1xuXG4gICAgcmV0dXJuIHN0cmluZztcbiAgfTtcblxuICAvKipcbiAgICogU2tpcHMgYWxsIHRleHQgdW50aWwgdGhlIGdpdmVuIHJlZ3VsYXIgZXhwcmVzc2lvbiBjYW4gYmUgbWF0Y2hlZC4gUmV0dXJuc1xuICAgKiB0aGUgc2tpcHBlZCBzdHJpbmcsIHdoaWNoIGlzIHRoZSBlbnRpcmUgdGFpbCBpZiBubyBtYXRjaCBjYW4gYmUgbWFkZS5cbiAgICovXG4gIFNjYW5uZXIucHJvdG90eXBlLnNjYW5VbnRpbCA9IGZ1bmN0aW9uIHNjYW5VbnRpbCAocmUpIHtcbiAgICB2YXIgaW5kZXggPSB0aGlzLnRhaWwuc2VhcmNoKHJlKSwgbWF0Y2g7XG5cbiAgICBzd2l0Y2ggKGluZGV4KSB7XG4gICAgICBjYXNlIC0xOlxuICAgICAgICBtYXRjaCA9IHRoaXMudGFpbDtcbiAgICAgICAgdGhpcy50YWlsID0gJyc7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAwOlxuICAgICAgICBtYXRjaCA9ICcnO1xuICAgICAgICBicmVhaztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIG1hdGNoID0gdGhpcy50YWlsLnN1YnN0cmluZygwLCBpbmRleCk7XG4gICAgICAgIHRoaXMudGFpbCA9IHRoaXMudGFpbC5zdWJzdHJpbmcoaW5kZXgpO1xuICAgIH1cblxuICAgIHRoaXMucG9zICs9IG1hdGNoLmxlbmd0aDtcblxuICAgIHJldHVybiBtYXRjaDtcbiAgfTtcblxuICAvKipcbiAgICogUmVwcmVzZW50cyBhIHJlbmRlcmluZyBjb250ZXh0IGJ5IHdyYXBwaW5nIGEgdmlldyBvYmplY3QgYW5kXG4gICAqIG1haW50YWluaW5nIGEgcmVmZXJlbmNlIHRvIHRoZSBwYXJlbnQgY29udGV4dC5cbiAgICovXG4gIGZ1bmN0aW9uIENvbnRleHQgKHZpZXcsIHBhcmVudENvbnRleHQpIHtcbiAgICB0aGlzLnZpZXcgPSB2aWV3O1xuICAgIHRoaXMuY2FjaGUgPSB7ICcuJzogdGhpcy52aWV3IH07XG4gICAgdGhpcy5wYXJlbnQgPSBwYXJlbnRDb250ZXh0O1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgY29udGV4dCB1c2luZyB0aGUgZ2l2ZW4gdmlldyB3aXRoIHRoaXMgY29udGV4dFxuICAgKiBhcyB0aGUgcGFyZW50LlxuICAgKi9cbiAgQ29udGV4dC5wcm90b3R5cGUucHVzaCA9IGZ1bmN0aW9uIHB1c2ggKHZpZXcpIHtcbiAgICByZXR1cm4gbmV3IENvbnRleHQodmlldywgdGhpcyk7XG4gIH07XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHZhbHVlIG9mIHRoZSBnaXZlbiBuYW1lIGluIHRoaXMgY29udGV4dCwgdHJhdmVyc2luZ1xuICAgKiB1cCB0aGUgY29udGV4dCBoaWVyYXJjaHkgaWYgdGhlIHZhbHVlIGlzIGFic2VudCBpbiB0aGlzIGNvbnRleHQncyB2aWV3LlxuICAgKi9cbiAgQ29udGV4dC5wcm90b3R5cGUubG9va3VwID0gZnVuY3Rpb24gbG9va3VwIChuYW1lKSB7XG4gICAgdmFyIGNhY2hlID0gdGhpcy5jYWNoZTtcblxuICAgIHZhciB2YWx1ZTtcbiAgICBpZiAoY2FjaGUuaGFzT3duUHJvcGVydHkobmFtZSkpIHtcbiAgICAgIHZhbHVlID0gY2FjaGVbbmFtZV07XG4gICAgfSBlbHNlIHtcbiAgICAgIHZhciBjb250ZXh0ID0gdGhpcywgaW50ZXJtZWRpYXRlVmFsdWUsIG5hbWVzLCBpbmRleCwgbG9va3VwSGl0ID0gZmFsc2U7XG5cbiAgICAgIHdoaWxlIChjb250ZXh0KSB7XG4gICAgICAgIGlmIChuYW1lLmluZGV4T2YoJy4nKSA+IDApIHtcbiAgICAgICAgICBpbnRlcm1lZGlhdGVWYWx1ZSA9IGNvbnRleHQudmlldztcbiAgICAgICAgICBuYW1lcyA9IG5hbWUuc3BsaXQoJy4nKTtcbiAgICAgICAgICBpbmRleCA9IDA7XG5cbiAgICAgICAgICAvKipcbiAgICAgICAgICAgKiBVc2luZyB0aGUgZG90IG5vdGlvbiBwYXRoIGluIGBuYW1lYCwgd2UgZGVzY2VuZCB0aHJvdWdoIHRoZVxuICAgICAgICAgICAqIG5lc3RlZCBvYmplY3RzLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogVG8gYmUgY2VydGFpbiB0aGF0IHRoZSBsb29rdXAgaGFzIGJlZW4gc3VjY2Vzc2Z1bCwgd2UgaGF2ZSB0b1xuICAgICAgICAgICAqIGNoZWNrIGlmIHRoZSBsYXN0IG9iamVjdCBpbiB0aGUgcGF0aCBhY3R1YWxseSBoYXMgdGhlIHByb3BlcnR5XG4gICAgICAgICAgICogd2UgYXJlIGxvb2tpbmcgZm9yLiBXZSBzdG9yZSB0aGUgcmVzdWx0IGluIGBsb29rdXBIaXRgLlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogVGhpcyBpcyBzcGVjaWFsbHkgbmVjZXNzYXJ5IGZvciB3aGVuIHRoZSB2YWx1ZSBoYXMgYmVlbiBzZXQgdG9cbiAgICAgICAgICAgKiBgdW5kZWZpbmVkYCBhbmQgd2Ugd2FudCB0byBhdm9pZCBsb29raW5nIHVwIHBhcmVudCBjb250ZXh0cy5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIEluIHRoZSBjYXNlIHdoZXJlIGRvdCBub3RhdGlvbiBpcyB1c2VkLCB3ZSBjb25zaWRlciB0aGUgbG9va3VwXG4gICAgICAgICAgICogdG8gYmUgc3VjY2Vzc2Z1bCBldmVuIGlmIHRoZSBsYXN0IFwib2JqZWN0XCIgaW4gdGhlIHBhdGggaXNcbiAgICAgICAgICAgKiBub3QgYWN0dWFsbHkgYW4gb2JqZWN0IGJ1dCBhIHByaW1pdGl2ZSAoZS5nLiwgYSBzdHJpbmcsIG9yIGFuXG4gICAgICAgICAgICogaW50ZWdlciksIGJlY2F1c2UgaXQgaXMgc29tZXRpbWVzIHVzZWZ1bCB0byBhY2Nlc3MgYSBwcm9wZXJ0eVxuICAgICAgICAgICAqIG9mIGFuIGF1dG9ib3hlZCBwcmltaXRpdmUsIHN1Y2ggYXMgdGhlIGxlbmd0aCBvZiBhIHN0cmluZy5cbiAgICAgICAgICAgKiovXG4gICAgICAgICAgd2hpbGUgKGludGVybWVkaWF0ZVZhbHVlICE9IG51bGwgJiYgaW5kZXggPCBuYW1lcy5sZW5ndGgpIHtcbiAgICAgICAgICAgIGlmIChpbmRleCA9PT0gbmFtZXMubGVuZ3RoIC0gMSlcbiAgICAgICAgICAgICAgbG9va3VwSGl0ID0gKFxuICAgICAgICAgICAgICAgIGhhc1Byb3BlcnR5KGludGVybWVkaWF0ZVZhbHVlLCBuYW1lc1tpbmRleF0pXG4gICAgICAgICAgICAgICAgfHwgcHJpbWl0aXZlSGFzT3duUHJvcGVydHkoaW50ZXJtZWRpYXRlVmFsdWUsIG5hbWVzW2luZGV4XSlcbiAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgaW50ZXJtZWRpYXRlVmFsdWUgPSBpbnRlcm1lZGlhdGVWYWx1ZVtuYW1lc1tpbmRleCsrXV07XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGludGVybWVkaWF0ZVZhbHVlID0gY29udGV4dC52aWV3W25hbWVdO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogT25seSBjaGVja2luZyBhZ2FpbnN0IGBoYXNQcm9wZXJ0eWAsIHdoaWNoIGFsd2F5cyByZXR1cm5zIGBmYWxzZWAgaWZcbiAgICAgICAgICAgKiBgY29udGV4dC52aWV3YCBpcyBub3QgYW4gb2JqZWN0LiBEZWxpYmVyYXRlbHkgb21pdHRpbmcgdGhlIGNoZWNrXG4gICAgICAgICAgICogYWdhaW5zdCBgcHJpbWl0aXZlSGFzT3duUHJvcGVydHlgIGlmIGRvdCBub3RhdGlvbiBpcyBub3QgdXNlZC5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIENvbnNpZGVyIHRoaXMgZXhhbXBsZTpcbiAgICAgICAgICAgKiBgYGBcbiAgICAgICAgICAgKiBNdXN0YWNoZS5yZW5kZXIoXCJUaGUgbGVuZ3RoIG9mIGEgZm9vdGJhbGwgZmllbGQgaXMge3sjbGVuZ3RofX17e2xlbmd0aH19e3svbGVuZ3RofX0uXCIsIHtsZW5ndGg6IFwiMTAwIHlhcmRzXCJ9KVxuICAgICAgICAgICAqIGBgYFxuICAgICAgICAgICAqXG4gICAgICAgICAgICogSWYgd2Ugd2VyZSB0byBjaGVjayBhbHNvIGFnYWluc3QgYHByaW1pdGl2ZUhhc093blByb3BlcnR5YCwgYXMgd2UgZG9cbiAgICAgICAgICAgKiBpbiB0aGUgZG90IG5vdGF0aW9uIGNhc2UsIHRoZW4gcmVuZGVyIGNhbGwgd291bGQgcmV0dXJuOlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogXCJUaGUgbGVuZ3RoIG9mIGEgZm9vdGJhbGwgZmllbGQgaXMgOS5cIlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogcmF0aGVyIHRoYW4gdGhlIGV4cGVjdGVkOlxuICAgICAgICAgICAqXG4gICAgICAgICAgICogXCJUaGUgbGVuZ3RoIG9mIGEgZm9vdGJhbGwgZmllbGQgaXMgMTAwIHlhcmRzLlwiXG4gICAgICAgICAgICoqL1xuICAgICAgICAgIGxvb2t1cEhpdCA9IGhhc1Byb3BlcnR5KGNvbnRleHQudmlldywgbmFtZSk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAobG9va3VwSGl0KSB7XG4gICAgICAgICAgdmFsdWUgPSBpbnRlcm1lZGlhdGVWYWx1ZTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnRleHQgPSBjb250ZXh0LnBhcmVudDtcbiAgICAgIH1cblxuICAgICAgY2FjaGVbbmFtZV0gPSB2YWx1ZTtcbiAgICB9XG5cbiAgICBpZiAoaXNGdW5jdGlvbih2YWx1ZSkpXG4gICAgICB2YWx1ZSA9IHZhbHVlLmNhbGwodGhpcy52aWV3KTtcblxuICAgIHJldHVybiB2YWx1ZTtcbiAgfTtcblxuICAvKipcbiAgICogQSBXcml0ZXIga25vd3MgaG93IHRvIHRha2UgYSBzdHJlYW0gb2YgdG9rZW5zIGFuZCByZW5kZXIgdGhlbSB0byBhXG4gICAqIHN0cmluZywgZ2l2ZW4gYSBjb250ZXh0LiBJdCBhbHNvIG1haW50YWlucyBhIGNhY2hlIG9mIHRlbXBsYXRlcyB0b1xuICAgKiBhdm9pZCB0aGUgbmVlZCB0byBwYXJzZSB0aGUgc2FtZSB0ZW1wbGF0ZSB0d2ljZS5cbiAgICovXG4gIGZ1bmN0aW9uIFdyaXRlciAoKSB7XG4gICAgdGhpcy50ZW1wbGF0ZUNhY2hlID0ge1xuICAgICAgX2NhY2hlOiB7fSxcbiAgICAgIHNldDogZnVuY3Rpb24gc2V0IChrZXksIHZhbHVlKSB7XG4gICAgICAgIHRoaXMuX2NhY2hlW2tleV0gPSB2YWx1ZTtcbiAgICAgIH0sXG4gICAgICBnZXQ6IGZ1bmN0aW9uIGdldCAoa2V5KSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jYWNoZVtrZXldO1xuICAgICAgfSxcbiAgICAgIGNsZWFyOiBmdW5jdGlvbiBjbGVhciAoKSB7XG4gICAgICAgIHRoaXMuX2NhY2hlID0ge307XG4gICAgICB9XG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDbGVhcnMgYWxsIGNhY2hlZCB0ZW1wbGF0ZXMgaW4gdGhpcyB3cml0ZXIuXG4gICAqL1xuICBXcml0ZXIucHJvdG90eXBlLmNsZWFyQ2FjaGUgPSBmdW5jdGlvbiBjbGVhckNhY2hlICgpIHtcbiAgICBpZiAodHlwZW9mIHRoaXMudGVtcGxhdGVDYWNoZSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHRoaXMudGVtcGxhdGVDYWNoZS5jbGVhcigpO1xuICAgIH1cbiAgfTtcblxuICAvKipcbiAgICogUGFyc2VzIGFuZCBjYWNoZXMgdGhlIGdpdmVuIGB0ZW1wbGF0ZWAgYWNjb3JkaW5nIHRvIHRoZSBnaXZlbiBgdGFnc2Agb3JcbiAgICogYG11c3RhY2hlLnRhZ3NgIGlmIGB0YWdzYCBpcyBvbWl0dGVkLCAgYW5kIHJldHVybnMgdGhlIGFycmF5IG9mIHRva2Vuc1xuICAgKiB0aGF0IGlzIGdlbmVyYXRlZCBmcm9tIHRoZSBwYXJzZS5cbiAgICovXG4gIFdyaXRlci5wcm90b3R5cGUucGFyc2UgPSBmdW5jdGlvbiBwYXJzZSAodGVtcGxhdGUsIHRhZ3MpIHtcbiAgICB2YXIgY2FjaGUgPSB0aGlzLnRlbXBsYXRlQ2FjaGU7XG4gICAgdmFyIGNhY2hlS2V5ID0gdGVtcGxhdGUgKyAnOicgKyAodGFncyB8fCBtdXN0YWNoZS50YWdzKS5qb2luKCc6Jyk7XG4gICAgdmFyIGlzQ2FjaGVFbmFibGVkID0gdHlwZW9mIGNhY2hlICE9PSAndW5kZWZpbmVkJztcbiAgICB2YXIgdG9rZW5zID0gaXNDYWNoZUVuYWJsZWQgPyBjYWNoZS5nZXQoY2FjaGVLZXkpIDogdW5kZWZpbmVkO1xuXG4gICAgaWYgKHRva2VucyA9PSB1bmRlZmluZWQpIHtcbiAgICAgIHRva2VucyA9IHBhcnNlVGVtcGxhdGUodGVtcGxhdGUsIHRhZ3MpO1xuICAgICAgaXNDYWNoZUVuYWJsZWQgJiYgY2FjaGUuc2V0KGNhY2hlS2V5LCB0b2tlbnMpO1xuICAgIH1cbiAgICByZXR1cm4gdG9rZW5zO1xuICB9O1xuXG4gIC8qKlxuICAgKiBIaWdoLWxldmVsIG1ldGhvZCB0aGF0IGlzIHVzZWQgdG8gcmVuZGVyIHRoZSBnaXZlbiBgdGVtcGxhdGVgIHdpdGhcbiAgICogdGhlIGdpdmVuIGB2aWV3YC5cbiAgICpcbiAgICogVGhlIG9wdGlvbmFsIGBwYXJ0aWFsc2AgYXJndW1lbnQgbWF5IGJlIGFuIG9iamVjdCB0aGF0IGNvbnRhaW5zIHRoZVxuICAgKiBuYW1lcyBhbmQgdGVtcGxhdGVzIG9mIHBhcnRpYWxzIHRoYXQgYXJlIHVzZWQgaW4gdGhlIHRlbXBsYXRlLiBJdCBtYXlcbiAgICogYWxzbyBiZSBhIGZ1bmN0aW9uIHRoYXQgaXMgdXNlZCB0byBsb2FkIHBhcnRpYWwgdGVtcGxhdGVzIG9uIHRoZSBmbHlcbiAgICogdGhhdCB0YWtlcyBhIHNpbmdsZSBhcmd1bWVudDogdGhlIG5hbWUgb2YgdGhlIHBhcnRpYWwuXG4gICAqXG4gICAqIElmIHRoZSBvcHRpb25hbCBgY29uZmlnYCBhcmd1bWVudCBpcyBnaXZlbiBoZXJlLCB0aGVuIGl0IHNob3VsZCBiZSBhblxuICAgKiBvYmplY3Qgd2l0aCBhIGB0YWdzYCBhdHRyaWJ1dGUgb3IgYW4gYGVzY2FwZWAgYXR0cmlidXRlIG9yIGJvdGguXG4gICAqIElmIGFuIGFycmF5IGlzIHBhc3NlZCwgdGhlbiBpdCB3aWxsIGJlIGludGVycHJldGVkIHRoZSBzYW1lIHdheSBhc1xuICAgKiBhIGB0YWdzYCBhdHRyaWJ1dGUgb24gYSBgY29uZmlnYCBvYmplY3QuXG4gICAqXG4gICAqIFRoZSBgdGFnc2AgYXR0cmlidXRlIG9mIGEgYGNvbmZpZ2Agb2JqZWN0IG11c3QgYmUgYW4gYXJyYXkgd2l0aCB0d29cbiAgICogc3RyaW5nIHZhbHVlczogdGhlIG9wZW5pbmcgYW5kIGNsb3NpbmcgdGFncyB1c2VkIGluIHRoZSB0ZW1wbGF0ZSAoZS5nLlxuICAgKiBbIFwiPCVcIiwgXCIlPlwiIF0pLiBUaGUgZGVmYXVsdCBpcyB0byBtdXN0YWNoZS50YWdzLlxuICAgKlxuICAgKiBUaGUgYGVzY2FwZWAgYXR0cmlidXRlIG9mIGEgYGNvbmZpZ2Agb2JqZWN0IG11c3QgYmUgYSBmdW5jdGlvbiB3aGljaFxuICAgKiBhY2NlcHRzIGEgc3RyaW5nIGFzIGlucHV0IGFuZCBvdXRwdXRzIGEgc2FmZWx5IGVzY2FwZWQgc3RyaW5nLlxuICAgKiBJZiBhbiBgZXNjYXBlYCBmdW5jdGlvbiBpcyBub3QgcHJvdmlkZWQsIHRoZW4gYW4gSFRNTC1zYWZlIHN0cmluZ1xuICAgKiBlc2NhcGluZyBmdW5jdGlvbiBpcyB1c2VkIGFzIHRoZSBkZWZhdWx0LlxuICAgKi9cbiAgV3JpdGVyLnByb3RvdHlwZS5yZW5kZXIgPSBmdW5jdGlvbiByZW5kZXIgKHRlbXBsYXRlLCB2aWV3LCBwYXJ0aWFscywgY29uZmlnKSB7XG4gICAgdmFyIHRhZ3MgPSB0aGlzLmdldENvbmZpZ1RhZ3MoY29uZmlnKTtcbiAgICB2YXIgdG9rZW5zID0gdGhpcy5wYXJzZSh0ZW1wbGF0ZSwgdGFncyk7XG4gICAgdmFyIGNvbnRleHQgPSAodmlldyBpbnN0YW5jZW9mIENvbnRleHQpID8gdmlldyA6IG5ldyBDb250ZXh0KHZpZXcsIHVuZGVmaW5lZCk7XG4gICAgcmV0dXJuIHRoaXMucmVuZGVyVG9rZW5zKHRva2VucywgY29udGV4dCwgcGFydGlhbHMsIHRlbXBsYXRlLCBjb25maWcpO1xuICB9O1xuXG4gIC8qKlxuICAgKiBMb3ctbGV2ZWwgbWV0aG9kIHRoYXQgcmVuZGVycyB0aGUgZ2l2ZW4gYXJyYXkgb2YgYHRva2Vuc2AgdXNpbmdcbiAgICogdGhlIGdpdmVuIGBjb250ZXh0YCBhbmQgYHBhcnRpYWxzYC5cbiAgICpcbiAgICogTm90ZTogVGhlIGBvcmlnaW5hbFRlbXBsYXRlYCBpcyBvbmx5IGV2ZXIgdXNlZCB0byBleHRyYWN0IHRoZSBwb3J0aW9uXG4gICAqIG9mIHRoZSBvcmlnaW5hbCB0ZW1wbGF0ZSB0aGF0IHdhcyBjb250YWluZWQgaW4gYSBoaWdoZXItb3JkZXIgc2VjdGlvbi5cbiAgICogSWYgdGhlIHRlbXBsYXRlIGRvZXNuJ3QgdXNlIGhpZ2hlci1vcmRlciBzZWN0aW9ucywgdGhpcyBhcmd1bWVudCBtYXlcbiAgICogYmUgb21pdHRlZC5cbiAgICovXG4gIFdyaXRlci5wcm90b3R5cGUucmVuZGVyVG9rZW5zID0gZnVuY3Rpb24gcmVuZGVyVG9rZW5zICh0b2tlbnMsIGNvbnRleHQsIHBhcnRpYWxzLCBvcmlnaW5hbFRlbXBsYXRlLCBjb25maWcpIHtcbiAgICB2YXIgYnVmZmVyID0gJyc7XG5cbiAgICB2YXIgdG9rZW4sIHN5bWJvbCwgdmFsdWU7XG4gICAgZm9yICh2YXIgaSA9IDAsIG51bVRva2VucyA9IHRva2Vucy5sZW5ndGg7IGkgPCBudW1Ub2tlbnM7ICsraSkge1xuICAgICAgdmFsdWUgPSB1bmRlZmluZWQ7XG4gICAgICB0b2tlbiA9IHRva2Vuc1tpXTtcbiAgICAgIHN5bWJvbCA9IHRva2VuWzBdO1xuXG4gICAgICBpZiAoc3ltYm9sID09PSAnIycpIHZhbHVlID0gdGhpcy5yZW5kZXJTZWN0aW9uKHRva2VuLCBjb250ZXh0LCBwYXJ0aWFscywgb3JpZ2luYWxUZW1wbGF0ZSwgY29uZmlnKTtcbiAgICAgIGVsc2UgaWYgKHN5bWJvbCA9PT0gJ14nKSB2YWx1ZSA9IHRoaXMucmVuZGVySW52ZXJ0ZWQodG9rZW4sIGNvbnRleHQsIHBhcnRpYWxzLCBvcmlnaW5hbFRlbXBsYXRlLCBjb25maWcpO1xuICAgICAgZWxzZSBpZiAoc3ltYm9sID09PSAnPicpIHZhbHVlID0gdGhpcy5yZW5kZXJQYXJ0aWFsKHRva2VuLCBjb250ZXh0LCBwYXJ0aWFscywgY29uZmlnKTtcbiAgICAgIGVsc2UgaWYgKHN5bWJvbCA9PT0gJyYnKSB2YWx1ZSA9IHRoaXMudW5lc2NhcGVkVmFsdWUodG9rZW4sIGNvbnRleHQpO1xuICAgICAgZWxzZSBpZiAoc3ltYm9sID09PSAnbmFtZScpIHZhbHVlID0gdGhpcy5lc2NhcGVkVmFsdWUodG9rZW4sIGNvbnRleHQsIGNvbmZpZyk7XG4gICAgICBlbHNlIGlmIChzeW1ib2wgPT09ICd0ZXh0JykgdmFsdWUgPSB0aGlzLnJhd1ZhbHVlKHRva2VuKTtcblxuICAgICAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQpXG4gICAgICAgIGJ1ZmZlciArPSB2YWx1ZTtcbiAgICB9XG5cbiAgICByZXR1cm4gYnVmZmVyO1xuICB9O1xuXG4gIFdyaXRlci5wcm90b3R5cGUucmVuZGVyU2VjdGlvbiA9IGZ1bmN0aW9uIHJlbmRlclNlY3Rpb24gKHRva2VuLCBjb250ZXh0LCBwYXJ0aWFscywgb3JpZ2luYWxUZW1wbGF0ZSwgY29uZmlnKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIHZhciBidWZmZXIgPSAnJztcbiAgICB2YXIgdmFsdWUgPSBjb250ZXh0Lmxvb2t1cCh0b2tlblsxXSk7XG5cbiAgICAvLyBUaGlzIGZ1bmN0aW9uIGlzIHVzZWQgdG8gcmVuZGVyIGFuIGFyYml0cmFyeSB0ZW1wbGF0ZVxuICAgIC8vIGluIHRoZSBjdXJyZW50IGNvbnRleHQgYnkgaGlnaGVyLW9yZGVyIHNlY3Rpb25zLlxuICAgIGZ1bmN0aW9uIHN1YlJlbmRlciAodGVtcGxhdGUpIHtcbiAgICAgIHJldHVybiBzZWxmLnJlbmRlcih0ZW1wbGF0ZSwgY29udGV4dCwgcGFydGlhbHMsIGNvbmZpZyk7XG4gICAgfVxuXG4gICAgaWYgKCF2YWx1ZSkgcmV0dXJuO1xuXG4gICAgaWYgKGlzQXJyYXkodmFsdWUpKSB7XG4gICAgICBmb3IgKHZhciBqID0gMCwgdmFsdWVMZW5ndGggPSB2YWx1ZS5sZW5ndGg7IGogPCB2YWx1ZUxlbmd0aDsgKytqKSB7XG4gICAgICAgIGJ1ZmZlciArPSB0aGlzLnJlbmRlclRva2Vucyh0b2tlbls0XSwgY29udGV4dC5wdXNoKHZhbHVlW2pdKSwgcGFydGlhbHMsIG9yaWdpbmFsVGVtcGxhdGUsIGNvbmZpZyk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnIHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuICAgICAgYnVmZmVyICs9IHRoaXMucmVuZGVyVG9rZW5zKHRva2VuWzRdLCBjb250ZXh0LnB1c2godmFsdWUpLCBwYXJ0aWFscywgb3JpZ2luYWxUZW1wbGF0ZSwgY29uZmlnKTtcbiAgICB9IGVsc2UgaWYgKGlzRnVuY3Rpb24odmFsdWUpKSB7XG4gICAgICBpZiAodHlwZW9mIG9yaWdpbmFsVGVtcGxhdGUgIT09ICdzdHJpbmcnKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCB1c2UgaGlnaGVyLW9yZGVyIHNlY3Rpb25zIHdpdGhvdXQgdGhlIG9yaWdpbmFsIHRlbXBsYXRlJyk7XG5cbiAgICAgIC8vIEV4dHJhY3QgdGhlIHBvcnRpb24gb2YgdGhlIG9yaWdpbmFsIHRlbXBsYXRlIHRoYXQgdGhlIHNlY3Rpb24gY29udGFpbnMuXG4gICAgICB2YWx1ZSA9IHZhbHVlLmNhbGwoY29udGV4dC52aWV3LCBvcmlnaW5hbFRlbXBsYXRlLnNsaWNlKHRva2VuWzNdLCB0b2tlbls1XSksIHN1YlJlbmRlcik7XG5cbiAgICAgIGlmICh2YWx1ZSAhPSBudWxsKVxuICAgICAgICBidWZmZXIgKz0gdmFsdWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIGJ1ZmZlciArPSB0aGlzLnJlbmRlclRva2Vucyh0b2tlbls0XSwgY29udGV4dCwgcGFydGlhbHMsIG9yaWdpbmFsVGVtcGxhdGUsIGNvbmZpZyk7XG4gICAgfVxuICAgIHJldHVybiBidWZmZXI7XG4gIH07XG5cbiAgV3JpdGVyLnByb3RvdHlwZS5yZW5kZXJJbnZlcnRlZCA9IGZ1bmN0aW9uIHJlbmRlckludmVydGVkICh0b2tlbiwgY29udGV4dCwgcGFydGlhbHMsIG9yaWdpbmFsVGVtcGxhdGUsIGNvbmZpZykge1xuICAgIHZhciB2YWx1ZSA9IGNvbnRleHQubG9va3VwKHRva2VuWzFdKTtcblxuICAgIC8vIFVzZSBKYXZhU2NyaXB0J3MgZGVmaW5pdGlvbiBvZiBmYWxzeS4gSW5jbHVkZSBlbXB0eSBhcnJheXMuXG4gICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9qYW5sL211c3RhY2hlLmpzL2lzc3Vlcy8xODZcbiAgICBpZiAoIXZhbHVlIHx8IChpc0FycmF5KHZhbHVlKSAmJiB2YWx1ZS5sZW5ndGggPT09IDApKVxuICAgICAgcmV0dXJuIHRoaXMucmVuZGVyVG9rZW5zKHRva2VuWzRdLCBjb250ZXh0LCBwYXJ0aWFscywgb3JpZ2luYWxUZW1wbGF0ZSwgY29uZmlnKTtcbiAgfTtcblxuICBXcml0ZXIucHJvdG90eXBlLmluZGVudFBhcnRpYWwgPSBmdW5jdGlvbiBpbmRlbnRQYXJ0aWFsIChwYXJ0aWFsLCBpbmRlbnRhdGlvbiwgbGluZUhhc05vblNwYWNlKSB7XG4gICAgdmFyIGZpbHRlcmVkSW5kZW50YXRpb24gPSBpbmRlbnRhdGlvbi5yZXBsYWNlKC9bXiBcXHRdL2csICcnKTtcbiAgICB2YXIgcGFydGlhbEJ5TmwgPSBwYXJ0aWFsLnNwbGl0KCdcXG4nKTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHBhcnRpYWxCeU5sLmxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAocGFydGlhbEJ5TmxbaV0ubGVuZ3RoICYmIChpID4gMCB8fCAhbGluZUhhc05vblNwYWNlKSkge1xuICAgICAgICBwYXJ0aWFsQnlObFtpXSA9IGZpbHRlcmVkSW5kZW50YXRpb24gKyBwYXJ0aWFsQnlObFtpXTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHBhcnRpYWxCeU5sLmpvaW4oJ1xcbicpO1xuICB9O1xuXG4gIFdyaXRlci5wcm90b3R5cGUucmVuZGVyUGFydGlhbCA9IGZ1bmN0aW9uIHJlbmRlclBhcnRpYWwgKHRva2VuLCBjb250ZXh0LCBwYXJ0aWFscywgY29uZmlnKSB7XG4gICAgaWYgKCFwYXJ0aWFscykgcmV0dXJuO1xuICAgIHZhciB0YWdzID0gdGhpcy5nZXRDb25maWdUYWdzKGNvbmZpZyk7XG5cbiAgICB2YXIgdmFsdWUgPSBpc0Z1bmN0aW9uKHBhcnRpYWxzKSA/IHBhcnRpYWxzKHRva2VuWzFdKSA6IHBhcnRpYWxzW3Rva2VuWzFdXTtcbiAgICBpZiAodmFsdWUgIT0gbnVsbCkge1xuICAgICAgdmFyIGxpbmVIYXNOb25TcGFjZSA9IHRva2VuWzZdO1xuICAgICAgdmFyIHRhZ0luZGV4ID0gdG9rZW5bNV07XG4gICAgICB2YXIgaW5kZW50YXRpb24gPSB0b2tlbls0XTtcbiAgICAgIHZhciBpbmRlbnRlZFZhbHVlID0gdmFsdWU7XG4gICAgICBpZiAodGFnSW5kZXggPT0gMCAmJiBpbmRlbnRhdGlvbikge1xuICAgICAgICBpbmRlbnRlZFZhbHVlID0gdGhpcy5pbmRlbnRQYXJ0aWFsKHZhbHVlLCBpbmRlbnRhdGlvbiwgbGluZUhhc05vblNwYWNlKTtcbiAgICAgIH1cbiAgICAgIHZhciB0b2tlbnMgPSB0aGlzLnBhcnNlKGluZGVudGVkVmFsdWUsIHRhZ3MpO1xuICAgICAgcmV0dXJuIHRoaXMucmVuZGVyVG9rZW5zKHRva2VucywgY29udGV4dCwgcGFydGlhbHMsIGluZGVudGVkVmFsdWUsIGNvbmZpZyk7XG4gICAgfVxuICB9O1xuXG4gIFdyaXRlci5wcm90b3R5cGUudW5lc2NhcGVkVmFsdWUgPSBmdW5jdGlvbiB1bmVzY2FwZWRWYWx1ZSAodG9rZW4sIGNvbnRleHQpIHtcbiAgICB2YXIgdmFsdWUgPSBjb250ZXh0Lmxvb2t1cCh0b2tlblsxXSk7XG4gICAgaWYgKHZhbHVlICE9IG51bGwpXG4gICAgICByZXR1cm4gdmFsdWU7XG4gIH07XG5cbiAgV3JpdGVyLnByb3RvdHlwZS5lc2NhcGVkVmFsdWUgPSBmdW5jdGlvbiBlc2NhcGVkVmFsdWUgKHRva2VuLCBjb250ZXh0LCBjb25maWcpIHtcbiAgICB2YXIgZXNjYXBlID0gdGhpcy5nZXRDb25maWdFc2NhcGUoY29uZmlnKSB8fCBtdXN0YWNoZS5lc2NhcGU7XG4gICAgdmFyIHZhbHVlID0gY29udGV4dC5sb29rdXAodG9rZW5bMV0pO1xuICAgIGlmICh2YWx1ZSAhPSBudWxsKVxuICAgICAgcmV0dXJuICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInICYmIGVzY2FwZSA9PT0gbXVzdGFjaGUuZXNjYXBlKSA/IFN0cmluZyh2YWx1ZSkgOiBlc2NhcGUodmFsdWUpO1xuICB9O1xuXG4gIFdyaXRlci5wcm90b3R5cGUucmF3VmFsdWUgPSBmdW5jdGlvbiByYXdWYWx1ZSAodG9rZW4pIHtcbiAgICByZXR1cm4gdG9rZW5bMV07XG4gIH07XG5cbiAgV3JpdGVyLnByb3RvdHlwZS5nZXRDb25maWdUYWdzID0gZnVuY3Rpb24gZ2V0Q29uZmlnVGFncyAoY29uZmlnKSB7XG4gICAgaWYgKGlzQXJyYXkoY29uZmlnKSkge1xuICAgICAgcmV0dXJuIGNvbmZpZztcbiAgICB9XG4gICAgZWxzZSBpZiAoY29uZmlnICYmIHR5cGVvZiBjb25maWcgPT09ICdvYmplY3QnKSB7XG4gICAgICByZXR1cm4gY29uZmlnLnRhZ3M7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gIH07XG5cbiAgV3JpdGVyLnByb3RvdHlwZS5nZXRDb25maWdFc2NhcGUgPSBmdW5jdGlvbiBnZXRDb25maWdFc2NhcGUgKGNvbmZpZykge1xuICAgIGlmIChjb25maWcgJiYgdHlwZW9mIGNvbmZpZyA9PT0gJ29iamVjdCcgJiYgIWlzQXJyYXkoY29uZmlnKSkge1xuICAgICAgcmV0dXJuIGNvbmZpZy5lc2NhcGU7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gIH07XG5cbiAgdmFyIG11c3RhY2hlID0ge1xuICAgIG5hbWU6ICdtdXN0YWNoZS5qcycsXG4gICAgdmVyc2lvbjogJzQuMi4wJyxcbiAgICB0YWdzOiBbICd7eycsICd9fScgXSxcbiAgICBjbGVhckNhY2hlOiB1bmRlZmluZWQsXG4gICAgZXNjYXBlOiB1bmRlZmluZWQsXG4gICAgcGFyc2U6IHVuZGVmaW5lZCxcbiAgICByZW5kZXI6IHVuZGVmaW5lZCxcbiAgICBTY2FubmVyOiB1bmRlZmluZWQsXG4gICAgQ29udGV4dDogdW5kZWZpbmVkLFxuICAgIFdyaXRlcjogdW5kZWZpbmVkLFxuICAgIC8qKlxuICAgICAqIEFsbG93cyBhIHVzZXIgdG8gb3ZlcnJpZGUgdGhlIGRlZmF1bHQgY2FjaGluZyBzdHJhdGVneSwgYnkgcHJvdmlkaW5nIGFuXG4gICAgICogb2JqZWN0IHdpdGggc2V0LCBnZXQgYW5kIGNsZWFyIG1ldGhvZHMuIFRoaXMgY2FuIGFsc28gYmUgdXNlZCB0byBkaXNhYmxlXG4gICAgICogdGhlIGNhY2hlIGJ5IHNldHRpbmcgaXQgdG8gdGhlIGxpdGVyYWwgYHVuZGVmaW5lZGAuXG4gICAgICovXG4gICAgc2V0IHRlbXBsYXRlQ2FjaGUgKGNhY2hlKSB7XG4gICAgICBkZWZhdWx0V3JpdGVyLnRlbXBsYXRlQ2FjaGUgPSBjYWNoZTtcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIEdldHMgdGhlIGRlZmF1bHQgb3Igb3ZlcnJpZGRlbiBjYWNoaW5nIG9iamVjdCBmcm9tIHRoZSBkZWZhdWx0IHdyaXRlci5cbiAgICAgKi9cbiAgICBnZXQgdGVtcGxhdGVDYWNoZSAoKSB7XG4gICAgICByZXR1cm4gZGVmYXVsdFdyaXRlci50ZW1wbGF0ZUNhY2hlO1xuICAgIH1cbiAgfTtcblxuICAvLyBBbGwgaGlnaC1sZXZlbCBtdXN0YWNoZS4qIGZ1bmN0aW9ucyB1c2UgdGhpcyB3cml0ZXIuXG4gIHZhciBkZWZhdWx0V3JpdGVyID0gbmV3IFdyaXRlcigpO1xuXG4gIC8qKlxuICAgKiBDbGVhcnMgYWxsIGNhY2hlZCB0ZW1wbGF0ZXMgaW4gdGhlIGRlZmF1bHQgd3JpdGVyLlxuICAgKi9cbiAgbXVzdGFjaGUuY2xlYXJDYWNoZSA9IGZ1bmN0aW9uIGNsZWFyQ2FjaGUgKCkge1xuICAgIHJldHVybiBkZWZhdWx0V3JpdGVyLmNsZWFyQ2FjaGUoKTtcbiAgfTtcblxuICAvKipcbiAgICogUGFyc2VzIGFuZCBjYWNoZXMgdGhlIGdpdmVuIHRlbXBsYXRlIGluIHRoZSBkZWZhdWx0IHdyaXRlciBhbmQgcmV0dXJucyB0aGVcbiAgICogYXJyYXkgb2YgdG9rZW5zIGl0IGNvbnRhaW5zLiBEb2luZyB0aGlzIGFoZWFkIG9mIHRpbWUgYXZvaWRzIHRoZSBuZWVkIHRvXG4gICAqIHBhcnNlIHRlbXBsYXRlcyBvbiB0aGUgZmx5IGFzIHRoZXkgYXJlIHJlbmRlcmVkLlxuICAgKi9cbiAgbXVzdGFjaGUucGFyc2UgPSBmdW5jdGlvbiBwYXJzZSAodGVtcGxhdGUsIHRhZ3MpIHtcbiAgICByZXR1cm4gZGVmYXVsdFdyaXRlci5wYXJzZSh0ZW1wbGF0ZSwgdGFncyk7XG4gIH07XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgdGhlIGB0ZW1wbGF0ZWAgd2l0aCB0aGUgZ2l2ZW4gYHZpZXdgLCBgcGFydGlhbHNgLCBhbmQgYGNvbmZpZ2BcbiAgICogdXNpbmcgdGhlIGRlZmF1bHQgd3JpdGVyLlxuICAgKi9cbiAgbXVzdGFjaGUucmVuZGVyID0gZnVuY3Rpb24gcmVuZGVyICh0ZW1wbGF0ZSwgdmlldywgcGFydGlhbHMsIGNvbmZpZykge1xuICAgIGlmICh0eXBlb2YgdGVtcGxhdGUgIT09ICdzdHJpbmcnKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdJbnZhbGlkIHRlbXBsYXRlISBUZW1wbGF0ZSBzaG91bGQgYmUgYSBcInN0cmluZ1wiICcgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnYnV0IFwiJyArIHR5cGVTdHIodGVtcGxhdGUpICsgJ1wiIHdhcyBnaXZlbiBhcyB0aGUgZmlyc3QgJyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICdhcmd1bWVudCBmb3IgbXVzdGFjaGUjcmVuZGVyKHRlbXBsYXRlLCB2aWV3LCBwYXJ0aWFscyknKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZGVmYXVsdFdyaXRlci5yZW5kZXIodGVtcGxhdGUsIHZpZXcsIHBhcnRpYWxzLCBjb25maWcpO1xuICB9O1xuXG4gIC8vIEV4cG9ydCB0aGUgZXNjYXBpbmcgZnVuY3Rpb24gc28gdGhhdCB0aGUgdXNlciBtYXkgb3ZlcnJpZGUgaXQuXG4gIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vamFubC9tdXN0YWNoZS5qcy9pc3N1ZXMvMjQ0XG4gIG11c3RhY2hlLmVzY2FwZSA9IGVzY2FwZUh0bWw7XG5cbiAgLy8gRXhwb3J0IHRoZXNlIG1haW5seSBmb3IgdGVzdGluZywgYnV0IGFsc28gZm9yIGFkdmFuY2VkIHVzYWdlLlxuICBtdXN0YWNoZS5TY2FubmVyID0gU2Nhbm5lcjtcbiAgbXVzdGFjaGUuQ29udGV4dCA9IENvbnRleHQ7XG4gIG11c3RhY2hlLldyaXRlciA9IFdyaXRlcjtcblxuICByZXR1cm4gbXVzdGFjaGU7XG5cbn0pKSk7XG4iLCJcInVzZSBzdHJpY3RcIjtcclxudmFyIF9fYXdhaXRlciA9ICh0aGlzICYmIHRoaXMuX19hd2FpdGVyKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XHJcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cclxuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xyXG4gICAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvci5uZXh0KHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cclxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cclxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxyXG4gICAgICAgIHN0ZXAoKGdlbmVyYXRvciA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSkubmV4dCgpKTtcclxuICAgIH0pO1xyXG59O1xyXG52YXIgX19nZW5lcmF0b3IgPSAodGhpcyAmJiB0aGlzLl9fZ2VuZXJhdG9yKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgYm9keSkge1xyXG4gICAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbigpIHsgaWYgKHRbMF0gJiAxKSB0aHJvdyB0WzFdOyByZXR1cm4gdFsxXTsgfSwgdHJ5czogW10sIG9wczogW10gfSwgZiwgeSwgdCwgZztcclxuICAgIHJldHVybiBnID0geyBuZXh0OiB2ZXJiKDApLCBcInRocm93XCI6IHZlcmIoMSksIFwicmV0dXJuXCI6IHZlcmIoMikgfSwgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIChnW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbigpIHsgcmV0dXJuIHRoaXM7IH0pLCBnO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IHJldHVybiBmdW5jdGlvbiAodikgeyByZXR1cm4gc3RlcChbbiwgdl0pOyB9OyB9XHJcbiAgICBmdW5jdGlvbiBzdGVwKG9wKSB7XHJcbiAgICAgICAgaWYgKGYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJHZW5lcmF0b3IgaXMgYWxyZWFkeSBleGVjdXRpbmcuXCIpO1xyXG4gICAgICAgIHdoaWxlIChfKSB0cnkge1xyXG4gICAgICAgICAgICBpZiAoZiA9IDEsIHkgJiYgKHQgPSBvcFswXSAmIDIgPyB5W1wicmV0dXJuXCJdIDogb3BbMF0gPyB5W1widGhyb3dcIl0gfHwgKCh0ID0geVtcInJldHVyblwiXSkgJiYgdC5jYWxsKHkpLCAwKSA6IHkubmV4dCkgJiYgISh0ID0gdC5jYWxsKHksIG9wWzFdKSkuZG9uZSkgcmV0dXJuIHQ7XHJcbiAgICAgICAgICAgIGlmICh5ID0gMCwgdCkgb3AgPSBbb3BbMF0gJiAyLCB0LnZhbHVlXTtcclxuICAgICAgICAgICAgc3dpdGNoIChvcFswXSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiBjYXNlIDE6IHQgPSBvcDsgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ6IF8ubGFiZWwrKzsgcmV0dXJuIHsgdmFsdWU6IG9wWzFdLCBkb25lOiBmYWxzZSB9O1xyXG4gICAgICAgICAgICAgICAgY2FzZSA1OiBfLmxhYmVsKys7IHkgPSBvcFsxXTsgb3AgPSBbMF07IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA3OiBvcCA9IF8ub3BzLnBvcCgpOyBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICBpZiAoISh0ID0gXy50cnlzLCB0ID0gdC5sZW5ndGggPiAwICYmIHRbdC5sZW5ndGggLSAxXSkgJiYgKG9wWzBdID09PSA2IHx8IG9wWzBdID09PSAyKSkgeyBfID0gMDsgY29udGludWU7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDMgJiYgKCF0IHx8IChvcFsxXSA+IHRbMF0gJiYgb3BbMV0gPCB0WzNdKSkpIHsgXy5sYWJlbCA9IG9wWzFdOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gNiAmJiBfLmxhYmVsIDwgdFsxXSkgeyBfLmxhYmVsID0gdFsxXTsgdCA9IG9wOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0ICYmIF8ubGFiZWwgPCB0WzJdKSB7IF8ubGFiZWwgPSB0WzJdOyBfLm9wcy5wdXNoKG9wKTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodFsyXSkgXy5vcHMucG9wKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvcCA9IGJvZHkuY2FsbCh0aGlzQXJnLCBfKTtcclxuICAgICAgICB9IGNhdGNoIChlKSB7IG9wID0gWzYsIGVdOyB5ID0gMDsgfSBmaW5hbGx5IHsgZiA9IHQgPSAwOyB9XHJcbiAgICAgICAgaWYgKG9wWzBdICYgNSkgdGhyb3cgb3BbMV07IHJldHVybiB7IHZhbHVlOiBvcFswXSA/IG9wWzFdIDogdm9pZCAwLCBkb25lOiB0cnVlIH07XHJcbiAgICB9XHJcbn07XHJcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcclxuZXhwb3J0cy5sb2FkQW5kTWVyZ2VBc3NpZ25tZW50TGlzdCA9IGV4cG9ydHMubWVyZ2VkQXNzaWdubWVudExpc3ROb01lbW8gPSBleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0ID0gZXhwb3J0cy5jb3Vyc2VJRExpc3QgPSB2b2lkIDA7XHJcbnZhciBzdG9yYWdlXzEgPSByZXF1aXJlKFwiLi9zdG9yYWdlXCIpO1xyXG52YXIgbmV0d29ya18xID0gcmVxdWlyZShcIi4vbmV0d29ya1wiKTtcclxudmFyIG1pbmlzYWthaV8xID0gcmVxdWlyZShcIi4vbWluaXNha2FpXCIpO1xyXG52YXIgZmF2b3JpdGVzXzEgPSByZXF1aXJlKFwiLi9mYXZvcml0ZXNcIik7XHJcbnZhciB1dGlsc18xID0gcmVxdWlyZShcIi4vdXRpbHNcIik7XHJcbnZhciBzZXR0aW5nc18xID0gcmVxdWlyZShcIi4vc2V0dGluZ3NcIik7XHJcbi8qKlxyXG4gKiBMb2FkIG9sZCBhc3NpZ25tZW50cy9xdWl6emVzIGZyb20gc3RvcmFnZSBhbmQgZmV0Y2ggbmV3IGFzc2lnbm1lbnRzL3F1aXp6ZXMgZnJvbSBTYWthaS5cclxuICogQHBhcmFtIHtDb25maWd9IGNvbmZpZ1xyXG4gKiBAcGFyYW0ge0NvdXJzZVNpdGVJbmZvW119IGNvdXJzZVNpdGVJbmZvc1xyXG4gKiBAcGFyYW0ge2Jvb2xlYW59IHVzZUFzc2lnbm1lbnRDYWNoZVxyXG4gKiBAcGFyYW0ge2Jvb2xlYW59IHVzZVF1aXpDYWNoZVxyXG4gKi9cclxuZnVuY3Rpb24gbG9hZEFuZE1lcmdlQXNzaWdubWVudExpc3QoY29uZmlnLCBjb3Vyc2VTaXRlSW5mb3MsIHVzZUFzc2lnbm1lbnRDYWNoZSwgdXNlUXVpekNhY2hlKSB7XHJcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIG9sZEFzc2lnbm1lbnRMaXN0LCBfYSwgb2xkUXVpekxpc3QsIF9iLCBuZXdBc3NpZ25tZW50TGlzdCwgbmV3UXVpekxpc3QsIHBlbmRpbmdMaXN0LCBfaSwgY291cnNlU2l0ZUluZm9zXzEsIGksIHJlc3VsdCwgX2MsIHJlc3VsdF8xLCBrLCBwZW5kaW5nTGlzdCwgX2QsIGNvdXJzZVNpdGVJbmZvc18yLCBpLCByZXN1bHQsIF9lLCByZXN1bHRfMiwgaywgbWVyZ2VkUXVpekxpc3QsIG1lbW9MaXN0LCBfZjtcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9nKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2cubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICBfYSA9IHV0aWxzXzEuY29udmVydEFycmF5VG9Bc3NpZ25tZW50O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5sb2FkRnJvbUxvY2FsU3RvcmFnZShcIkNTX0Fzc2lnbm1lbnRMaXN0XCIpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBvbGRBc3NpZ25tZW50TGlzdCA9IF9hLmFwcGx5KHZvaWQgMCwgW19nLnNlbnQoKV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIF9iID0gdXRpbHNfMS5jb252ZXJ0QXJyYXlUb0Fzc2lnbm1lbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLmxvYWRGcm9tTG9jYWxTdG9yYWdlKFwiQ1NfUXVpekxpc3RcIildO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgIG9sZFF1aXpMaXN0ID0gX2IuYXBwbHkodm9pZCAwLCBbX2cuc2VudCgpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3QXNzaWdubWVudExpc3QgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICBuZXdRdWl6TGlzdCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdXNlQXNzaWdubWVudENhY2hlKSByZXR1cm4gWzMgLypicmVhayovLCAzXTtcclxuICAgICAgICAgICAgICAgICAgICBuZXdBc3NpZ25tZW50TGlzdCA9IG9sZEFzc2lnbm1lbnRMaXN0O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDZdO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAzOlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmV0Y2hpbmcgYXNzaWdubWVudHMuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgcGVuZGluZ0xpc3QgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBBZGQgY291cnNlIHNpdGVzIHRvIGZldGNoLXBlbmRpbmcgbGlzdFxyXG4gICAgICAgICAgICAgICAgICAgIGZvciAoX2kgPSAwLCBjb3Vyc2VTaXRlSW5mb3NfMSA9IGNvdXJzZVNpdGVJbmZvczsgX2kgPCBjb3Vyc2VTaXRlSW5mb3NfMS5sZW5ndGg7IF9pKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaSA9IGNvdXJzZVNpdGVJbmZvc18xW19pXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGVuZGluZ0xpc3QucHVzaChuZXR3b3JrXzEuZ2V0QXNzaWdubWVudEJ5Q291cnNlSUQoY29uZmlnLmJhc2VVUkwsIGkuY291cnNlSUQpKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgUHJvbWlzZS5hbGxTZXR0bGVkKHBlbmRpbmdMaXN0KV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ6XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gX2cuc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAoX2MgPSAwLCByZXN1bHRfMSA9IHJlc3VsdDsgX2MgPCByZXN1bHRfMS5sZW5ndGg7IF9jKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgayA9IHJlc3VsdF8xW19jXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGsuc3RhdHVzID09PSBcImZ1bGZpbGxlZFwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3QXNzaWdubWVudExpc3QucHVzaChrLnZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gVXBkYXRlIGFzc2lnbm1lbnQgZmV0Y2ggdGltZXN0YW1wXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLnNhdmVUb0xvY2FsU3RvcmFnZShcIkNTX0Fzc2lnbm1lbnRGZXRjaFRpbWVcIiwgdXRpbHNfMS5ub3dUaW1lKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDU6XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gVXBkYXRlIGFzc2lnbm1lbnQgZmV0Y2ggdGltZXN0YW1wXHJcbiAgICAgICAgICAgICAgICAgICAgX2cuc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbmZpZy5mZXRjaGVkVGltZS5hc3NpZ25tZW50ID0gdXRpbHNfMS5ub3dUaW1lO1xyXG4gICAgICAgICAgICAgICAgICAgIF9nLmxhYmVsID0gNjtcclxuICAgICAgICAgICAgICAgIGNhc2UgNjpcclxuICAgICAgICAgICAgICAgICAgICAvLyBDb21wYXJlIGFzc2lnbm1lbnRzIHdpdGggb2xkIG9uZXNcclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0Tm9NZW1vID0gdXRpbHNfMS5jb21wYXJlQW5kTWVyZ2VBc3NpZ25tZW50TGlzdChvbGRBc3NpZ25tZW50TGlzdCwgbmV3QXNzaWdubWVudExpc3QpO1xyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydHMubWVyZ2VkQXNzaWdubWVudExpc3QgPSB1dGlsc18xLmNvbXBhcmVBbmRNZXJnZUFzc2lnbm1lbnRMaXN0KG9sZEFzc2lnbm1lbnRMaXN0LCBuZXdBc3NpZ25tZW50TGlzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF1c2VRdWl6Q2FjaGUpIHJldHVybiBbMyAvKmJyZWFrKi8sIDddO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygb2xkUXVpekxpc3QgIT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmV3UXVpekxpc3QgPSBvbGRRdWl6TGlzdDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgMTBdO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA3OlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmV0Y2hpbmcgcXVpenplcy4uLlwiKTtcclxuICAgICAgICAgICAgICAgICAgICBwZW5kaW5nTGlzdCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIEFkZCBjb3Vyc2Ugc2l0ZXMgdG8gZmV0Y2gtcGVuZGluZyBsaXN0XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChfZCA9IDAsIGNvdXJzZVNpdGVJbmZvc18yID0gY291cnNlU2l0ZUluZm9zOyBfZCA8IGNvdXJzZVNpdGVJbmZvc18yLmxlbmd0aDsgX2QrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpID0gY291cnNlU2l0ZUluZm9zXzJbX2RdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwZW5kaW5nTGlzdC5wdXNoKG5ldHdvcmtfMS5nZXRRdWl6RnJvbUNvdXJzZUlEKGNvbmZpZy5iYXNlVVJMLCBpLmNvdXJzZUlEKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIFByb21pc2UuYWxsU2V0dGxlZChwZW5kaW5nTGlzdCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA4OlxyXG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IF9nLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKF9lID0gMCwgcmVzdWx0XzIgPSByZXN1bHQ7IF9lIDwgcmVzdWx0XzIubGVuZ3RoOyBfZSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGsgPSByZXN1bHRfMltfZV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChrLnN0YXR1cyA9PT0gXCJmdWxmaWxsZWRcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5ld1F1aXpMaXN0LnB1c2goay52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSBhc3NpZ25tZW50IGZldGNoIHRpbWVzdGFtcFxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5zYXZlVG9Mb2NhbFN0b3JhZ2UoXCJDU19RdWl6RmV0Y2hUaW1lXCIsIHV0aWxzXzEubm93VGltZSldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA5OlxyXG4gICAgICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSBhc3NpZ25tZW50IGZldGNoIHRpbWVzdGFtcFxyXG4gICAgICAgICAgICAgICAgICAgIF9nLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25maWcuZmV0Y2hlZFRpbWUucXVpeiA9IHV0aWxzXzEubm93VGltZTtcclxuICAgICAgICAgICAgICAgICAgICBfZy5sYWJlbCA9IDEwO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxMDpcclxuICAgICAgICAgICAgICAgICAgICBtZXJnZWRRdWl6TGlzdCA9IHV0aWxzXzEuY29tcGFyZUFuZE1lcmdlQXNzaWdubWVudExpc3Qob2xkUXVpekxpc3QsIG5ld1F1aXpMaXN0KTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBNZXJnZSBhc3NpZ25tZW50cyBhbmQgcXVpenplc1xyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydHMubWVyZ2VkQXNzaWdubWVudExpc3QgPSB1dGlsc18xLm1lcmdlSW50b0Fzc2lnbm1lbnRMaXN0KGV4cG9ydHMubWVyZ2VkQXNzaWdubWVudExpc3QsIG1lcmdlZFF1aXpMaXN0KTtcclxuICAgICAgICAgICAgICAgICAgICBfZiA9IHV0aWxzXzEuY29udmVydEFycmF5VG9Bc3NpZ25tZW50O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5sb2FkRnJvbUxvY2FsU3RvcmFnZShcIkNTX01lbW9MaXN0XCIpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTE6XHJcbiAgICAgICAgICAgICAgICAgICAgbWVtb0xpc3QgPSBfZi5hcHBseSh2b2lkIDAsIFtfZy5zZW50KCldKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBNZXJnZSBtZW1vc1xyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydHMubWVyZ2VkQXNzaWdubWVudExpc3QgPSB1dGlsc18xLnNvcnRBc3NpZ25tZW50TGlzdCh1dGlsc18xLm1lcmdlSW50b0Fzc2lnbm1lbnRMaXN0KGV4cG9ydHMubWVyZ2VkQXNzaWdubWVudExpc3QsIG1lbW9MaXN0KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gU2F2ZSBhc3NpZ25tZW50cyBhbmQgcXVpenplcyB0byBsb2NhbCBzdG9yYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLnNhdmVUb0xvY2FsU3RvcmFnZShcIkNTX0Fzc2lnbm1lbnRMaXN0XCIsIGV4cG9ydHMubWVyZ2VkQXNzaWdubWVudExpc3ROb01lbW8pXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTI6XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gU2F2ZSBhc3NpZ25tZW50cyBhbmQgcXVpenplcyB0byBsb2NhbCBzdG9yYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgX2cuc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5zYXZlVG9Mb2NhbFN0b3JhZ2UoXCJDU19RdWl6TGlzdFwiLCBtZXJnZWRRdWl6TGlzdCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxMzpcclxuICAgICAgICAgICAgICAgICAgICBfZy5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi8sIGV4cG9ydHMubWVyZ2VkQXNzaWdubWVudExpc3RdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLmxvYWRBbmRNZXJnZUFzc2lnbm1lbnRMaXN0ID0gbG9hZEFuZE1lcmdlQXNzaWdubWVudExpc3Q7XHJcbi8qKlxyXG4gKiBMb2FkIGNvdXJzZSBzaXRlIElEc1xyXG4gKi9cclxuZnVuY3Rpb24gbG9hZENvdXJzZUlETGlzdCgpIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRzLmNvdXJzZUlETGlzdCA9IG5ldHdvcmtfMS5nZXRDb3Vyc2VJRExpc3QoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEuc2F2ZVRvTG9jYWxTdG9yYWdlKFwiQ1NfQ291cnNlSW5mb1wiLCBleHBvcnRzLmNvdXJzZUlETGlzdCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmZ1bmN0aW9uIHVwZGF0ZVJlYWRGbGFnKCkge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciB1cGRhdGVkQXNzaWdubWVudExpc3Q7XHJcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEFzc2lnbm1lbnRMaXN0ID0gdXRpbHNfMS51cGRhdGVJc1JlYWRGbGFnKGV4cG9ydHMubWVyZ2VkQXNzaWdubWVudExpc3ROb01lbW8pO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5zYXZlVG9Mb2NhbFN0b3JhZ2UoXCJDU19Bc3NpZ25tZW50TGlzdFwiLCB1cGRhdGVkQXNzaWdubWVudExpc3QpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5mdW5jdGlvbiBtYWluKCkge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBjb25maWc7XHJcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF1dGlsc18xLmlzTG9nZ2VkSW4oKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgOF07XHJcbiAgICAgICAgICAgICAgICAgICAgbWluaXNha2FpXzEuY3JlYXRlTWluaVNha2FpQnRuKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc2V0dGluZ3NfMS5sb2FkQ29uZmlncygpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBjb25maWcgPSBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgbG9hZENvdXJzZUlETGlzdCgpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgbG9hZEFuZE1lcmdlQXNzaWdubWVudExpc3QoY29uZmlnLCBleHBvcnRzLmNvdXJzZUlETGlzdCwgdXRpbHNfMS5pc1VzaW5nQ2FjaGUoY29uZmlnLmZldGNoZWRUaW1lLmFzc2lnbm1lbnQsIGNvbmZpZy5jYWNoZUludGVydmFsLmFzc2lnbm1lbnQpLCB1dGlsc18xLmlzVXNpbmdDYWNoZShjb25maWcuZmV0Y2hlZFRpbWUucXVpeiwgY29uZmlnLmNhY2hlSW50ZXJ2YWwucXVpeikpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0ID0gX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIGZhdm9yaXRlc18xLmFkZEZhdm9yaXRlZENvdXJzZVNpdGVzKGNvbmZpZy5iYXNlVVJMKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIG1pbmlzYWthaV8xLmRpc3BsYXlNaW5pU2FrYWkoZXhwb3J0cy5tZXJnZWRBc3NpZ25tZW50TGlzdCwgZXhwb3J0cy5jb3Vyc2VJRExpc3QpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTpcclxuICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgbWluaXNha2FpXzEuY3JlYXRlRmF2b3JpdGVzQmFyTm90aWZpY2F0aW9uKGV4cG9ydHMuY291cnNlSURMaXN0LCBleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0KV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDY6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHVwZGF0ZVJlYWRGbGFnKCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA3OlxyXG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICBfYS5sYWJlbCA9IDg7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDg6IHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxubWFpbigpO1xyXG4iLCJcInVzZSBzdHJpY3RcIjtcclxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xyXG5leHBvcnRzLmFwcGVuZENoaWxkQWxsID0gZXhwb3J0cy5jbG9uZUVsZW0gPSBleHBvcnRzLmNyZWF0ZUVsZW0gPSBleHBvcnRzLmFkZEF0dHJpYnV0ZXMgPSBleHBvcnRzLlNldHRpbmdzRG9tID0gZXhwb3J0cy5oYW1idXJnZXIgPSBleHBvcnRzLmFzc2lnbm1lbnREaXYgPSBleHBvcnRzLm1pbmlTYWthaSA9IHZvaWQgMDtcclxudmFyIGV2ZW50TGlzdGVuZXJfMSA9IHJlcXVpcmUoXCIuL2V2ZW50TGlzdGVuZXJcIik7XHJcbi8qKlxyXG4gKiBDcmVhdGUgRE9NIGVsZW1lbnRzXHJcbiAqL1xyXG5mdW5jdGlvbiBjcmVhdGVFbGVtKHRhZywgZGljdCwgZXZlbnRMaXN0ZW5lcikge1xyXG4gICAgdmFyIGVsZW0gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZyk7XHJcbiAgICBhZGRBdHRyaWJ1dGVzKGVsZW0sIGRpY3QsIGV2ZW50TGlzdGVuZXIpO1xyXG4gICAgcmV0dXJuIGVsZW07XHJcbn1cclxuZXhwb3J0cy5jcmVhdGVFbGVtID0gY3JlYXRlRWxlbTtcclxuLyoqXHJcbiAqIENsb25lIERPTSBlbGVtZW50c1xyXG4gKi9cclxuZnVuY3Rpb24gY2xvbmVFbGVtKGVsZW0sIGRpY3QsIGV2ZW50TGlzdGVuZXIpIHtcclxuICAgIHZhciBjbG9uZSA9IGVsZW0uY2xvbmVOb2RlKHRydWUpO1xyXG4gICAgYWRkQXR0cmlidXRlcyhjbG9uZSwgZGljdCwgZXZlbnRMaXN0ZW5lcik7XHJcbiAgICByZXR1cm4gY2xvbmU7XHJcbn1cclxuZXhwb3J0cy5jbG9uZUVsZW0gPSBjbG9uZUVsZW07XHJcbi8qKlxyXG4gKiBBZGQgYXR0cmlidXRlcyB0byBET00gZWxlbWVudHNcclxuICovXHJcbmZ1bmN0aW9uIGFkZEF0dHJpYnV0ZXMoZWxlbSwgZGljdCwgZXZlbnRMaXN0ZW5lcikge1xyXG4gICAgZm9yICh2YXIga2V5IGluIGRpY3QpIHtcclxuICAgICAgICBpZiAoa2V5ID09PSBcInN0eWxlXCIpXHJcbiAgICAgICAgICAgIGVsZW1ba2V5XS5kaXNwbGF5ID0gZGljdFtrZXldO1xyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAvLyBAdHMtaWdub3JlXHJcbiAgICAgICAgICAgIGVsZW1ba2V5XSA9IGRpY3Rba2V5XTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBmb3IgKHZhciBrZXkgaW4gZXZlbnRMaXN0ZW5lcikge1xyXG4gICAgICAgIGVsZW0uYWRkRXZlbnRMaXN0ZW5lcihrZXksIGV2ZW50TGlzdGVuZXJba2V5XSk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZWxlbTtcclxufVxyXG5leHBvcnRzLmFkZEF0dHJpYnV0ZXMgPSBhZGRBdHRyaWJ1dGVzO1xyXG4vKipcclxuICogQXBwZW5kIGFsbCBlbGVtZW50cyBhcyBjaGlsZCBvZiAxc3QgYXJnXHJcbiAqL1xyXG5mdW5jdGlvbiBhcHBlbmRDaGlsZEFsbCh0bywgYXJyKSB7XHJcbiAgICBmb3IgKHZhciBvYmogaW4gYXJyKSB7XHJcbiAgICAgICAgdG8uYXBwZW5kQ2hpbGQoYXJyW29ial0pO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRvO1xyXG59XHJcbmV4cG9ydHMuYXBwZW5kQ2hpbGRBbGwgPSBhcHBlbmRDaGlsZEFsbDtcclxuZXhwb3J0cy5taW5pU2FrYWkgPSBjcmVhdGVFbGVtKFwiZGl2XCIsIHsgaWQ6IFwibWluaVNha2FpXCIgfSk7XHJcbmV4cG9ydHMubWluaVNha2FpLmNsYXNzTGlzdC5hZGQoXCJjcy1taW5pc2FrYWlcIiwgXCJjcy10YWJcIik7XHJcbmV4cG9ydHMuYXNzaWdubWVudERpdiA9IGNyZWF0ZUVsZW0oXCJkaXZcIiwgeyBjbGFzc05hbWU6IFwiY3MtYXNzaWdubWVudC10YWJcIiB9KTtcclxuZXhwb3J0cy5oYW1idXJnZXIgPSBjcmVhdGVFbGVtKFwiZGl2XCIsIHsgY2xhc3NOYW1lOiBcImNzLWxvYWRpbmdcIiB9LCB7IGNsaWNrOiBldmVudExpc3RlbmVyXzEudG9nZ2xlTWluaVNha2FpIH0pO1xyXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLW5hbWVzcGFjZVxyXG52YXIgU2V0dGluZ3NEb207XHJcbihmdW5jdGlvbiAoU2V0dGluZ3NEb20pIHtcclxuICAgIFNldHRpbmdzRG9tLm1haW5EaXYgPSBjcmVhdGVFbGVtKFwiZGl2XCIsIHsgY2xhc3NOYW1lOiBcImNwLXNldHRpbmdzXCIgfSk7XHJcbiAgICBTZXR0aW5nc0RvbS5kaXYgPSBjcmVhdGVFbGVtKFwiZGl2XCIpO1xyXG4gICAgU2V0dGluZ3NEb20ucCA9IGNyZWF0ZUVsZW0oXCJwXCIsIHsgY2xhc3NOYW1lOiBcImNwLXNldHRpbmdzLXRleHRcIiB9KTtcclxuICAgIFNldHRpbmdzRG9tLmxhYmVsID0gY3JlYXRlRWxlbShcImxhYmVsXCIpO1xyXG4gICAgU2V0dGluZ3NEb20udG9nZ2xlQnRuID0gY3JlYXRlRWxlbShcImlucHV0XCIsIHsgdHlwZTogXCJjaGVja2JveFwiIH0pO1xyXG4gICAgU2V0dGluZ3NEb20ucmVzZXRCdG4gPSBjcmVhdGVFbGVtKFwiaW5wdXRcIiwgeyB0eXBlOiBcImJ1dHRvblwiIH0pO1xyXG4gICAgU2V0dGluZ3NEb20uc3RyaW5nQm94ID0gY3JlYXRlRWxlbShcImlucHV0XCIsIHsgdHlwZTogXCJjb2xvclwiLCBjbGFzc05hbWU6IFwiY3Atc2V0dGluZ3MtaW5wdXRib3hcIiB9KTtcclxuICAgIFNldHRpbmdzRG9tLmlucHV0Qm94ID0gY3JlYXRlRWxlbShcImlucHV0XCIsIHsgdHlwZTogXCJudW1iZXJcIiwgY2xhc3NOYW1lOiBcImNwLXNldHRpbmdzLWlucHV0Ym94XCIgfSk7XHJcbiAgICBTZXR0aW5nc0RvbS5zcGFuID0gY3JlYXRlRWxlbShcInNwYW5cIiwgeyBjbGFzc05hbWU6IFwiY3MtdG9nZ2xlLXNsaWRlciByb3VuZFwiIH0pO1xyXG59KShTZXR0aW5nc0RvbSB8fCAoU2V0dGluZ3NEb20gPSB7fSkpO1xyXG5leHBvcnRzLlNldHRpbmdzRG9tID0gU2V0dGluZ3NEb207XHJcbiIsIlwidXNlIHN0cmljdFwiO1xyXG52YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcclxuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxyXG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogYWRvcHQocmVzdWx0LnZhbHVlKS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XHJcbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xyXG4gICAgfSk7XHJcbn07XHJcbnZhciBfX2dlbmVyYXRvciA9ICh0aGlzICYmIHRoaXMuX19nZW5lcmF0b3IpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBib2R5KSB7XHJcbiAgICB2YXIgXyA9IHsgbGFiZWw6IDAsIHNlbnQ6IGZ1bmN0aW9uKCkgeyBpZiAodFswXSAmIDEpIHRocm93IHRbMV07IHJldHVybiB0WzFdOyB9LCB0cnlzOiBbXSwgb3BzOiBbXSB9LCBmLCB5LCB0LCBnO1xyXG4gICAgcmV0dXJuIGcgPSB7IG5leHQ6IHZlcmIoMCksIFwidGhyb3dcIjogdmVyYigxKSwgXCJyZXR1cm5cIjogdmVyYigyKSB9LCB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgKGdbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uKCkgeyByZXR1cm4gdGhpczsgfSksIGc7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBzdGVwKFtuLCB2XSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAob3ApIHtcclxuICAgICAgICBpZiAoZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkdlbmVyYXRvciBpcyBhbHJlYWR5IGV4ZWN1dGluZy5cIik7XHJcbiAgICAgICAgd2hpbGUgKF8pIHRyeSB7XHJcbiAgICAgICAgICAgIGlmIChmID0gMSwgeSAmJiAodCA9IG9wWzBdICYgMiA/IHlbXCJyZXR1cm5cIl0gOiBvcFswXSA/IHlbXCJ0aHJvd1wiXSB8fCAoKHQgPSB5W1wicmV0dXJuXCJdKSAmJiB0LmNhbGwoeSksIDApIDogeS5uZXh0KSAmJiAhKHQgPSB0LmNhbGwoeSwgb3BbMV0pKS5kb25lKSByZXR1cm4gdDtcclxuICAgICAgICAgICAgaWYgKHkgPSAwLCB0KSBvcCA9IFtvcFswXSAmIDIsIHQudmFsdWVdO1xyXG4gICAgICAgICAgICBzd2l0Y2ggKG9wWzBdKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IGNhc2UgMTogdCA9IG9wOyBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgNDogXy5sYWJlbCsrOyByZXR1cm4geyB2YWx1ZTogb3BbMV0sIGRvbmU6IGZhbHNlIH07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDU6IF8ubGFiZWwrKzsgeSA9IG9wWzFdOyBvcCA9IFswXTsgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDc6IG9wID0gXy5vcHMucG9wKCk7IF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghKHQgPSBfLnRyeXMsIHQgPSB0Lmxlbmd0aCA+IDAgJiYgdFt0Lmxlbmd0aCAtIDFdKSAmJiAob3BbMF0gPT09IDYgfHwgb3BbMF0gPT09IDIpKSB7IF8gPSAwOyBjb250aW51ZTsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gMyAmJiAoIXQgfHwgKG9wWzFdID4gdFswXSAmJiBvcFsxXSA8IHRbM10pKSkgeyBfLmxhYmVsID0gb3BbMV07IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSA2ICYmIF8ubGFiZWwgPCB0WzFdKSB7IF8ubGFiZWwgPSB0WzFdOyB0ID0gb3A7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHQgJiYgXy5sYWJlbCA8IHRbMl0pIHsgXy5sYWJlbCA9IHRbMl07IF8ub3BzLnB1c2gob3ApOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0WzJdKSBfLm9wcy5wb3AoKTtcclxuICAgICAgICAgICAgICAgICAgICBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG9wID0gYm9keS5jYWxsKHRoaXNBcmcsIF8pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHsgb3AgPSBbNiwgZV07IHkgPSAwOyB9IGZpbmFsbHkgeyBmID0gdCA9IDA7IH1cclxuICAgICAgICBpZiAob3BbMF0gJiA1KSB0aHJvdyBvcFsxXTsgcmV0dXJuIHsgdmFsdWU6IG9wWzBdID8gb3BbMV0gOiB2b2lkIDAsIGRvbmU6IHRydWUgfTtcclxuICAgIH1cclxufTtcclxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xyXG5leHBvcnRzLmVkaXRGYXZvcml0ZXNNZXNzYWdlID0gZXhwb3J0cy5kZWxldGVNZW1vID0gZXhwb3J0cy51cGRhdGVTZXR0aW5ncyA9IGV4cG9ydHMuYWRkTWVtbyA9IGV4cG9ydHMudG9nZ2xlRmluaXNoZWRGbGFnID0gZXhwb3J0cy50b2dnbGVNZW1vQm94ID0gZXhwb3J0cy50b2dnbGVTZXR0aW5nc1RhYiA9IGV4cG9ydHMudG9nZ2xlQXNzaWdubWVudFRhYiA9IGV4cG9ydHMudG9nZ2xlTWluaVNha2FpID0gdm9pZCAwO1xyXG52YXIgZG9tXzEgPSByZXF1aXJlKFwiLi9kb21cIik7XHJcbnZhciBzdG9yYWdlXzEgPSByZXF1aXJlKFwiLi9zdG9yYWdlXCIpO1xyXG52YXIgbW9kZWxfMSA9IHJlcXVpcmUoXCIuL21vZGVsXCIpO1xyXG52YXIgdXRpbHNfMSA9IHJlcXVpcmUoXCIuL3V0aWxzXCIpO1xyXG52YXIgY29udGVudF9zY3JpcHRfMSA9IHJlcXVpcmUoXCIuL2NvbnRlbnRfc2NyaXB0XCIpO1xyXG52YXIgc2V0dGluZ3NfMSA9IHJlcXVpcmUoXCIuL3NldHRpbmdzXCIpO1xyXG52YXIgbWluaXNha2FpXzEgPSByZXF1aXJlKFwiLi9taW5pc2FrYWlcIik7XHJcbnZhciB0b2dnbGUgPSBmYWxzZTtcclxuLyoqXHJcbiAqIENoYW5nZSB2aXNpYmlsaXR5IG9mIG1pbmlTYWthaVxyXG4gKi9cclxuZnVuY3Rpb24gdG9nZ2xlTWluaVNha2FpKCkge1xyXG4gICAgdmFyIF9hO1xyXG4gICAgaWYgKHRvZ2dsZSkge1xyXG4gICAgICAgIC8vIEhpZGUgbWluaVNha2FpXHJcbiAgICAgICAgZG9tXzEubWluaVNha2FpLnN0eWxlLndpZHRoID0gXCIwcHhcIjtcclxuICAgICAgICAoX2EgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNzLWNvdmVyXCIpKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EucmVtb3ZlKCk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgICAvLyBEaXNwbGF5IG1pbmlTYWthaVxyXG4gICAgICAgIGRvbV8xLm1pbmlTYWthaS5zdHlsZS53aWR0aCA9IFwiMzAwcHhcIjtcclxuICAgICAgICB2YXIgY292ZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xyXG4gICAgICAgIGNvdmVyLmlkID0gXCJjcy1jb3ZlclwiO1xyXG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiYm9keVwiKVswXS5hcHBlbmRDaGlsZChjb3Zlcik7XHJcbiAgICAgICAgY292ZXIub25jbGljayA9IHRvZ2dsZU1pbmlTYWthaTtcclxuICAgIH1cclxuICAgIHRvZ2dsZSA9ICF0b2dnbGU7XHJcbn1cclxuZXhwb3J0cy50b2dnbGVNaW5pU2FrYWkgPSB0b2dnbGVNaW5pU2FrYWk7XHJcbi8qKlxyXG4gKiBDaGFuZ2UgdmlzaWJpbGl0eSBvZiBBc3NpZ25tZW50IHRhYlxyXG4gKi9cclxuZnVuY3Rpb24gdG9nZ2xlQXNzaWdubWVudFRhYigpIHtcclxuICAgIHZhciBhc3NpZ25tZW50VGFiID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5jcy1hc3NpZ25tZW50LXRhYlwiKTtcclxuICAgIGFzc2lnbm1lbnRUYWIuc3R5bGUuZGlzcGxheSA9IFwiXCI7XHJcbiAgICB2YXIgc2V0dGluZ3NUYWIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmNzLXNldHRpbmdzLXRhYlwiKTtcclxuICAgIHNldHRpbmdzVGFiLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcclxuICAgIHZhciBhZGRNZW1vQnV0dG9uID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNjcy1hZGQtbWVtby1idG5cIik7XHJcbiAgICBhZGRNZW1vQnV0dG9uLnN0eWxlLmRpc3BsYXkgPSBcIlwiO1xyXG4gICAgdmFyIGFzc2lnbm1lbnRGZXRjaGVkVGltZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuY3MtYXNzaWdubWVudC10aW1lXCIpO1xyXG4gICAgYXNzaWdubWVudEZldGNoZWRUaW1lLnN0eWxlLmRpc3BsYXkgPSBcIlwiO1xyXG4gICAgdmFyIHF1aXpGZXRjaGVkVGltZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuY3MtcXVpei10aW1lXCIpO1xyXG4gICAgcXVpekZldGNoZWRUaW1lLnN0eWxlLmRpc3BsYXkgPSBcIlwiO1xyXG59XHJcbmV4cG9ydHMudG9nZ2xlQXNzaWdubWVudFRhYiA9IHRvZ2dsZUFzc2lnbm1lbnRUYWI7XHJcbi8qKlxyXG4gKiBDaGFuZ2UgdmlzaWJpbGl0eSBvZiBTZXR0aW5ncyB0YWJcclxuICovXHJcbmZ1bmN0aW9uIHRvZ2dsZVNldHRpbmdzVGFiKCkge1xyXG4gICAgdmFyIGFzc2lnbm1lbnRUYWIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmNzLWFzc2lnbm1lbnQtdGFiXCIpO1xyXG4gICAgYXNzaWdubWVudFRhYi5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XHJcbiAgICB2YXIgc2V0dGluZ3NUYWIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmNzLXNldHRpbmdzLXRhYlwiKTtcclxuICAgIHNldHRpbmdzVGFiLnN0eWxlLmRpc3BsYXkgPSBcIlwiO1xyXG4gICAgdmFyIGFkZE1lbW9CdXR0b24gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2NzLWFkZC1tZW1vLWJ0blwiKTtcclxuICAgIGFkZE1lbW9CdXR0b24uc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xyXG4gICAgdmFyIGFzc2lnbm1lbnRGZXRjaGVkVGltZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuY3MtYXNzaWdubWVudC10aW1lXCIpO1xyXG4gICAgYXNzaWdubWVudEZldGNoZWRUaW1lLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcclxuICAgIHZhciBxdWl6RmV0Y2hlZFRpbWUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmNzLXF1aXotdGltZVwiKTtcclxuICAgIHF1aXpGZXRjaGVkVGltZS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XHJcbn1cclxuZXhwb3J0cy50b2dnbGVTZXR0aW5nc1RhYiA9IHRvZ2dsZVNldHRpbmdzVGFiO1xyXG4vKipcclxuICogQ2hhbmdlIHZpc2liaWxpdHkgb2YgTWVtbyBib3hcclxuICovXHJcbmZ1bmN0aW9uIHRvZ2dsZU1lbW9Cb3goKSB7XHJcbiAgICB2YXIgYWRkTWVtb0JveCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuYWRkTWVtb0JveFwiKTtcclxuICAgIHZhciB0b2dnbGVTdGF0dXMgPSBhZGRNZW1vQm94LnN0eWxlLmRpc3BsYXk7XHJcbiAgICBpZiAodG9nZ2xlU3RhdHVzID09PSBcIlwiKSB7XHJcbiAgICAgICAgYWRkTWVtb0JveC5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgICBhZGRNZW1vQm94LnN0eWxlLmRpc3BsYXkgPSBcIlwiO1xyXG4gICAgfVxyXG59XHJcbmV4cG9ydHMudG9nZ2xlTWVtb0JveCA9IHRvZ2dsZU1lbW9Cb3g7XHJcbi8qKlxyXG4gKiBUb2dnbGUgZmluaXNoZWQgY2hlY2tib3ggZm9yIGFzc2lnbm1lbnQvcXVpelxyXG4gKi9cclxuZnVuY3Rpb24gdG9nZ2xlRmluaXNoZWRGbGFnKGV2ZW50KSB7XHJcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIGFzc2lnbm1lbnRJRCwgYXNzaWdubWVudExpc3QsIF9hLCBfYiwgX2MsIHVwZGF0ZWRBc3NpZ25tZW50TGlzdCwgX2ksIGFzc2lnbm1lbnRMaXN0XzEsIGFzc2lnbm1lbnQsIHVwZGF0ZWRBc3NpZ25tZW50RW50cmllcywgX2QsIF9lLCBhc3NpZ25tZW50RW50cnksIGlzRmluaXNoZWQsIGlzUXVpejtcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9mKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2YubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50SUQgPSBldmVudC50YXJnZXQuaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEoYXNzaWdubWVudElEWzBdID09PSBcIm1cIikpIHJldHVybiBbMyAvKmJyZWFrKi8sIDJdO1xyXG4gICAgICAgICAgICAgICAgICAgIF9hID0gdXRpbHNfMS5jb252ZXJ0QXJyYXlUb0Fzc2lnbm1lbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLmxvYWRGcm9tTG9jYWxTdG9yYWdlKFwiQ1NfTWVtb0xpc3RcIildO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIGFzc2lnbm1lbnRMaXN0ID0gX2EuYXBwbHkodm9pZCAwLCBbX2Yuc2VudCgpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgNl07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDI6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEoYXNzaWdubWVudElEWzBdID09PSBcInFcIikpIHJldHVybiBbMyAvKmJyZWFrKi8sIDRdO1xyXG4gICAgICAgICAgICAgICAgICAgIF9iID0gdXRpbHNfMS5jb252ZXJ0QXJyYXlUb0Fzc2lnbm1lbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLmxvYWRGcm9tTG9jYWxTdG9yYWdlKFwiQ1NfUXVpekxpc3RcIildO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAzOlxyXG4gICAgICAgICAgICAgICAgICAgIGFzc2lnbm1lbnRMaXN0ID0gX2IuYXBwbHkodm9pZCAwLCBbX2Yuc2VudCgpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgNl07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ6XHJcbiAgICAgICAgICAgICAgICAgICAgX2MgPSB1dGlsc18xLmNvbnZlcnRBcnJheVRvQXNzaWdubWVudDtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEubG9hZEZyb21Mb2NhbFN0b3JhZ2UoXCJDU19Bc3NpZ25tZW50TGlzdFwiKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDU6XHJcbiAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudExpc3QgPSBfYy5hcHBseSh2b2lkIDAsIFtfZi5zZW50KCldKTtcclxuICAgICAgICAgICAgICAgICAgICBfZi5sYWJlbCA9IDY7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDY6XHJcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEFzc2lnbm1lbnRMaXN0ID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChfaSA9IDAsIGFzc2lnbm1lbnRMaXN0XzEgPSBhc3NpZ25tZW50TGlzdDsgX2kgPCBhc3NpZ25tZW50TGlzdF8xLmxlbmd0aDsgX2krKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50ID0gYXNzaWdubWVudExpc3RfMVtfaV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRBc3NpZ25tZW50RW50cmllcyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKF9kID0gMCwgX2UgPSBhc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzOyBfZCA8IF9lLmxlbmd0aDsgX2QrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudEVudHJ5ID0gX2VbX2RdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGFzc2lnbm1lbnRFbnRyeS5hc3NpZ25tZW50SUQgPT09IGFzc2lnbm1lbnRJRCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRmluaXNoZWQgPSBhc3NpZ25tZW50RW50cnkuaXNGaW5pc2hlZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1F1aXogPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGFzc2lnbm1lbnRFbnRyeS5pc1F1aXogIT09IFwidW5kZWZpbmVkXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzUXVpeiA9IGFzc2lnbm1lbnRFbnRyeS5pc1F1aXo7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEFzc2lnbm1lbnRFbnRyaWVzLnB1c2gobmV3IG1vZGVsXzEuQXNzaWdubWVudEVudHJ5KGFzc2lnbm1lbnRFbnRyeS5hc3NpZ25tZW50SUQsIGFzc2lnbm1lbnRFbnRyeS5hc3NpZ25tZW50VGl0bGUsIGFzc2lnbm1lbnRFbnRyeS5kdWVEYXRlVGltZXN0YW1wLCBhc3NpZ25tZW50RW50cnkuY2xvc2VEYXRlVGltZXN0YW1wLCBhc3NpZ25tZW50RW50cnkuaXNNZW1vLCAhaXNGaW5pc2hlZCwgaXNRdWl6LCBhc3NpZ25tZW50RW50cnkuYXNzaWdubWVudERldGFpbCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEFzc2lnbm1lbnRFbnRyaWVzLnB1c2goYXNzaWdubWVudEVudHJ5KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkQXNzaWdubWVudExpc3QucHVzaChuZXcgbW9kZWxfMS5Bc3NpZ25tZW50KGFzc2lnbm1lbnQuY291cnNlU2l0ZUluZm8sIHVwZGF0ZWRBc3NpZ25tZW50RW50cmllcywgYXNzaWdubWVudC5pc1JlYWQpKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEoYXNzaWdubWVudElEWzBdID09PSBcIm1cIikpIHJldHVybiBbMyAvKmJyZWFrKi8sIDhdO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5zYXZlVG9Mb2NhbFN0b3JhZ2UoXCJDU19NZW1vTGlzdFwiLCB1cGRhdGVkQXNzaWdubWVudExpc3QpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzpcclxuICAgICAgICAgICAgICAgICAgICBfZi5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgMTJdO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA4OlxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghKGFzc2lnbm1lbnRJRFswXSA9PT0gXCJxXCIpKSByZXR1cm4gWzMgLypicmVhayovLCAxMF07XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLnNhdmVUb0xvY2FsU3RvcmFnZShcIkNTX1F1aXpMaXN0XCIsIHVwZGF0ZWRBc3NpZ25tZW50TGlzdCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA5OlxyXG4gICAgICAgICAgICAgICAgICAgIF9mLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzMgLypicmVhayovLCAxMl07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDEwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEuc2F2ZVRvTG9jYWxTdG9yYWdlKFwiQ1NfQXNzaWdubWVudExpc3RcIiwgdXBkYXRlZEFzc2lnbm1lbnRMaXN0KV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDExOlxyXG4gICAgICAgICAgICAgICAgICAgIF9mLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICBfZi5sYWJlbCA9IDEyO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxMjogcmV0dXJuIFs0IC8qeWllbGQqLywgcmVkcmF3RmF2b3JpdGVzQmFyKGNvbnRlbnRfc2NyaXB0XzEuY291cnNlSURMaXN0LCB0cnVlKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDEzOlxyXG4gICAgICAgICAgICAgICAgICAgIF9mLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMudG9nZ2xlRmluaXNoZWRGbGFnID0gdG9nZ2xlRmluaXNoZWRGbGFnO1xyXG4vKipcclxuICogVXBkYXRlIFNldHRpbmdzIHBhcmFtZXRlclxyXG4gKi9cclxuZnVuY3Rpb24gdXBkYXRlU2V0dGluZ3MoZXZlbnQsIHR5cGUpIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgc2V0dGluZ3NJRCwgc2V0dGluZ3NWYWx1ZSwgY29uZmlnLCBDU3NldHRpbmdzLCBjb2xvckxpc3QsIF9pLCBjb2xvckxpc3RfMSwgaywgcTtcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICBzZXR0aW5nc0lEID0gZXZlbnQudGFyZ2V0LmlkO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldHRpbmdzVmFsdWUgPSBldmVudC50YXJnZXQudmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc2V0dGluZ3NfMS5sb2FkQ29uZmlncygpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBjb25maWcgPSBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgQ1NzZXR0aW5ncyA9IGNvbmZpZy5DU3NldHRpbmdzO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIFR5cGUgb2YgU2V0dGluZ3NcclxuICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcImNoZWNrXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXR0aW5nc1ZhbHVlID0gZXZlbnQudGFyZ2V0LmNoZWNrZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcIm51bWJlclwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0dGluZ3NWYWx1ZSA9IHBhcnNlSW50KGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcInN0cmluZ1wiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlID09PSBcInJlc2V0XCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3JMaXN0ID0gW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ0b3BDb2xvckRhbmdlclwiLCBcInRvcENvbG9yV2FybmluZ1wiLCBcInRvcENvbG9yU3VjY2Vzc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJtaW5pQ29sb3JEYW5nZXJcIiwgXCJtaW5pQ29sb3JXYXJuaW5nXCIsIFwibWluaUNvbG9yU3VjY2Vzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoX2kgPSAwLCBjb2xvckxpc3RfMSA9IGNvbG9yTGlzdDsgX2kgPCBjb2xvckxpc3RfMS5sZW5ndGg7IF9pKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGsgPSBjb2xvckxpc3RfMVtfaV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBAdHMtaWdub3JlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDU3NldHRpbmdzW2tdID0gc2V0dGluZ3NfMS5EZWZhdWx0U2V0dGluZ3Nba107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBxID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoayk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEB0cy1pZ25vcmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxLnZhbHVlID0gc2V0dGluZ3NfMS5EZWZhdWx0U2V0dGluZ3Nba107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEB0cy1pZ25vcmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ1NzZXR0aW5nc1tzZXR0aW5nc0lEXSA9IHNldHRpbmdzVmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5zYXZlVG9Mb2NhbFN0b3JhZ2UoXCJDU19TZXR0aW5nc1wiLCBDU3NldHRpbmdzKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDI6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHJlZHJhd0Zhdm9yaXRlc0Jhcihjb250ZW50X3NjcmlwdF8xLmNvdXJzZUlETGlzdCwgdHJ1ZSldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAzOlxyXG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMudXBkYXRlU2V0dGluZ3MgPSB1cGRhdGVTZXR0aW5ncztcclxuLyoqXHJcbiAqIEFkZCBNZW1vIHRvIG1pbmlTYWthaSBhbmQgc2F2ZS5cclxuICovXHJcbmZ1bmN0aW9uIGFkZE1lbW8oKSB7XHJcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIHNlbGVjdGVkSWR4LCBjb3Vyc2VJRCwgbWVtb1RpdGxlLCBtZW1vRHVlRGF0ZVRpbWVzdGFtcCwgbWVtb0xpc3QsIG1lbW9FbnRyeSwgbWVtbywgaWR4LCBhc3NpZ25tZW50TGlzdCwgcXVpekxpc3Q7XHJcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRJZHggPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnRvZG9MZWNOYW1lXCIpLnNlbGVjdGVkSW5kZXg7XHJcbiAgICAgICAgICAgICAgICAgICAgY291cnNlSUQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnRvZG9MZWNOYW1lXCIpLm9wdGlvbnNbc2VsZWN0ZWRJZHhdLmlkO1xyXG4gICAgICAgICAgICAgICAgICAgIG1lbW9UaXRsZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIudG9kb0NvbnRlbnRcIikudmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVtb0R1ZURhdGVUaW1lc3RhbXAgPSBuZXcgRGF0ZShkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnRvZG9EdWVcIikudmFsdWUpLmdldFRpbWUoKSAvIDEwMDA7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLmxvYWRGcm9tTG9jYWxTdG9yYWdlKFwiQ1NfTWVtb0xpc3RcIildO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIG1lbW9MaXN0ID0gX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIG1lbW9FbnRyeSA9IG5ldyBtb2RlbF8xLkFzc2lnbm1lbnRFbnRyeSh1dGlsc18xLmdlblVuaXF1ZUlEKFwibVwiKSwgbWVtb1RpdGxlLCBtZW1vRHVlRGF0ZVRpbWVzdGFtcCwgbWVtb0R1ZURhdGVUaW1lc3RhbXAsIHRydWUsIGZhbHNlLCBmYWxzZSwgXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVtbyA9IG5ldyBtb2RlbF8xLkFzc2lnbm1lbnQobmV3IG1vZGVsXzEuQ291cnNlU2l0ZUluZm8oY291cnNlSUQsIGNvdXJzZUlEKSwgW21lbW9FbnRyeV0sIHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVtb0xpc3QgIT09IFwidW5kZWZpbmVkXCIgJiYgbWVtb0xpc3QubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZW1vTGlzdCA9IHV0aWxzXzEuY29udmVydEFycmF5VG9Bc3NpZ25tZW50KG1lbW9MaXN0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWR4ID0gbWVtb0xpc3QuZmluZEluZGV4KGZ1bmN0aW9uIChvbGRNZW1vKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gb2xkTWVtby5jb3Vyc2VTaXRlSW5mby5jb3Vyc2VJRCA9PT0gY291cnNlSUQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaWR4ICE9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVtb0xpc3RbaWR4XS5hc3NpZ25tZW50RW50cmllcy5wdXNoKG1lbW9FbnRyeSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZW1vTGlzdC5wdXNoKG1lbW8pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZW1vTGlzdCA9IFttZW1vXTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgc3RvcmFnZV8xLnNhdmVUb0xvY2FsU3RvcmFnZShcIkNTX01lbW9MaXN0XCIsIG1lbW9MaXN0KTtcclxuICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50TGlzdCA9IHV0aWxzXzEubWVyZ2VJbnRvQXNzaWdubWVudExpc3QoY29udGVudF9zY3JpcHRfMS5tZXJnZWRBc3NpZ25tZW50TGlzdE5vTWVtbywgbWVtb0xpc3QpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5sb2FkRnJvbUxvY2FsU3RvcmFnZShcIkNTX1F1aXpMaXN0XCIpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICBxdWl6TGlzdCA9IF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZWRyYXdNaW5pU2FrYWkoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBtaW5pc2FrYWlfMS5kaXNwbGF5TWluaVNha2FpKHV0aWxzXzEubWVyZ2VJbnRvQXNzaWdubWVudExpc3QoYXNzaWdubWVudExpc3QsIHF1aXpMaXN0KSwgY29udGVudF9zY3JpcHRfMS5jb3Vyc2VJRExpc3QpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgcmVkcmF3RmF2b3JpdGVzQmFyKGNvbnRlbnRfc2NyaXB0XzEuY291cnNlSURMaXN0LCB0cnVlKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuZXhwb3J0cy5hZGRNZW1vID0gYWRkTWVtbztcclxuLyoqXHJcbiAqIERlbGV0ZSBNZW1vIGZyb20gbWluaVNha2FpIGFuZCBzdG9yYWdlLlxyXG4gKi9cclxuZnVuY3Rpb24gZGVsZXRlTWVtbyhldmVudCkge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBtZW1vSUQsIG1lbW9MaXN0LCBfYSwgZGVsZXRlZE1lbW9MaXN0LCBfaSwgbWVtb0xpc3RfMSwgbWVtbywgbWVtb0VudHJpZXMsIF9iLCBfYywgbWVtb0VudHJ5LCBhc3NpZ25tZW50TGlzdCwgcXVpekxpc3Q7XHJcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfZCkge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKF9kLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICAgICAgbWVtb0lEID0gZXZlbnQudGFyZ2V0LmlkO1xyXG4gICAgICAgICAgICAgICAgICAgIF9hID0gdXRpbHNfMS5jb252ZXJ0QXJyYXlUb0Fzc2lnbm1lbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLmxvYWRGcm9tTG9jYWxTdG9yYWdlKFwiQ1NfTWVtb0xpc3RcIildO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIG1lbW9MaXN0ID0gX2EuYXBwbHkodm9pZCAwLCBbX2Quc2VudCgpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlZE1lbW9MaXN0ID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChfaSA9IDAsIG1lbW9MaXN0XzEgPSBtZW1vTGlzdDsgX2kgPCBtZW1vTGlzdF8xLmxlbmd0aDsgX2krKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZW1vID0gbWVtb0xpc3RfMVtfaV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lbW9FbnRyaWVzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoX2IgPSAwLCBfYyA9IG1lbW8uYXNzaWdubWVudEVudHJpZXM7IF9iIDwgX2MubGVuZ3RoOyBfYisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZW1vRW50cnkgPSBfY1tfYl07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobWVtb0VudHJ5LmFzc2lnbm1lbnRJRCAhPT0gbWVtb0lEKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lbW9FbnRyaWVzLnB1c2gobWVtb0VudHJ5KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxldGVkTWVtb0xpc3QucHVzaChuZXcgbW9kZWxfMS5Bc3NpZ25tZW50KG1lbW8uY291cnNlU2l0ZUluZm8sIG1lbW9FbnRyaWVzLCBtZW1vLmlzUmVhZCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBzdG9yYWdlXzEuc2F2ZVRvTG9jYWxTdG9yYWdlKFwiQ1NfTWVtb0xpc3RcIiwgZGVsZXRlZE1lbW9MaXN0KTtcclxuICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50TGlzdCA9IHV0aWxzXzEubWVyZ2VJbnRvQXNzaWdubWVudExpc3QoY29udGVudF9zY3JpcHRfMS5tZXJnZWRBc3NpZ25tZW50TGlzdE5vTWVtbywgZGVsZXRlZE1lbW9MaXN0KTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEubG9hZEZyb21Mb2NhbFN0b3JhZ2UoXCJDU19RdWl6TGlzdFwiKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDI6XHJcbiAgICAgICAgICAgICAgICAgICAgcXVpekxpc3QgPSBfZC5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVkcmF3TWluaVNha2FpKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgbWluaXNha2FpXzEuZGlzcGxheU1pbmlTYWthaSh1dGlsc18xLm1lcmdlSW50b0Fzc2lnbm1lbnRMaXN0KGFzc2lnbm1lbnRMaXN0LCBxdWl6TGlzdCksIGNvbnRlbnRfc2NyaXB0XzEuY291cnNlSURMaXN0KV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDM6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Quc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHJlZHJhd0Zhdm9yaXRlc0Jhcihjb250ZW50X3NjcmlwdF8xLmNvdXJzZUlETGlzdCwgdHJ1ZSldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OlxyXG4gICAgICAgICAgICAgICAgICAgIF9kLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMuZGVsZXRlTWVtbyA9IGRlbGV0ZU1lbW87XHJcbi8qKlxyXG4gKiBFZGl0IGRlZmF1bHQgbWVzc2FnZSBvZiBmYXZvcml0ZXMgdGFiLlxyXG4gKi9cclxuZnVuY3Rpb24gZWRpdEZhdm9yaXRlc01lc3NhZ2UoKSB7XHJcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIG1lc3NhZ2UsIGxlY3R1cmVUYWJzLCBsZWN0dXJlVGFic0NvdW50LCBpO1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiBcclxuICAgICAgICAgICAgICAgIC8vIFdhaXQgMjAwbXMgdW50aWwgalF1ZXJ5IGZpbmlzaGVkIGdlbmVyYXRpbmcgbWVzc2FnZS5cclxuICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyKSB7IHJldHVybiBzZXRUaW1lb3V0KHIsIDIwMCk7IH0pXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICAvLyBXYWl0IDIwMG1zIHVudGlsIGpRdWVyeSBmaW5pc2hlZCBnZW5lcmF0aW5nIG1lc3NhZ2UuXHJcbiAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiZmF2b3JpdGVzLW1heC1tYXJrZXJcIilbMF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UuaW5uZXJIVE1MID0gXCI8aSBjbGFzcz1cXFwiZmEgZmEtYmVsbCB3YXJuaW5nLWljb25cXFwiPjwvaT5cIiArIGNocm9tZS5ydW50aW1lLmdldE1hbmlmZXN0KCkubmFtZSArIFwiXFx1MzA2QlxcdTMwODhcXHUzMDYzXFx1MzA2NlxcdTMwNEFcXHU2QzE3XFx1MzA2QlxcdTUxNjVcXHUzMDhBXFx1NzY3QlxcdTkzMzJcXHUzMDU3XFx1MzA1Rjxicj5cXHUzMEI1XFx1MzBBNFxcdTMwQzhcXHUzMDRDXFx1NTE2OFxcdTMwNjZcXHUzMEQwXFx1MzBGQ1xcdTMwNkJcXHU4RkZEXFx1NTJBMFxcdTMwNTVcXHUzMDhDXFx1MzA3RVxcdTMwNTdcXHUzMDVGXFx1MzAwMlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZWN0dXJlVGFicyA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJmYXYtc2l0ZXMtZW50cnlcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxlY3R1cmVUYWJzQ291bnQgPSBsZWN0dXJlVGFicy5sZW5ndGg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCBsZWN0dXJlVGFic0NvdW50OyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlY3R1cmVUYWJzW2ldLmNsYXNzTGlzdC5yZW1vdmUoXCJzaXRlLWZhdm9yaXRlLWlzLXBhc3QtbWF4XCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiY291bGQgbm90IGVkaXQgbWVzc2FnZVwiKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLmVkaXRGYXZvcml0ZXNNZXNzYWdlID0gZWRpdEZhdm9yaXRlc01lc3NhZ2U7XHJcbi8qKlxyXG4gKiBSZWRyYXcgZmF2b3JpdGVzIGJhclxyXG4gKiBAcGFyYW0ge0NvdXJzZVNpdGVJbmZvW119IGNvdXJzZUlETGlzdFxyXG4gKiBAcGFyYW0ge2Jvb2xlYW59IHVzZUNhY2hlXHJcbiAqL1xyXG5mdW5jdGlvbiByZWRyYXdGYXZvcml0ZXNCYXIoY291cnNlSURMaXN0LCB1c2VDYWNoZSkge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBjb25maWcsIG5ld0Fzc2lnbm1lbnRMaXN0O1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgICAgIG1pbmlzYWthaV8xLmRlbGV0ZUZhdm9yaXRlc0Jhck5vdGlmaWNhdGlvbigpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHNldHRpbmdzXzEubG9hZENvbmZpZ3MoKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlnID0gX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIGNvbnRlbnRfc2NyaXB0XzEubG9hZEFuZE1lcmdlQXNzaWdubWVudExpc3QoY29uZmlnLCBjb3Vyc2VJRExpc3QsIHVzZUNhY2hlLCB1c2VDYWNoZSldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgIG5ld0Fzc2lnbm1lbnRMaXN0ID0gX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIG1pbmlzYWthaV8xLmNyZWF0ZUZhdm9yaXRlc0Jhck5vdGlmaWNhdGlvbihjb3Vyc2VJRExpc3QsIG5ld0Fzc2lnbm1lbnRMaXN0KV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDM6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuLyoqXHJcbiAqIFJlZHJhdyBtaW5pU2FrYWlcclxuICovXHJcbmZ1bmN0aW9uIHJlZHJhd01pbmlTYWthaSgpIHtcclxuICAgIHdoaWxlIChkb21fMS5taW5pU2FrYWkuZmlyc3RDaGlsZCkge1xyXG4gICAgICAgIGRvbV8xLm1pbmlTYWthaS5yZW1vdmVDaGlsZChkb21fMS5taW5pU2FrYWkuZmlyc3RDaGlsZCk7XHJcbiAgICB9XHJcbiAgICB3aGlsZSAoZG9tXzEuYXNzaWdubWVudERpdi5maXJzdENoaWxkKSB7XHJcbiAgICAgICAgZG9tXzEuYXNzaWdubWVudERpdi5yZW1vdmVDaGlsZChkb21fMS5hc3NpZ25tZW50RGl2LmZpcnN0Q2hpbGQpO1xyXG4gICAgfVxyXG4gICAgZG9tXzEubWluaVNha2FpLnJlbW92ZSgpO1xyXG4gICAgZG9tXzEuYXNzaWdubWVudERpdi5yZW1vdmUoKTtcclxufVxyXG4iLCJcInVzZSBzdHJpY3RcIjtcclxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xyXG5leHBvcnRzLmFkZEZhdm9yaXRlZENvdXJzZVNpdGVzID0gdm9pZCAwO1xyXG52YXIgZXZlbnRMaXN0ZW5lcl8xID0gcmVxdWlyZShcIi4vZXZlbnRMaXN0ZW5lclwiKTtcclxuLyoqXHJcbiAqIExpbWl0IG1heGltdW0gbnVtYmVyIG9mIGNvdXJzZSBzaXRlc1xyXG4gKiBAdHlwZSB7aW50fVxyXG4gKi9cclxudmFyIE1BWF9GQVZPUklURVMgPSAyMDtcclxuZnVuY3Rpb24gZ2V0U2l0ZUlkQW5kSHJlZlNpdGVOYW1lTWFwKCkge1xyXG4gICAgdmFyIHNpdGVzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5mYXYtc2l0ZXMtZW50cnlcIik7XHJcbiAgICB2YXIgbWFwID0gbmV3IE1hcCgpO1xyXG4gICAgc2l0ZXMuZm9yRWFjaChmdW5jdGlvbiAoc2l0ZSkge1xyXG4gICAgICAgIHZhciBfYSwgX2IsIF9jO1xyXG4gICAgICAgIHZhciBzaXRlSWQgPSAoX2EgPSBzaXRlLnF1ZXJ5U2VsZWN0b3IoXCIuc2l0ZS1mYXZvcml0ZS1idG5cIikpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5nZXRBdHRyaWJ1dGUoXCJkYXRhLXNpdGUtaWRcIik7XHJcbiAgICAgICAgaWYgKHNpdGVJZCA9PSBudWxsKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgdmFyIGhyZWYgPSAoKF9iID0gc2l0ZS5xdWVyeVNlbGVjdG9yKFwiLmZhdi10aXRsZVwiKSkgPT09IG51bGwgfHwgX2IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9iLmNoaWxkTm9kZXNbMV0pLmhyZWY7XHJcbiAgICAgICAgdmFyIHRpdGxlID0gKChfYyA9IHNpdGUucXVlcnlTZWxlY3RvcihcIi5mYXYtdGl0bGVcIikpID09PSBudWxsIHx8IF9jID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYy5jaGlsZE5vZGVzWzFdKS50aXRsZTtcclxuICAgICAgICBtYXAuc2V0KHNpdGVJZCwgeyBocmVmOiBocmVmLCB0aXRsZTogdGl0bGUgfSk7XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBtYXA7XHJcbn1cclxuLyoqXHJcbiAqIENoZWNrIGlmIGN1cnJlbnQgc2l0ZS1pZCBpcyBnaXZlbiBzaXRlLWlkXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSBzaXRlSWRcclxuICovXHJcbmZ1bmN0aW9uIGlzQ3VycmVudFNpdGUoc2l0ZUlkKSB7XHJcbiAgICB2YXIgY3VycmVudFNpdGVJZE0gPSB3aW5kb3cubG9jYXRpb24uaHJlZi5tYXRjaCgvaHR0cHM/OlxcL1xcL1teXFwvXStcXC9wb3J0YWxcXC9zaXRlXFwvKFteXFwvXSspLyk7XHJcbiAgICBpZiAoY3VycmVudFNpdGVJZE0gPT0gbnVsbClcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICByZXR1cm4gY3VycmVudFNpdGVJZE1bMV0gPT0gc2l0ZUlkO1xyXG59XHJcbi8qKlxyXG4gKiBHZXQgaHJlZnMgb2Ygc2l0ZXMgaW4gZmF2b3JpdGUgYmFyXHJcbiAqL1xyXG5mdW5jdGlvbiBnZXRDdXJyZW50RmF2b3JpdGVzU2l0ZSgpIHtcclxuICAgIHZhciB0b3BuYXYgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3RvcG5hdlwiKTtcclxuICAgIGlmICh0b3BuYXYgPT0gbnVsbClcclxuICAgICAgICByZXR1cm4gbmV3IEFycmF5KCk7XHJcbiAgICB2YXIgc2l0ZXMgPSB0b3BuYXYucXVlcnlTZWxlY3RvckFsbChcIi5NcnBocy1zaXRlc05hdl9fbWVudWl0ZW1cIik7XHJcbiAgICB2YXIgaHJlZnMgPSBbXTtcclxuICAgIGZvciAodmFyIF9pID0gMCwgX2EgPSBBcnJheS5mcm9tKHNpdGVzKTsgX2kgPCBfYS5sZW5ndGg7IF9pKyspIHtcclxuICAgICAgICB2YXIgc2l0ZSA9IF9hW19pXTtcclxuICAgICAgICB2YXIgaHJlZiA9IHNpdGUuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImxpbmstY29udGFpbmVyXCIpWzBdLmhyZWY7XHJcbiAgICAgICAgaHJlZnMucHVzaChocmVmKTtcclxuICAgIH1cclxuICAgIHJldHVybiBocmVmcztcclxufVxyXG4vKipcclxuICogQWRkIGNvdXJzZSBzaXRlcyB0byBmYXZvcml0ZXMgYmFyIChtb3JlIHRoYW4gU2FrYWkgY29uZmlnKVxyXG4gKiBAcGFyYW0ge3N0cmluZ30gYmFzZVVSTFxyXG4gKi9cclxuZnVuY3Rpb24gYWRkRmF2b3JpdGVkQ291cnNlU2l0ZXMoYmFzZVVSTCkge1xyXG4gICAgdmFyIF9hO1xyXG4gICAgdmFyIHRvcG5hdiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjdG9wbmF2XCIpO1xyXG4gICAgaWYgKHRvcG5hdiA9PSBudWxsKVxyXG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7IHJldHVybiByZXNvbHZlKCk7IH0pO1xyXG4gICAgdmFyIHJlcXVlc3QgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcclxuICAgIHJlcXVlc3Qub3BlbihcIkdFVFwiLCBiYXNlVVJMICsgXCIvcG9ydGFsL2Zhdm9yaXRlcy9saXN0XCIpO1xyXG4gICAgcmVxdWVzdC5yZXNwb25zZVR5cGUgPSBcImpzb25cIjtcclxuICAgIChfYSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIub3JnYW5pemVGYXZvcml0ZXNcIikpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZXZlbnRMaXN0ZW5lcl8xLmVkaXRGYXZvcml0ZXNNZXNzYWdlKTtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgcmVxdWVzdC5hZGRFdmVudExpc3RlbmVyKFwibG9hZFwiLCBmdW5jdGlvbiAoZSkge1xyXG4gICAgICAgICAgICB2YXIgcmVzID0gcmVxdWVzdC5yZXNwb25zZTtcclxuICAgICAgICAgICAgaWYgKHJlcyA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImZhaWxlZCB0byBmZXRjaCBmYXZvcml0ZXMgbGlzdFwiKTtcclxuICAgICAgICAgICAgICAgIHJlamVjdCgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHZhciBmYXZvcml0ZXMgPSByZXMuZmF2b3JpdGVTaXRlSWRzO1xyXG4gICAgICAgICAgICB2YXIgc2l0ZXNJbmZvID0gZ2V0U2l0ZUlkQW5kSHJlZlNpdGVOYW1lTWFwKCk7XHJcbiAgICAgICAgICAgIHZhciBjdXJyZW50RmF2b3JpdGVTaXRlID0gZ2V0Q3VycmVudEZhdm9yaXRlc1NpdGUoKTtcclxuICAgICAgICAgICAgdmFyIF9sb29wXzEgPSBmdW5jdGlvbiAoZmF2b3JpdGUpIHtcclxuICAgICAgICAgICAgICAgIC8vIHNraXAgaWYgZmF2b3JpdGUgaXMgdGhlIGN1cnJlbnQgc2l0ZVxyXG4gICAgICAgICAgICAgICAgaWYgKGlzQ3VycmVudFNpdGUoZmF2b3JpdGUpKVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcImNvbnRpbnVlXCI7XHJcbiAgICAgICAgICAgICAgICB2YXIgc2l0ZUluZm8gPSBzaXRlc0luZm8uZ2V0KGZhdm9yaXRlKTtcclxuICAgICAgICAgICAgICAgIGlmIChzaXRlSW5mbyA9PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiY29udGludWVcIjtcclxuICAgICAgICAgICAgICAgIHZhciBocmVmID0gc2l0ZUluZm8uaHJlZjtcclxuICAgICAgICAgICAgICAgIHZhciB0aXRsZSA9IHNpdGVJbmZvLnRpdGxlO1xyXG4gICAgICAgICAgICAgICAgLy8gc2tpcCBpZiB0aGUgc2l0ZSBpcyBhbHJlYWR5IHNob3duXHJcbiAgICAgICAgICAgICAgICBpZiAoY3VycmVudEZhdm9yaXRlU2l0ZS5maW5kKGZ1bmN0aW9uIChjKSB7IHJldHVybiBjID09IGhyZWY7IH0pICE9IG51bGwpXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiY29udGludWVcIjtcclxuICAgICAgICAgICAgICAgIHZhciBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaVwiKTtcclxuICAgICAgICAgICAgICAgIGxpLmNsYXNzTGlzdC5hZGQoXCJNcnBocy1zaXRlc05hdl9fbWVudWl0ZW1cIik7XHJcbiAgICAgICAgICAgICAgICB2YXIgYW5jaG9yID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImFcIik7XHJcbiAgICAgICAgICAgICAgICBhbmNob3IuY2xhc3NMaXN0LmFkZChcImxpbmstY29udGFpbmVyXCIpO1xyXG4gICAgICAgICAgICAgICAgYW5jaG9yLmhyZWYgPSBocmVmO1xyXG4gICAgICAgICAgICAgICAgYW5jaG9yLnRpdGxlID0gdGl0bGU7XHJcbiAgICAgICAgICAgICAgICB2YXIgc3BhbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xyXG4gICAgICAgICAgICAgICAgc3Bhbi5pbm5lclRleHQgPSB0aXRsZTtcclxuICAgICAgICAgICAgICAgIGFuY2hvci5hcHBlbmRDaGlsZChzcGFuKTtcclxuICAgICAgICAgICAgICAgIGxpLmFwcGVuZENoaWxkKGFuY2hvcik7XHJcbiAgICAgICAgICAgICAgICB0b3BuYXYuYXBwZW5kQ2hpbGQobGkpO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBmb3IgKHZhciBfaSA9IDAsIF9hID0gZmF2b3JpdGVzLnNsaWNlKDAsIE1BWF9GQVZPUklURVMpOyBfaSA8IF9hLmxlbmd0aDsgX2krKykge1xyXG4gICAgICAgICAgICAgICAgdmFyIGZhdm9yaXRlID0gX2FbX2ldO1xyXG4gICAgICAgICAgICAgICAgX2xvb3BfMShmYXZvcml0ZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJlcXVlc3Quc2VuZCgpO1xyXG4gICAgfSk7XHJcbn1cclxuZXhwb3J0cy5hZGRGYXZvcml0ZWRDb3Vyc2VTaXRlcyA9IGFkZEZhdm9yaXRlZENvdXJzZVNpdGVzO1xyXG4iLCJcInVzZSBzdHJpY3RcIjtcclxudmFyIF9fYXdhaXRlciA9ICh0aGlzICYmIHRoaXMuX19hd2FpdGVyKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XHJcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cclxuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xyXG4gICAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvci5uZXh0KHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cclxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cclxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxyXG4gICAgICAgIHN0ZXAoKGdlbmVyYXRvciA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSkubmV4dCgpKTtcclxuICAgIH0pO1xyXG59O1xyXG52YXIgX19nZW5lcmF0b3IgPSAodGhpcyAmJiB0aGlzLl9fZ2VuZXJhdG9yKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgYm9keSkge1xyXG4gICAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbigpIHsgaWYgKHRbMF0gJiAxKSB0aHJvdyB0WzFdOyByZXR1cm4gdFsxXTsgfSwgdHJ5czogW10sIG9wczogW10gfSwgZiwgeSwgdCwgZztcclxuICAgIHJldHVybiBnID0geyBuZXh0OiB2ZXJiKDApLCBcInRocm93XCI6IHZlcmIoMSksIFwicmV0dXJuXCI6IHZlcmIoMikgfSwgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIChnW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbigpIHsgcmV0dXJuIHRoaXM7IH0pLCBnO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IHJldHVybiBmdW5jdGlvbiAodikgeyByZXR1cm4gc3RlcChbbiwgdl0pOyB9OyB9XHJcbiAgICBmdW5jdGlvbiBzdGVwKG9wKSB7XHJcbiAgICAgICAgaWYgKGYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJHZW5lcmF0b3IgaXMgYWxyZWFkeSBleGVjdXRpbmcuXCIpO1xyXG4gICAgICAgIHdoaWxlIChfKSB0cnkge1xyXG4gICAgICAgICAgICBpZiAoZiA9IDEsIHkgJiYgKHQgPSBvcFswXSAmIDIgPyB5W1wicmV0dXJuXCJdIDogb3BbMF0gPyB5W1widGhyb3dcIl0gfHwgKCh0ID0geVtcInJldHVyblwiXSkgJiYgdC5jYWxsKHkpLCAwKSA6IHkubmV4dCkgJiYgISh0ID0gdC5jYWxsKHksIG9wWzFdKSkuZG9uZSkgcmV0dXJuIHQ7XHJcbiAgICAgICAgICAgIGlmICh5ID0gMCwgdCkgb3AgPSBbb3BbMF0gJiAyLCB0LnZhbHVlXTtcclxuICAgICAgICAgICAgc3dpdGNoIChvcFswXSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiBjYXNlIDE6IHQgPSBvcDsgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ6IF8ubGFiZWwrKzsgcmV0dXJuIHsgdmFsdWU6IG9wWzFdLCBkb25lOiBmYWxzZSB9O1xyXG4gICAgICAgICAgICAgICAgY2FzZSA1OiBfLmxhYmVsKys7IHkgPSBvcFsxXTsgb3AgPSBbMF07IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA3OiBvcCA9IF8ub3BzLnBvcCgpOyBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICBpZiAoISh0ID0gXy50cnlzLCB0ID0gdC5sZW5ndGggPiAwICYmIHRbdC5sZW5ndGggLSAxXSkgJiYgKG9wWzBdID09PSA2IHx8IG9wWzBdID09PSAyKSkgeyBfID0gMDsgY29udGludWU7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDMgJiYgKCF0IHx8IChvcFsxXSA+IHRbMF0gJiYgb3BbMV0gPCB0WzNdKSkpIHsgXy5sYWJlbCA9IG9wWzFdOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gNiAmJiBfLmxhYmVsIDwgdFsxXSkgeyBfLmxhYmVsID0gdFsxXTsgdCA9IG9wOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0ICYmIF8ubGFiZWwgPCB0WzJdKSB7IF8ubGFiZWwgPSB0WzJdOyBfLm9wcy5wdXNoKG9wKTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodFsyXSkgXy5vcHMucG9wKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvcCA9IGJvZHkuY2FsbCh0aGlzQXJnLCBfKTtcclxuICAgICAgICB9IGNhdGNoIChlKSB7IG9wID0gWzYsIGVdOyB5ID0gMDsgfSBmaW5hbGx5IHsgZiA9IHQgPSAwOyB9XHJcbiAgICAgICAgaWYgKG9wWzBdICYgNSkgdGhyb3cgb3BbMV07IHJldHVybiB7IHZhbHVlOiBvcFswXSA/IG9wWzFdIDogdm9pZCAwLCBkb25lOiB0cnVlIH07XHJcbiAgICB9XHJcbn07XHJcbnZhciBfX2ltcG9ydERlZmF1bHQgPSAodGhpcyAmJiB0aGlzLl9faW1wb3J0RGVmYXVsdCkgfHwgZnVuY3Rpb24gKG1vZCkge1xyXG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBcImRlZmF1bHRcIjogbW9kIH07XHJcbn07XHJcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcclxuZXhwb3J0cy5jcmVhdGVGYXZvcml0ZXNCYXJOb3RpZmljYXRpb24gPSBleHBvcnRzLmRlbGV0ZUZhdm9yaXRlc0Jhck5vdGlmaWNhdGlvbiA9IGV4cG9ydHMuZGlzcGxheU1pbmlTYWthaSA9IGV4cG9ydHMuY3JlYXRlTWluaVNha2FpID0gZXhwb3J0cy5jcmVhdGVNaW5pU2FrYWlCdG4gPSBleHBvcnRzLmNyZWF0ZU1pbmlTYWthaUdlbmVyYWxpemVkID0gdm9pZCAwO1xyXG52YXIgbW9kZWxfMSA9IHJlcXVpcmUoXCIuL21vZGVsXCIpO1xyXG52YXIgdXRpbHNfMSA9IHJlcXVpcmUoXCIuL3V0aWxzXCIpO1xyXG52YXIgZG9tXzEgPSByZXF1aXJlKFwiLi9kb21cIik7XHJcbnZhciBldmVudExpc3RlbmVyXzEgPSByZXF1aXJlKFwiLi9ldmVudExpc3RlbmVyXCIpO1xyXG4vLyBAdHMtaWdub3JlXHJcbnZhciBtdXN0YWNoZV8xID0gX19pbXBvcnREZWZhdWx0KHJlcXVpcmUoXCJtdXN0YWNoZVwiKSk7XHJcbnZhciBzZXR0aW5nc18xID0gcmVxdWlyZShcIi4vc2V0dGluZ3NcIik7XHJcbi8qKlxyXG4gKiBDcmVhdGUgYSBidXR0b24gdG8gb3BlbiBtaW5pU2FrYWlcclxuICovXHJcbmZ1bmN0aW9uIGNyZWF0ZU1pbmlTYWthaUJ0bigpIHtcclxuICAgIHZhciB0b3BiYXIgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm1hc3RMb2dpblwiKTtcclxuICAgIHRyeSB7XHJcbiAgICAgICAgdG9wYmFyID09PSBudWxsIHx8IHRvcGJhciA9PT0gdm9pZCAwID8gdm9pZCAwIDogdG9wYmFyLmFwcGVuZENoaWxkKGRvbV8xLmhhbWJ1cmdlcik7XHJcbiAgICB9XHJcbiAgICBjYXRjaCAoZSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiY291bGQgbm90IGxhdW5jaCBtaW5pU2FrYWkuXCIpO1xyXG4gICAgfVxyXG59XHJcbmV4cG9ydHMuY3JlYXRlTWluaVNha2FpQnRuID0gY3JlYXRlTWluaVNha2FpQnRuO1xyXG4vKipcclxuICogVXNpbmcgdGVtcGxhdGUgZW5naW5lIHRvIGdlbmVyYXRlIG1pbmlTYWthaSBsaXN0LlxyXG4gKi9cclxuZnVuY3Rpb24gY3JlYXRlTWluaVNha2FpR2VuZXJhbGl6ZWQocm9vdCwgYXNzaWdubWVudExpc3QsIGNvdXJzZVNpdGVJbmZvcywgc3Vic2V0LCBpbnNlcnRpb25Qcm9jZXNzKSB7XHJcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIGNvbmZpZywgYXNzaWdubWVudEZldGNoZWRUaW1lU3RyaW5nLCBxdWl6RmV0Y2hlZFRpbWVTdHJpbmcsIGNvdXJzZVNpdGVMaXN0LCBjb3Vyc2VJRE1hcCwgZGFuZ2VyRWxlbWVudHMsIHdhcm5pbmdFbGVtZW50cywgc3VjY2Vzc0VsZW1lbnRzLCBvdGhlckVsZW1lbnRzLCBsYXRlU3VibWl0RWxlbWVudHMsIHNvcnRFbGVtZW50cywgbm9Bc3NpZ25tZW50SW1nLCBhc3NpZ25tZW50Q250LCBfaSwgYXNzaWdubWVudExpc3RfMSwgYXNzaWdubWVudCwgdGVtcGxhdGVWYXJzO1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBzZXR0aW5nc18xLmxvYWRDb25maWdzKCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbmZpZyA9IF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50RmV0Y2hlZFRpbWVTdHJpbmcgPSB1dGlsc18xLmZvcm1hdFRpbWVzdGFtcChjb25maWcuZmV0Y2hlZFRpbWUuYXNzaWdubWVudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcXVpekZldGNoZWRUaW1lU3RyaW5nID0gdXRpbHNfMS5mb3JtYXRUaW1lc3RhbXAoY29uZmlnLmZldGNoZWRUaW1lLnF1aXopO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvdXJzZVNpdGVMaXN0ID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgY291cnNlSURNYXAgPSB1dGlsc18xLmNyZWF0ZUNvdXJzZUlETWFwKGNvdXJzZVNpdGVJbmZvcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgZGFuZ2VyRWxlbWVudHMgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICB3YXJuaW5nRWxlbWVudHMgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICBzdWNjZXNzRWxlbWVudHMgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICBvdGhlckVsZW1lbnRzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgbGF0ZVN1Ym1pdEVsZW1lbnRzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gaXRlcmF0ZSBvdmVyIGNvdXJzZVNpdGVcclxuICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50TGlzdC5mb3JFYWNoKGZ1bmN0aW9uIChhc3NpZ25tZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjb3Vyc2VOYW1lID0gY291cnNlSURNYXAuZ2V0KGFzc2lnbm1lbnQuY291cnNlU2l0ZUluZm8uY291cnNlSUQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBpdGVyYXRlIG92ZXIgYXNzaWdubWVudCBlbnRyaWVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFzc2lnbm1lbnQuYXNzaWdubWVudEVudHJpZXMuZm9yRWFjaChmdW5jdGlvbiAoYXNzaWdubWVudEVudHJ5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGF5c1VudGlsRHVlID0gdXRpbHNfMS5nZXREYXlzVW50aWwodXRpbHNfMS5ub3dUaW1lLCBhc3NpZ25tZW50RW50cnkuZ2V0RHVlRGF0ZVRpbWVzdGFtcCAqIDEwMDApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGRpc3BsYXlBc3NpZ25tZW50RW50cnkgPSBuZXcgbW9kZWxfMS5EaXNwbGF5QXNzaWdubWVudEVudHJ5KGFzc2lnbm1lbnQuY291cnNlU2l0ZUluZm8uY291cnNlSUQsIGFzc2lnbm1lbnRFbnRyeS5hc3NpZ25tZW50SUQsIGFzc2lnbm1lbnRFbnRyeS5hc3NpZ25tZW50VGl0bGUsIGFzc2lnbm1lbnRFbnRyeS5kdWVEYXRlVGltZXN0YW1wLCBhc3NpZ25tZW50RW50cnkuY2xvc2VEYXRlVGltZXN0YW1wLCBhc3NpZ25tZW50RW50cnkuaXNGaW5pc2hlZCwgYXNzaWdubWVudEVudHJ5LmlzUXVpeiwgYXNzaWdubWVudEVudHJ5LmlzTWVtbyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGlzcGxheUFzc2lnbm1lbnQgPSBuZXcgbW9kZWxfMS5EaXNwbGF5QXNzaWdubWVudChbZGlzcGxheUFzc2lnbm1lbnRFbnRyeV0sIGNvdXJzZU5hbWUsIGFzc2lnbm1lbnQuZ2V0VG9wU2l0ZSgpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBhcHBlbmRFbGVtZW50ID0gZnVuY3Rpb24gKGNvdXJzZU5hbWUsIGRpc3BsYXlBc3NpZ25tZW50cykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjb3Vyc2VOYW1lTWFwID0gZGlzcGxheUFzc2lnbm1lbnRzLm1hcChmdW5jdGlvbiAoZSkgeyByZXR1cm4gZS5jb3Vyc2VOYW1lOyB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoY291cnNlTmFtZU1hcC5pbmNsdWRlcyhjb3Vyc2VOYW1lKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaWR4ID0gY291cnNlTmFtZU1hcC5pbmRleE9mKGNvdXJzZU5hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5QXNzaWdubWVudHNbaWR4XS5hc3NpZ25tZW50RW50cmllcy5wdXNoKGRpc3BsYXlBc3NpZ25tZW50RW50cnkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5QXNzaWdubWVudHNbaWR4XS5hc3NpZ25tZW50RW50cmllcy5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYS5nZXREdWVEYXRlVGltZXN0YW1wIC0gYi5nZXREdWVEYXRlVGltZXN0YW1wO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXlBc3NpZ25tZW50cy5wdXNoKGRpc3BsYXlBc3NpZ25tZW50KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQXBwZW5kIGVsZW1lbnRzIGFjY29yZGluZyB0byBkdWUgZGF0ZSBjYXRlZ29yeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoIChkYXlzVW50aWxEdWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiZHVlMjRoXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwcGVuZEVsZW1lbnQoY291cnNlTmFtZSwgZGFuZ2VyRWxlbWVudHMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiZHVlNWRcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXBwZW5kRWxlbWVudChjb3Vyc2VOYW1lLCB3YXJuaW5nRWxlbWVudHMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiZHVlMTRkXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwcGVuZEVsZW1lbnQoY291cnNlTmFtZSwgc3VjY2Vzc0VsZW1lbnRzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcImR1ZU92ZXIxNGRcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXBwZW5kRWxlbWVudChjb3Vyc2VOYW1lLCBvdGhlckVsZW1lbnRzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcImR1ZVBhc3NlZFwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY2FzZS1kZWNsYXJhdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHNob3dMYXRlU3VibWl0QXNzaWdubWVudCA9IGNvbmZpZy5DU3NldHRpbmdzID8gY29uZmlnLkNTc2V0dGluZ3MuZ2V0RGlzcGxheUxhdGVTdWJtaXRBc3NpZ25tZW50IDogZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzaG93TGF0ZVN1Ym1pdEFzc2lnbm1lbnQgJiYgdXRpbHNfMS5nZXREYXlzVW50aWwodXRpbHNfMS5ub3dUaW1lLCBhc3NpZ25tZW50RW50cnkuZ2V0Q2xvc2VEYXRlVGltZXN0YW1wICogMTAwMCkgIT09IFwiZHVlUGFzc2VkXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwcGVuZEVsZW1lbnQoY291cnNlTmFtZSwgbGF0ZVN1Ym1pdEVsZW1lbnRzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZVNpdGVMaXN0LnB1c2gobmV3IG1vZGVsXzEuQ291cnNlU2l0ZUluZm8oYXNzaWdubWVudC5jb3Vyc2VTaXRlSW5mby5jb3Vyc2VJRCwgY291cnNlTmFtZSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHNvcnRFbGVtZW50cyA9IGZ1bmN0aW9uIChlbGVtZW50cywgaXNMYXRlU3VibWlzc2lvbikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNMYXRlU3VibWlzc2lvbiA9PT0gdm9pZCAwKSB7IGlzTGF0ZVN1Ym1pc3Npb24gPSBmYWxzZTsgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50cy5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdGltZXN0YW1wO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzTGF0ZVN1Ym1pc3Npb24pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lc3RhbXAgPSBmdW5jdGlvbiAobykgeyByZXR1cm4gTWF0aC5taW4uYXBwbHkoTWF0aCwgby5hc3NpZ25tZW50RW50cmllcy5tYXAoZnVuY3Rpb24gKHApIHsgcmV0dXJuIHAuZ2V0Q2xvc2VEYXRlVGltZXN0YW1wOyB9KSk7IH07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lc3RhbXAgPSBmdW5jdGlvbiAobykgeyByZXR1cm4gTWF0aC5taW4uYXBwbHkoTWF0aCwgby5hc3NpZ25tZW50RW50cmllcy5tYXAoZnVuY3Rpb24gKHApIHsgcmV0dXJuIHAuZ2V0RHVlRGF0ZVRpbWVzdGFtcDsgfSkpOyB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRpbWVzdGFtcChhKSAtIHRpbWVzdGFtcChiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBlbGVtZW50cztcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgIG5vQXNzaWdubWVudEltZyA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudENudCA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFzc2lnbm1lbnRMaXN0Lmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKF9pID0gMCwgYXNzaWdubWVudExpc3RfMSA9IGFzc2lnbm1lbnRMaXN0OyBfaSA8IGFzc2lnbm1lbnRMaXN0XzEubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50ID0gYXNzaWdubWVudExpc3RfMVtfaV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50Q250ICs9IGFzc2lnbm1lbnQuYXNzaWdubWVudEVudHJpZXMubGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChhc3NpZ25tZW50TGlzdC5sZW5ndGggPT09IDAgfHwgYXNzaWdubWVudENudCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBub0Fzc2lnbm1lbnRJbWcgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbWc6IGNocm9tZS5ydW50aW1lLmdldFVSTChcImltZy9ub0Fzc2lnbm1lbnQucG5nXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVZhcnMgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZldGNoZWRUaW1lOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50OiBhc3NpZ25tZW50RmV0Y2hlZFRpbWVTdHJpbmcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWl6OiBxdWl6RmV0Y2hlZFRpbWVTdHJpbmcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbmlTYWthaUxvZ286IGNocm9tZS5ydW50aW1lLmdldFVSTChcImltZy9sb2dvLnBuZ1wiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgVkVSU0lPTjogY29uZmlnLnZlcnNpb24sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1YnNldDogc3Vic2V0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBub0Fzc2lnbm1lbnQ6IG5vQXNzaWdubWVudEltZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudHM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhbmdlcjogc29ydEVsZW1lbnRzKGRhbmdlckVsZW1lbnRzKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdhcm5pbmc6IHNvcnRFbGVtZW50cyh3YXJuaW5nRWxlbWVudHMpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3VjY2Vzczogc29ydEVsZW1lbnRzKHN1Y2Nlc3NFbGVtZW50cyksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvdGhlcjogc29ydEVsZW1lbnRzKG90aGVyRWxlbWVudHMpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGF0ZVN1Ym1pdDogc29ydEVsZW1lbnRzKGxhdGVTdWJtaXRFbGVtZW50cywgdHJ1ZSksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhbmdlcjogZGFuZ2VyRWxlbWVudHMubGVuZ3RoID4gMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdhcm5pbmc6IHdhcm5pbmdFbGVtZW50cy5sZW5ndGggPiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3VjY2Vzczogc3VjY2Vzc0VsZW1lbnRzLmxlbmd0aCA+IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvdGhlcjogb3RoZXJFbGVtZW50cy5sZW5ndGggPiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGF0ZVN1Ym1pdDogbGF0ZVN1Ym1pdEVsZW1lbnRzLmxlbmd0aCA+IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudFRhYjogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcInRhYl9hc3NpZ25tZW50c1wiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldHRpbmdzVGFiOiBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKFwidGFiX3NldHRpbmdzXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudEZldGNoZWRUaW1lOiBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKFwiYXNzaWdubWVudF9hY3F1aXNpdGlvbl9kYXRlXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVpekZldGNoZWRUaW1lOiBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKFwidGVzdHF1aXpfYWNxdWlzaXRpb25fZGF0ZVwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGR1ZTI0aDogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcImR1ZTI0aFwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGR1ZTVkOiBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKFwiZHVlNWRcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkdWUxNGQ6IGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJkdWUxNGRcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkdWVPdmVyMTRkOiBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKFwiZHVlT3ZlcjE0ZFwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGR1ZVBhc3NlZDogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcImR1ZVBhc3NlZFwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5vQXNzaWdubWVudDogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcIm5vX2F2YWlsYWJsZV9hc3NpZ25tZW50c1wiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG9kb0JveDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY291cnNlTmFtZTogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcInRvZG9fYm94X2NvdXJzZV9uYW1lXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVtb0xhYmVsOiBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKFwidG9kb19ib3hfbWVtb1wiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGR1ZURhdGU6IGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJ0b2RvX2JveF9kdWVfZGF0ZVwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZEJ0bkxhYmVsOiBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKFwidG9kb19ib3hfYWRkXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY291cnNlU2l0ZUxpc3Q6IGNvdXJzZVNpdGVMaXN0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWRnZToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVtbzogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcIm1lbW9cIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWl6OiBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKFwicXVpelwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIExvYWQgbXVzdGFjaGVcclxuICAgICAgICAgICAgICAgICAgICBmZXRjaChjaHJvbWUucnVudGltZS5nZXRVUkwoXCJ2aWV3cy9taW5pc2FrYWkubXVzdGFjaGVcIikpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXMpIHsgcmV0dXJuIHJlcy50ZXh0KCk7IH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICh0ZW1wbGF0ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVuZGVyZWQgPSBtdXN0YWNoZV8xLmRlZmF1bHQucmVuZGVyKHRlbXBsYXRlLCB0ZW1wbGF0ZVZhcnMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpbnNlcnRpb25Qcm9jZXNzKHJlbmRlcmVkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVnaXN0ZXJFdmVudEhhbmRsZXJzKHJvb3QpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXN1YnNldClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNyZWF0ZVNldHRpbmdzVGFiKHJvb3QpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpbml0U3RhdGUocm9vdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLmNyZWF0ZU1pbmlTYWthaUdlbmVyYWxpemVkID0gY3JlYXRlTWluaVNha2FpR2VuZXJhbGl6ZWQ7XHJcbi8qKlxyXG4gKiBJbnNlcnQgbWluaVNha2FpIGludG8gU2FrYWkuXHJcbiAqL1xyXG5mdW5jdGlvbiBjcmVhdGVNaW5pU2FrYWkoYXNzaWdubWVudExpc3QsIGNvdXJzZVNpdGVJbmZvcykge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBjcmVhdGVNaW5pU2FrYWlHZW5lcmFsaXplZChkb21fMS5taW5pU2FrYWksIGFzc2lnbm1lbnRMaXN0LCBjb3Vyc2VTaXRlSW5mb3MsIGZhbHNlLCBmdW5jdGlvbiAocmVuZGVyZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZG9tXzEubWluaVNha2FpLmlubmVySFRNTCA9IHJlbmRlcmVkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcGFyZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJwYWdlQm9keVwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlZiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidG9vbE1lbnVXcmFwXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnQgPT09IG51bGwgfHwgcGFyZW50ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBwYXJlbnQuaW5zZXJ0QmVmb3JlKGRvbV8xLm1pbmlTYWthaSwgcmVmKTtcclxuICAgICAgICAgICAgICAgICAgICB9KV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuZXhwb3J0cy5jcmVhdGVNaW5pU2FrYWkgPSBjcmVhdGVNaW5pU2FrYWk7XHJcbi8qKlxyXG4gKiBJbml0aWFsaXplIFNldHRpbmdzIHRhYi5cclxuICovXHJcbmZ1bmN0aW9uIGNyZWF0ZVNldHRpbmdzVGFiKHJvb3QpIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgY29uZmlnO1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBzZXR0aW5nc18xLmxvYWRDb25maWdzKCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbmZpZyA9IF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVTZXR0aW5nSXRlbShyb290LCBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKCdzZXR0aW5nc19jb2xvcl9jaGVja2VkX2l0ZW0nKSwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0RGlzcGxheUNoZWNrZWRBc3NpZ25tZW50LCBcImRpc3BsYXlDaGVja2VkQXNzaWdubWVudFwiKTtcclxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVTZXR0aW5nSXRlbShyb290LCBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKCdzZXR0aW5nc19kaXNwbGF5X2xhdGVfc3VibWl0X2Fzc2lnbm1lbnQnKSwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0RGlzcGxheUxhdGVTdWJtaXRBc3NpZ25tZW50LCBcImRpc3BsYXlMYXRlU3VibWl0QXNzaWdubWVudFwiKTtcclxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVTZXR0aW5nSXRlbShyb290LCBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKCdzZXR0aW5nc19hc3NpZ25tZW50X2NhY2hlJyksIGNvbmZpZy5DU3NldHRpbmdzLmdldEFzc2lnbm1lbnRDYWNoZUludGVydmFsLCBcImFzc2lnbm1lbnRDYWNoZUludGVydmFsXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZVNldHRpbmdJdGVtKHJvb3QsIGNocm9tZS5pMThuLmdldE1lc3NhZ2UoJ3NldHRpbmdzX3F1aXp6ZXNfY2FjaGUnKSwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0UXVpekNhY2hlSW50ZXJ2YWwsIFwicXVpekNhY2hlSW50ZXJ2YWxcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlU2V0dGluZ0l0ZW0ocm9vdCwgY2hyb21lLmkxOG4uZ2V0TWVzc2FnZSgnc2V0dGluZ3NfY29sb3JzX2hvdXInLCBbJ1RhYiBCYXInLCAnMjQnXSksIGNvbmZpZy5DU3NldHRpbmdzLmdldFRvcENvbG9yRGFuZ2VyLCBcInRvcENvbG9yRGFuZ2VyXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZVNldHRpbmdJdGVtKHJvb3QsIGNocm9tZS5pMThuLmdldE1lc3NhZ2UoJ3NldHRpbmdzX2NvbG9yc19kYXknLCBbJ1RhYiBCYXInLCAnNSddKSwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0VG9wQ29sb3JXYXJuaW5nLCBcInRvcENvbG9yV2FybmluZ1wiKTtcclxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVTZXR0aW5nSXRlbShyb290LCBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKCdzZXR0aW5nc19jb2xvcnNfZGF5JywgWydUYWIgQmFyJywgJzE0J10pLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRUb3BDb2xvclN1Y2Nlc3MsIFwidG9wQ29sb3JTdWNjZXNzXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZVNldHRpbmdJdGVtKHJvb3QsIGNocm9tZS5pMThuLmdldE1lc3NhZ2UoJ3NldHRpbmdzX2NvbG9yc19ob3VyJywgWydtaW5pUGFuZEEnLCAnMjQnXSksIGNvbmZpZy5DU3NldHRpbmdzLmdldE1pbmlDb2xvckRhbmdlciwgXCJtaW5pQ29sb3JEYW5nZXJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlU2V0dGluZ0l0ZW0ocm9vdCwgY2hyb21lLmkxOG4uZ2V0TWVzc2FnZSgnc2V0dGluZ3NfY29sb3JzX2RheScsIFsnbWluaVBhbmRBJywgJzUnXSksIGNvbmZpZy5DU3NldHRpbmdzLmdldE1pbmlDb2xvcldhcm5pbmcsIFwibWluaUNvbG9yV2FybmluZ1wiKTtcclxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVTZXR0aW5nSXRlbShyb290LCBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKCdzZXR0aW5nc19jb2xvcnNfZGF5JywgWydtaW5pUGFuZEEnLCAnMTQnXSksIGNvbmZpZy5DU3NldHRpbmdzLmdldE1pbmlDb2xvclN1Y2Nlc3MsIFwibWluaUNvbG9yU3VjY2Vzc1wiKTtcclxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVTZXR0aW5nSXRlbShyb290LCBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKFwic2V0dGluZ3NfcmVzZXRfY29sb3JzXCIpLCBcInJlc2V0XCIsIFwicmVzZXRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgICAgICAgICAgICAgICAgIHJvb3QucXVlcnlTZWxlY3RvcihcIi5jcy1zZXR0aW5ncy10YWJcIikuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuLyoqXHJcbiAqIENyZWF0ZSBTZXR0aW5ncyB0YWIgaXRlbS5cclxuICovXHJcbmZ1bmN0aW9uIGNyZWF0ZVNldHRpbmdJdGVtKHJvb3QsIGl0ZW1EZXNjcmlwdGlvbiwgdmFsdWUsIGlkLCBkaXNwbGF5KSB7XHJcbiAgICBpZiAoZGlzcGxheSA9PT0gdm9pZCAwKSB7IGRpc3BsYXkgPSB0cnVlOyB9XHJcbiAgICB2YXIgc2V0dGluZ3NEaXYgPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIuY3Mtc2V0dGluZ3MtdGFiXCIpO1xyXG4gICAgaWYgKHNldHRpbmdzRGl2ID09IG51bGwpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIi5jcy1zZXR0aW5ncy10YWIgbm90IGZvdW5kXCIpO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHZhciBtYWluRGl2ID0gZG9tXzEuU2V0dGluZ3NEb20ubWFpbkRpdi5jbG9uZU5vZGUodHJ1ZSk7XHJcbiAgICB2YXIgbGFiZWwgPSBkb21fMS5TZXR0aW5nc0RvbS5sYWJlbC5jbG9uZU5vZGUodHJ1ZSk7XHJcbiAgICB2YXIgcCA9IGRvbV8xLlNldHRpbmdzRG9tLnAuY2xvbmVOb2RlKHRydWUpO1xyXG4gICAgcC5pbm5lclRleHQgPSBpdGVtRGVzY3JpcHRpb247XHJcbiAgICBpZiAoIWRpc3BsYXkpXHJcbiAgICAgICAgbWFpbkRpdi5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XHJcbiAgICB2YXIgc2V0dGluZ0l0ZW07XHJcbiAgICB2YXIgc3BhbiA9IGRvbV8xLlNldHRpbmdzRG9tLnNwYW4uY2xvbmVOb2RlKHRydWUpO1xyXG4gICAgc3dpdGNoICh0eXBlb2YgdmFsdWUpIHtcclxuICAgICAgICBjYXNlIFwiYm9vbGVhblwiOlxyXG4gICAgICAgICAgICBsYWJlbC5jbGFzc0xpc3QuYWRkKFwiY3MtdG9nZ2xlLWJ0blwiKTtcclxuICAgICAgICAgICAgc2V0dGluZ0l0ZW0gPSBkb21fMS5jbG9uZUVsZW0oZG9tXzEuU2V0dGluZ3NEb20udG9nZ2xlQnRuLCB7IGNoZWNrZWQ6IHZhbHVlLCBpZDogaWQgfSwgeyBcImNoYW5nZVwiOiBmdW5jdGlvbiAocmVzKSB7IGV2ZW50TGlzdGVuZXJfMS51cGRhdGVTZXR0aW5ncyhyZXMsIFwiY2hlY2tcIik7IH0gfSk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJudW1iZXJcIjpcclxuICAgICAgICAgICAgc2V0dGluZ0l0ZW0gPSBkb21fMS5jbG9uZUVsZW0oZG9tXzEuU2V0dGluZ3NEb20uaW5wdXRCb3gsIHsgdmFsdWU6IHZhbHVlLCBpZDogaWQgfSwgeyBcImNoYW5nZVwiOiBmdW5jdGlvbiAocmVzKSB7IGV2ZW50TGlzdGVuZXJfMS51cGRhdGVTZXR0aW5ncyhyZXMsIFwibnVtYmVyXCIpOyB9IH0pO1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIFwic3RyaW5nXCI6XHJcbiAgICAgICAgICAgIGlmIChpZCA9PT0gXCJyZXNldFwiKSB7XHJcbiAgICAgICAgICAgICAgICBzZXR0aW5nSXRlbSA9IGRvbV8xLmNsb25lRWxlbShkb21fMS5TZXR0aW5nc0RvbS5yZXNldEJ0biwgeyB2YWx1ZTogdmFsdWUsIGlkOiBpZCB9LCB7IFwiY2xpY2tcIjogZnVuY3Rpb24gKHJlcykgeyBldmVudExpc3RlbmVyXzEudXBkYXRlU2V0dGluZ3MocmVzLCBcInJlc2V0XCIpOyB9IH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgc2V0dGluZ0l0ZW0gPSBkb21fMS5jbG9uZUVsZW0oZG9tXzEuU2V0dGluZ3NEb20uc3RyaW5nQm94LCB7IHZhbHVlOiB2YWx1ZSwgaWQ6IGlkIH0sIHsgXCJjaGFuZ2VcIjogZnVuY3Rpb24gKHJlcykgeyBldmVudExpc3RlbmVyXzEudXBkYXRlU2V0dGluZ3MocmVzLCBcInN0cmluZ1wiKTsgfSB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgIH1cclxuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiKVxyXG4gICAgICAgIGRvbV8xLmFwcGVuZENoaWxkQWxsKGxhYmVsLCBbc2V0dGluZ0l0ZW0sIHNwYW5dKTtcclxuICAgIGVsc2VcclxuICAgICAgICBkb21fMS5hcHBlbmRDaGlsZEFsbChsYWJlbCwgW3NldHRpbmdJdGVtXSk7XHJcbiAgICBkb21fMS5hcHBlbmRDaGlsZEFsbChtYWluRGl2LCBbcCwgbGFiZWxdKTtcclxuICAgIHNldHRpbmdzRGl2LmFwcGVuZENoaWxkKG1haW5EaXYpO1xyXG59XHJcbi8qKlxyXG4gKiBBZGQgZXZlbnQgbGlzdGVuZXIgdG8gZWFjaCBTZXR0aW5ncyBpdGVtXHJcbiAqL1xyXG5mdW5jdGlvbiByZWdpc3RlckV2ZW50SGFuZGxlcnMocm9vdCkge1xyXG4gICAgdmFyIF9hLCBfYiwgX2MsIF9kLCBfZTtcclxuICAgIChfYSA9IHJvb3QucXVlcnlTZWxlY3RvcihcIiNhc3NpZ25tZW50VGFiXCIpKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIGV2ZW50TGlzdGVuZXJfMS50b2dnbGVBc3NpZ25tZW50VGFiKCk7IH0pO1xyXG4gICAgKF9iID0gcm9vdC5xdWVyeVNlbGVjdG9yKFwiI3NldHRpbmdzVGFiXCIpKSA9PT0gbnVsbCB8fCBfYiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2IuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIGV2ZW50TGlzdGVuZXJfMS50b2dnbGVTZXR0aW5nc1RhYigpOyB9KTtcclxuICAgIHJvb3QucXVlcnlTZWxlY3RvckFsbChcIi5jcy1jaGVja2JveFwiKS5mb3JFYWNoKGZ1bmN0aW9uIChjKSB7IHJldHVybiBjLmFkZEV2ZW50TGlzdGVuZXIoXCJjaGFuZ2VcIiwgZnVuY3Rpb24gKGUpIHsgcmV0dXJuIGV2ZW50TGlzdGVuZXJfMS50b2dnbGVGaW5pc2hlZEZsYWcoZSk7IH0pOyB9KTtcclxuICAgIChfYyA9IHJvb3QucXVlcnlTZWxlY3RvcihcIiNjbG9zZV9idG5cIikpID09PSBudWxsIHx8IF9jID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24gKCkgeyByZXR1cm4gZXZlbnRMaXN0ZW5lcl8xLnRvZ2dsZU1pbmlTYWthaSgpOyB9KTtcclxuICAgIChfZCA9IHJvb3QucXVlcnlTZWxlY3RvcihcIiNjcy1hZGQtbWVtby1idG5cIikpID09PSBudWxsIHx8IF9kID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24gKCkgeyByZXR1cm4gZXZlbnRMaXN0ZW5lcl8xLnRvZ2dsZU1lbW9Cb3goKTsgfSk7XHJcbiAgICAoX2UgPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIjdG9kby1hZGRcIikpID09PSBudWxsIHx8IF9lID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZS5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24gKCkgeyByZXR1cm4gZXZlbnRMaXN0ZW5lcl8xLmFkZE1lbW8oKTsgfSk7XHJcbiAgICByb290LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuY3MtZGVsLW1lbW8tYnRuXCIpLmZvckVhY2goZnVuY3Rpb24gKGIpIHsgcmV0dXJuIGIuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uIChlKSB7IHJldHVybiBldmVudExpc3RlbmVyXzEuZGVsZXRlTWVtbyhlKTsgfSk7IH0pO1xyXG59XHJcbi8qKlxyXG4gKiBJbml0aWFsaXplIHN0YXRlc1xyXG4gKi9cclxuZnVuY3Rpb24gaW5pdFN0YXRlKHJvb3QpIHtcclxuICAgIC8vIEB0cy1pZ25vcmVcclxuICAgIHJvb3QucXVlcnlTZWxlY3RvcihcIiNhc3NpZ25tZW50VGFiXCIpLmNoZWNrZWQgPSB0cnVlO1xyXG4gICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgcm9vdC5xdWVyeVNlbGVjdG9yKFwiLnRvZG9EdWVcIikudmFsdWUgPSBuZXcgRGF0ZShuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3Vic3RyKDAsIDE2KSArIFwiLTEwOjAwXCIpXHJcbiAgICAgICAgLnRvSVNPU3RyaW5nKClcclxuICAgICAgICAuc3Vic3RyKDAsIDE2KTtcclxufVxyXG4vKipcclxuICogRGlzcGxheSBtaW5pU2FrYWlcclxuICovXHJcbmZ1bmN0aW9uIGRpc3BsYXlNaW5pU2FrYWkobWVyZ2VkQXNzaWdubWVudExpc3QsIGNvdXJzZVNpdGVJbmZvcykge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBjcmVhdGVNaW5pU2FrYWkobWVyZ2VkQXNzaWdubWVudExpc3QsIGNvdXJzZVNpdGVJbmZvcyldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICB1dGlsc18xLm1pbmlTYWthaVJlYWR5KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLmRpc3BsYXlNaW5pU2FrYWkgPSBkaXNwbGF5TWluaVNha2FpO1xyXG4vKipcclxuICogQWRkIG5vdGlmaWNhdGlvbiBiYWRnZSBmb3IgbmV3IEFzc2lnbm1lbnQvUXVpelxyXG4gKi9cclxuZnVuY3Rpb24gY3JlYXRlRmF2b3JpdGVzQmFyTm90aWZpY2F0aW9uKGNvdXJzZVNpdGVJbmZvcywgYXNzaWdubWVudExpc3QpIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgY29uZmlnLCBkZWZhdWx0VGFiLCBkZWZhdWx0VGFiQ291bnQsIF9pLCBjb3Vyc2VTaXRlSW5mb3NfMSwgY291cnNlU2l0ZUluZm8sIF9sb29wXzEsIGo7XHJcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IHJldHVybiBbNCAvKnlpZWxkKi8sIHNldHRpbmdzXzEubG9hZENvbmZpZ3MoKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlnID0gX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHRUYWIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLk1ycGhzLXNpdGVzTmF2X19tZW51aXRlbVwiKTtcclxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VGFiQ291bnQgPSBPYmplY3Qua2V5cyhkZWZhdWx0VGFiKS5sZW5ndGg7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChfaSA9IDAsIGNvdXJzZVNpdGVJbmZvc18xID0gY291cnNlU2l0ZUluZm9zOyBfaSA8IGNvdXJzZVNpdGVJbmZvc18xLmxlbmd0aDsgX2krKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3Vyc2VTaXRlSW5mbyA9IGNvdXJzZVNpdGVJbmZvc18xW19pXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2xvb3BfMSA9IGZ1bmN0aW9uIChqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBAdHMtaWdub3JlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgY291cnNlSUQgPSBkZWZhdWx0VGFiW2pdLmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJsaW5rLWNvbnRhaW5lclwiKVswXS5ocmVmLm1hdGNoKFwiKGh0dHBzPzovL1teL10rKS9wb3J0YWwvc2l0ZS0/W2Etel0qLyhbXi9dKylcIilbMl07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcSA9IGFzc2lnbm1lbnRMaXN0LmZpbmRJbmRleChmdW5jdGlvbiAoYXNzaWdubWVudCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBhc3NpZ25tZW50LmNvdXJzZVNpdGVJbmZvLmNvdXJzZUlEID09PSBjb3Vyc2VJRDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHEgIT09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNsb3Nlc3RUaW1lID0gKGNvbmZpZy5DU3NldHRpbmdzLmRpc3BsYXlDaGVja2VkQXNzaWdubWVudCkgPyBhc3NpZ25tZW50TGlzdFtxXS5jbG9zZXN0RHVlRGF0ZVRpbWVzdGFtcCA6IGFzc2lnbm1lbnRMaXN0W3FdLmNsb3Nlc3REdWVEYXRlVGltZXN0YW1wRXhjbHVkZUZpbmlzaGVkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghYXNzaWdubWVudExpc3RbcV0uaXNSZWFkICYmIGNsb3Nlc3RUaW1lICE9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VGFiW2pdLmNsYXNzTGlzdC5hZGQoXCJjcy1ub3RpZmljYXRpb24tYmFkZ2VcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBkYXlzVW50aWxEdWUgPSB1dGlsc18xLmdldERheXNVbnRpbCh1dGlsc18xLm5vd1RpbWUsIGNsb3Nlc3RUaW1lICogMTAwMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGFUYWdDb3VudCA9IGRlZmF1bHRUYWJbal0uZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJhXCIpLmxlbmd0aDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKGRheXNVbnRpbER1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiZHVlMjRoXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VGFiW2pdLmNsYXNzTGlzdC5hZGQoXCJjcy10YWItZGFuZ2VyXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhVGFnQ291bnQ7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRUYWJbal0uZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJhXCIpW2ldLmNsYXNzTGlzdC5hZGQoXCJjcy10YWItZGFuZ2VyXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJkdWU1ZFwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFRhYltqXS5jbGFzc0xpc3QuYWRkKFwiY3MtdGFiLXdhcm5pbmdcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFUYWdDb3VudDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFRhYltqXS5nZXRFbGVtZW50c0J5VGFnTmFtZShcImFcIilbaV0uY2xhc3NMaXN0LmFkZChcImNzLXRhYi13YXJuaW5nXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJkdWUxNGRcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRUYWJbal0uY2xhc3NMaXN0LmFkZChcImNzLXRhYi1zdWNjZXNzXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhVGFnQ291bnQ7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRUYWJbal0uZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJhXCIpW2ldLmNsYXNzTGlzdC5hZGQoXCJjcy10YWItc3VjY2Vzc1wiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiZHVlT3ZlcjE0ZFwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFRhYltqXS5jbGFzc0xpc3QuYWRkKFwiY3MtdGFiLW90aGVyXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhVGFnQ291bnQ7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRUYWJbal0uZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJhXCIpW2ldLmNsYXNzTGlzdC5hZGQoXCJjcy10YWItb3RoZXJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoaiA9IDI7IGogPCBkZWZhdWx0VGFiQ291bnQ7IGorKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX2xvb3BfMShqKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBvdmVycmlkZUNTU0NvbG9yKCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMuY3JlYXRlRmF2b3JpdGVzQmFyTm90aWZpY2F0aW9uID0gY3JlYXRlRmF2b3JpdGVzQmFyTm90aWZpY2F0aW9uO1xyXG4vKipcclxuICogRGVsZXRlIG5vdGlmaWNhdGlvbiBiYWRnZSBmb3IgbmV3IEFzc2lnbm1lbnQvUXVpelxyXG4gKi9cclxuZnVuY3Rpb24gZGVsZXRlRmF2b3JpdGVzQmFyTm90aWZpY2F0aW9uKCkge1xyXG4gICAgdmFyIGNsYXNzbGlzdCA9IFtcImNzLW5vdGlmaWNhdGlvbi1iYWRnZVwiLCBcImNzLXRhYi1kYW5nZXJcIiwgXCJjcy10YWItd2FybmluZ1wiLCBcImNzLXRhYi1zdWNjZXNzXCJdO1xyXG4gICAgZm9yICh2YXIgX2kgPSAwLCBjbGFzc2xpc3RfMSA9IGNsYXNzbGlzdDsgX2kgPCBjbGFzc2xpc3RfMS5sZW5ndGg7IF9pKyspIHtcclxuICAgICAgICB2YXIgYyA9IGNsYXNzbGlzdF8xW19pXTtcclxuICAgICAgICB2YXIgcSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuXCIgKyBjKTtcclxuICAgICAgICAvLyBAdHMtaWdub3JlXHJcbiAgICAgICAgZm9yICh2YXIgX2EgPSAwLCBxXzEgPSBxOyBfYSA8IHFfMS5sZW5ndGg7IF9hKyspIHtcclxuICAgICAgICAgICAgdmFyIF8xID0gcV8xW19hXTtcclxuICAgICAgICAgICAgXzEuY2xhc3NMaXN0LnJlbW92ZShcIlwiICsgYyk7XHJcbiAgICAgICAgICAgIF8xLnN0eWxlID0gXCJcIjtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuZXhwb3J0cy5kZWxldGVGYXZvcml0ZXNCYXJOb3RpZmljYXRpb24gPSBkZWxldGVGYXZvcml0ZXNCYXJOb3RpZmljYXRpb247XHJcbi8qKlxyXG4gKiBPdmVycmlkZSBDU1Mgb2YgZmF2b3JpdGVzIGJhciBhbmQgbWluaVNha2FpLlxyXG4gKi9cclxuZnVuY3Rpb24gb3ZlcnJpZGVDU1NDb2xvcigpIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgY29uZmlnLCBvdmVyd3JpdGVib3JkZXIsIG92ZXJ3cml0ZWJhY2tncm91bmQ7XHJcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IHJldHVybiBbNCAvKnlpZWxkKi8sIHNldHRpbmdzXzEubG9hZENvbmZpZ3MoKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlnID0gX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIG92ZXJ3cml0ZWJvcmRlciA9IGZ1bmN0aW9uIChjbGFzc05hbWUsIGNvbG9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBlbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShjbGFzc05hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGVsZW1lbnQubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBlbGVtID0gZWxlbWVudFtpXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBhdHRyID0gXCJzb2xpZCAycHggXCIgKyBjb2xvcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsZW0uc3R5bGVbXCJib3JkZXItdG9wXCJdID0gYXR0cjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsZW0uc3R5bGVbXCJib3JkZXItbGVmdFwiXSA9IGF0dHI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtLnN0eWxlW1wiYm9yZGVyLWJvdHRvbVwiXSA9IGF0dHI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtLnN0eWxlW1wiYm9yZGVyLXJpZ2h0XCJdID0gYXR0cjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgb3ZlcndyaXRlYmFja2dyb3VuZCA9IGZ1bmN0aW9uIChjbGFzc05hbWUsIGNvbG9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBlbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShjbGFzc05hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGVsZW1lbnQubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBlbGVtID0gZWxlbWVudFtpXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsZW0uc2V0QXR0cmlidXRlKFwic3R5bGVcIiwgXCJiYWNrZ3JvdW5kOlwiICsgY29sb3IgKyBcIiFpbXBvcnRhbnRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIE92ZXJ3cml0ZSBjb2xvcnNcclxuICAgICAgICAgICAgICAgICAgICBvdmVyd3JpdGViYWNrZ3JvdW5kKFwiY3MtY291cnNlLWRhbmdlclwiLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRNaW5pQ29sb3JEYW5nZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgIG92ZXJ3cml0ZWJhY2tncm91bmQoXCJjcy1jb3Vyc2Utd2FybmluZ1wiLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRNaW5pQ29sb3JXYXJuaW5nKTtcclxuICAgICAgICAgICAgICAgICAgICBvdmVyd3JpdGViYWNrZ3JvdW5kKFwiY3MtY291cnNlLXN1Y2Nlc3NcIiwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0TWluaUNvbG9yU3VjY2Vzcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgb3ZlcndyaXRlYmFja2dyb3VuZChcImNzLXRhYi1kYW5nZXJcIiwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0VG9wQ29sb3JEYW5nZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgIG92ZXJ3cml0ZWJhY2tncm91bmQoXCJjcy10YWItd2FybmluZ1wiLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRUb3BDb2xvcldhcm5pbmcpO1xyXG4gICAgICAgICAgICAgICAgICAgIG92ZXJ3cml0ZWJhY2tncm91bmQoXCJjcy10YWItc3VjY2Vzc1wiLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRUb3BDb2xvclN1Y2Nlc3MpO1xyXG4gICAgICAgICAgICAgICAgICAgIG92ZXJ3cml0ZWJvcmRlcihcImNzLWFzc2lnbm1lbnQtZGFuZ2VyXCIsIGNvbmZpZy5DU3NldHRpbmdzLmdldE1pbmlDb2xvckRhbmdlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgb3ZlcndyaXRlYm9yZGVyKFwiY3MtYXNzaWdubWVudC13YXJuaW5nXCIsIGNvbmZpZy5DU3NldHRpbmdzLmdldE1pbmlDb2xvcldhcm5pbmcpO1xyXG4gICAgICAgICAgICAgICAgICAgIG92ZXJ3cml0ZWJvcmRlcihcImNzLWFzc2lnbm1lbnQtc3VjY2Vzc1wiLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRNaW5pQ29sb3JTdWNjZXNzKTtcclxuICAgICAgICAgICAgICAgICAgICBvdmVyd3JpdGVib3JkZXIoXCJjcy10YWItZGFuZ2VyXCIsIGNvbmZpZy5DU3NldHRpbmdzLmdldFRvcENvbG9yRGFuZ2VyKTtcclxuICAgICAgICAgICAgICAgICAgICBvdmVyd3JpdGVib3JkZXIoXCJjcy10YWItd2FybmluZ1wiLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRUb3BDb2xvcldhcm5pbmcpO1xyXG4gICAgICAgICAgICAgICAgICAgIG92ZXJ3cml0ZWJvcmRlcihcImNzLXRhYi1zdWNjZXNzXCIsIGNvbmZpZy5DU3NldHRpbmdzLmdldFRvcENvbG9yU3VjY2Vzcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG4iLCJcInVzZSBzdHJpY3RcIjtcclxudmFyIF9fZXh0ZW5kcyA9ICh0aGlzICYmIHRoaXMuX19leHRlbmRzKSB8fCAoZnVuY3Rpb24gKCkge1xyXG4gICAgdmFyIGV4dGVuZFN0YXRpY3MgPSBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGV4dGVuZFN0YXRpY3MgPSBPYmplY3Quc2V0UHJvdG90eXBlT2YgfHxcclxuICAgICAgICAgICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxyXG4gICAgICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYiwgcCkpIGRbcF0gPSBiW3BdOyB9O1xyXG4gICAgICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgfTtcclxuICAgIHJldHVybiBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGlmICh0eXBlb2YgYiAhPT0gXCJmdW5jdGlvblwiICYmIGIgIT09IG51bGwpXHJcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDbGFzcyBleHRlbmRzIHZhbHVlIFwiICsgU3RyaW5nKGIpICsgXCIgaXMgbm90IGEgY29uc3RydWN0b3Igb3IgbnVsbFwiKTtcclxuICAgICAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgICAgIGZ1bmN0aW9uIF9fKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gZDsgfVxyXG4gICAgICAgIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcclxuICAgIH07XHJcbn0pKCk7XHJcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcclxuZXhwb3J0cy5EaXNwbGF5QXNzaWdubWVudCA9IGV4cG9ydHMuRGlzcGxheUFzc2lnbm1lbnRFbnRyeSA9IGV4cG9ydHMuQ291cnNlU2l0ZUluZm8gPSBleHBvcnRzLkFzc2lnbm1lbnQgPSBleHBvcnRzLkFzc2lnbm1lbnRFbnRyeSA9IHZvaWQgMDtcclxudmFyIHV0aWxzXzEgPSByZXF1aXJlKFwiLi91dGlsc1wiKTtcclxudmFyIE1BWF9USU1FU1RBTVAgPSA5OTk5OTk5OTk5OTk5OTtcclxudmFyIEFzc2lnbm1lbnRFbnRyeSA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcclxuICAgIGZ1bmN0aW9uIEFzc2lnbm1lbnRFbnRyeShhc3NpZ25tZW50SUQsIGFzc2lnbm1lbnRUaXRsZSwgZHVlRGF0ZVRpbWVzdGFtcCwgY2xvc2VEYXRlVGltZXN0YW1wLCBpc01lbW8sIGlzRmluaXNoZWQsIGlzUXVpeiwgYXNzaWdubWVudERldGFpbCwgYXNzaWdubWVudFBhZ2UpIHtcclxuICAgICAgICB0aGlzLmFzc2lnbm1lbnRJRCA9IGFzc2lnbm1lbnRJRDtcclxuICAgICAgICB0aGlzLmFzc2lnbm1lbnRUaXRsZSA9IGFzc2lnbm1lbnRUaXRsZTtcclxuICAgICAgICB0aGlzLmFzc2lnbm1lbnREZXRhaWwgPSBhc3NpZ25tZW50RGV0YWlsO1xyXG4gICAgICAgIHRoaXMuZHVlRGF0ZVRpbWVzdGFtcCA9IGR1ZURhdGVUaW1lc3RhbXA7XHJcbiAgICAgICAgdGhpcy5jbG9zZURhdGVUaW1lc3RhbXAgPSBjbG9zZURhdGVUaW1lc3RhbXA7XHJcbiAgICAgICAgdGhpcy5pc01lbW8gPSBpc01lbW87XHJcbiAgICAgICAgdGhpcy5pc0ZpbmlzaGVkID0gaXNGaW5pc2hlZDtcclxuICAgICAgICB0aGlzLmlzUXVpeiA9IGlzUXVpejtcclxuICAgICAgICB0aGlzLmFzc2lnbm1lbnRQYWdlID0gYXNzaWdubWVudFBhZ2U7XHJcbiAgICB9XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoQXNzaWdubWVudEVudHJ5LnByb3RvdHlwZSwgXCJnZXREdWVEYXRlVGltZXN0YW1wXCIsIHtcclxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZHVlRGF0ZVRpbWVzdGFtcCA/IHRoaXMuZHVlRGF0ZVRpbWVzdGFtcCA6IE1BWF9USU1FU1RBTVA7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KEFzc2lnbm1lbnRFbnRyeS5wcm90b3R5cGUsIFwiZ2V0Q2xvc2VEYXRlVGltZXN0YW1wXCIsIHtcclxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY2xvc2VEYXRlVGltZXN0YW1wID8gdGhpcy5jbG9zZURhdGVUaW1lc3RhbXAgOiBNQVhfVElNRVNUQU1QO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIHJldHVybiBBc3NpZ25tZW50RW50cnk7XHJcbn0oKSk7XHJcbmV4cG9ydHMuQXNzaWdubWVudEVudHJ5ID0gQXNzaWdubWVudEVudHJ5O1xyXG52YXIgQXNzaWdubWVudCA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcclxuICAgIGZ1bmN0aW9uIEFzc2lnbm1lbnQoY291cnNlU2l0ZUluZm8sIGFzc2lnbm1lbnRFbnRyaWVzLCBpc1JlYWQpIHtcclxuICAgICAgICB0aGlzLmNvdXJzZVNpdGVJbmZvID0gY291cnNlU2l0ZUluZm87XHJcbiAgICAgICAgdGhpcy5hc3NpZ25tZW50RW50cmllcyA9IGFzc2lnbm1lbnRFbnRyaWVzO1xyXG4gICAgICAgIHRoaXMuaXNSZWFkID0gaXNSZWFkO1xyXG4gICAgfVxyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KEFzc2lnbm1lbnQucHJvdG90eXBlLCBcImNsb3Nlc3REdWVEYXRlVGltZXN0YW1wXCIsIHtcclxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuYXNzaWdubWVudEVudHJpZXMubGVuZ3RoID09IDApXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gLTE7XHJcbiAgICAgICAgICAgIHZhciBtaW4gPSBNQVhfVElNRVNUQU1QO1xyXG4gICAgICAgICAgICBmb3IgKHZhciBfaSA9IDAsIF9hID0gdGhpcy5hc3NpZ25tZW50RW50cmllczsgX2kgPCBfYS5sZW5ndGg7IF9pKyspIHtcclxuICAgICAgICAgICAgICAgIHZhciBlbnRyeSA9IF9hW19pXTtcclxuICAgICAgICAgICAgICAgIGlmIChtaW4gPiBlbnRyeS5nZXREdWVEYXRlVGltZXN0YW1wICYmIGVudHJ5LmdldER1ZURhdGVUaW1lc3RhbXAgKiAxMDAwID49IHV0aWxzXzEubm93VGltZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIG1pbiA9IGVudHJ5LmdldER1ZURhdGVUaW1lc3RhbXA7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKG1pbiA9PT0gTUFYX1RJTUVTVEFNUClcclxuICAgICAgICAgICAgICAgIG1pbiA9IC0xO1xyXG4gICAgICAgICAgICByZXR1cm4gbWluO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShBc3NpZ25tZW50LnByb3RvdHlwZSwgXCJjbG9zZXN0RHVlRGF0ZVRpbWVzdGFtcEV4Y2x1ZGVGaW5pc2hlZFwiLCB7XHJcbiAgICAgICAgLy8g5a6M5LqG5riI44G/5Lul5aSW44GL44KJY2xvc2VzdFRpbWXjgpLlj5blvpfjgZnjgotcclxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuYXNzaWdubWVudEVudHJpZXMubGVuZ3RoID09IDApXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gLTE7XHJcbiAgICAgICAgICAgIHZhciBtaW4gPSBNQVhfVElNRVNUQU1QO1xyXG4gICAgICAgICAgICB2YXIgZXhjbHVkZUNvdW50ID0gMDtcclxuICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IHRoaXMuYXNzaWdubWVudEVudHJpZXM7IF9pIDwgX2EubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgZW50cnkgPSBfYVtfaV07XHJcbiAgICAgICAgICAgICAgICBpZiAoZW50cnkuaXNGaW5pc2hlZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGV4Y2x1ZGVDb3VudCsrO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKG1pbiA+IGVudHJ5LmdldER1ZURhdGVUaW1lc3RhbXAgJiYgZW50cnkuZ2V0RHVlRGF0ZVRpbWVzdGFtcCAqIDEwMDAgPj0gdXRpbHNfMS5ub3dUaW1lKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWluID0gZW50cnkuZ2V0RHVlRGF0ZVRpbWVzdGFtcDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoZXhjbHVkZUNvdW50ID09PSB0aGlzLmFzc2lnbm1lbnRFbnRyaWVzLmxlbmd0aClcclxuICAgICAgICAgICAgICAgIG1pbiA9IC0xO1xyXG4gICAgICAgICAgICBpZiAobWluID09PSBNQVhfVElNRVNUQU1QKVxyXG4gICAgICAgICAgICAgICAgbWluID0gLTE7XHJcbiAgICAgICAgICAgIHJldHVybiBtaW47XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgQXNzaWdubWVudC5wcm90b3R5cGUuZ2V0VG9wU2l0ZSA9IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBmb3IgKHZhciBfaSA9IDAsIF9hID0gdGhpcy5hc3NpZ25tZW50RW50cmllczsgX2kgPCBfYS5sZW5ndGg7IF9pKyspIHtcclxuICAgICAgICAgICAgdmFyIGVudHJ5ID0gX2FbX2ldO1xyXG4gICAgICAgICAgICBpZiAoZW50cnkuYXNzaWdubWVudFBhZ2UgIT0gbnVsbClcclxuICAgICAgICAgICAgICAgIHJldHVybiBlbnRyeS5hc3NpZ25tZW50UGFnZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIFwiXCI7XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIEFzc2lnbm1lbnQ7XHJcbn0oKSk7XHJcbmV4cG9ydHMuQXNzaWdubWVudCA9IEFzc2lnbm1lbnQ7XHJcbnZhciBDb3Vyc2VTaXRlSW5mbyA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcclxuICAgIGZ1bmN0aW9uIENvdXJzZVNpdGVJbmZvKGNvdXJzZUlELCBjb3Vyc2VOYW1lKSB7XHJcbiAgICAgICAgdGhpcy5jb3Vyc2VJRCA9IGNvdXJzZUlEO1xyXG4gICAgICAgIHRoaXMuY291cnNlTmFtZSA9IGNvdXJzZU5hbWU7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gQ291cnNlU2l0ZUluZm87XHJcbn0oKSk7XHJcbmV4cG9ydHMuQ291cnNlU2l0ZUluZm8gPSBDb3Vyc2VTaXRlSW5mbztcclxudmFyIERpc3BsYXlBc3NpZ25tZW50RW50cnkgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XHJcbiAgICBfX2V4dGVuZHMoRGlzcGxheUFzc2lnbm1lbnRFbnRyeSwgX3N1cGVyKTtcclxuICAgIGZ1bmN0aW9uIERpc3BsYXlBc3NpZ25tZW50RW50cnkoY291cnNlSUQsIGFzc2lnbm1lbnRJRCwgYXNzaWdubWVudFRpdGxlLCBkdWVEYXRlVGltZXN0YW1wLCBjbG9zZURhdGVUaW1lc3RhbXAsIGlzRmluaXNoZWQsIGlzUXVpeiwgaXNNZW1vKSB7XHJcbiAgICAgICAgdmFyIF90aGlzID0gX3N1cGVyLmNhbGwodGhpcywgYXNzaWdubWVudElELCBhc3NpZ25tZW50VGl0bGUsIGR1ZURhdGVUaW1lc3RhbXAsIGNsb3NlRGF0ZVRpbWVzdGFtcCwgaXNNZW1vLCBpc0ZpbmlzaGVkLCBpc1F1aXopIHx8IHRoaXM7XHJcbiAgICAgICAgX3RoaXMuY291cnNlSUQgPSBjb3Vyc2VJRDtcclxuICAgICAgICByZXR1cm4gX3RoaXM7XHJcbiAgICB9XHJcbiAgICBEaXNwbGF5QXNzaWdubWVudEVudHJ5LmdldFRpbWVSZW1haW4gPSBmdW5jdGlvbiAocmVtYWluVGltZXN0YW1wKSB7XHJcbiAgICAgICAgdmFyIGRheSA9IE1hdGguZmxvb3IocmVtYWluVGltZXN0YW1wIC8gKDM2MDAgKiAyNCkpO1xyXG4gICAgICAgIHZhciBob3VycyA9IE1hdGguZmxvb3IoKHJlbWFpblRpbWVzdGFtcCAtIGRheSAqIDM2MDAgKiAyNCkgLyAzNjAwKTtcclxuICAgICAgICB2YXIgbWludXRlcyA9IE1hdGguZmxvb3IoKHJlbWFpblRpbWVzdGFtcCAtIChkYXkgKiAzNjAwICogMjQgKyBob3VycyAqIDM2MDApKSAvIDYwKTtcclxuICAgICAgICByZXR1cm4gW2RheS50b1N0cmluZygpLCBob3Vycy50b1N0cmluZygpLCBtaW51dGVzLnRvU3RyaW5nKCldO1xyXG4gICAgfTtcclxuICAgIERpc3BsYXlBc3NpZ25tZW50RW50cnkuY3JlYXRlVGltZVN0cmluZyA9IGZ1bmN0aW9uICh0aW1lc3RhbXApIHtcclxuICAgICAgICBpZiAoIXRpbWVzdGFtcClcclxuICAgICAgICAgICAgcmV0dXJuIGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJkdWVfbm90X3NldFwiKTtcclxuICAgICAgICB2YXIgdGltZVJlbWFpbiA9IERpc3BsYXlBc3NpZ25tZW50RW50cnkuZ2V0VGltZVJlbWFpbigodGltZXN0YW1wICogMTAwMCAtIHV0aWxzXzEubm93VGltZSkgLyAxMDAwKTtcclxuICAgICAgICByZXR1cm4gY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcInJlbWFpbl90aW1lXCIsIFt0aW1lUmVtYWluWzBdLCB0aW1lUmVtYWluWzFdLCB0aW1lUmVtYWluWzJdXSk7XHJcbiAgICB9O1xyXG4gICAgRGlzcGxheUFzc2lnbm1lbnRFbnRyeS5jcmVhdGVEYXRlU3RyaW5nID0gZnVuY3Rpb24gKHRpbWVzdGFtcCkge1xyXG4gICAgICAgIGlmICghdGltZXN0YW1wKVxyXG4gICAgICAgICAgICByZXR1cm4gXCItLS0tLy0tLy0tXCI7XHJcbiAgICAgICAgdmFyIGRhdGUgPSBuZXcgRGF0ZSh0aW1lc3RhbXAgKiAxMDAwKTtcclxuICAgICAgICByZXR1cm4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoKSArIFwiIFwiICsgZGF0ZS5nZXRIb3VycygpICsgXCI6XCIgKyAoXCIwMFwiICsgZGF0ZS5nZXRNaW51dGVzKCkpLnNsaWNlKC0yKTtcclxuICAgIH07XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoRGlzcGxheUFzc2lnbm1lbnRFbnRyeS5wcm90b3R5cGUsIFwicmVtYWluVGltZVN0cmluZ1wiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBEaXNwbGF5QXNzaWdubWVudEVudHJ5LmNyZWF0ZVRpbWVTdHJpbmcodGhpcy5kdWVEYXRlVGltZXN0YW1wKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoRGlzcGxheUFzc2lnbm1lbnRFbnRyeS5wcm90b3R5cGUsIFwicmVtYWluQ2xvc2VUaW1lU3RyaW5nXCIsIHtcclxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIERpc3BsYXlBc3NpZ25tZW50RW50cnkuY3JlYXRlVGltZVN0cmluZyh0aGlzLmNsb3NlRGF0ZVRpbWVzdGFtcCk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KERpc3BsYXlBc3NpZ25tZW50RW50cnkucHJvdG90eXBlLCBcImR1ZURhdGVTdHJpbmdcIiwge1xyXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gRGlzcGxheUFzc2lnbm1lbnRFbnRyeS5jcmVhdGVEYXRlU3RyaW5nKHRoaXMuZHVlRGF0ZVRpbWVzdGFtcCk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KERpc3BsYXlBc3NpZ25tZW50RW50cnkucHJvdG90eXBlLCBcImR1ZUNsb3NlRGF0ZVN0cmluZ1wiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBEaXNwbGF5QXNzaWdubWVudEVudHJ5LmNyZWF0ZURhdGVTdHJpbmcodGhpcy5jbG9zZURhdGVUaW1lc3RhbXApO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIHJldHVybiBEaXNwbGF5QXNzaWdubWVudEVudHJ5O1xyXG59KEFzc2lnbm1lbnRFbnRyeSkpO1xyXG5leHBvcnRzLkRpc3BsYXlBc3NpZ25tZW50RW50cnkgPSBEaXNwbGF5QXNzaWdubWVudEVudHJ5O1xyXG52YXIgRGlzcGxheUFzc2lnbm1lbnQgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XHJcbiAgICBmdW5jdGlvbiBEaXNwbGF5QXNzaWdubWVudChhc3NpZ25tZW50RW50cmllcywgY291cnNlTmFtZSwgY291cnNlUGFnZSkge1xyXG4gICAgICAgIHRoaXMuYXNzaWdubWVudEVudHJpZXMgPSBhc3NpZ25tZW50RW50cmllcztcclxuICAgICAgICB0aGlzLmNvdXJzZU5hbWUgPSBjb3Vyc2VOYW1lO1xyXG4gICAgICAgIHRoaXMuY291cnNlUGFnZSA9IGNvdXJzZVBhZ2U7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gRGlzcGxheUFzc2lnbm1lbnQ7XHJcbn0oKSk7XHJcbmV4cG9ydHMuRGlzcGxheUFzc2lnbm1lbnQgPSBEaXNwbGF5QXNzaWdubWVudDtcclxuIiwiXCJ1c2Ugc3RyaWN0XCI7XHJcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xyXG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufTtcclxudmFyIF9fZ2VuZXJhdG9yID0gKHRoaXMgJiYgdGhpcy5fX2dlbmVyYXRvcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59O1xyXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XHJcbmV4cG9ydHMuZ2V0UXVpekZyb21Db3Vyc2VJRCA9IGV4cG9ydHMuZ2V0QXNzaWdubWVudEJ5Q291cnNlSUQgPSBleHBvcnRzLmdldENvdXJzZUlETGlzdCA9IGV4cG9ydHMuZ2V0QmFzZVVSTCA9IHZvaWQgMDtcclxudmFyIG1vZGVsXzEgPSByZXF1aXJlKFwiLi9tb2RlbFwiKTtcclxudmFyIHV0aWxzXzEgPSByZXF1aXJlKFwiLi91dGlsc1wiKTtcclxuLyoqXHJcbiAqIEdldCBiYXNlIFVSTCBvZiBTYWthaS5cclxuICovXHJcbmZ1bmN0aW9uIGdldEJhc2VVUkwoKSB7XHJcbiAgICB2YXIgYmFzZVVSTCA9IFwiXCI7XHJcbiAgICB2YXIgbWF0Y2ggPSBsb2NhdGlvbi5ocmVmLm1hdGNoKFwiKGh0dHBzPzovL1teL10rKS9wb3J0YWxcIik7XHJcbiAgICBpZiAobWF0Y2gpIHtcclxuICAgICAgICBiYXNlVVJMID0gbWF0Y2hbMV07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYmFzZVVSTDtcclxufVxyXG5leHBvcnRzLmdldEJhc2VVUkwgPSBnZXRCYXNlVVJMO1xyXG4vKipcclxuICogRmV0Y2ggY291cnNlIHNpdGUgSURzLlxyXG4gKi9cclxuZnVuY3Rpb24gZ2V0Q291cnNlSURMaXN0KCkge1xyXG4gICAgdmFyIGVsZW1lbnRDb2xsZWN0aW9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImZhdi1zaXRlcy1lbnRyeVwiKTtcclxuICAgIHZhciBlbGVtZW50cyA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGVsZW1lbnRDb2xsZWN0aW9uKTtcclxuICAgIHZhciByZXN1bHQgPSBbXTtcclxuICAgIGZvciAodmFyIF9pID0gMCwgZWxlbWVudHNfMSA9IGVsZW1lbnRzOyBfaSA8IGVsZW1lbnRzXzEubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgdmFyIGVsZW0gPSBlbGVtZW50c18xW19pXTtcclxuICAgICAgICB2YXIgbGVjdHVyZUluZm8gPSBuZXcgbW9kZWxfMS5Db3Vyc2VTaXRlSW5mbyhcIlwiLCBcIlwiKTtcclxuICAgICAgICB2YXIgbGVjdHVyZSA9IGVsZW0uZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJkaXZcIilbMF0uZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJhXCIpWzBdO1xyXG4gICAgICAgIHZhciBtID0gbGVjdHVyZS5ocmVmLm1hdGNoKFwiKGh0dHBzPzovL1teL10rKS9wb3J0YWwvc2l0ZS0/W2Etel0qLyhbXi9dKylcIik7XHJcbiAgICAgICAgaWYgKG0gJiYgbVsyXVswXSAhPT0gXCJ+XCIpIHtcclxuICAgICAgICAgICAgbGVjdHVyZUluZm8uY291cnNlSUQgPSBtWzJdO1xyXG4gICAgICAgICAgICBsZWN0dXJlSW5mby5jb3Vyc2VOYW1lID0gbGVjdHVyZS50aXRsZTtcclxuICAgICAgICAgICAgcmVzdWx0LnB1c2gobGVjdHVyZUluZm8pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuZXhwb3J0cy5nZXRDb3Vyc2VJRExpc3QgPSBnZXRDb3Vyc2VJRExpc3Q7XHJcbi8qKlxyXG4gKiBGZXRjaCBhc3NpZ25tZW50cyBmcm9tIFNha2FpIFJFU1QgQVBJLlxyXG4gKiBAcGFyYW0ge3N0cmluZ30gYmFzZVVSTFxyXG4gKiBAcGFyYW0ge3N0cmluZ30gY291cnNlSURcclxuICovXHJcbmZ1bmN0aW9uIGdldEFzc2lnbm1lbnRCeUNvdXJzZUlEKGJhc2VVUkwsIGNvdXJzZUlEKSB7XHJcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xyXG4gICAgdmFyIHF1ZXJ5VVJMID0gYmFzZVVSTCArIFwiL2RpcmVjdC9hc3NpZ25tZW50L3NpdGUvXCIgKyBjb3Vyc2VJRCArIFwiLmpzb25cIjtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgZmV0Y2gocXVlcnlVUkwsIHsgY2FjaGU6IFwibm8tY2FjaGVcIiB9KVxyXG4gICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHsgcmV0dXJuIF9fYXdhaXRlcihfdGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgdmFyIHJlcywgY291cnNlU2l0ZUluZm8sIGFzc2lnbm1lbnRFbnRyaWVzO1xyXG4gICAgICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gWzMgLypicmVhayovLCAyXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgcmVzcG9uc2UuanNvbigpXTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcyA9IF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291cnNlU2l0ZUluZm8gPSBuZXcgbW9kZWxfMS5Db3Vyc2VTaXRlSW5mbyhjb3Vyc2VJRCwgY291cnNlSUQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50RW50cmllcyA9IGNvbnZKc29uVG9Bc3NpZ25tZW50RW50cmllcyhyZXMsIGJhc2VVUkwsIGNvdXJzZUlEKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShuZXcgbW9kZWxfMS5Bc3NpZ25tZW50KGNvdXJzZVNpdGVJbmZvLCBhc3NpZ25tZW50RW50cmllcywgZmFsc2UpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgM107XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoXCJSZXF1ZXN0IGZhaWxlZDogXCIgKyByZXNwb25zZS5zdGF0dXMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfYS5sYWJlbCA9IDM7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAzOiByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pOyB9KVxyXG4gICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKGVycikgeyByZXR1cm4gY29uc29sZS5lcnJvcihlcnIpOyB9KTsgLy8gRXJyb3I6IFJlcXVlc3QgZmFpbGVkOiA0MDRcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMuZ2V0QXNzaWdubWVudEJ5Q291cnNlSUQgPSBnZXRBc3NpZ25tZW50QnlDb3Vyc2VJRDtcclxuLyoqXHJcbiAqIEZldGNoIHF1aXp6ZXMgZnJvbSBTYWthaSBSRVNUIEFQSS5cclxuICogQHBhcmFtIHtzdHJpbmd9IGJhc2VVUkxcclxuICogQHBhcmFtIHtzdHJpbmd9IGNvdXJzZUlEXHJcbiAqL1xyXG5mdW5jdGlvbiBnZXRRdWl6RnJvbUNvdXJzZUlEKGJhc2VVUkwsIGNvdXJzZUlEKSB7XHJcbiAgICB2YXIgX3RoaXMgPSB0aGlzO1xyXG4gICAgdmFyIHF1ZXJ5VVJMID0gYmFzZVVSTCArIFwiL2RpcmVjdC9zYW1fcHViL2NvbnRleHQvXCIgKyBjb3Vyc2VJRCArIFwiLmpzb25cIjtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgZmV0Y2gocXVlcnlVUkwsIHsgY2FjaGU6IFwibm8tY2FjaGVcIiB9KVxyXG4gICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHsgcmV0dXJuIF9fYXdhaXRlcihfdGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgdmFyIHJlcywgY291cnNlU2l0ZUluZm8sIGFzc2lnbm1lbnRFbnRyaWVzO1xyXG4gICAgICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gWzMgLypicmVhayovLCAyXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgcmVzcG9uc2UuanNvbigpXTtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcyA9IF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291cnNlU2l0ZUluZm8gPSBuZXcgbW9kZWxfMS5Db3Vyc2VTaXRlSW5mbyhjb3Vyc2VJRCwgY291cnNlSUQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50RW50cmllcyA9IGNvbnZKc29uVG9RdWl6RW50cmllcyhyZXMsIGJhc2VVUkwsIGNvdXJzZUlEKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShuZXcgbW9kZWxfMS5Bc3NpZ25tZW50KGNvdXJzZVNpdGVJbmZvLCBhc3NpZ25tZW50RW50cmllcywgZmFsc2UpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgM107XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoXCJSZXF1ZXN0IGZhaWxlZDogXCIgKyByZXNwb25zZS5zdGF0dXMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfYS5sYWJlbCA9IDM7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAzOiByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pOyB9KVxyXG4gICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKGVycikgeyByZXR1cm4gY29uc29sZS5lcnJvcihlcnIpOyB9KTsgLy8gRXJyb3I6IFJlcXVlc3QgZmFpbGVkOiA0MDRcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMuZ2V0UXVpekZyb21Db3Vyc2VJRCA9IGdldFF1aXpGcm9tQ291cnNlSUQ7XHJcbi8qKlxyXG4gKiBDb252ZXJ0IGpzb24gcmVzcG9uc2UgdG8gQXNzaWdubWVudEVudHJpZXMuXHJcbiAqIEBwYXJhbSBkYXRhXHJcbiAqIEBwYXJhbSBiYXNlVVJMXHJcbiAqIEBwYXJhbSBzaXRlSURcclxuICovXHJcbmZ1bmN0aW9uIGNvbnZKc29uVG9Bc3NpZ25tZW50RW50cmllcyhkYXRhLCBiYXNlVVJMLCBzaXRlSUQpIHtcclxuICAgIHZhciBhc3NpZ25tZW50X2NvbGxlY3Rpb24gPSBkYXRhLmFzc2lnbm1lbnRfY29sbGVjdGlvbjtcclxuICAgIHJldHVybiBhc3NpZ25tZW50X2NvbGxlY3Rpb25cclxuICAgICAgICAuZmlsdGVyKGZ1bmN0aW9uIChqc29uKSB7IHJldHVybiBqc29uLmNsb3NlVGltZS5lcG9jaFNlY29uZCAqIDEwMDAgPj0gdXRpbHNfMS5ub3dUaW1lOyB9KVxyXG4gICAgICAgIC5tYXAoZnVuY3Rpb24gKGpzb24pIHtcclxuICAgICAgICB2YXIgYXNzaWdubWVudElEID0ganNvbi5pZDtcclxuICAgICAgICB2YXIgYXNzaWdubWVudFRpdGxlID0ganNvbi50aXRsZTtcclxuICAgICAgICB2YXIgYXNzaWdubWVudERldGFpbCA9IGpzb24uaW5zdHJ1Y3Rpb25zO1xyXG4gICAgICAgIHZhciBkdWVEYXRlVGltZXN0YW1wID0ganNvbi5kdWVUaW1lLmVwb2NoU2Vjb25kID8ganNvbi5kdWVUaW1lLmVwb2NoU2Vjb25kIDogbnVsbDtcclxuICAgICAgICB2YXIgY2xvc2VEYXRlVGltZXN0YW1wID0ganNvbi5jbG9zZVRpbWUuZXBvY2hTZWNvbmQgPyBqc29uLmNsb3NlVGltZS5lcG9jaFNlY29uZCA6IG51bGw7XHJcbiAgICAgICAgdmFyIGVudHJ5ID0gbmV3IG1vZGVsXzEuQXNzaWdubWVudEVudHJ5KGFzc2lnbm1lbnRJRCwgYXNzaWdubWVudFRpdGxlLCBkdWVEYXRlVGltZXN0YW1wLCBjbG9zZURhdGVUaW1lc3RhbXAsIGZhbHNlLCBmYWxzZSwgZmFsc2UsIGFzc2lnbm1lbnREZXRhaWwpO1xyXG4gICAgICAgIGVudHJ5LmFzc2lnbm1lbnRQYWdlID0gYmFzZVVSTCArIFwiL3BvcnRhbC9zaXRlL1wiICsgc2l0ZUlEO1xyXG4gICAgICAgIHJldHVybiBlbnRyeTtcclxuICAgIH0pO1xyXG59XHJcbi8qKlxyXG4gKiBDb252ZXJ0IGpzb24gcmVzcG9uc2UgdG8gUXVpekVudHJpZXMuXHJcbiAqIEBwYXJhbSBkYXRhXHJcbiAqIEBwYXJhbSBiYXNlVVJMXHJcbiAqIEBwYXJhbSBzaXRlSURcclxuICovXHJcbmZ1bmN0aW9uIGNvbnZKc29uVG9RdWl6RW50cmllcyhkYXRhLCBiYXNlVVJMLCBzaXRlSUQpIHtcclxuICAgIHJldHVybiBkYXRhLnNhbV9wdWJfY29sbGVjdGlvblxyXG4gICAgICAgIC5maWx0ZXIoZnVuY3Rpb24gKGpzb24pIHsgcmV0dXJuIGpzb24uc3RhcnREYXRlIDwgdXRpbHNfMS5ub3dUaW1lICYmIChqc29uLmR1ZURhdGUgPj0gdXRpbHNfMS5ub3dUaW1lIHx8IGpzb24uZHVlRGF0ZSA9PSBudWxsKTsgfSlcclxuICAgICAgICAubWFwKGZ1bmN0aW9uIChqc29uKSB7XHJcbiAgICAgICAgdmFyIHF1aXpJRCA9IFwicVwiICsganNvbi5wdWJsaXNoZWRBc3Nlc3NtZW50SWQ7XHJcbiAgICAgICAgdmFyIHF1aXpUaXRsZSA9IGpzb24udGl0bGU7XHJcbiAgICAgICAgdmFyIHF1aXpEZXRhaWwgPSBcIlwiO1xyXG4gICAgICAgIHZhciBxdWl6RHVlRXBvY2ggPSBqc29uLmR1ZURhdGUgPyBqc29uLmR1ZURhdGUgLyAxMDAwIDogbnVsbDtcclxuICAgICAgICB2YXIgZW50cnkgPSBuZXcgbW9kZWxfMS5Bc3NpZ25tZW50RW50cnkocXVpeklELCBxdWl6VGl0bGUsIHF1aXpEdWVFcG9jaCwgcXVpekR1ZUVwb2NoLCBmYWxzZSwgZmFsc2UsIHRydWUsIHF1aXpEZXRhaWwpO1xyXG4gICAgICAgIGVudHJ5LmFzc2lnbm1lbnRQYWdlID0gYmFzZVVSTCArIFwiL3BvcnRhbC9zaXRlL1wiICsgc2l0ZUlEO1xyXG4gICAgICAgIHJldHVybiBlbnRyeTtcclxuICAgIH0pO1xyXG59XHJcbiIsIlwidXNlIHN0cmljdFwiO1xyXG52YXIgX19leHRlbmRzID0gKHRoaXMgJiYgdGhpcy5fX2V4dGVuZHMpIHx8IChmdW5jdGlvbiAoKSB7XHJcbiAgICB2YXIgZXh0ZW5kU3RhdGljcyA9IGZ1bmN0aW9uIChkLCBiKSB7XHJcbiAgICAgICAgZXh0ZW5kU3RhdGljcyA9IE9iamVjdC5zZXRQcm90b3R5cGVPZiB8fFxyXG4gICAgICAgICAgICAoeyBfX3Byb3RvX186IFtdIH0gaW5zdGFuY2VvZiBBcnJheSAmJiBmdW5jdGlvbiAoZCwgYikgeyBkLl9fcHJvdG9fXyA9IGI7IH0pIHx8XHJcbiAgICAgICAgICAgIGZ1bmN0aW9uIChkLCBiKSB7IGZvciAodmFyIHAgaW4gYikgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChiLCBwKSkgZFtwXSA9IGJbcF07IH07XHJcbiAgICAgICAgcmV0dXJuIGV4dGVuZFN0YXRpY3MoZCwgYik7XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIGZ1bmN0aW9uIChkLCBiKSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBiICE9PSBcImZ1bmN0aW9uXCIgJiYgYiAhPT0gbnVsbClcclxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNsYXNzIGV4dGVuZHMgdmFsdWUgXCIgKyBTdHJpbmcoYikgKyBcIiBpcyBub3QgYSBjb25zdHJ1Y3RvciBvciBudWxsXCIpO1xyXG4gICAgICAgIGV4dGVuZFN0YXRpY3MoZCwgYik7XHJcbiAgICAgICAgZnVuY3Rpb24gX18oKSB7IHRoaXMuY29uc3RydWN0b3IgPSBkOyB9XHJcbiAgICAgICAgZC5wcm90b3R5cGUgPSBiID09PSBudWxsID8gT2JqZWN0LmNyZWF0ZShiKSA6IChfXy5wcm90b3R5cGUgPSBiLnByb3RvdHlwZSwgbmV3IF9fKCkpO1xyXG4gICAgfTtcclxufSkoKTtcclxudmFyIF9fYXdhaXRlciA9ICh0aGlzICYmIHRoaXMuX19hd2FpdGVyKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XHJcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cclxuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xyXG4gICAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvci5uZXh0KHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cclxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cclxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxyXG4gICAgICAgIHN0ZXAoKGdlbmVyYXRvciA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSkubmV4dCgpKTtcclxuICAgIH0pO1xyXG59O1xyXG52YXIgX19nZW5lcmF0b3IgPSAodGhpcyAmJiB0aGlzLl9fZ2VuZXJhdG9yKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgYm9keSkge1xyXG4gICAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbigpIHsgaWYgKHRbMF0gJiAxKSB0aHJvdyB0WzFdOyByZXR1cm4gdFsxXTsgfSwgdHJ5czogW10sIG9wczogW10gfSwgZiwgeSwgdCwgZztcclxuICAgIHJldHVybiBnID0geyBuZXh0OiB2ZXJiKDApLCBcInRocm93XCI6IHZlcmIoMSksIFwicmV0dXJuXCI6IHZlcmIoMikgfSwgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIChnW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbigpIHsgcmV0dXJuIHRoaXM7IH0pLCBnO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IHJldHVybiBmdW5jdGlvbiAodikgeyByZXR1cm4gc3RlcChbbiwgdl0pOyB9OyB9XHJcbiAgICBmdW5jdGlvbiBzdGVwKG9wKSB7XHJcbiAgICAgICAgaWYgKGYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJHZW5lcmF0b3IgaXMgYWxyZWFkeSBleGVjdXRpbmcuXCIpO1xyXG4gICAgICAgIHdoaWxlIChfKSB0cnkge1xyXG4gICAgICAgICAgICBpZiAoZiA9IDEsIHkgJiYgKHQgPSBvcFswXSAmIDIgPyB5W1wicmV0dXJuXCJdIDogb3BbMF0gPyB5W1widGhyb3dcIl0gfHwgKCh0ID0geVtcInJldHVyblwiXSkgJiYgdC5jYWxsKHkpLCAwKSA6IHkubmV4dCkgJiYgISh0ID0gdC5jYWxsKHksIG9wWzFdKSkuZG9uZSkgcmV0dXJuIHQ7XHJcbiAgICAgICAgICAgIGlmICh5ID0gMCwgdCkgb3AgPSBbb3BbMF0gJiAyLCB0LnZhbHVlXTtcclxuICAgICAgICAgICAgc3dpdGNoIChvcFswXSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiBjYXNlIDE6IHQgPSBvcDsgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ6IF8ubGFiZWwrKzsgcmV0dXJuIHsgdmFsdWU6IG9wWzFdLCBkb25lOiBmYWxzZSB9O1xyXG4gICAgICAgICAgICAgICAgY2FzZSA1OiBfLmxhYmVsKys7IHkgPSBvcFsxXTsgb3AgPSBbMF07IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA3OiBvcCA9IF8ub3BzLnBvcCgpOyBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICBpZiAoISh0ID0gXy50cnlzLCB0ID0gdC5sZW5ndGggPiAwICYmIHRbdC5sZW5ndGggLSAxXSkgJiYgKG9wWzBdID09PSA2IHx8IG9wWzBdID09PSAyKSkgeyBfID0gMDsgY29udGludWU7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDMgJiYgKCF0IHx8IChvcFsxXSA+IHRbMF0gJiYgb3BbMV0gPCB0WzNdKSkpIHsgXy5sYWJlbCA9IG9wWzFdOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gNiAmJiBfLmxhYmVsIDwgdFsxXSkgeyBfLmxhYmVsID0gdFsxXTsgdCA9IG9wOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0ICYmIF8ubGFiZWwgPCB0WzJdKSB7IF8ubGFiZWwgPSB0WzJdOyBfLm9wcy5wdXNoKG9wKTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodFsyXSkgXy5vcHMucG9wKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvcCA9IGJvZHkuY2FsbCh0aGlzQXJnLCBfKTtcclxuICAgICAgICB9IGNhdGNoIChlKSB7IG9wID0gWzYsIGVdOyB5ID0gMDsgfSBmaW5hbGx5IHsgZiA9IHQgPSAwOyB9XHJcbiAgICAgICAgaWYgKG9wWzBdICYgNSkgdGhyb3cgb3BbMV07IHJldHVybiB7IHZhbHVlOiBvcFswXSA/IG9wWzFdIDogdm9pZCAwLCBkb25lOiB0cnVlIH07XHJcbiAgICB9XHJcbn07XHJcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcclxuZXhwb3J0cy5sb2FkQ29uZmlncyA9IGV4cG9ydHMubG9hZFNldHRpbmdzID0gZXhwb3J0cy5EZWZhdWx0U2V0dGluZ3MgPSBleHBvcnRzLlNldHRpbmdzID0gdm9pZCAwO1xyXG52YXIgc3RvcmFnZV8xID0gcmVxdWlyZShcIi4vc3RvcmFnZVwiKTtcclxudmFyIHV0aWxzXzEgPSByZXF1aXJlKFwiLi91dGlsc1wiKTtcclxudmFyIG5ldHdvcmtfMSA9IHJlcXVpcmUoXCIuL25ldHdvcmtcIik7XHJcbnZhciBTZXR0aW5ncyA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcclxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZW1wdHktZnVuY3Rpb25cclxuICAgIGZ1bmN0aW9uIFNldHRpbmdzKCkge1xyXG4gICAgfVxyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFNldHRpbmdzLnByb3RvdHlwZSwgXCJnZXRBc3NpZ25tZW50Q2FjaGVJbnRlcnZhbFwiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmFzc2lnbm1lbnRDYWNoZUludGVydmFsID8gdGhpcy5hc3NpZ25tZW50Q2FjaGVJbnRlcnZhbCA6IERlZmF1bHRTZXR0aW5ncy5hc3NpZ25tZW50Q2FjaGVJbnRlcnZhbDtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU2V0dGluZ3MucHJvdG90eXBlLCBcImdldFF1aXpDYWNoZUludGVydmFsXCIsIHtcclxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMucXVpekNhY2hlSW50ZXJ2YWwgPyB0aGlzLnF1aXpDYWNoZUludGVydmFsIDogRGVmYXVsdFNldHRpbmdzLnF1aXpDYWNoZUludGVydmFsO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShTZXR0aW5ncy5wcm90b3R5cGUsIFwiZ2V0RGlzcGxheUNoZWNrZWRBc3NpZ25tZW50XCIsIHtcclxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGlzcGxheUNoZWNrZWRBc3NpZ25tZW50ICE9PSB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgID8gdGhpcy5kaXNwbGF5Q2hlY2tlZEFzc2lnbm1lbnRcclxuICAgICAgICAgICAgICAgIDogRGVmYXVsdFNldHRpbmdzLmRpc3BsYXlDaGVja2VkQXNzaWdubWVudDtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU2V0dGluZ3MucHJvdG90eXBlLCBcImdldERpc3BsYXlMYXRlU3VibWl0QXNzaWdubWVudFwiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRpc3BsYXlMYXRlU3VibWl0QXNzaWdubWVudCAhPT0gdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICA/IHRoaXMuZGlzcGxheUxhdGVTdWJtaXRBc3NpZ25tZW50XHJcbiAgICAgICAgICAgICAgICA6IERlZmF1bHRTZXR0aW5ncy5kaXNwbGF5TGF0ZVN1Ym1pdEFzc2lnbm1lbnQ7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFNldHRpbmdzLnByb3RvdHlwZSwgXCJnZXRUb3BDb2xvckRhbmdlclwiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnRvcENvbG9yRGFuZ2VyID8gdGhpcy50b3BDb2xvckRhbmdlciA6IERlZmF1bHRTZXR0aW5ncy50b3BDb2xvckRhbmdlcjtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU2V0dGluZ3MucHJvdG90eXBlLCBcImdldFRvcENvbG9yV2FybmluZ1wiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnRvcENvbG9yV2FybmluZyA/IHRoaXMudG9wQ29sb3JXYXJuaW5nIDogRGVmYXVsdFNldHRpbmdzLnRvcENvbG9yV2FybmluZztcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU2V0dGluZ3MucHJvdG90eXBlLCBcImdldFRvcENvbG9yU3VjY2Vzc1wiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnRvcENvbG9yU3VjY2VzcyA/IHRoaXMudG9wQ29sb3JTdWNjZXNzIDogRGVmYXVsdFNldHRpbmdzLnRvcENvbG9yU3VjY2VzcztcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU2V0dGluZ3MucHJvdG90eXBlLCBcImdldE1pbmlDb2xvckRhbmdlclwiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLm1pbmlDb2xvckRhbmdlciA/IHRoaXMubWluaUNvbG9yRGFuZ2VyIDogRGVmYXVsdFNldHRpbmdzLm1pbmlDb2xvckRhbmdlcjtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU2V0dGluZ3MucHJvdG90eXBlLCBcImdldE1pbmlDb2xvcldhcm5pbmdcIiwge1xyXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5taW5pQ29sb3JXYXJuaW5nID8gdGhpcy5taW5pQ29sb3JXYXJuaW5nIDogRGVmYXVsdFNldHRpbmdzLm1pbmlDb2xvcldhcm5pbmc7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFNldHRpbmdzLnByb3RvdHlwZSwgXCJnZXRNaW5pQ29sb3JTdWNjZXNzXCIsIHtcclxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMubWluaUNvbG9yU3VjY2VzcyA/IHRoaXMubWluaUNvbG9yU3VjY2VzcyA6IERlZmF1bHRTZXR0aW5ncy5taW5pQ29sb3JTdWNjZXNzO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIHJldHVybiBTZXR0aW5ncztcclxufSgpKTtcclxuZXhwb3J0cy5TZXR0aW5ncyA9IFNldHRpbmdzO1xyXG52YXIgRGVmYXVsdFNldHRpbmdzID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKF9zdXBlcikge1xyXG4gICAgX19leHRlbmRzKERlZmF1bHRTZXR0aW5ncywgX3N1cGVyKTtcclxuICAgIGZ1bmN0aW9uIERlZmF1bHRTZXR0aW5ncygpIHtcclxuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XHJcbiAgICB9XHJcbiAgICBEZWZhdWx0U2V0dGluZ3MuYXNzaWdubWVudENhY2hlSW50ZXJ2YWwgPSAxMjA7XHJcbiAgICBEZWZhdWx0U2V0dGluZ3MucXVpekNhY2hlSW50ZXJ2YWwgPSA2MDA7XHJcbiAgICBEZWZhdWx0U2V0dGluZ3MuZGlzcGxheUNoZWNrZWRBc3NpZ25tZW50ID0gdHJ1ZTtcclxuICAgIERlZmF1bHRTZXR0aW5ncy5kaXNwbGF5TGF0ZVN1Ym1pdEFzc2lnbm1lbnQgPSBmYWxzZTtcclxuICAgIERlZmF1bHRTZXR0aW5ncy50b3BDb2xvckRhbmdlciA9IFwiI2Y3ODk4OVwiO1xyXG4gICAgRGVmYXVsdFNldHRpbmdzLnRvcENvbG9yV2FybmluZyA9IFwiI2ZkZDc4M1wiO1xyXG4gICAgRGVmYXVsdFNldHRpbmdzLnRvcENvbG9yU3VjY2VzcyA9IFwiIzhiZDQ4ZFwiO1xyXG4gICAgRGVmYXVsdFNldHRpbmdzLm1pbmlDb2xvckRhbmdlciA9IFwiI2U4NTU1NVwiO1xyXG4gICAgRGVmYXVsdFNldHRpbmdzLm1pbmlDb2xvcldhcm5pbmcgPSBcIiNkN2FhNTdcIjtcclxuICAgIERlZmF1bHRTZXR0aW5ncy5taW5pQ29sb3JTdWNjZXNzID0gXCIjNjJiNjY1XCI7XHJcbiAgICByZXR1cm4gRGVmYXVsdFNldHRpbmdzO1xyXG59KFNldHRpbmdzKSk7XHJcbmV4cG9ydHMuRGVmYXVsdFNldHRpbmdzID0gRGVmYXVsdFNldHRpbmdzO1xyXG5mdW5jdGlvbiBsb2FkU2V0dGluZ3MoKSB7XHJcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIHNldHRpbmdzQXJyLCBDU3NldHRpbmdzO1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEubG9hZEZyb21Mb2NhbFN0b3JhZ2UoXCJDU19TZXR0aW5nc1wiKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0dGluZ3NBcnIgPSBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgQ1NzZXR0aW5ncyA9IHV0aWxzXzEuY29udmVydEFycmF5VG9TZXR0aW5ncyhzZXR0aW5nc0Fycik7XHJcbiAgICAgICAgICAgICAgICAgICAgQ1NzZXR0aW5ncy5kaXNwbGF5Q2hlY2tlZEFzc2lnbm1lbnQgPSBDU3NldHRpbmdzLmdldERpc3BsYXlDaGVja2VkQXNzaWdubWVudDtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qLywgQ1NzZXR0aW5nc107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMubG9hZFNldHRpbmdzID0gbG9hZFNldHRpbmdzO1xyXG4vKipcclxuICogTG9hZCBjb25maWd1cmF0aW9ucyBmcm9tIGxvY2FsIHN0b3JhZ2VcclxuICovXHJcbmZ1bmN0aW9uIGxvYWRDb25maWdzKCkge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBiYXNlVVJMLCBWRVJTSU9OLCBDU3NldHRpbmdzLCBhc3NpZ25tZW50Q2FjaGVJbnRlcnZhbCwgcXVpekNhY2hlSW50ZXJ2YWwsIGFzc2lnbm1lbnRGZXRjaGVkVGltZSwgcXVpekZldGNoZWRUaW1lO1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgICAgIGJhc2VVUkwgPSBuZXR3b3JrXzEuZ2V0QmFzZVVSTCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIFZFUlNJT04gPSBjaHJvbWUucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb247XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgbG9hZFNldHRpbmdzKCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIENTc2V0dGluZ3MgPSBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgQ1NzZXR0aW5ncy5kaXNwbGF5Q2hlY2tlZEFzc2lnbm1lbnQgPSBDU3NldHRpbmdzLmdldERpc3BsYXlDaGVja2VkQXNzaWdubWVudDtcclxuICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50Q2FjaGVJbnRlcnZhbCA9IENTc2V0dGluZ3MuZ2V0QXNzaWdubWVudENhY2hlSW50ZXJ2YWw7XHJcbiAgICAgICAgICAgICAgICAgICAgcXVpekNhY2hlSW50ZXJ2YWwgPSBDU3NldHRpbmdzLmdldFF1aXpDYWNoZUludGVydmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5sb2FkRnJvbUxvY2FsU3RvcmFnZShcIkNTX0Fzc2lnbm1lbnRGZXRjaFRpbWVcIiwgXCJ1bmRlZmluZWRcIildO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgIGFzc2lnbm1lbnRGZXRjaGVkVGltZSA9IF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEubG9hZEZyb21Mb2NhbFN0b3JhZ2UoXCJDU19RdWl6RmV0Y2hUaW1lXCIsIFwidW5kZWZpbmVkXCIpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgICAgICAgICBxdWl6RmV0Y2hlZFRpbWUgPSBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi8sIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhc2VVUkw6IGJhc2VVUkwsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2ZXJzaW9uOiBWRVJTSU9OLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ1NzZXR0aW5nczogQ1NzZXR0aW5ncyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhY2hlSW50ZXJ2YWw6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50OiBhc3NpZ25tZW50Q2FjaGVJbnRlcnZhbCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWl6OiBxdWl6Q2FjaGVJbnRlcnZhbCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmZXRjaGVkVGltZToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzc2lnbm1lbnQ6IGFzc2lnbm1lbnRGZXRjaGVkVGltZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWl6OiBxdWl6RmV0Y2hlZFRpbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuZXhwb3J0cy5sb2FkQ29uZmlncyA9IGxvYWRDb25maWdzO1xyXG4iLCJcInVzZSBzdHJpY3RcIjtcclxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xyXG5leHBvcnRzLmdldEtleXMgPSBleHBvcnRzLnNhdmVUb0xvY2FsU3RvcmFnZSA9IGV4cG9ydHMubG9hZEZyb21Mb2NhbFN0b3JhZ2UyID0gZXhwb3J0cy5sb2FkRnJvbUxvY2FsU3RvcmFnZSA9IHZvaWQgMDtcclxuLyoqXHJcbiAqIEdldCBhbGwga2V5cyBpbiBsb2NhbCBzdG9yYWdlXHJcbiAqL1xyXG5mdW5jdGlvbiBnZXRLZXlzKCkge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQobnVsbCwgZnVuY3Rpb24gKGtleXMpIHtcclxuICAgICAgICAgICAgcmVzb2x2ZShPYmplY3Qua2V5cyhrZXlzKSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLmdldEtleXMgPSBnZXRLZXlzO1xyXG4vKipcclxuICogTG9hZCBmcm9tIGxvY2FsIHN0b3JhZ2VcclxuICogQHBhcmFtIHtzdHJpbmd9IGtleVxyXG4gKiBAcGFyYW0ge3N0cmluZ30gaWZVbmRlZmluZWRUeXBlIENhbiBzcGVjaWZ5IHJlc3BvbnNlIHR5cGUgaWYgcmVzdWx0IHdhcyB1bmRlZmluZWRcclxuICovXHJcbmZ1bmN0aW9uIGxvYWRGcm9tTG9jYWxTdG9yYWdlKGtleSwgaWZVbmRlZmluZWRUeXBlKSB7XHJcbiAgICBpZiAoaWZVbmRlZmluZWRUeXBlID09PSB2b2lkIDApIHsgaWZVbmRlZmluZWRUeXBlID0gXCJhcnJheVwiOyB9XHJcbiAgICB2YXIgYmFzZVVSTCA9IHdpbmRvdy5sb2NhdGlvbi5ob3N0bmFtZTtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KGJhc2VVUkwsIGZ1bmN0aW9uIChpdGVtcykge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZW1zW2Jhc2VVUkxdID09PSBcInVuZGVmaW5lZFwiIHx8IHR5cGVvZiBpdGVtc1tiYXNlVVJMXVtrZXldID09PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgcmVzID0gdm9pZCAwO1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoIChpZlVuZGVmaW5lZFR5cGUpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIFwibnVtYmVyXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcyA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgXCJzdHJpbmdcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzID0gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcInVuZGVmaW5lZFwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXMgPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJlc29sdmUocmVzKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKGl0ZW1zW2Jhc2VVUkxdW2tleV0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuZXhwb3J0cy5sb2FkRnJvbUxvY2FsU3RvcmFnZSA9IGxvYWRGcm9tTG9jYWxTdG9yYWdlO1xyXG4vKipcclxuICogTG9hZCBmcm9tIGxvY2FsIHN0b3JhZ2VcclxuICogRk9SIFN1YlNha2FpIHNpbmNlIGl0IG1pZ2h0IG5vdCBiZSBleGVjdXRlZCBpbiBTYWthaUxNUy5cclxuICogQHBhcmFtIHtzdHJpbmd9IGJhc2VVUkxcclxuICogQHBhcmFtIHtzdHJpbmd9IGtleVxyXG4gKi9cclxuZnVuY3Rpb24gbG9hZEZyb21Mb2NhbFN0b3JhZ2UyKGJhc2VVUkwsIGtleSkge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoYmFzZVVSTCwgZnVuY3Rpb24gKGl0ZW1zKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlbXNbYmFzZVVSTF0gPT09IFwidW5kZWZpbmVkXCIgfHwgdHlwZW9mIGl0ZW1zW2Jhc2VVUkxdW2tleV0gPT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICAgICAgICAgIHJlc29sdmUoW10pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgIHJlc29sdmUoaXRlbXNbYmFzZVVSTF1ba2V5XSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLmxvYWRGcm9tTG9jYWxTdG9yYWdlMiA9IGxvYWRGcm9tTG9jYWxTdG9yYWdlMjtcclxuLyoqXHJcbiAqIFNhdmUgdG8gbG9jYWwgc3RvcmFnZVxyXG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5XHJcbiAqIEBwYXJhbSB7YW55fSB2YWx1ZVxyXG4gKi9cclxuZnVuY3Rpb24gc2F2ZVRvTG9jYWxTdG9yYWdlKGtleSwgdmFsdWUpIHtcclxuICAgIHZhciBiYXNlVVJMID0gd2luZG93LmxvY2F0aW9uLmhvc3RuYW1lO1xyXG4gICAgdmFyIGVudGl0eSA9IHt9O1xyXG4gICAgZW50aXR5W2tleV0gPSB2YWx1ZTtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KGJhc2VVUkwsIGZ1bmN0aW9uIChpdGVtcykge1xyXG4gICAgICAgICAgICB2YXIgX2E7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlbXNbYmFzZVVSTF0gPT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgICAgICAgICAgIGl0ZW1zW2Jhc2VVUkxdID0ge307XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaXRlbXNbYmFzZVVSTF1ba2V5XSA9IHZhbHVlO1xyXG4gICAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoKF9hID0ge30sIF9hW2Jhc2VVUkxdID0gaXRlbXNbYmFzZVVSTF0sIF9hKSwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAgICAgcmVzb2x2ZShcInNhdmVkXCIpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMuc2F2ZVRvTG9jYWxTdG9yYWdlID0gc2F2ZVRvTG9jYWxTdG9yYWdlO1xyXG4iLCJcInVzZSBzdHJpY3RcIjtcclxudmFyIF9fYXdhaXRlciA9ICh0aGlzICYmIHRoaXMuX19hd2FpdGVyKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XHJcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cclxuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xyXG4gICAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvci5uZXh0KHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cclxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cclxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxyXG4gICAgICAgIHN0ZXAoKGdlbmVyYXRvciA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSkubmV4dCgpKTtcclxuICAgIH0pO1xyXG59O1xyXG52YXIgX19nZW5lcmF0b3IgPSAodGhpcyAmJiB0aGlzLl9fZ2VuZXJhdG9yKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgYm9keSkge1xyXG4gICAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbigpIHsgaWYgKHRbMF0gJiAxKSB0aHJvdyB0WzFdOyByZXR1cm4gdFsxXTsgfSwgdHJ5czogW10sIG9wczogW10gfSwgZiwgeSwgdCwgZztcclxuICAgIHJldHVybiBnID0geyBuZXh0OiB2ZXJiKDApLCBcInRocm93XCI6IHZlcmIoMSksIFwicmV0dXJuXCI6IHZlcmIoMikgfSwgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIChnW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbigpIHsgcmV0dXJuIHRoaXM7IH0pLCBnO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IHJldHVybiBmdW5jdGlvbiAodikgeyByZXR1cm4gc3RlcChbbiwgdl0pOyB9OyB9XHJcbiAgICBmdW5jdGlvbiBzdGVwKG9wKSB7XHJcbiAgICAgICAgaWYgKGYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJHZW5lcmF0b3IgaXMgYWxyZWFkeSBleGVjdXRpbmcuXCIpO1xyXG4gICAgICAgIHdoaWxlIChfKSB0cnkge1xyXG4gICAgICAgICAgICBpZiAoZiA9IDEsIHkgJiYgKHQgPSBvcFswXSAmIDIgPyB5W1wicmV0dXJuXCJdIDogb3BbMF0gPyB5W1widGhyb3dcIl0gfHwgKCh0ID0geVtcInJldHVyblwiXSkgJiYgdC5jYWxsKHkpLCAwKSA6IHkubmV4dCkgJiYgISh0ID0gdC5jYWxsKHksIG9wWzFdKSkuZG9uZSkgcmV0dXJuIHQ7XHJcbiAgICAgICAgICAgIGlmICh5ID0gMCwgdCkgb3AgPSBbb3BbMF0gJiAyLCB0LnZhbHVlXTtcclxuICAgICAgICAgICAgc3dpdGNoIChvcFswXSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiBjYXNlIDE6IHQgPSBvcDsgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ6IF8ubGFiZWwrKzsgcmV0dXJuIHsgdmFsdWU6IG9wWzFdLCBkb25lOiBmYWxzZSB9O1xyXG4gICAgICAgICAgICAgICAgY2FzZSA1OiBfLmxhYmVsKys7IHkgPSBvcFsxXTsgb3AgPSBbMF07IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA3OiBvcCA9IF8ub3BzLnBvcCgpOyBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICBpZiAoISh0ID0gXy50cnlzLCB0ID0gdC5sZW5ndGggPiAwICYmIHRbdC5sZW5ndGggLSAxXSkgJiYgKG9wWzBdID09PSA2IHx8IG9wWzBdID09PSAyKSkgeyBfID0gMDsgY29udGludWU7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDMgJiYgKCF0IHx8IChvcFsxXSA+IHRbMF0gJiYgb3BbMV0gPCB0WzNdKSkpIHsgXy5sYWJlbCA9IG9wWzFdOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gNiAmJiBfLmxhYmVsIDwgdFsxXSkgeyBfLmxhYmVsID0gdFsxXTsgdCA9IG9wOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0ICYmIF8ubGFiZWwgPCB0WzJdKSB7IF8ubGFiZWwgPSB0WzJdOyBfLm9wcy5wdXNoKG9wKTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodFsyXSkgXy5vcHMucG9wKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvcCA9IGJvZHkuY2FsbCh0aGlzQXJnLCBfKTtcclxuICAgICAgICB9IGNhdGNoIChlKSB7IG9wID0gWzYsIGVdOyB5ID0gMDsgfSBmaW5hbGx5IHsgZiA9IHQgPSAwOyB9XHJcbiAgICAgICAgaWYgKG9wWzBdICYgNSkgdGhyb3cgb3BbMV07IHJldHVybiB7IHZhbHVlOiBvcFswXSA/IG9wWzFdIDogdm9pZCAwLCBkb25lOiB0cnVlIH07XHJcbiAgICB9XHJcbn07XHJcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcclxudmFyIHN0b3JhZ2VfMSA9IHJlcXVpcmUoXCIuL3N0b3JhZ2VcIik7XHJcbnZhciB1dGlsc18xID0gcmVxdWlyZShcIi4vdXRpbHNcIik7XHJcbnZhciBtaW5pc2FrYWlfMSA9IHJlcXVpcmUoXCIuL21pbmlzYWthaVwiKTtcclxudmFyIHN1YlNha2FpUm9vdCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjc3ViLXNha2FpXCIpO1xyXG4vKipcclxuICogVXBkYXRlIHN1YlNha2FpIHRvIGxhdGVzdCBpbmZvXHJcbiAqL1xyXG5mdW5jdGlvbiB1cGRhdGVTdWJTYWthaShyb290KSB7XHJcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIGhvc3RuYW1lLCBtZXJnZWRBc3NpZ25tZW50TGlzdCwgYXNzaWdubWVudExpc3QsIF9hLCBxdWl6TGlzdCwgX2IsIGFzc2lnbm1lbnRNZW1vTGlzdCwgX2MsIGNvdXJzZUlEcztcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9kKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2QubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLmdldEtleXMoKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgaG9zdG5hbWUgPSAoX2Quc2VudCgpKVswXTtcclxuICAgICAgICAgICAgICAgICAgICBfYSA9IHV0aWxzXzEuY29udmVydEFycmF5VG9Bc3NpZ25tZW50O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5sb2FkRnJvbUxvY2FsU3RvcmFnZTIoaG9zdG5hbWUsIFwiQ1NfQXNzaWdubWVudExpc3RcIildO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgIGFzc2lnbm1lbnRMaXN0ID0gX2EuYXBwbHkodm9pZCAwLCBbX2Quc2VudCgpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgX2IgPSB1dGlsc18xLmNvbnZlcnRBcnJheVRvQXNzaWdubWVudDtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEubG9hZEZyb21Mb2NhbFN0b3JhZ2UyKGhvc3RuYW1lLCBcIkNTX1F1aXpMaXN0XCIpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgICAgICAgICBxdWl6TGlzdCA9IF9iLmFwcGx5KHZvaWQgMCwgW19kLnNlbnQoKV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIF9jID0gdXRpbHNfMS5jb252ZXJ0QXJyYXlUb0Fzc2lnbm1lbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLmxvYWRGcm9tTG9jYWxTdG9yYWdlMihob3N0bmFtZSwgXCJDU19NZW1vTGlzdFwiKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ6XHJcbiAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudE1lbW9MaXN0ID0gX2MuYXBwbHkodm9pZCAwLCBbX2Quc2VudCgpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLmxvYWRGcm9tTG9jYWxTdG9yYWdlMihob3N0bmFtZSwgXCJDU19Db3Vyc2VJbmZvXCIpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTpcclxuICAgICAgICAgICAgICAgICAgICBjb3Vyc2VJRHMgPSAoX2Quc2VudCgpKTtcclxuICAgICAgICAgICAgICAgICAgICBtZXJnZWRBc3NpZ25tZW50TGlzdCA9IHV0aWxzXzEubWVyZ2VJbnRvQXNzaWdubWVudExpc3QoYXNzaWdubWVudExpc3QsIHF1aXpMaXN0KTtcclxuICAgICAgICAgICAgICAgICAgICBtZXJnZWRBc3NpZ25tZW50TGlzdCA9IHV0aWxzXzEubWVyZ2VJbnRvQXNzaWdubWVudExpc3QobWVyZ2VkQXNzaWdubWVudExpc3QsIGFzc2lnbm1lbnRNZW1vTGlzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVyZ2VkQXNzaWdubWVudExpc3QgPSB1dGlsc18xLnNvcnRBc3NpZ25tZW50TGlzdChtZXJnZWRBc3NpZ25tZW50TGlzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgbWluaXNha2FpXzEuY3JlYXRlTWluaVNha2FpR2VuZXJhbGl6ZWQocm9vdCwgbWVyZ2VkQXNzaWdubWVudExpc3QsIGNvdXJzZUlEcywgdHJ1ZSwgZnVuY3Rpb24gKHJlbmRlcmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZW5kZXJlZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb290LmlubmVySFRNTCA9IHJlbmRlcmVkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDY6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Quc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuZnVuY3Rpb24gYWRkU3ViU2FrYWlUb1BvcHVwKCkge1xyXG4gICAgaWYgKHN1YlNha2FpUm9vdCA9PSBudWxsKVxyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgcmV0dXJuIHN1YlNha2FpUm9vdDtcclxufVxyXG4vKipcclxuICogSW5pdGlhbGl6ZSBzdWJTYWthaVxyXG4gKi9cclxuZnVuY3Rpb24gaW5pdFN1YlNha2FpKCkge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciByb290LCBfYTtcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9iKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2IubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICByb290ID0gYWRkU3ViU2FrYWlUb1BvcHVwKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgX2EgPSByb290O1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghX2EpIHJldHVybiBbMyAvKmJyZWFrKi8sIDJdO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHVwZGF0ZVN1YlNha2FpKHJvb3QpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBfYSA9IChfYi5zZW50KCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIF9iLmxhYmVsID0gMjtcclxuICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICBfYTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmluaXRTdWJTYWthaSgpO1xyXG4iLCJcInVzZSBzdHJpY3RcIjtcclxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xyXG5leHBvcnRzLnNvcnRBc3NpZ25tZW50TGlzdCA9IGV4cG9ydHMubWVyZ2VJbnRvQXNzaWdubWVudExpc3QgPSBleHBvcnRzLmdlblVuaXF1ZUlEID0gZXhwb3J0cy5pc1VzaW5nQ2FjaGUgPSBleHBvcnRzLmNvbXBhcmVBbmRNZXJnZUFzc2lnbm1lbnRMaXN0ID0gZXhwb3J0cy5jb252ZXJ0QXJyYXlUb0Fzc2lnbm1lbnQgPSBleHBvcnRzLmNvbnZlcnRBcnJheVRvU2V0dGluZ3MgPSBleHBvcnRzLm1pbmlTYWthaVJlYWR5ID0gZXhwb3J0cy5pc0xvZ2dlZEluID0gZXhwb3J0cy5mb3JtYXRUaW1lc3RhbXAgPSBleHBvcnRzLmNyZWF0ZUNvdXJzZUlETWFwID0gZXhwb3J0cy5nZXREYXlzVW50aWwgPSBleHBvcnRzLnVwZGF0ZUlzUmVhZEZsYWcgPSBleHBvcnRzLmdldFNpdGVDb3Vyc2VJRCA9IGV4cG9ydHMuZ2V0TG9nZ2VkSW5JbmZvRnJvbVNjcmlwdCA9IGV4cG9ydHMubm93VGltZSA9IHZvaWQgMDtcclxudmFyIG1vZGVsXzEgPSByZXF1aXJlKFwiLi9tb2RlbFwiKTtcclxudmFyIHNldHRpbmdzXzEgPSByZXF1aXJlKFwiLi9zZXR0aW5nc1wiKTtcclxuZXhwb3J0cy5ub3dUaW1lID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XHJcbi8qKlxyXG4gKiBDYWxjdWxhdGUgY2F0ZWdvcnkgb2YgYXNzaWdubWVudCBkdWUgZGF0ZVxyXG4gKiBAcGFyYW0ge251bWJlcn0gZHQxIHN0YW5kYXJkIHRpbWVcclxuICogQHBhcmFtIHtudW1iZXJ9IGR0MiB0YXJnZXQgdGltZVxyXG4gKi9cclxuZnVuY3Rpb24gZ2V0RGF5c1VudGlsKGR0MSwgZHQyKSB7XHJcbiAgICB2YXIgZGlmZiA9IChkdDIgLSBkdDEpIC8gMTAwMDtcclxuICAgIGRpZmYgLz0gMzYwMCAqIDI0O1xyXG4gICAgdmFyIGNhdGVnb3J5O1xyXG4gICAgaWYgKGRpZmYgPiAwICYmIGRpZmYgPD0gMSkge1xyXG4gICAgICAgIGNhdGVnb3J5ID0gXCJkdWUyNGhcIjtcclxuICAgIH1cclxuICAgIGVsc2UgaWYgKGRpZmYgPiAxICYmIGRpZmYgPD0gNSkge1xyXG4gICAgICAgIGNhdGVnb3J5ID0gXCJkdWU1ZFwiO1xyXG4gICAgfVxyXG4gICAgZWxzZSBpZiAoZGlmZiA+IDUgJiYgZGlmZiA8PSAxNCkge1xyXG4gICAgICAgIGNhdGVnb3J5ID0gXCJkdWUxNGRcIjtcclxuICAgIH1cclxuICAgIGVsc2UgaWYgKGRpZmYgPiAxNCkge1xyXG4gICAgICAgIGNhdGVnb3J5ID0gXCJkdWVPdmVyMTRkXCI7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgICBjYXRlZ29yeSA9IFwiZHVlUGFzc2VkXCI7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gY2F0ZWdvcnk7XHJcbn1cclxuZXhwb3J0cy5nZXREYXlzVW50aWwgPSBnZXREYXlzVW50aWw7XHJcbi8qKlxyXG4gKiBGb3JtYXQgdGltZXN0YW1wIGZvciBkaXNwbGF5aW5nXHJcbiAqIEBwYXJhbSB7bnVtYmVyIHwgdW5kZWZpbmVkfSB0aW1lc3RhbXBcclxuICovXHJcbmZ1bmN0aW9uIGZvcm1hdFRpbWVzdGFtcCh0aW1lc3RhbXApIHtcclxuICAgIHZhciBkYXRlID0gbmV3IERhdGUodGltZXN0YW1wID8gdGltZXN0YW1wIDogZXhwb3J0cy5ub3dUaW1lKTtcclxuICAgIHJldHVybiAoZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoKSArXHJcbiAgICAgICAgXCIgXCIgK1xyXG4gICAgICAgIGRhdGUuZ2V0SG91cnMoKSArXHJcbiAgICAgICAgXCI6XCIgK1xyXG4gICAgICAgIChcIjAwXCIgKyBkYXRlLmdldE1pbnV0ZXMoKSkuc2xpY2UoLTIpICtcclxuICAgICAgICBcIjpcIiArXHJcbiAgICAgICAgKFwiMDBcIiArIGRhdGUuZ2V0U2Vjb25kcygpKS5zbGljZSgtMikpO1xyXG59XHJcbmV4cG9ydHMuZm9ybWF0VGltZXN0YW1wID0gZm9ybWF0VGltZXN0YW1wO1xyXG4vKipcclxuICogQ3JlYXRlcyBhIE1hcCBvZiBjb3Vyc2VJRCBhbmQgY291cnNlIG5hbWUuXHJcbiAqIEBwYXJhbSB7Q291cnNlU2l0ZUluZm9bXX0gY291cnNlU2l0ZUluZm9zXHJcbiAqL1xyXG5mdW5jdGlvbiBjcmVhdGVDb3Vyc2VJRE1hcChjb3Vyc2VTaXRlSW5mb3MpIHtcclxuICAgIHZhciBjb3Vyc2VJRE1hcCA9IG5ldyBNYXAoKTtcclxuICAgIGZvciAodmFyIF9pID0gMCwgY291cnNlU2l0ZUluZm9zXzEgPSBjb3Vyc2VTaXRlSW5mb3M7IF9pIDwgY291cnNlU2l0ZUluZm9zXzEubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgdmFyIGNvdXJzZVNpdGVJbmZvID0gY291cnNlU2l0ZUluZm9zXzFbX2ldO1xyXG4gICAgICAgIHZhciBjb3Vyc2VOYW1lID0gdm9pZCAwO1xyXG4gICAgICAgIGlmIChjb3Vyc2VTaXRlSW5mby5jb3Vyc2VOYW1lID09PSB1bmRlZmluZWQpXHJcbiAgICAgICAgICAgIGNvdXJzZU5hbWUgPSBcIlwiO1xyXG4gICAgICAgIGVsc2VcclxuICAgICAgICAgICAgY291cnNlTmFtZSA9IGNvdXJzZVNpdGVJbmZvLmNvdXJzZU5hbWU7XHJcbiAgICAgICAgY291cnNlSURNYXAuc2V0KGNvdXJzZVNpdGVJbmZvLmNvdXJzZUlELCBjb3Vyc2VOYW1lKTtcclxuICAgIH1cclxuICAgIHJldHVybiBjb3Vyc2VJRE1hcDtcclxufVxyXG5leHBvcnRzLmNyZWF0ZUNvdXJzZUlETWFwID0gY3JlYXRlQ291cnNlSURNYXA7XHJcbnZhciBnZXRMb2dnZWRJbkluZm9Gcm9tU2NyaXB0ID0gZnVuY3Rpb24gKCkge1xyXG4gICAgcmV0dXJuIEFycmF5LmZyb20oZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJzY3JpcHRcIikpO1xyXG59O1xyXG5leHBvcnRzLmdldExvZ2dlZEluSW5mb0Zyb21TY3JpcHQgPSBnZXRMb2dnZWRJbkluZm9Gcm9tU2NyaXB0O1xyXG4vKipcclxuICogQ2hlY2sgaWYgdXNlciBpcyBsb2dnZW5kIGluIHRvIFNha2FpLlxyXG4gKi9cclxuZnVuY3Rpb24gaXNMb2dnZWRJbigpIHtcclxuICAgIHZhciBzY3JpcHRzID0gZXhwb3J0cy5nZXRMb2dnZWRJbkluZm9Gcm9tU2NyaXB0KCk7XHJcbiAgICB2YXIgbG9nZ2VkSW4gPSBmYWxzZTtcclxuICAgIGZvciAodmFyIF9pID0gMCwgc2NyaXB0c18xID0gc2NyaXB0czsgX2kgPCBzY3JpcHRzXzEubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgdmFyIHNjcmlwdCA9IHNjcmlwdHNfMVtfaV07XHJcbiAgICAgICAgaWYgKHNjcmlwdC50ZXh0Lm1hdGNoKCdcImxvZ2dlZEluXCI6IHRydWUnKSlcclxuICAgICAgICAgICAgbG9nZ2VkSW4gPSB0cnVlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGxvZ2dlZEluO1xyXG59XHJcbmV4cG9ydHMuaXNMb2dnZWRJbiA9IGlzTG9nZ2VkSW47XHJcbi8qKlxyXG4gKiBHZXQgY291cnNlSUQgb2YgY3VycmVudCBzaXRlLlxyXG4gKi9cclxudmFyIGdldFNpdGVDb3Vyc2VJRCA9IGZ1bmN0aW9uICh1cmwpIHtcclxuICAgIHZhciBfYTtcclxuICAgIHZhciBjb3Vyc2VJRDtcclxuICAgIHZhciByZWcgPSBuZXcgUmVnRXhwKFwiKGh0dHBzPzovL1teL10rKS9wb3J0YWwvc2l0ZS8oW14vXSspXCIpO1xyXG4gICAgaWYgKHVybC5tYXRjaChyZWcpKSB7XHJcbiAgICAgICAgY291cnNlSUQgPSAoX2EgPSB1cmwubWF0Y2gocmVnKSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hWzJdO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGNvdXJzZUlEO1xyXG59O1xyXG5leHBvcnRzLmdldFNpdGVDb3Vyc2VJRCA9IGdldFNpdGVDb3Vyc2VJRDtcclxuLyoqXHJcbiAqIFVwZGF0ZSBuZXctYXNzaWdubWVudCBub3RpZmljYXRpb24gZmxhZ3MuXHJcbiAqIEBwYXJhbSB7QXNzaWdubWVudFtdfSBhc3NpZ25tZW50TGlzdFxyXG4gKi9cclxudmFyIHVwZGF0ZUlzUmVhZEZsYWcgPSBmdW5jdGlvbiAoYXNzaWdubWVudExpc3QpIHtcclxuICAgIHZhciBjb3Vyc2VJRCA9IGV4cG9ydHMuZ2V0U2l0ZUNvdXJzZUlEKGxvY2F0aW9uLmhyZWYpO1xyXG4gICAgdmFyIHVwZGF0ZWRBc3NpZ25tZW50TGlzdCA9IFtdO1xyXG4gICAgLy8gVE9ETzogUmV2aWV3IHRoaXMgcHJvY2Vzc1xyXG4gICAgaWYgKGNvdXJzZUlEICYmIGNvdXJzZUlELmxlbmd0aCA+PSAxNykge1xyXG4gICAgICAgIGZvciAodmFyIF9pID0gMCwgYXNzaWdubWVudExpc3RfMSA9IGFzc2lnbm1lbnRMaXN0OyBfaSA8IGFzc2lnbm1lbnRMaXN0XzEubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgICAgIHZhciBhc3NpZ25tZW50ID0gYXNzaWdubWVudExpc3RfMVtfaV07XHJcbiAgICAgICAgICAgIGlmIChhc3NpZ25tZW50LmNvdXJzZVNpdGVJbmZvLmNvdXJzZUlEID09PSBjb3Vyc2VJRCkge1xyXG4gICAgICAgICAgICAgICAgdXBkYXRlZEFzc2lnbm1lbnRMaXN0LnB1c2gobmV3IG1vZGVsXzEuQXNzaWdubWVudChhc3NpZ25tZW50LmNvdXJzZVNpdGVJbmZvLCBhc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzLCB0cnVlKSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB1cGRhdGVkQXNzaWdubWVudExpc3QucHVzaChhc3NpZ25tZW50KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICAgIHVwZGF0ZWRBc3NpZ25tZW50TGlzdCA9IGFzc2lnbm1lbnRMaXN0O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHVwZGF0ZWRBc3NpZ25tZW50TGlzdDtcclxufTtcclxuZXhwb3J0cy51cGRhdGVJc1JlYWRGbGFnID0gdXBkYXRlSXNSZWFkRmxhZztcclxuLyoqXHJcbiAqIENoYW5nZSBsb2FkaW5nIGljb24gdG8gaGFtYnVyZ2VyIGJ1dHRvbi5cclxuICovXHJcbmZ1bmN0aW9uIG1pbmlTYWthaVJlYWR5KCkge1xyXG4gICAgdmFyIGxvYWRpbmdJY29uID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImNzLWxvYWRpbmdcIilbMF07XHJcbiAgICB2YXIgaGFtYnVyZ2VySWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJpbWdcIik7XHJcbiAgICBoYW1idXJnZXJJY29uLnNyYyA9IGNocm9tZS5ydW50aW1lLmdldFVSTChcImltZy9taW5pU2FrYWlCdG4ucG5nXCIpO1xyXG4gICAgaGFtYnVyZ2VySWNvbi5jbGFzc05hbWUgPSBcImNzLW1pbmlzYWthaS1idG5cIjtcclxuICAgIGxvYWRpbmdJY29uLmNsYXNzTmFtZSA9IFwiY3MtbWluaXNha2FpLWJ0bi1kaXZcIjtcclxuICAgIGxvYWRpbmdJY29uLmFwcGVuZChoYW1idXJnZXJJY29uKTtcclxufVxyXG5leHBvcnRzLm1pbmlTYWthaVJlYWR5ID0gbWluaVNha2FpUmVhZHk7XHJcbi8qKlxyXG4gKiBDb252ZXJ0IGFycmF5IHRvIFNldHRpbmdzIGNsYXNzXHJcbiAqIEBwYXJhbSB7YW55fSBhcnJcclxuICovXHJcbmZ1bmN0aW9uIGNvbnZlcnRBcnJheVRvU2V0dGluZ3MoYXJyKSB7XHJcbiAgICB2YXIgc2V0dGluZ3MgPSBuZXcgc2V0dGluZ3NfMS5TZXR0aW5ncygpO1xyXG4gICAgc2V0dGluZ3MuYXNzaWdubWVudENhY2hlSW50ZXJ2YWwgPSBhcnIuYXNzaWdubWVudENhY2hlSW50ZXJ2YWw7XHJcbiAgICBzZXR0aW5ncy5xdWl6Q2FjaGVJbnRlcnZhbCA9IGFyci5xdWl6Q2FjaGVJbnRlcnZhbDtcclxuICAgIHNldHRpbmdzLmRpc3BsYXlDaGVja2VkQXNzaWdubWVudCA9IGFyci5kaXNwbGF5Q2hlY2tlZEFzc2lnbm1lbnQ7XHJcbiAgICBzZXR0aW5ncy5kaXNwbGF5TGF0ZVN1Ym1pdEFzc2lnbm1lbnQgPSBhcnIuZGlzcGxheUxhdGVTdWJtaXRBc3NpZ25tZW50O1xyXG4gICAgc2V0dGluZ3MudG9wQ29sb3JEYW5nZXIgPSBhcnIudG9wQ29sb3JEYW5nZXI7XHJcbiAgICBzZXR0aW5ncy50b3BDb2xvcldhcm5pbmcgPSBhcnIudG9wQ29sb3JXYXJuaW5nO1xyXG4gICAgc2V0dGluZ3MudG9wQ29sb3JTdWNjZXNzID0gYXJyLnRvcENvbG9yU3VjY2VzcztcclxuICAgIHNldHRpbmdzLm1pbmlDb2xvckRhbmdlciA9IGFyci5taW5pQ29sb3JEYW5nZXI7XHJcbiAgICBzZXR0aW5ncy5taW5pQ29sb3JXYXJuaW5nID0gYXJyLm1pbmlDb2xvcldhcm5pbmc7XHJcbiAgICBzZXR0aW5ncy5taW5pQ29sb3JTdWNjZXNzID0gYXJyLm1pbmlDb2xvclN1Y2Nlc3M7XHJcbiAgICByZXR1cm4gc2V0dGluZ3M7XHJcbn1cclxuZXhwb3J0cy5jb252ZXJ0QXJyYXlUb1NldHRpbmdzID0gY29udmVydEFycmF5VG9TZXR0aW5ncztcclxuLyoqXHJcbiAqIENvbnZlcnQgYXJyYXkgdG8gQXNzaWdubWVudCBjbGFzc1xyXG4gKiBAcGFyYW0ge2FueX0gYXJyXHJcbiAqL1xyXG5mdW5jdGlvbiBjb252ZXJ0QXJyYXlUb0Fzc2lnbm1lbnQoYXJyKSB7XHJcbiAgICB2YXIgYXNzaWdubWVudExpc3QgPSBbXTtcclxuICAgIGZvciAodmFyIF9pID0gMCwgYXJyXzEgPSBhcnI7IF9pIDwgYXJyXzEubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgdmFyIGkgPSBhcnJfMVtfaV07XHJcbiAgICAgICAgdmFyIGFzc2lnbm1lbnRFbnRyaWVzID0gW107XHJcbiAgICAgICAgZm9yICh2YXIgX2EgPSAwLCBfYiA9IGkuYXNzaWdubWVudEVudHJpZXM7IF9hIDwgX2IubGVuZ3RoOyBfYSsrKSB7XHJcbiAgICAgICAgICAgIHZhciBlID0gX2JbX2FdO1xyXG4gICAgICAgICAgICB2YXIgZW50cnkgPSBuZXcgbW9kZWxfMS5Bc3NpZ25tZW50RW50cnkoZS5hc3NpZ25tZW50SUQsIGUuYXNzaWdubWVudFRpdGxlLCBlLmR1ZURhdGVUaW1lc3RhbXAsIGUuY2xvc2VEYXRlVGltZXN0YW1wLCBlLmlzTWVtbywgZS5pc0ZpbmlzaGVkLCBlLmlzUXVpeiwgZS5hc3NpZ25tZW50RGV0YWlsKTtcclxuICAgICAgICAgICAgZW50cnkuYXNzaWdubWVudFBhZ2UgPSBlLmFzc2lnbm1lbnRQYWdlO1xyXG4gICAgICAgICAgICBpZiAoZW50cnkuZ2V0Q2xvc2VEYXRlVGltZXN0YW1wICogMTAwMCA+IGV4cG9ydHMubm93VGltZSlcclxuICAgICAgICAgICAgICAgIGFzc2lnbm1lbnRFbnRyaWVzLnB1c2goZW50cnkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBhc3NpZ25tZW50TGlzdC5wdXNoKG5ldyBtb2RlbF8xLkFzc2lnbm1lbnQobmV3IG1vZGVsXzEuQ291cnNlU2l0ZUluZm8oaS5jb3Vyc2VTaXRlSW5mby5jb3Vyc2VJRCwgaS5jb3Vyc2VTaXRlSW5mby5jb3Vyc2VOYW1lKSwgYXNzaWdubWVudEVudHJpZXMsIGkuaXNSZWFkKSk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYXNzaWdubWVudExpc3Q7XHJcbn1cclxuZXhwb3J0cy5jb252ZXJ0QXJyYXlUb0Fzc2lnbm1lbnQgPSBjb252ZXJ0QXJyYXlUb0Fzc2lnbm1lbnQ7XHJcbi8qKlxyXG4gKiBDb21wYXJlIG9sZCBhbmQgbmV3IEFzc2lnbm1lbnRMaXN0IGFuZCBtZXJnZSB0aGVtLlxyXG4gKiBAcGFyYW0ge0Fzc2lnbm1lbnRbXX0gb2xkQXNzaWdubWVudGlMaXN0XHJcbiAqIEBwYXJhbSB7QXNzaWdubWVudFtdfSBuZXdBc3NpZ25tZW50TGlzdFxyXG4gKi9cclxuZnVuY3Rpb24gY29tcGFyZUFuZE1lcmdlQXNzaWdubWVudExpc3Qob2xkQXNzaWdubWVudGlMaXN0LCBuZXdBc3NpZ25tZW50TGlzdCkge1xyXG4gICAgdmFyIG1lcmdlZEFzc2lnbm1lbnRMaXN0ID0gW107XHJcbiAgICB2YXIgX2xvb3BfMSA9IGZ1bmN0aW9uIChuZXdBc3NpZ25tZW50KSB7XHJcbiAgICAgICAgdmFyIGlkeCA9IG9sZEFzc2lnbm1lbnRpTGlzdC5maW5kSW5kZXgoZnVuY3Rpb24gKG9sZEFzc2lnbm1lbnQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIG9sZEFzc2lnbm1lbnQuY291cnNlU2l0ZUluZm8uY291cnNlSUQgPT09IG5ld0Fzc2lnbm1lbnQuY291cnNlU2l0ZUluZm8uY291cnNlSUQ7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy8gSWYgdGhpcyBjb3Vyc2VJRCBpcyAqKk5PVCoqIGluIG9sZEFzc2lnbm1lbnRMaXN0OlxyXG4gICAgICAgIGlmIChpZHggPT09IC0xKSB7XHJcbiAgICAgICAgICAgIC8vIFNpbmNlIHRoaXMgY291cnNlIHNpdGUgaGFzIGEgZmlyc3QgYXNzaWdubWVudCwgc2V0IGlzUmVhZCBmbGFncyB0byBmYWxzZS5cclxuICAgICAgICAgICAgdmFyIGlzUmVhZCA9IG5ld0Fzc2lnbm1lbnQuYXNzaWdubWVudEVudHJpZXMubGVuZ3RoID09PSAwO1xyXG4gICAgICAgICAgICAvLyBTb3J0IGFuZCBhZGQgdGhpcyB0byBBc3NpZ25tZW50TGlzdFxyXG4gICAgICAgICAgICBuZXdBc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzLnNvcnQoZnVuY3Rpb24gKGEsIGIpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBhLmdldER1ZURhdGVUaW1lc3RhbXAgLSBiLmdldER1ZURhdGVUaW1lc3RhbXA7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBtZXJnZWRBc3NpZ25tZW50TGlzdC5wdXNoKG5ldyBtb2RlbF8xLkFzc2lnbm1lbnQobmV3QXNzaWdubWVudC5jb3Vyc2VTaXRlSW5mbywgbmV3QXNzaWdubWVudC5hc3NpZ25tZW50RW50cmllcywgaXNSZWFkKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIElmIHRoaXMgY291cnNlSUQgKipJUyoqIGluIG9sZEFzc2lnbm1lbnRMaXN0OlxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAvLyBUYWtlIG92ZXIgaXNSZWFkIGZsYWdcclxuICAgICAgICAgICAgdmFyIGlzUmVhZCA9IG9sZEFzc2lnbm1lbnRpTGlzdFtpZHhdLmlzUmVhZDtcclxuICAgICAgICAgICAgLy8gSnVzdCBpbiBjYXNlIGlmIEFzc2lnbm1lbnRMaXN0IGlzIGVtcHR5LCBzZXQgZmxhZyB0byB0cnVlXHJcbiAgICAgICAgICAgIGlmIChuZXdBc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzLmxlbmd0aCA9PT0gMClcclxuICAgICAgICAgICAgICAgIGlzUmVhZCA9IHRydWU7XHJcbiAgICAgICAgICAgIHZhciBtZXJnZWRBc3NpZ25tZW50RW50cmllcyA9IFtdO1xyXG4gICAgICAgICAgICB2YXIgX2xvb3BfMiA9IGZ1bmN0aW9uIChuZXdBc3NpZ25tZW50RW50cnkpIHtcclxuICAgICAgICAgICAgICAgIC8vIEZpbmQgaWYgdGhpcyBuZXcgYXNzaWdubWVudCBpcyBpbiBvbGQgQXNzaWdubWVudExpc3RcclxuICAgICAgICAgICAgICAgIHZhciBvbGRBc3NpZ25tZW50ID0gb2xkQXNzaWdubWVudGlMaXN0W2lkeF07XHJcbiAgICAgICAgICAgICAgICB2YXIgcSA9IG9sZEFzc2lnbm1lbnQuYXNzaWdubWVudEVudHJpZXMuZmluZEluZGV4KGZ1bmN0aW9uIChvbGRBc3NpZ25tZW50RW50cnkpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gb2xkQXNzaWdubWVudEVudHJ5LmFzc2lnbm1lbnRJRCA9PT0gbmV3QXNzaWdubWVudEVudHJ5LmFzc2lnbm1lbnRJRDtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgLy8gSWYgdGhlcmUgaXMgc2FtZSBhc3NpZ25tZW50SUQsIHVwZGF0ZSBpdC5cclxuICAgICAgICAgICAgICAgIGlmIChxID09PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIFNldCBpc1JlYWQgZmxhZyB0byBmYWxzZSBzaW5jZSB0aGVyZSBtaWdodCBiZSBzb21lIHVwZGF0ZXMgaW4gYXNzaWdubWVudC5cclxuICAgICAgICAgICAgICAgICAgICBpc1JlYWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICBtZXJnZWRBc3NpZ25tZW50RW50cmllcy5wdXNoKG5ld0Fzc2lnbm1lbnRFbnRyeSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyBJZiB0aGVyZSBpcyBub3QsIGNyZWF0ZSBhIG5ldyBBc3NpZ25tZW50RW50cnkgZm9yIHRoZSBjb3Vyc2Ugc2l0ZS5cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBlbnRyeSA9IG5ldyBtb2RlbF8xLkFzc2lnbm1lbnRFbnRyeShuZXdBc3NpZ25tZW50RW50cnkuYXNzaWdubWVudElELCBuZXdBc3NpZ25tZW50RW50cnkuYXNzaWdubWVudFRpdGxlLCBuZXdBc3NpZ25tZW50RW50cnkuZHVlRGF0ZVRpbWVzdGFtcCwgbmV3QXNzaWdubWVudEVudHJ5LmNsb3NlRGF0ZVRpbWVzdGFtcCwgbmV3QXNzaWdubWVudEVudHJ5LmlzTWVtbywgb2xkQXNzaWdubWVudC5hc3NpZ25tZW50RW50cmllc1txXS5pc0ZpbmlzaGVkLCBuZXdBc3NpZ25tZW50RW50cnkuaXNRdWl6LCBuZXdBc3NpZ25tZW50RW50cnkuYXNzaWdubWVudERldGFpbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgZW50cnkuYXNzaWdubWVudFBhZ2UgPSBuZXdBc3NpZ25tZW50RW50cnkuYXNzaWdubWVudFBhZ2U7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVyZ2VkQXNzaWdubWVudEVudHJpZXMucHVzaChlbnRyeSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIGZvciAodmFyIF9hID0gMCwgX2IgPSBuZXdBc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzOyBfYSA8IF9iLmxlbmd0aDsgX2ErKykge1xyXG4gICAgICAgICAgICAgICAgdmFyIG5ld0Fzc2lnbm1lbnRFbnRyeSA9IF9iW19hXTtcclxuICAgICAgICAgICAgICAgIF9sb29wXzIobmV3QXNzaWdubWVudEVudHJ5KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyBTb3J0IEFzc2lnbm1lbnRMaXN0XHJcbiAgICAgICAgICAgIG1lcmdlZEFzc2lnbm1lbnRFbnRyaWVzLnNvcnQoZnVuY3Rpb24gKGEsIGIpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBhLmdldER1ZURhdGVUaW1lc3RhbXAgLSBiLmdldER1ZURhdGVUaW1lc3RhbXA7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBtZXJnZWRBc3NpZ25tZW50TGlzdC5wdXNoKG5ldyBtb2RlbF8xLkFzc2lnbm1lbnQobmV3QXNzaWdubWVudC5jb3Vyc2VTaXRlSW5mbywgbWVyZ2VkQXNzaWdubWVudEVudHJpZXMsIGlzUmVhZCkpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcbiAgICAvLyBNZXJnZSBBc3NpZ25tZW50cyBiYXNlZCBvbiBuZXdBc3NpZ25tZW50TGlzdFxyXG4gICAgZm9yICh2YXIgX2kgPSAwLCBuZXdBc3NpZ25tZW50TGlzdF8xID0gbmV3QXNzaWdubWVudExpc3Q7IF9pIDwgbmV3QXNzaWdubWVudExpc3RfMS5sZW5ndGg7IF9pKyspIHtcclxuICAgICAgICB2YXIgbmV3QXNzaWdubWVudCA9IG5ld0Fzc2lnbm1lbnRMaXN0XzFbX2ldO1xyXG4gICAgICAgIF9sb29wXzEobmV3QXNzaWdubWVudCk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbWVyZ2VkQXNzaWdubWVudExpc3Q7XHJcbn1cclxuZXhwb3J0cy5jb21wYXJlQW5kTWVyZ2VBc3NpZ25tZW50TGlzdCA9IGNvbXBhcmVBbmRNZXJnZUFzc2lnbm1lbnRMaXN0O1xyXG4vKipcclxuICogTWVyZ2UgQXNzaWdubWVudHMsIFF1aXp6ZXMsIE1lbW9zIHRvZ2V0aGVyLlxyXG4gKiBAcGFyYW0ge0Fzc2lnbm1lbnRbXX0gdGFyZ2V0QXNzaWdubWVudExpc3RcclxuICogQHBhcmFtIHtBc3NpZ25tZW50W119IG5ld0Fzc2lnbm1lbnRMaXN0XHJcbiAqL1xyXG5mdW5jdGlvbiBtZXJnZUludG9Bc3NpZ25tZW50TGlzdCh0YXJnZXRBc3NpZ25tZW50TGlzdCwgbmV3QXNzaWdubWVudExpc3QpIHtcclxuICAgIHZhciBtZXJnZWRBc3NpZ25tZW50TGlzdCA9IFtdO1xyXG4gICAgZm9yICh2YXIgX2kgPSAwLCB0YXJnZXRBc3NpZ25tZW50TGlzdF8xID0gdGFyZ2V0QXNzaWdubWVudExpc3Q7IF9pIDwgdGFyZ2V0QXNzaWdubWVudExpc3RfMS5sZW5ndGg7IF9pKyspIHtcclxuICAgICAgICB2YXIgYXNzaWdubWVudCA9IHRhcmdldEFzc2lnbm1lbnRMaXN0XzFbX2ldO1xyXG4gICAgICAgIG1lcmdlZEFzc2lnbm1lbnRMaXN0LnB1c2gobmV3IG1vZGVsXzEuQXNzaWdubWVudChhc3NpZ25tZW50LmNvdXJzZVNpdGVJbmZvLCBhc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzLCBhc3NpZ25tZW50LmlzUmVhZCkpO1xyXG4gICAgfVxyXG4gICAgdmFyIF9sb29wXzMgPSBmdW5jdGlvbiAobmV3QXNzaWdubWVudCkge1xyXG4gICAgICAgIHZhciBpZHggPSB0YXJnZXRBc3NpZ25tZW50TGlzdC5maW5kSW5kZXgoZnVuY3Rpb24gKGFzc2lnbm1lbnQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIG5ld0Fzc2lnbm1lbnQuY291cnNlU2l0ZUluZm8uY291cnNlSUQgPT09IGFzc2lnbm1lbnQuY291cnNlU2l0ZUluZm8uY291cnNlSUQ7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdmFyIG1lcmdlZEFzc2lnbm1lbnQgPSBtZXJnZWRBc3NpZ25tZW50TGlzdFtpZHhdO1xyXG4gICAgICAgIGlmIChpZHggIT09IC0xKSB7XHJcbiAgICAgICAgICAgIG1lcmdlZEFzc2lnbm1lbnQuYXNzaWdubWVudEVudHJpZXMgPSBtZXJnZWRBc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzLmNvbmNhdChuZXdBc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIG1lcmdlZEFzc2lnbm1lbnRMaXN0LnB1c2gobmV3IG1vZGVsXzEuQXNzaWdubWVudChuZXdBc3NpZ25tZW50LmNvdXJzZVNpdGVJbmZvLCBuZXdBc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzLCB0cnVlKSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZvciAodmFyIF9hID0gMCwgbmV3QXNzaWdubWVudExpc3RfMiA9IG5ld0Fzc2lnbm1lbnRMaXN0OyBfYSA8IG5ld0Fzc2lnbm1lbnRMaXN0XzIubGVuZ3RoOyBfYSsrKSB7XHJcbiAgICAgICAgdmFyIG5ld0Fzc2lnbm1lbnQgPSBuZXdBc3NpZ25tZW50TGlzdF8yW19hXTtcclxuICAgICAgICBfbG9vcF8zKG5ld0Fzc2lnbm1lbnQpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG1lcmdlZEFzc2lnbm1lbnRMaXN0O1xyXG59XHJcbmV4cG9ydHMubWVyZ2VJbnRvQXNzaWdubWVudExpc3QgPSBtZXJnZUludG9Bc3NpZ25tZW50TGlzdDtcclxuLyoqXHJcbiAqIEZ1bmN0aW9uIGZvciBzb3J0aW5nIEFzc2lnbm1lbnRzXHJcbiAqIEBwYXJhbSB7QXNzaWdubWVudFtdfSBhc3NpZ25tZW50TGlzdFxyXG4gKi9cclxuZnVuY3Rpb24gc29ydEFzc2lnbm1lbnRMaXN0KGFzc2lnbm1lbnRMaXN0KSB7XHJcbiAgICByZXR1cm4gQXJyYXkuZnJvbShhc3NpZ25tZW50TGlzdCkuc29ydChmdW5jdGlvbiAoYSwgYikge1xyXG4gICAgICAgIGlmIChhLmNsb3Nlc3REdWVEYXRlVGltZXN0YW1wID4gYi5jbG9zZXN0RHVlRGF0ZVRpbWVzdGFtcClcclxuICAgICAgICAgICAgcmV0dXJuIDE7XHJcbiAgICAgICAgaWYgKGEuY2xvc2VzdER1ZURhdGVUaW1lc3RhbXAgPCBiLmNsb3Nlc3REdWVEYXRlVGltZXN0YW1wKVxyXG4gICAgICAgICAgICByZXR1cm4gLTE7XHJcbiAgICAgICAgcmV0dXJuIDA7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLnNvcnRBc3NpZ25tZW50TGlzdCA9IHNvcnRBc3NpZ25tZW50TGlzdDtcclxuLyoqXHJcbiAqIERlY2lkZXMgd2hldGhlciB0byB1c2UgY2FjaGVcclxuICogQHBhcmFtIHtudW1iZXIgfCB1bmRlZmluZWR9IGZldGNoZWRUaW1lXHJcbiAqIEBwYXJhbSB7bnVtYmVyfSBjYWNoZUludGVydmFsXHJcbiAqL1xyXG5mdW5jdGlvbiBpc1VzaW5nQ2FjaGUoZmV0Y2hlZFRpbWUsIGNhY2hlSW50ZXJ2YWwpIHtcclxuICAgIGlmIChmZXRjaGVkVGltZSlcclxuICAgICAgICByZXR1cm4gKGV4cG9ydHMubm93VGltZSAtIGZldGNoZWRUaW1lKSAvIDEwMDAgPD0gY2FjaGVJbnRlcnZhbDtcclxuICAgIGVsc2VcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbn1cclxuZXhwb3J0cy5pc1VzaW5nQ2FjaGUgPSBpc1VzaW5nQ2FjaGU7XHJcbi8qKlxyXG4gKiBHZW5lcmF0ZSB1bmlxdWUgSURcclxuICogQHBhcmFtIHtzdHJpbmd9IHByZWZpeFxyXG4gKi9cclxuZnVuY3Rpb24gZ2VuVW5pcXVlSUQocHJlZml4KSB7XHJcbiAgICByZXR1cm4gcHJlZml4ICsgbmV3IERhdGUoKS5nZXRUaW1lKCkudG9TdHJpbmcoMTYpICsgTWF0aC5mbG9vcigxMjM0NTYgKiBNYXRoLnJhbmRvbSgpKS50b1N0cmluZygxNik7XHJcbn1cclxuZXhwb3J0cy5nZW5VbmlxdWVJRCA9IGdlblVuaXF1ZUlEO1xyXG4iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiIiwiLy8gc3RhcnR1cFxuLy8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4vLyBUaGlzIGVudHJ5IG1vZHVsZSBpcyByZWZlcmVuY2VkIGJ5IG90aGVyIG1vZHVsZXMgc28gaXQgY2FuJ3QgYmUgaW5saW5lZFxudmFyIF9fd2VicGFja19leHBvcnRzX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fKFwiLi9zcmMvc3Vic2FrYWkudHNcIik7XG4iLCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=