/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/mustache/mustache.js":
/*!*******************************************!*\
  !*** ./node_modules/mustache/mustache.js ***!
  \*******************************************/
/***/ (function(module) {

(function (global, factory) {
   true ? module.exports = factory() :
  0;
}(this, (function () { 'use strict';

  /*!
   * mustache.js - Logic-less {{mustache}} templates with JavaScript
   * http://github.com/janl/mustache.js
   */

  var objectToString = Object.prototype.toString;
  var isArray = Array.isArray || function isArrayPolyfill (object) {
    return objectToString.call(object) === '[object Array]';
  };

  function isFunction (object) {
    return typeof object === 'function';
  }

  /**
   * More correct typeof string handling array
   * which normally returns typeof 'object'
   */
  function typeStr (obj) {
    return isArray(obj) ? 'array' : typeof obj;
  }

  function escapeRegExp (string) {
    return string.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');
  }

  /**
   * Null safe way of checking whether or not an object,
   * including its prototype, has a given property
   */
  function hasProperty (obj, propName) {
    return obj != null && typeof obj === 'object' && (propName in obj);
  }

  /**
   * Safe way of detecting whether or not the given thing is a primitive and
   * whether it has the given property
   */
  function primitiveHasOwnProperty (primitive, propName) {
    return (
      primitive != null
      && typeof primitive !== 'object'
      && primitive.hasOwnProperty
      && primitive.hasOwnProperty(propName)
    );
  }

  // Workaround for https://issues.apache.org/jira/browse/COUCHDB-577
  // See https://github.com/janl/mustache.js/issues/189
  var regExpTest = RegExp.prototype.test;
  function testRegExp (re, string) {
    return regExpTest.call(re, string);
  }

  var nonSpaceRe = /\S/;
  function isWhitespace (string) {
    return !testRegExp(nonSpaceRe, string);
  }

  var entityMap = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
    '/': '&#x2F;',
    '`': '&#x60;',
    '=': '&#x3D;'
  };

  function escapeHtml (string) {
    return String(string).replace(/[&<>"'`=\/]/g, function fromEntityMap (s) {
      return entityMap[s];
    });
  }

  var whiteRe = /\s*/;
  var spaceRe = /\s+/;
  var equalsRe = /\s*=/;
  var curlyRe = /\s*\}/;
  var tagRe = /#|\^|\/|>|\{|&|=|!/;

  /**
   * Breaks up the given `template` string into a tree of tokens. If the `tags`
   * argument is given here it must be an array with two string values: the
   * opening and closing tags used in the template (e.g. [ "<%", "%>" ]). Of
   * course, the default is to use mustaches (i.e. mustache.tags).
   *
   * A token is an array with at least 4 elements. The first element is the
   * mustache symbol that was used inside the tag, e.g. "#" or "&". If the tag
   * did not contain a symbol (i.e. {{myValue}}) this element is "name". For
   * all text that appears outside a symbol this element is "text".
   *
   * The second element of a token is its "value". For mustache tags this is
   * whatever else was inside the tag besides the opening symbol. For text tokens
   * this is the text itself.
   *
   * The third and fourth elements of the token are the start and end indices,
   * respectively, of the token in the original template.
   *
   * Tokens that are the root node of a subtree contain two more elements: 1) an
   * array of tokens in the subtree and 2) the index in the original template at
   * which the closing tag for that section begins.
   *
   * Tokens for partials also contain two more elements: 1) a string value of
   * indendation prior to that tag and 2) the index of that tag on that line -
   * eg a value of 2 indicates the partial is the third tag on this line.
   */
  function parseTemplate (template, tags) {
    if (!template)
      return [];
    var lineHasNonSpace = false;
    var sections = [];     // Stack to hold section tokens
    var tokens = [];       // Buffer to hold the tokens
    var spaces = [];       // Indices of whitespace tokens on the current line
    var hasTag = false;    // Is there a {{tag}} on the current line?
    var nonSpace = false;  // Is there a non-space char on the current line?
    var indentation = '';  // Tracks indentation for tags that use it
    var tagIndex = 0;      // Stores a count of number of tags encountered on a line

    // Strips all whitespace tokens array for the current line
    // if there was a {{#tag}} on it and otherwise only space.
    function stripSpace () {
      if (hasTag && !nonSpace) {
        while (spaces.length)
          delete tokens[spaces.pop()];
      } else {
        spaces = [];
      }

      hasTag = false;
      nonSpace = false;
    }

    var openingTagRe, closingTagRe, closingCurlyRe;
    function compileTags (tagsToCompile) {
      if (typeof tagsToCompile === 'string')
        tagsToCompile = tagsToCompile.split(spaceRe, 2);

      if (!isArray(tagsToCompile) || tagsToCompile.length !== 2)
        throw new Error('Invalid tags: ' + tagsToCompile);

      openingTagRe = new RegExp(escapeRegExp(tagsToCompile[0]) + '\\s*');
      closingTagRe = new RegExp('\\s*' + escapeRegExp(tagsToCompile[1]));
      closingCurlyRe = new RegExp('\\s*' + escapeRegExp('}' + tagsToCompile[1]));
    }

    compileTags(tags || mustache.tags);

    var scanner = new Scanner(template);

    var start, type, value, chr, token, openSection;
    while (!scanner.eos()) {
      start = scanner.pos;

      // Match any text between tags.
      value = scanner.scanUntil(openingTagRe);

      if (value) {
        for (var i = 0, valueLength = value.length; i < valueLength; ++i) {
          chr = value.charAt(i);

          if (isWhitespace(chr)) {
            spaces.push(tokens.length);
            indentation += chr;
          } else {
            nonSpace = true;
            lineHasNonSpace = true;
            indentation += ' ';
          }

          tokens.push([ 'text', chr, start, start + 1 ]);
          start += 1;

          // Check for whitespace on the current line.
          if (chr === '\n') {
            stripSpace();
            indentation = '';
            tagIndex = 0;
            lineHasNonSpace = false;
          }
        }
      }

      // Match the opening tag.
      if (!scanner.scan(openingTagRe))
        break;

      hasTag = true;

      // Get the tag type.
      type = scanner.scan(tagRe) || 'name';
      scanner.scan(whiteRe);

      // Get the tag value.
      if (type === '=') {
        value = scanner.scanUntil(equalsRe);
        scanner.scan(equalsRe);
        scanner.scanUntil(closingTagRe);
      } else if (type === '{') {
        value = scanner.scanUntil(closingCurlyRe);
        scanner.scan(curlyRe);
        scanner.scanUntil(closingTagRe);
        type = '&';
      } else {
        value = scanner.scanUntil(closingTagRe);
      }

      // Match the closing tag.
      if (!scanner.scan(closingTagRe))
        throw new Error('Unclosed tag at ' + scanner.pos);

      if (type == '>') {
        token = [ type, value, start, scanner.pos, indentation, tagIndex, lineHasNonSpace ];
      } else {
        token = [ type, value, start, scanner.pos ];
      }
      tagIndex++;
      tokens.push(token);

      if (type === '#' || type === '^') {
        sections.push(token);
      } else if (type === '/') {
        // Check section nesting.
        openSection = sections.pop();

        if (!openSection)
          throw new Error('Unopened section "' + value + '" at ' + start);

        if (openSection[1] !== value)
          throw new Error('Unclosed section "' + openSection[1] + '" at ' + start);
      } else if (type === 'name' || type === '{' || type === '&') {
        nonSpace = true;
      } else if (type === '=') {
        // Set the tags for the next time around.
        compileTags(value);
      }
    }

    stripSpace();

    // Make sure there are no open sections when we're done.
    openSection = sections.pop();

    if (openSection)
      throw new Error('Unclosed section "' + openSection[1] + '" at ' + scanner.pos);

    return nestTokens(squashTokens(tokens));
  }

  /**
   * Combines the values of consecutive text tokens in the given `tokens` array
   * to a single token.
   */
  function squashTokens (tokens) {
    var squashedTokens = [];

    var token, lastToken;
    for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
      token = tokens[i];

      if (token) {
        if (token[0] === 'text' && lastToken && lastToken[0] === 'text') {
          lastToken[1] += token[1];
          lastToken[3] = token[3];
        } else {
          squashedTokens.push(token);
          lastToken = token;
        }
      }
    }

    return squashedTokens;
  }

  /**
   * Forms the given array of `tokens` into a nested tree structure where
   * tokens that represent a section have two additional items: 1) an array of
   * all tokens that appear in that section and 2) the index in the original
   * template that represents the end of that section.
   */
  function nestTokens (tokens) {
    var nestedTokens = [];
    var collector = nestedTokens;
    var sections = [];

    var token, section;
    for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
      token = tokens[i];

      switch (token[0]) {
        case '#':
        case '^':
          collector.push(token);
          sections.push(token);
          collector = token[4] = [];
          break;
        case '/':
          section = sections.pop();
          section[5] = token[2];
          collector = sections.length > 0 ? sections[sections.length - 1][4] : nestedTokens;
          break;
        default:
          collector.push(token);
      }
    }

    return nestedTokens;
  }

  /**
   * A simple string scanner that is used by the template parser to find
   * tokens in template strings.
   */
  function Scanner (string) {
    this.string = string;
    this.tail = string;
    this.pos = 0;
  }

  /**
   * Returns `true` if the tail is empty (end of string).
   */
  Scanner.prototype.eos = function eos () {
    return this.tail === '';
  };

  /**
   * Tries to match the given regular expression at the current position.
   * Returns the matched text if it can match, the empty string otherwise.
   */
  Scanner.prototype.scan = function scan (re) {
    var match = this.tail.match(re);

    if (!match || match.index !== 0)
      return '';

    var string = match[0];

    this.tail = this.tail.substring(string.length);
    this.pos += string.length;

    return string;
  };

  /**
   * Skips all text until the given regular expression can be matched. Returns
   * the skipped string, which is the entire tail if no match can be made.
   */
  Scanner.prototype.scanUntil = function scanUntil (re) {
    var index = this.tail.search(re), match;

    switch (index) {
      case -1:
        match = this.tail;
        this.tail = '';
        break;
      case 0:
        match = '';
        break;
      default:
        match = this.tail.substring(0, index);
        this.tail = this.tail.substring(index);
    }

    this.pos += match.length;

    return match;
  };

  /**
   * Represents a rendering context by wrapping a view object and
   * maintaining a reference to the parent context.
   */
  function Context (view, parentContext) {
    this.view = view;
    this.cache = { '.': this.view };
    this.parent = parentContext;
  }

  /**
   * Creates a new context using the given view with this context
   * as the parent.
   */
  Context.prototype.push = function push (view) {
    return new Context(view, this);
  };

  /**
   * Returns the value of the given name in this context, traversing
   * up the context hierarchy if the value is absent in this context's view.
   */
  Context.prototype.lookup = function lookup (name) {
    var cache = this.cache;

    var value;
    if (cache.hasOwnProperty(name)) {
      value = cache[name];
    } else {
      var context = this, intermediateValue, names, index, lookupHit = false;

      while (context) {
        if (name.indexOf('.') > 0) {
          intermediateValue = context.view;
          names = name.split('.');
          index = 0;

          /**
           * Using the dot notion path in `name`, we descend through the
           * nested objects.
           *
           * To be certain that the lookup has been successful, we have to
           * check if the last object in the path actually has the property
           * we are looking for. We store the result in `lookupHit`.
           *
           * This is specially necessary for when the value has been set to
           * `undefined` and we want to avoid looking up parent contexts.
           *
           * In the case where dot notation is used, we consider the lookup
           * to be successful even if the last "object" in the path is
           * not actually an object but a primitive (e.g., a string, or an
           * integer), because it is sometimes useful to access a property
           * of an autoboxed primitive, such as the length of a string.
           **/
          while (intermediateValue != null && index < names.length) {
            if (index === names.length - 1)
              lookupHit = (
                hasProperty(intermediateValue, names[index])
                || primitiveHasOwnProperty(intermediateValue, names[index])
              );

            intermediateValue = intermediateValue[names[index++]];
          }
        } else {
          intermediateValue = context.view[name];

          /**
           * Only checking against `hasProperty`, which always returns `false` if
           * `context.view` is not an object. Deliberately omitting the check
           * against `primitiveHasOwnProperty` if dot notation is not used.
           *
           * Consider this example:
           * ```
           * Mustache.render("The length of a football field is {{#length}}{{length}}{{/length}}.", {length: "100 yards"})
           * ```
           *
           * If we were to check also against `primitiveHasOwnProperty`, as we do
           * in the dot notation case, then render call would return:
           *
           * "The length of a football field is 9."
           *
           * rather than the expected:
           *
           * "The length of a football field is 100 yards."
           **/
          lookupHit = hasProperty(context.view, name);
        }

        if (lookupHit) {
          value = intermediateValue;
          break;
        }

        context = context.parent;
      }

      cache[name] = value;
    }

    if (isFunction(value))
      value = value.call(this.view);

    return value;
  };

  /**
   * A Writer knows how to take a stream of tokens and render them to a
   * string, given a context. It also maintains a cache of templates to
   * avoid the need to parse the same template twice.
   */
  function Writer () {
    this.templateCache = {
      _cache: {},
      set: function set (key, value) {
        this._cache[key] = value;
      },
      get: function get (key) {
        return this._cache[key];
      },
      clear: function clear () {
        this._cache = {};
      }
    };
  }

  /**
   * Clears all cached templates in this writer.
   */
  Writer.prototype.clearCache = function clearCache () {
    if (typeof this.templateCache !== 'undefined') {
      this.templateCache.clear();
    }
  };

  /**
   * Parses and caches the given `template` according to the given `tags` or
   * `mustache.tags` if `tags` is omitted,  and returns the array of tokens
   * that is generated from the parse.
   */
  Writer.prototype.parse = function parse (template, tags) {
    var cache = this.templateCache;
    var cacheKey = template + ':' + (tags || mustache.tags).join(':');
    var isCacheEnabled = typeof cache !== 'undefined';
    var tokens = isCacheEnabled ? cache.get(cacheKey) : undefined;

    if (tokens == undefined) {
      tokens = parseTemplate(template, tags);
      isCacheEnabled && cache.set(cacheKey, tokens);
    }
    return tokens;
  };

  /**
   * High-level method that is used to render the given `template` with
   * the given `view`.
   *
   * The optional `partials` argument may be an object that contains the
   * names and templates of partials that are used in the template. It may
   * also be a function that is used to load partial templates on the fly
   * that takes a single argument: the name of the partial.
   *
   * If the optional `config` argument is given here, then it should be an
   * object with a `tags` attribute or an `escape` attribute or both.
   * If an array is passed, then it will be interpreted the same way as
   * a `tags` attribute on a `config` object.
   *
   * The `tags` attribute of a `config` object must be an array with two
   * string values: the opening and closing tags used in the template (e.g.
   * [ "<%", "%>" ]). The default is to mustache.tags.
   *
   * The `escape` attribute of a `config` object must be a function which
   * accepts a string as input and outputs a safely escaped string.
   * If an `escape` function is not provided, then an HTML-safe string
   * escaping function is used as the default.
   */
  Writer.prototype.render = function render (template, view, partials, config) {
    var tags = this.getConfigTags(config);
    var tokens = this.parse(template, tags);
    var context = (view instanceof Context) ? view : new Context(view, undefined);
    return this.renderTokens(tokens, context, partials, template, config);
  };

  /**
   * Low-level method that renders the given array of `tokens` using
   * the given `context` and `partials`.
   *
   * Note: The `originalTemplate` is only ever used to extract the portion
   * of the original template that was contained in a higher-order section.
   * If the template doesn't use higher-order sections, this argument may
   * be omitted.
   */
  Writer.prototype.renderTokens = function renderTokens (tokens, context, partials, originalTemplate, config) {
    var buffer = '';

    var token, symbol, value;
    for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
      value = undefined;
      token = tokens[i];
      symbol = token[0];

      if (symbol === '#') value = this.renderSection(token, context, partials, originalTemplate, config);
      else if (symbol === '^') value = this.renderInverted(token, context, partials, originalTemplate, config);
      else if (symbol === '>') value = this.renderPartial(token, context, partials, config);
      else if (symbol === '&') value = this.unescapedValue(token, context);
      else if (symbol === 'name') value = this.escapedValue(token, context, config);
      else if (symbol === 'text') value = this.rawValue(token);

      if (value !== undefined)
        buffer += value;
    }

    return buffer;
  };

  Writer.prototype.renderSection = function renderSection (token, context, partials, originalTemplate, config) {
    var self = this;
    var buffer = '';
    var value = context.lookup(token[1]);

    // This function is used to render an arbitrary template
    // in the current context by higher-order sections.
    function subRender (template) {
      return self.render(template, context, partials, config);
    }

    if (!value) return;

    if (isArray(value)) {
      for (var j = 0, valueLength = value.length; j < valueLength; ++j) {
        buffer += this.renderTokens(token[4], context.push(value[j]), partials, originalTemplate, config);
      }
    } else if (typeof value === 'object' || typeof value === 'string' || typeof value === 'number') {
      buffer += this.renderTokens(token[4], context.push(value), partials, originalTemplate, config);
    } else if (isFunction(value)) {
      if (typeof originalTemplate !== 'string')
        throw new Error('Cannot use higher-order sections without the original template');

      // Extract the portion of the original template that the section contains.
      value = value.call(context.view, originalTemplate.slice(token[3], token[5]), subRender);

      if (value != null)
        buffer += value;
    } else {
      buffer += this.renderTokens(token[4], context, partials, originalTemplate, config);
    }
    return buffer;
  };

  Writer.prototype.renderInverted = function renderInverted (token, context, partials, originalTemplate, config) {
    var value = context.lookup(token[1]);

    // Use JavaScript's definition of falsy. Include empty arrays.
    // See https://github.com/janl/mustache.js/issues/186
    if (!value || (isArray(value) && value.length === 0))
      return this.renderTokens(token[4], context, partials, originalTemplate, config);
  };

  Writer.prototype.indentPartial = function indentPartial (partial, indentation, lineHasNonSpace) {
    var filteredIndentation = indentation.replace(/[^ \t]/g, '');
    var partialByNl = partial.split('\n');
    for (var i = 0; i < partialByNl.length; i++) {
      if (partialByNl[i].length && (i > 0 || !lineHasNonSpace)) {
        partialByNl[i] = filteredIndentation + partialByNl[i];
      }
    }
    return partialByNl.join('\n');
  };

  Writer.prototype.renderPartial = function renderPartial (token, context, partials, config) {
    if (!partials) return;
    var tags = this.getConfigTags(config);

    var value = isFunction(partials) ? partials(token[1]) : partials[token[1]];
    if (value != null) {
      var lineHasNonSpace = token[6];
      var tagIndex = token[5];
      var indentation = token[4];
      var indentedValue = value;
      if (tagIndex == 0 && indentation) {
        indentedValue = this.indentPartial(value, indentation, lineHasNonSpace);
      }
      var tokens = this.parse(indentedValue, tags);
      return this.renderTokens(tokens, context, partials, indentedValue, config);
    }
  };

  Writer.prototype.unescapedValue = function unescapedValue (token, context) {
    var value = context.lookup(token[1]);
    if (value != null)
      return value;
  };

  Writer.prototype.escapedValue = function escapedValue (token, context, config) {
    var escape = this.getConfigEscape(config) || mustache.escape;
    var value = context.lookup(token[1]);
    if (value != null)
      return (typeof value === 'number' && escape === mustache.escape) ? String(value) : escape(value);
  };

  Writer.prototype.rawValue = function rawValue (token) {
    return token[1];
  };

  Writer.prototype.getConfigTags = function getConfigTags (config) {
    if (isArray(config)) {
      return config;
    }
    else if (config && typeof config === 'object') {
      return config.tags;
    }
    else {
      return undefined;
    }
  };

  Writer.prototype.getConfigEscape = function getConfigEscape (config) {
    if (config && typeof config === 'object' && !isArray(config)) {
      return config.escape;
    }
    else {
      return undefined;
    }
  };

  var mustache = {
    name: 'mustache.js',
    version: '4.2.0',
    tags: [ '{{', '}}' ],
    clearCache: undefined,
    escape: undefined,
    parse: undefined,
    render: undefined,
    Scanner: undefined,
    Context: undefined,
    Writer: undefined,
    /**
     * Allows a user to override the default caching strategy, by providing an
     * object with set, get and clear methods. This can also be used to disable
     * the cache by setting it to the literal `undefined`.
     */
    set templateCache (cache) {
      defaultWriter.templateCache = cache;
    },
    /**
     * Gets the default or overridden caching object from the default writer.
     */
    get templateCache () {
      return defaultWriter.templateCache;
    }
  };

  // All high-level mustache.* functions use this writer.
  var defaultWriter = new Writer();

  /**
   * Clears all cached templates in the default writer.
   */
  mustache.clearCache = function clearCache () {
    return defaultWriter.clearCache();
  };

  /**
   * Parses and caches the given template in the default writer and returns the
   * array of tokens it contains. Doing this ahead of time avoids the need to
   * parse templates on the fly as they are rendered.
   */
  mustache.parse = function parse (template, tags) {
    return defaultWriter.parse(template, tags);
  };

  /**
   * Renders the `template` with the given `view`, `partials`, and `config`
   * using the default writer.
   */
  mustache.render = function render (template, view, partials, config) {
    if (typeof template !== 'string') {
      throw new TypeError('Invalid template! Template should be a "string" ' +
                          'but "' + typeStr(template) + '" was given as the first ' +
                          'argument for mustache#render(template, view, partials)');
    }

    return defaultWriter.render(template, view, partials, config);
  };

  // Export the escaping function so that the user may override it.
  // See https://github.com/janl/mustache.js/issues/244
  mustache.escape = escapeHtml;

  // Export these mainly for testing, but also for advanced usage.
  mustache.Scanner = Scanner;
  mustache.Context = Context;
  mustache.Writer = Writer;

  return mustache;

})));


/***/ }),

/***/ "./src/content_script.ts":
/*!*******************************!*\
  !*** ./src/content_script.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.loadAndMergeAssignmentList = exports.mergedAssignmentListNoMemo = exports.mergedAssignmentList = exports.courseIDList = void 0;
var storage_1 = __webpack_require__(/*! ./storage */ "./src/storage.ts");
var network_1 = __webpack_require__(/*! ./network */ "./src/network.ts");
var minisakai_1 = __webpack_require__(/*! ./minisakai */ "./src/minisakai.ts");
var favorites_1 = __webpack_require__(/*! ./favorites */ "./src/favorites.ts");
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
var settings_1 = __webpack_require__(/*! ./settings */ "./src/settings.ts");
/**
 * Load old assignments/quizzes from storage and fetch new assignments/quizzes from Sakai.
 * @param {Config} config
 * @param {CourseSiteInfo[]} courseSiteInfos
 * @param {boolean} useAssignmentCache
 * @param {boolean} useQuizCache
 */
function loadAndMergeAssignmentList(config, courseSiteInfos, useAssignmentCache, useQuizCache) {
    return __awaiter(this, void 0, void 0, function () {
        var oldAssignmentList, _a, oldQuizList, _b, newAssignmentList, newQuizList, pendingList, _i, courseSiteInfos_1, i, result, _c, result_1, k, pendingList, _d, courseSiteInfos_2, i, result, _e, result_2, k, mergedQuizList, memoList, _f;
        return __generator(this, function (_g) {
            switch (_g.label) {
                case 0:
                    _a = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_AssignmentList")];
                case 1:
                    oldAssignmentList = _a.apply(void 0, [_g.sent()]);
                    _b = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_QuizList")];
                case 2:
                    oldQuizList = _b.apply(void 0, [_g.sent()]);
                    newAssignmentList = [];
                    newQuizList = [];
                    if (!useAssignmentCache) return [3 /*break*/, 3];
                    newAssignmentList = oldAssignmentList;
                    return [3 /*break*/, 6];
                case 3:
                    console.log("Fetching assignments...");
                    pendingList = [];
                    // Add course sites to fetch-pending list
                    for (_i = 0, courseSiteInfos_1 = courseSiteInfos; _i < courseSiteInfos_1.length; _i++) {
                        i = courseSiteInfos_1[_i];
                        pendingList.push(network_1.getAssignmentByCourseID(config.baseURL, i.courseID));
                    }
                    return [4 /*yield*/, Promise.allSettled(pendingList)];
                case 4:
                    result = _g.sent();
                    for (_c = 0, result_1 = result; _c < result_1.length; _c++) {
                        k = result_1[_c];
                        if (k.status === "fulfilled")
                            newAssignmentList.push(k.value);
                    }
                    // Update assignment fetch timestamp
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_AssignmentFetchTime", utils_1.nowTime)];
                case 5:
                    // Update assignment fetch timestamp
                    _g.sent();
                    config.fetchedTime.assignment = utils_1.nowTime;
                    _g.label = 6;
                case 6:
                    // Compare assignments with old ones
                    exports.mergedAssignmentListNoMemo = utils_1.compareAndMergeAssignmentList(oldAssignmentList, newAssignmentList);
                    exports.mergedAssignmentList = utils_1.compareAndMergeAssignmentList(oldAssignmentList, newAssignmentList);
                    if (!useQuizCache) return [3 /*break*/, 7];
                    if (typeof oldQuizList !== "undefined") {
                        newQuizList = oldQuizList;
                    }
                    return [3 /*break*/, 10];
                case 7:
                    console.log("Fetching quizzes...");
                    pendingList = [];
                    // Add course sites to fetch-pending list
                    for (_d = 0, courseSiteInfos_2 = courseSiteInfos; _d < courseSiteInfos_2.length; _d++) {
                        i = courseSiteInfos_2[_d];
                        pendingList.push(network_1.getQuizFromCourseID(config.baseURL, i.courseID));
                    }
                    return [4 /*yield*/, Promise.allSettled(pendingList)];
                case 8:
                    result = _g.sent();
                    for (_e = 0, result_2 = result; _e < result_2.length; _e++) {
                        k = result_2[_e];
                        if (k.status === "fulfilled")
                            newQuizList.push(k.value);
                    }
                    // Update assignment fetch timestamp
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_QuizFetchTime", utils_1.nowTime)];
                case 9:
                    // Update assignment fetch timestamp
                    _g.sent();
                    config.fetchedTime.quiz = utils_1.nowTime;
                    _g.label = 10;
                case 10:
                    mergedQuizList = utils_1.compareAndMergeAssignmentList(oldQuizList, newQuizList);
                    // Merge assignments and quizzes
                    exports.mergedAssignmentList = utils_1.mergeIntoAssignmentList(exports.mergedAssignmentList, mergedQuizList);
                    _f = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_MemoList")];
                case 11:
                    memoList = _f.apply(void 0, [_g.sent()]);
                    // Merge memos
                    exports.mergedAssignmentList = utils_1.sortAssignmentList(utils_1.mergeIntoAssignmentList(exports.mergedAssignmentList, memoList));
                    // Save assignments and quizzes to local storage
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_AssignmentList", exports.mergedAssignmentListNoMemo)];
                case 12:
                    // Save assignments and quizzes to local storage
                    _g.sent();
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_QuizList", mergedQuizList)];
                case 13:
                    _g.sent();
                    return [2 /*return*/, exports.mergedAssignmentList];
            }
        });
    });
}
exports.loadAndMergeAssignmentList = loadAndMergeAssignmentList;
/**
 * Load course site IDs
 */
function loadCourseIDList() {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    exports.courseIDList = network_1.getCourseIDList();
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_CourseInfo", exports.courseIDList)];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
function updateReadFlag() {
    return __awaiter(this, void 0, void 0, function () {
        var updatedAssignmentList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    updatedAssignmentList = utils_1.updateIsReadFlag(exports.mergedAssignmentListNoMemo);
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_AssignmentList", updatedAssignmentList)];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
function main() {
    return __awaiter(this, void 0, void 0, function () {
        var config;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!utils_1.isLoggedIn()) return [3 /*break*/, 8];
                    minisakai_1.createMiniSakaiBtn();
                    return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    return [4 /*yield*/, loadCourseIDList()];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, loadAndMergeAssignmentList(config, exports.courseIDList, utils_1.isUsingCache(config.fetchedTime.assignment, config.cacheInterval.assignment), utils_1.isUsingCache(config.fetchedTime.quiz, config.cacheInterval.quiz))];
                case 3:
                    exports.mergedAssignmentList = _a.sent();
                    return [4 /*yield*/, favorites_1.addFavoritedCourseSites(config.baseURL)];
                case 4:
                    _a.sent();
                    return [4 /*yield*/, minisakai_1.displayMiniSakai(exports.mergedAssignmentList, exports.courseIDList)];
                case 5:
                    _a.sent();
                    return [4 /*yield*/, minisakai_1.createFavoritesBarNotification(exports.courseIDList, exports.mergedAssignmentList)];
                case 6:
                    _a.sent();
                    return [4 /*yield*/, updateReadFlag()];
                case 7:
                    _a.sent();
                    _a.label = 8;
                case 8: return [2 /*return*/];
            }
        });
    });
}
main();


/***/ }),

/***/ "./src/dom.ts":
/*!********************!*\
  !*** ./src/dom.ts ***!
  \********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.appendChildAll = exports.cloneElem = exports.createElem = exports.addAttributes = exports.SettingsDom = exports.hamburger = exports.assignmentDiv = exports.miniSakai = void 0;
var eventListener_1 = __webpack_require__(/*! ./eventListener */ "./src/eventListener.ts");
/**
 * Create DOM elements
 */
function createElem(tag, dict, eventListener) {
    var elem = document.createElement(tag);
    addAttributes(elem, dict, eventListener);
    return elem;
}
exports.createElem = createElem;
/**
 * Clone DOM elements
 */
function cloneElem(elem, dict, eventListener) {
    var clone = elem.cloneNode(true);
    addAttributes(clone, dict, eventListener);
    return clone;
}
exports.cloneElem = cloneElem;
/**
 * Add attributes to DOM elements
 */
function addAttributes(elem, dict, eventListener) {
    for (var key in dict) {
        if (key === "style")
            elem[key].display = dict[key];
        else {
            // @ts-ignore
            elem[key] = dict[key];
        }
    }
    for (var key in eventListener) {
        elem.addEventListener(key, eventListener[key]);
    }
    return elem;
}
exports.addAttributes = addAttributes;
/**
 * Append all elements as child of 1st arg
 */
function appendChildAll(to, arr) {
    for (var obj in arr) {
        to.appendChild(arr[obj]);
    }
    return to;
}
exports.appendChildAll = appendChildAll;
exports.miniSakai = createElem("div", { id: "miniSakai" });
exports.miniSakai.classList.add("cs-minisakai", "cs-tab");
exports.assignmentDiv = createElem("div", { className: "cs-assignment-tab" });
exports.hamburger = createElem("div", { className: "cs-loading" }, { click: eventListener_1.toggleMiniSakai });
// eslint-disable-next-line @typescript-eslint/no-namespace
var SettingsDom;
(function (SettingsDom) {
    SettingsDom.mainDiv = createElem("div", { className: "cp-settings" });
    SettingsDom.div = createElem("div");
    SettingsDom.p = createElem("p", { className: "cp-settings-text" });
    SettingsDom.label = createElem("label");
    SettingsDom.toggleBtn = createElem("input", { type: "checkbox" });
    SettingsDom.resetBtn = createElem("input", { type: "button" });
    SettingsDom.stringBox = createElem("input", { type: "color", className: "cp-settings-inputbox" });
    SettingsDom.inputBox = createElem("input", { type: "number", className: "cp-settings-inputbox" });
    SettingsDom.span = createElem("span", { className: "cs-toggle-slider round" });
})(SettingsDom || (SettingsDom = {}));
exports.SettingsDom = SettingsDom;


/***/ }),

/***/ "./src/eventListener.ts":
/*!******************************!*\
  !*** ./src/eventListener.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.editFavoritesMessage = exports.deleteMemo = exports.updateSettings = exports.addMemo = exports.toggleFinishedFlag = exports.toggleMemoBox = exports.toggleSettingsTab = exports.toggleAssignmentTab = exports.toggleMiniSakai = void 0;
var dom_1 = __webpack_require__(/*! ./dom */ "./src/dom.ts");
var storage_1 = __webpack_require__(/*! ./storage */ "./src/storage.ts");
var model_1 = __webpack_require__(/*! ./model */ "./src/model.ts");
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
var content_script_1 = __webpack_require__(/*! ./content_script */ "./src/content_script.ts");
var settings_1 = __webpack_require__(/*! ./settings */ "./src/settings.ts");
var minisakai_1 = __webpack_require__(/*! ./minisakai */ "./src/minisakai.ts");
var toggle = false;
/**
 * Change visibility of miniSakai
 */
function toggleMiniSakai() {
    var _a;
    if (toggle) {
        // Hide miniSakai
        dom_1.miniSakai.style.width = "0px";
        (_a = document.getElementById("cs-cover")) === null || _a === void 0 ? void 0 : _a.remove();
    }
    else {
        // Display miniSakai
        dom_1.miniSakai.style.width = "300px";
        var cover = document.createElement("div");
        cover.id = "cs-cover";
        document.getElementsByTagName("body")[0].appendChild(cover);
        cover.onclick = toggleMiniSakai;
    }
    toggle = !toggle;
}
exports.toggleMiniSakai = toggleMiniSakai;
/**
 * Change visibility of Assignment tab
 */
function toggleAssignmentTab() {
    var assignmentTab = document.querySelector(".cs-assignment-tab");
    assignmentTab.style.display = "";
    var settingsTab = document.querySelector(".cs-settings-tab");
    settingsTab.style.display = "none";
    var addMemoButton = document.querySelector("#cs-add-memo-btn");
    addMemoButton.style.display = "";
    var assignmentFetchedTime = document.querySelector(".cs-assignment-time");
    assignmentFetchedTime.style.display = "";
    var quizFetchedTime = document.querySelector(".cs-quiz-time");
    quizFetchedTime.style.display = "";
}
exports.toggleAssignmentTab = toggleAssignmentTab;
/**
 * Change visibility of Settings tab
 */
function toggleSettingsTab() {
    var assignmentTab = document.querySelector(".cs-assignment-tab");
    assignmentTab.style.display = "none";
    var settingsTab = document.querySelector(".cs-settings-tab");
    settingsTab.style.display = "";
    var addMemoButton = document.querySelector("#cs-add-memo-btn");
    addMemoButton.style.display = "none";
    var assignmentFetchedTime = document.querySelector(".cs-assignment-time");
    assignmentFetchedTime.style.display = "none";
    var quizFetchedTime = document.querySelector(".cs-quiz-time");
    quizFetchedTime.style.display = "none";
}
exports.toggleSettingsTab = toggleSettingsTab;
/**
 * Change visibility of Memo box
 */
function toggleMemoBox() {
    var addMemoBox = document.querySelector(".addMemoBox");
    var toggleStatus = addMemoBox.style.display;
    if (toggleStatus === "") {
        addMemoBox.style.display = "none";
    }
    else {
        addMemoBox.style.display = "";
    }
}
exports.toggleMemoBox = toggleMemoBox;
/**
 * Toggle finished checkbox for assignment/quiz
 */
function toggleFinishedFlag(event) {
    return __awaiter(this, void 0, void 0, function () {
        var assignmentID, assignmentList, _a, _b, _c, updatedAssignmentList, _i, assignmentList_1, assignment, updatedAssignmentEntries, _d, _e, assignmentEntry, isFinished, isQuiz;
        return __generator(this, function (_f) {
            switch (_f.label) {
                case 0:
                    assignmentID = event.target.id;
                    if (!(assignmentID[0] === "m")) return [3 /*break*/, 2];
                    _a = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_MemoList")];
                case 1:
                    assignmentList = _a.apply(void 0, [_f.sent()]);
                    return [3 /*break*/, 6];
                case 2:
                    if (!(assignmentID[0] === "q")) return [3 /*break*/, 4];
                    _b = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_QuizList")];
                case 3:
                    assignmentList = _b.apply(void 0, [_f.sent()]);
                    return [3 /*break*/, 6];
                case 4:
                    _c = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_AssignmentList")];
                case 5:
                    assignmentList = _c.apply(void 0, [_f.sent()]);
                    _f.label = 6;
                case 6:
                    updatedAssignmentList = [];
                    for (_i = 0, assignmentList_1 = assignmentList; _i < assignmentList_1.length; _i++) {
                        assignment = assignmentList_1[_i];
                        updatedAssignmentEntries = [];
                        for (_d = 0, _e = assignment.assignmentEntries; _d < _e.length; _d++) {
                            assignmentEntry = _e[_d];
                            if (assignmentEntry.assignmentID === assignmentID) {
                                isFinished = assignmentEntry.isFinished;
                                isQuiz = false;
                                if (typeof assignmentEntry.isQuiz !== "undefined")
                                    isQuiz = assignmentEntry.isQuiz;
                                updatedAssignmentEntries.push(new model_1.AssignmentEntry(assignmentEntry.assignmentID, assignmentEntry.assignmentTitle, assignmentEntry.dueDateTimestamp, assignmentEntry.closeDateTimestamp, assignmentEntry.isMemo, !isFinished, isQuiz, assignmentEntry.assignmentDetail));
                            }
                            else {
                                updatedAssignmentEntries.push(assignmentEntry);
                            }
                        }
                        updatedAssignmentList.push(new model_1.Assignment(assignment.courseSiteInfo, updatedAssignmentEntries, assignment.isRead));
                    }
                    if (!(assignmentID[0] === "m")) return [3 /*break*/, 8];
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_MemoList", updatedAssignmentList)];
                case 7:
                    _f.sent();
                    return [3 /*break*/, 12];
                case 8:
                    if (!(assignmentID[0] === "q")) return [3 /*break*/, 10];
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_QuizList", updatedAssignmentList)];
                case 9:
                    _f.sent();
                    return [3 /*break*/, 12];
                case 10: return [4 /*yield*/, storage_1.saveToLocalStorage("CS_AssignmentList", updatedAssignmentList)];
                case 11:
                    _f.sent();
                    _f.label = 12;
                case 12: return [4 /*yield*/, redrawFavoritesBar(content_script_1.courseIDList, true)];
                case 13:
                    _f.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.toggleFinishedFlag = toggleFinishedFlag;
/**
 * Update Settings parameter
 */
function updateSettings(event, type) {
    return __awaiter(this, void 0, void 0, function () {
        var settingsID, settingsValue, config, CSsettings, colorList, _i, colorList_1, k, q;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    settingsID = event.target.id;
                    settingsValue = event.target.value;
                    return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    CSsettings = config.CSsettings;
                    // Type of Settings
                    switch (type) {
                        case "check":
                            settingsValue = event.target.checked;
                            break;
                        case "number":
                            settingsValue = parseInt(event.target.value);
                            break;
                        case "string":
                            break;
                    }
                    if (type === "reset") {
                        colorList = [
                            "topColorDanger", "topColorWarning", "topColorSuccess",
                            "miniColorDanger", "miniColorWarning", "miniColorSuccess"
                        ];
                        for (_i = 0, colorList_1 = colorList; _i < colorList_1.length; _i++) {
                            k = colorList_1[_i];
                            // @ts-ignore
                            CSsettings[k] = settings_1.DefaultSettings[k];
                            q = document.getElementById(k);
                            if (q) {
                                // @ts-ignore
                                q.value = settings_1.DefaultSettings[k];
                            }
                        }
                    }
                    else {
                        // @ts-ignore
                        CSsettings[settingsID] = settingsValue;
                    }
                    return [4 /*yield*/, storage_1.saveToLocalStorage("CS_Settings", CSsettings)];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, redrawFavoritesBar(content_script_1.courseIDList, true)];
                case 3:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.updateSettings = updateSettings;
/**
 * Add Memo to miniSakai and save.
 */
function addMemo() {
    return __awaiter(this, void 0, void 0, function () {
        var selectedIdx, courseID, memoTitle, memoDueDateTimestamp, memoList, memoEntry, memo, idx, assignmentList, quizList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    selectedIdx = document.querySelector(".todoLecName").selectedIndex;
                    courseID = document.querySelector(".todoLecName").options[selectedIdx].id;
                    memoTitle = document.querySelector(".todoContent").value;
                    memoDueDateTimestamp = new Date(document.querySelector(".todoDue").value).getTime() / 1000;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_MemoList")];
                case 1:
                    memoList = _a.sent();
                    memoEntry = new model_1.AssignmentEntry(utils_1.genUniqueID("m"), memoTitle, memoDueDateTimestamp, memoDueDateTimestamp, true, false, false, "");
                    memo = new model_1.Assignment(new model_1.CourseSiteInfo(courseID, courseID), [memoEntry], true);
                    if (typeof memoList !== "undefined" && memoList.length > 0) {
                        memoList = utils_1.convertArrayToAssignment(memoList);
                        idx = memoList.findIndex(function (oldMemo) {
                            return oldMemo.courseSiteInfo.courseID === courseID;
                        });
                        if (idx !== -1) {
                            memoList[idx].assignmentEntries.push(memoEntry);
                        }
                        else {
                            memoList.push(memo);
                        }
                    }
                    else {
                        memoList = [memo];
                    }
                    storage_1.saveToLocalStorage("CS_MemoList", memoList);
                    assignmentList = utils_1.mergeIntoAssignmentList(content_script_1.mergedAssignmentListNoMemo, memoList);
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_QuizList")];
                case 2:
                    quizList = _a.sent();
                    redrawMiniSakai();
                    return [4 /*yield*/, minisakai_1.displayMiniSakai(utils_1.mergeIntoAssignmentList(assignmentList, quizList), content_script_1.courseIDList)];
                case 3:
                    _a.sent();
                    return [4 /*yield*/, redrawFavoritesBar(content_script_1.courseIDList, true)];
                case 4:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.addMemo = addMemo;
/**
 * Delete Memo from miniSakai and storage.
 */
function deleteMemo(event) {
    return __awaiter(this, void 0, void 0, function () {
        var memoID, memoList, _a, deletedMemoList, _i, memoList_1, memo, memoEntries, _b, _c, memoEntry, assignmentList, quizList;
        return __generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    memoID = event.target.id;
                    _a = utils_1.convertArrayToAssignment;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_MemoList")];
                case 1:
                    memoList = _a.apply(void 0, [_d.sent()]);
                    deletedMemoList = [];
                    for (_i = 0, memoList_1 = memoList; _i < memoList_1.length; _i++) {
                        memo = memoList_1[_i];
                        memoEntries = [];
                        for (_b = 0, _c = memo.assignmentEntries; _b < _c.length; _b++) {
                            memoEntry = _c[_b];
                            if (memoEntry.assignmentID !== memoID)
                                memoEntries.push(memoEntry);
                        }
                        deletedMemoList.push(new model_1.Assignment(memo.courseSiteInfo, memoEntries, memo.isRead));
                    }
                    storage_1.saveToLocalStorage("CS_MemoList", deletedMemoList);
                    assignmentList = utils_1.mergeIntoAssignmentList(content_script_1.mergedAssignmentListNoMemo, deletedMemoList);
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_QuizList")];
                case 2:
                    quizList = _d.sent();
                    redrawMiniSakai();
                    return [4 /*yield*/, minisakai_1.displayMiniSakai(utils_1.mergeIntoAssignmentList(assignmentList, quizList), content_script_1.courseIDList)];
                case 3:
                    _d.sent();
                    return [4 /*yield*/, redrawFavoritesBar(content_script_1.courseIDList, true)];
                case 4:
                    _d.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.deleteMemo = deleteMemo;
/**
 * Edit default message of favorites tab.
 */
function editFavoritesMessage() {
    return __awaiter(this, void 0, void 0, function () {
        var message, lectureTabs, lectureTabsCount, i;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: 
                // Wait 200ms until jQuery finished generating message.
                return [4 /*yield*/, new Promise(function (r) { return setTimeout(r, 200); })];
                case 1:
                    // Wait 200ms until jQuery finished generating message.
                    _a.sent();
                    try {
                        message = document.getElementsByClassName("favorites-max-marker")[0];
                        message.innerHTML = "<i class=\"fa fa-bell warning-icon\"></i>" + chrome.runtime.getManifest().name + "\u306B\u3088\u3063\u3066\u304A\u6C17\u306B\u5165\u308A\u767B\u9332\u3057\u305F<br>\u30B5\u30A4\u30C8\u304C\u5168\u3066\u30D0\u30FC\u306B\u8FFD\u52A0\u3055\u308C\u307E\u3057\u305F\u3002";
                        lectureTabs = document.getElementsByClassName("fav-sites-entry");
                        lectureTabsCount = lectureTabs.length;
                        for (i = 0; i < lectureTabsCount; i++) {
                            lectureTabs[i].classList.remove("site-favorite-is-past-max");
                        }
                    }
                    catch (e) {
                        console.log("could not edit message");
                    }
                    return [2 /*return*/];
            }
        });
    });
}
exports.editFavoritesMessage = editFavoritesMessage;
/**
 * Redraw favorites bar
 * @param {CourseSiteInfo[]} courseIDList
 * @param {boolean} useCache
 */
function redrawFavoritesBar(courseIDList, useCache) {
    return __awaiter(this, void 0, void 0, function () {
        var config, newAssignmentList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    minisakai_1.deleteFavoritesBarNotification();
                    return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    return [4 /*yield*/, content_script_1.loadAndMergeAssignmentList(config, courseIDList, useCache, useCache)];
                case 2:
                    newAssignmentList = _a.sent();
                    return [4 /*yield*/, minisakai_1.createFavoritesBarNotification(courseIDList, newAssignmentList)];
                case 3:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
/**
 * Redraw miniSakai
 */
function redrawMiniSakai() {
    while (dom_1.miniSakai.firstChild) {
        dom_1.miniSakai.removeChild(dom_1.miniSakai.firstChild);
    }
    while (dom_1.assignmentDiv.firstChild) {
        dom_1.assignmentDiv.removeChild(dom_1.assignmentDiv.firstChild);
    }
    dom_1.miniSakai.remove();
    dom_1.assignmentDiv.remove();
}


/***/ }),

/***/ "./src/favorites.ts":
/*!**************************!*\
  !*** ./src/favorites.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.addFavoritedCourseSites = void 0;
var eventListener_1 = __webpack_require__(/*! ./eventListener */ "./src/eventListener.ts");
/**
 * Limit maximum number of course sites
 * @type {int}
 */
var MAX_FAVORITES = 20;
function getSiteIdAndHrefSiteNameMap() {
    var sites = document.querySelectorAll(".fav-sites-entry");
    var map = new Map();
    sites.forEach(function (site) {
        var _a, _b, _c;
        var siteId = (_a = site.querySelector(".site-favorite-btn")) === null || _a === void 0 ? void 0 : _a.getAttribute("data-site-id");
        if (siteId == null)
            return;
        var href = ((_b = site.querySelector(".fav-title")) === null || _b === void 0 ? void 0 : _b.childNodes[1]).href;
        var title = ((_c = site.querySelector(".fav-title")) === null || _c === void 0 ? void 0 : _c.childNodes[1]).title;
        map.set(siteId, { href: href, title: title });
    });
    return map;
}
/**
 * Check if current site-id is given site-id
 * @param {string} siteId
 */
function isCurrentSite(siteId) {
    var currentSiteIdM = window.location.href.match(/https?:\/\/[^\/]+\/portal\/site\/([^\/]+)/);
    if (currentSiteIdM == null)
        return false;
    return currentSiteIdM[1] == siteId;
}
/**
 * Get hrefs of sites in favorite bar
 */
function getCurrentFavoritesSite() {
    var topnav = document.querySelector("#topnav");
    if (topnav == null)
        return new Array();
    var sites = topnav.querySelectorAll(".Mrphs-sitesNav__menuitem");
    var hrefs = [];
    for (var _i = 0, _a = Array.from(sites); _i < _a.length; _i++) {
        var site = _a[_i];
        var href = site.getElementsByClassName("link-container")[0].href;
        hrefs.push(href);
    }
    return hrefs;
}
/**
 * Add course sites to favorites bar (more than Sakai config)
 * @param {string} baseURL
 */
function addFavoritedCourseSites(baseURL) {
    var _a;
    var topnav = document.querySelector("#topnav");
    if (topnav == null)
        return new Promise(function (resolve, reject) { return resolve(); });
    var request = new XMLHttpRequest();
    request.open("GET", baseURL + "/portal/favorites/list");
    request.responseType = "json";
    (_a = document.querySelector(".organizeFavorites")) === null || _a === void 0 ? void 0 : _a.addEventListener("click", eventListener_1.editFavoritesMessage);
    return new Promise(function (resolve, reject) {
        request.addEventListener("load", function (e) {
            var res = request.response;
            if (res == null) {
                console.log("failed to fetch favorites list");
                reject();
            }
            var favorites = res.favoriteSiteIds;
            var sitesInfo = getSiteIdAndHrefSiteNameMap();
            var currentFavoriteSite = getCurrentFavoritesSite();
            var _loop_1 = function (favorite) {
                // skip if favorite is the current site
                if (isCurrentSite(favorite))
                    return "continue";
                var siteInfo = sitesInfo.get(favorite);
                if (siteInfo == undefined)
                    return "continue";
                var href = siteInfo.href;
                var title = siteInfo.title;
                // skip if the site is already shown
                if (currentFavoriteSite.find(function (c) { return c == href; }) != null)
                    return "continue";
                var li = document.createElement("li");
                li.classList.add("Mrphs-sitesNav__menuitem");
                var anchor = document.createElement("a");
                anchor.classList.add("link-container");
                anchor.href = href;
                anchor.title = title;
                var span = document.createElement("span");
                span.innerText = title;
                anchor.appendChild(span);
                li.appendChild(anchor);
                topnav.appendChild(li);
            };
            for (var _i = 0, _a = favorites.slice(0, MAX_FAVORITES); _i < _a.length; _i++) {
                var favorite = _a[_i];
                _loop_1(favorite);
            }
            resolve();
        });
        request.send();
    });
}
exports.addFavoritedCourseSites = addFavoritedCourseSites;


/***/ }),

/***/ "./src/minisakai.ts":
/*!**************************!*\
  !*** ./src/minisakai.ts ***!
  \**************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createFavoritesBarNotification = exports.deleteFavoritesBarNotification = exports.displayMiniSakai = exports.createMiniSakai = exports.createMiniSakaiBtn = exports.createMiniSakaiGeneralized = void 0;
var model_1 = __webpack_require__(/*! ./model */ "./src/model.ts");
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
var dom_1 = __webpack_require__(/*! ./dom */ "./src/dom.ts");
var eventListener_1 = __webpack_require__(/*! ./eventListener */ "./src/eventListener.ts");
// @ts-ignore
var mustache_1 = __importDefault(__webpack_require__(/*! mustache */ "./node_modules/mustache/mustache.js"));
var settings_1 = __webpack_require__(/*! ./settings */ "./src/settings.ts");
/**
 * Create a button to open miniSakai
 */
function createMiniSakaiBtn() {
    var topbar = document.getElementById("mastLogin");
    try {
        topbar === null || topbar === void 0 ? void 0 : topbar.appendChild(dom_1.hamburger);
    }
    catch (e) {
        console.log("could not launch miniSakai.");
    }
}
exports.createMiniSakaiBtn = createMiniSakaiBtn;
/**
 * Using template engine to generate miniSakai list.
 */
function createMiniSakaiGeneralized(root, assignmentList, courseSiteInfos, subset, insertionProcess) {
    return __awaiter(this, void 0, void 0, function () {
        var config, assignmentFetchedTimeString, quizFetchedTimeString, courseSiteList, courseIDMap, dangerElements, warningElements, successElements, otherElements, lateSubmitElements, sortElements, noAssignmentImg, assignmentCnt, _i, assignmentList_1, assignment, templateVars;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    assignmentFetchedTimeString = utils_1.formatTimestamp(config.fetchedTime.assignment);
                    quizFetchedTimeString = utils_1.formatTimestamp(config.fetchedTime.quiz);
                    courseSiteList = [];
                    courseIDMap = utils_1.createCourseIDMap(courseSiteInfos);
                    dangerElements = [];
                    warningElements = [];
                    successElements = [];
                    otherElements = [];
                    lateSubmitElements = [];
                    // iterate over courseSite
                    assignmentList.forEach(function (assignment) {
                        var courseName = courseIDMap.get(assignment.courseSiteInfo.courseID);
                        // iterate over assignment entries
                        assignment.assignmentEntries.forEach(function (assignmentEntry) {
                            var daysUntilDue = utils_1.getDaysUntil(utils_1.nowTime, assignmentEntry.getDueDateTimestamp * 1000);
                            var displayAssignmentEntry = new model_1.DisplayAssignmentEntry(assignment.courseSiteInfo.courseID, assignmentEntry.assignmentID, assignmentEntry.assignmentTitle, assignmentEntry.dueDateTimestamp, assignmentEntry.closeDateTimestamp, assignmentEntry.isFinished, assignmentEntry.isQuiz, assignmentEntry.isMemo);
                            var displayAssignment = new model_1.DisplayAssignment([displayAssignmentEntry], courseName, assignment.getTopSite());
                            var appendElement = function (courseName, displayAssignments) {
                                var courseNameMap = displayAssignments.map(function (e) { return e.courseName; });
                                if (courseNameMap.includes(courseName)) {
                                    var idx = courseNameMap.indexOf(courseName);
                                    displayAssignments[idx].assignmentEntries.push(displayAssignmentEntry);
                                    displayAssignments[idx].assignmentEntries.sort(function (a, b) {
                                        return a.getDueDateTimestamp - b.getDueDateTimestamp;
                                    });
                                }
                                else {
                                    displayAssignments.push(displayAssignment);
                                }
                            };
                            // Append elements according to due date category
                            switch (daysUntilDue) {
                                case "due24h":
                                    appendElement(courseName, dangerElements);
                                    break;
                                case "due5d":
                                    appendElement(courseName, warningElements);
                                    break;
                                case "due14d":
                                    appendElement(courseName, successElements);
                                    break;
                                case "dueOver14d":
                                    appendElement(courseName, otherElements);
                                    break;
                                case "duePassed":
                                    // eslint-disable-next-line no-case-declarations
                                    var showLateSubmitAssignment = config.CSsettings ? config.CSsettings.getDisplayLateSubmitAssignment : false;
                                    if (showLateSubmitAssignment && utils_1.getDaysUntil(utils_1.nowTime, assignmentEntry.getCloseDateTimestamp * 1000) !== "duePassed") {
                                        appendElement(courseName, lateSubmitElements);
                                    }
                                    break;
                            }
                        });
                        courseSiteList.push(new model_1.CourseSiteInfo(assignment.courseSiteInfo.courseID, courseName));
                    });
                    sortElements = function (elements, isLateSubmission) {
                        if (isLateSubmission === void 0) { isLateSubmission = false; }
                        elements.sort(function (a, b) {
                            var timestamp;
                            if (isLateSubmission) {
                                timestamp = function (o) { return Math.min.apply(Math, o.assignmentEntries.map(function (p) { return p.getCloseDateTimestamp; })); };
                            }
                            else {
                                timestamp = function (o) { return Math.min.apply(Math, o.assignmentEntries.map(function (p) { return p.getDueDateTimestamp; })); };
                            }
                            return timestamp(a) - timestamp(b);
                        });
                        return elements;
                    };
                    noAssignmentImg = null;
                    assignmentCnt = 0;
                    if (assignmentList.length !== 0) {
                        for (_i = 0, assignmentList_1 = assignmentList; _i < assignmentList_1.length; _i++) {
                            assignment = assignmentList_1[_i];
                            assignmentCnt += assignment.assignmentEntries.length;
                        }
                    }
                    if (assignmentList.length === 0 || assignmentCnt === 0) {
                        noAssignmentImg = {
                            img: chrome.runtime.getURL("img/noAssignment.png"),
                        };
                    }
                    templateVars = {
                        fetchedTime: {
                            assignment: assignmentFetchedTimeString,
                            quiz: quizFetchedTimeString,
                        },
                        miniSakaiLogo: chrome.runtime.getURL("img/logo.png"),
                        VERSION: config.version,
                        subset: subset,
                        noAssignment: noAssignmentImg,
                        elements: {
                            danger: sortElements(dangerElements),
                            warning: sortElements(warningElements),
                            success: sortElements(successElements),
                            other: sortElements(otherElements),
                            lateSubmit: sortElements(lateSubmitElements, true),
                        },
                        display: {
                            danger: dangerElements.length > 0,
                            warning: warningElements.length > 0,
                            success: successElements.length > 0,
                            other: otherElements.length > 0,
                            lateSubmit: lateSubmitElements.length > 0,
                        },
                        titles: {
                            assignmentTab: chrome.i18n.getMessage("tab_assignments"),
                            settingsTab: chrome.i18n.getMessage("tab_settings"),
                            assignmentFetchedTime: chrome.i18n.getMessage("assignment_acquisition_date"),
                            quizFetchedTime: chrome.i18n.getMessage("testquiz_acquisition_date"),
                            due24h: chrome.i18n.getMessage("due24h"),
                            due5d: chrome.i18n.getMessage("due5d"),
                            due14d: chrome.i18n.getMessage("due14d"),
                            dueOver14d: chrome.i18n.getMessage("dueOver14d"),
                            duePassed: chrome.i18n.getMessage("duePassed"),
                            noAssignment: chrome.i18n.getMessage("no_available_assignments"),
                        },
                        todoBox: {
                            courseName: chrome.i18n.getMessage("todo_box_course_name"),
                            memoLabel: chrome.i18n.getMessage("todo_box_memo"),
                            dueDate: chrome.i18n.getMessage("todo_box_due_date"),
                            addBtnLabel: chrome.i18n.getMessage("todo_box_add"),
                            courseSiteList: courseSiteList,
                        },
                        badge: {
                            memo: chrome.i18n.getMessage("memo"),
                            quiz: chrome.i18n.getMessage("quiz"),
                        },
                    };
                    // Load mustache
                    fetch(chrome.runtime.getURL("views/minisakai.mustache"))
                        .then(function (res) { return res.text(); })
                        .then(function (template) {
                        var rendered = mustache_1.default.render(template, templateVars);
                        insertionProcess(rendered);
                        registerEventHandlers(root);
                        if (!subset)
                            createSettingsTab(root);
                        initState(root);
                    });
                    return [2 /*return*/];
            }
        });
    });
}
exports.createMiniSakaiGeneralized = createMiniSakaiGeneralized;
/**
 * Insert miniSakai into Sakai.
 */
function createMiniSakai(assignmentList, courseSiteInfos) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, createMiniSakaiGeneralized(dom_1.miniSakai, assignmentList, courseSiteInfos, false, function (rendered) {
                        dom_1.miniSakai.innerHTML = rendered;
                        var parent = document.getElementById("pageBody");
                        var ref = document.getElementById("toolMenuWrap");
                        parent === null || parent === void 0 ? void 0 : parent.insertBefore(dom_1.miniSakai, ref);
                    })];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.createMiniSakai = createMiniSakai;
/**
 * Initialize Settings tab.
 */
function createSettingsTab(root) {
    return __awaiter(this, void 0, void 0, function () {
        var config;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    createSettingItem(root, chrome.i18n.getMessage('settings_color_checked_item'), config.CSsettings.getDisplayCheckedAssignment, "displayCheckedAssignment");
                    createSettingItem(root, chrome.i18n.getMessage('settings_display_late_submit_assignment'), config.CSsettings.getDisplayLateSubmitAssignment, "displayLateSubmitAssignment");
                    createSettingItem(root, chrome.i18n.getMessage('settings_assignment_cache'), config.CSsettings.getAssignmentCacheInterval, "assignmentCacheInterval");
                    createSettingItem(root, chrome.i18n.getMessage('settings_quizzes_cache'), config.CSsettings.getQuizCacheInterval, "quizCacheInterval");
                    createSettingItem(root, chrome.i18n.getMessage('settings_colors_hour', ['Tab Bar', '24']), config.CSsettings.getTopColorDanger, "topColorDanger");
                    createSettingItem(root, chrome.i18n.getMessage('settings_colors_day', ['Tab Bar', '5']), config.CSsettings.getTopColorWarning, "topColorWarning");
                    createSettingItem(root, chrome.i18n.getMessage('settings_colors_day', ['Tab Bar', '14']), config.CSsettings.getTopColorSuccess, "topColorSuccess");
                    createSettingItem(root, chrome.i18n.getMessage('settings_colors_hour', ['miniPandA', '24']), config.CSsettings.getMiniColorDanger, "miniColorDanger");
                    createSettingItem(root, chrome.i18n.getMessage('settings_colors_day', ['miniPandA', '5']), config.CSsettings.getMiniColorWarning, "miniColorWarning");
                    createSettingItem(root, chrome.i18n.getMessage('settings_colors_day', ['miniPandA', '14']), config.CSsettings.getMiniColorSuccess, "miniColorSuccess");
                    createSettingItem(root, chrome.i18n.getMessage("settings_reset_colors"), "reset", "reset");
                    // @ts-ignore
                    root.querySelector(".cs-settings-tab").style.display = "none";
                    return [2 /*return*/];
            }
        });
    });
}
/**
 * Create Settings tab item.
 */
function createSettingItem(root, itemDescription, value, id, display) {
    if (display === void 0) { display = true; }
    var settingsDiv = root.querySelector(".cs-settings-tab");
    if (settingsDiv == null) {
        console.log(".cs-settings-tab not found");
        return;
    }
    var mainDiv = dom_1.SettingsDom.mainDiv.cloneNode(true);
    var label = dom_1.SettingsDom.label.cloneNode(true);
    var p = dom_1.SettingsDom.p.cloneNode(true);
    p.innerText = itemDescription;
    if (!display)
        mainDiv.style.display = "none";
    var settingItem;
    var span = dom_1.SettingsDom.span.cloneNode(true);
    switch (typeof value) {
        case "boolean":
            label.classList.add("cs-toggle-btn");
            settingItem = dom_1.cloneElem(dom_1.SettingsDom.toggleBtn, { checked: value, id: id }, { "change": function (res) { eventListener_1.updateSettings(res, "check"); } });
            break;
        case "number":
            settingItem = dom_1.cloneElem(dom_1.SettingsDom.inputBox, { value: value, id: id }, { "change": function (res) { eventListener_1.updateSettings(res, "number"); } });
            break;
        case "string":
            if (id === "reset") {
                settingItem = dom_1.cloneElem(dom_1.SettingsDom.resetBtn, { value: value, id: id }, { "click": function (res) { eventListener_1.updateSettings(res, "reset"); } });
            }
            else {
                settingItem = dom_1.cloneElem(dom_1.SettingsDom.stringBox, { value: value, id: id }, { "change": function (res) { eventListener_1.updateSettings(res, "string"); } });
            }
            break;
        default:
            break;
    }
    if (typeof value === "boolean")
        dom_1.appendChildAll(label, [settingItem, span]);
    else
        dom_1.appendChildAll(label, [settingItem]);
    dom_1.appendChildAll(mainDiv, [p, label]);
    settingsDiv.appendChild(mainDiv);
}
/**
 * Add event listener to each Settings item
 */
function registerEventHandlers(root) {
    var _a, _b, _c, _d, _e;
    (_a = root.querySelector("#assignmentTab")) === null || _a === void 0 ? void 0 : _a.addEventListener("click", function () { return eventListener_1.toggleAssignmentTab(); });
    (_b = root.querySelector("#settingsTab")) === null || _b === void 0 ? void 0 : _b.addEventListener("click", function () { return eventListener_1.toggleSettingsTab(); });
    root.querySelectorAll(".cs-checkbox").forEach(function (c) { return c.addEventListener("change", function (e) { return eventListener_1.toggleFinishedFlag(e); }); });
    (_c = root.querySelector("#close_btn")) === null || _c === void 0 ? void 0 : _c.addEventListener("click", function () { return eventListener_1.toggleMiniSakai(); });
    (_d = root.querySelector("#cs-add-memo-btn")) === null || _d === void 0 ? void 0 : _d.addEventListener("click", function () { return eventListener_1.toggleMemoBox(); });
    (_e = root.querySelector("#todo-add")) === null || _e === void 0 ? void 0 : _e.addEventListener("click", function () { return eventListener_1.addMemo(); });
    root.querySelectorAll(".cs-del-memo-btn").forEach(function (b) { return b.addEventListener("click", function (e) { return eventListener_1.deleteMemo(e); }); });
}
/**
 * Initialize states
 */
function initState(root) {
    // @ts-ignore
    root.querySelector("#assignmentTab").checked = true;
    // @ts-ignore
    root.querySelector(".todoDue").value = new Date(new Date().toISOString().substr(0, 16) + "-10:00")
        .toISOString()
        .substr(0, 16);
}
/**
 * Display miniSakai
 */
function displayMiniSakai(mergedAssignmentList, courseSiteInfos) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, createMiniSakai(mergedAssignmentList, courseSiteInfos)];
                case 1:
                    _a.sent();
                    utils_1.miniSakaiReady();
                    return [2 /*return*/];
            }
        });
    });
}
exports.displayMiniSakai = displayMiniSakai;
/**
 * Add notification badge for new Assignment/Quiz
 */
function createFavoritesBarNotification(courseSiteInfos, assignmentList) {
    return __awaiter(this, void 0, void 0, function () {
        var config, defaultTab, defaultTabCount, _i, courseSiteInfos_1, courseSiteInfo, _loop_1, j;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    defaultTab = document.querySelectorAll(".Mrphs-sitesNav__menuitem");
                    defaultTabCount = Object.keys(defaultTab).length;
                    for (_i = 0, courseSiteInfos_1 = courseSiteInfos; _i < courseSiteInfos_1.length; _i++) {
                        courseSiteInfo = courseSiteInfos_1[_i];
                        _loop_1 = function (j) {
                            // @ts-ignore
                            var courseID = defaultTab[j].getElementsByClassName("link-container")[0].href.match("(https?://[^/]+)/portal/site-?[a-z]*/([^/]+)")[2];
                            var q = assignmentList.findIndex(function (assignment) {
                                return assignment.courseSiteInfo.courseID === courseID;
                            });
                            if (q !== -1) {
                                var closestTime = (config.CSsettings.displayCheckedAssignment) ? assignmentList[q].closestDueDateTimestamp : assignmentList[q].closestDueDateTimestampExcludeFinished;
                                if (!assignmentList[q].isRead && closestTime !== -1) {
                                    defaultTab[j].classList.add("cs-notification-badge");
                                }
                                var daysUntilDue = utils_1.getDaysUntil(utils_1.nowTime, closestTime * 1000);
                                var aTagCount = defaultTab[j].getElementsByTagName("a").length;
                                switch (daysUntilDue) {
                                    case "due24h":
                                        defaultTab[j].classList.add("cs-tab-danger");
                                        for (var i = 0; i < aTagCount; i++) {
                                            defaultTab[j].getElementsByTagName("a")[i].classList.add("cs-tab-danger");
                                        }
                                        break;
                                    case "due5d":
                                        defaultTab[j].classList.add("cs-tab-warning");
                                        for (var i = 0; i < aTagCount; i++) {
                                            defaultTab[j].getElementsByTagName("a")[i].classList.add("cs-tab-warning");
                                        }
                                        break;
                                    case "due14d":
                                        defaultTab[j].classList.add("cs-tab-success");
                                        for (var i = 0; i < aTagCount; i++) {
                                            defaultTab[j].getElementsByTagName("a")[i].classList.add("cs-tab-success");
                                        }
                                        break;
                                    case "dueOver14d":
                                        defaultTab[j].classList.add("cs-tab-other");
                                        for (var i = 0; i < aTagCount; i++) {
                                            defaultTab[j].getElementsByTagName("a")[i].classList.add("cs-tab-other");
                                        }
                                        break;
                                }
                            }
                        };
                        for (j = 2; j < defaultTabCount; j++) {
                            _loop_1(j);
                        }
                    }
                    return [4 /*yield*/, overrideCSSColor()];
                case 2:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
exports.createFavoritesBarNotification = createFavoritesBarNotification;
/**
 * Delete notification badge for new Assignment/Quiz
 */
function deleteFavoritesBarNotification() {
    var classlist = ["cs-notification-badge", "cs-tab-danger", "cs-tab-warning", "cs-tab-success"];
    for (var _i = 0, classlist_1 = classlist; _i < classlist_1.length; _i++) {
        var c = classlist_1[_i];
        var q = document.querySelectorAll("." + c);
        // @ts-ignore
        for (var _a = 0, q_1 = q; _a < q_1.length; _a++) {
            var _1 = q_1[_a];
            _1.classList.remove("" + c);
            _1.style = "";
        }
    }
}
exports.deleteFavoritesBarNotification = deleteFavoritesBarNotification;
/**
 * Override CSS of favorites bar and miniSakai.
 */
function overrideCSSColor() {
    return __awaiter(this, void 0, void 0, function () {
        var config, overwriteborder, overwritebackground;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, settings_1.loadConfigs()];
                case 1:
                    config = _a.sent();
                    overwriteborder = function (className, color) {
                        var element = document.getElementsByClassName(className);
                        for (var i = 0; i < element.length; i++) {
                            var elem = element[i];
                            var attr = "solid 2px " + color;
                            elem.style["border-top"] = attr;
                            elem.style["border-left"] = attr;
                            elem.style["border-bottom"] = attr;
                            elem.style["border-right"] = attr;
                        }
                    };
                    overwritebackground = function (className, color) {
                        var element = document.getElementsByClassName(className);
                        for (var i = 0; i < element.length; i++) {
                            var elem = element[i];
                            elem.setAttribute("style", "background:" + color + "!important");
                        }
                    };
                    // Overwrite colors
                    overwritebackground("cs-course-danger", config.CSsettings.getMiniColorDanger);
                    overwritebackground("cs-course-warning", config.CSsettings.getMiniColorWarning);
                    overwritebackground("cs-course-success", config.CSsettings.getMiniColorSuccess);
                    overwritebackground("cs-tab-danger", config.CSsettings.getTopColorDanger);
                    overwritebackground("cs-tab-warning", config.CSsettings.getTopColorWarning);
                    overwritebackground("cs-tab-success", config.CSsettings.getTopColorSuccess);
                    overwriteborder("cs-assignment-danger", config.CSsettings.getMiniColorDanger);
                    overwriteborder("cs-assignment-warning", config.CSsettings.getMiniColorWarning);
                    overwriteborder("cs-assignment-success", config.CSsettings.getMiniColorSuccess);
                    overwriteborder("cs-tab-danger", config.CSsettings.getTopColorDanger);
                    overwriteborder("cs-tab-warning", config.CSsettings.getTopColorWarning);
                    overwriteborder("cs-tab-success", config.CSsettings.getTopColorSuccess);
                    return [2 /*return*/];
            }
        });
    });
}


/***/ }),

/***/ "./src/model.ts":
/*!**********************!*\
  !*** ./src/model.ts ***!
  \**********************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DisplayAssignment = exports.DisplayAssignmentEntry = exports.CourseSiteInfo = exports.Assignment = exports.AssignmentEntry = void 0;
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
var MAX_TIMESTAMP = 99999999999999;
var AssignmentEntry = /** @class */ (function () {
    function AssignmentEntry(assignmentID, assignmentTitle, dueDateTimestamp, closeDateTimestamp, isMemo, isFinished, isQuiz, assignmentDetail, assignmentPage) {
        this.assignmentID = assignmentID;
        this.assignmentTitle = assignmentTitle;
        this.assignmentDetail = assignmentDetail;
        this.dueDateTimestamp = dueDateTimestamp;
        this.closeDateTimestamp = closeDateTimestamp;
        this.isMemo = isMemo;
        this.isFinished = isFinished;
        this.isQuiz = isQuiz;
        this.assignmentPage = assignmentPage;
    }
    Object.defineProperty(AssignmentEntry.prototype, "getDueDateTimestamp", {
        get: function () {
            return this.dueDateTimestamp ? this.dueDateTimestamp : MAX_TIMESTAMP;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(AssignmentEntry.prototype, "getCloseDateTimestamp", {
        get: function () {
            return this.closeDateTimestamp ? this.closeDateTimestamp : MAX_TIMESTAMP;
        },
        enumerable: false,
        configurable: true
    });
    return AssignmentEntry;
}());
exports.AssignmentEntry = AssignmentEntry;
var Assignment = /** @class */ (function () {
    function Assignment(courseSiteInfo, assignmentEntries, isRead) {
        this.courseSiteInfo = courseSiteInfo;
        this.assignmentEntries = assignmentEntries;
        this.isRead = isRead;
    }
    Object.defineProperty(Assignment.prototype, "closestDueDateTimestamp", {
        get: function () {
            if (this.assignmentEntries.length == 0)
                return -1;
            var min = MAX_TIMESTAMP;
            for (var _i = 0, _a = this.assignmentEntries; _i < _a.length; _i++) {
                var entry = _a[_i];
                if (min > entry.getDueDateTimestamp && entry.getDueDateTimestamp * 1000 >= utils_1.nowTime) {
                    min = entry.getDueDateTimestamp;
                }
            }
            if (min === MAX_TIMESTAMP)
                min = -1;
            return min;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Assignment.prototype, "closestDueDateTimestampExcludeFinished", {
        // 完了済み以外からclosestTimeを取得する
        get: function () {
            if (this.assignmentEntries.length == 0)
                return -1;
            var min = MAX_TIMESTAMP;
            var excludeCount = 0;
            for (var _i = 0, _a = this.assignmentEntries; _i < _a.length; _i++) {
                var entry = _a[_i];
                if (entry.isFinished) {
                    excludeCount++;
                    continue;
                }
                if (min > entry.getDueDateTimestamp && entry.getDueDateTimestamp * 1000 >= utils_1.nowTime) {
                    min = entry.getDueDateTimestamp;
                }
            }
            if (excludeCount === this.assignmentEntries.length)
                min = -1;
            if (min === MAX_TIMESTAMP)
                min = -1;
            return min;
        },
        enumerable: false,
        configurable: true
    });
    Assignment.prototype.getTopSite = function () {
        for (var _i = 0, _a = this.assignmentEntries; _i < _a.length; _i++) {
            var entry = _a[_i];
            if (entry.assignmentPage != null)
                return entry.assignmentPage;
        }
        return "";
    };
    return Assignment;
}());
exports.Assignment = Assignment;
var CourseSiteInfo = /** @class */ (function () {
    function CourseSiteInfo(courseID, courseName) {
        this.courseID = courseID;
        this.courseName = courseName;
    }
    return CourseSiteInfo;
}());
exports.CourseSiteInfo = CourseSiteInfo;
var DisplayAssignmentEntry = /** @class */ (function (_super) {
    __extends(DisplayAssignmentEntry, _super);
    function DisplayAssignmentEntry(courseID, assignmentID, assignmentTitle, dueDateTimestamp, closeDateTimestamp, isFinished, isQuiz, isMemo) {
        var _this = _super.call(this, assignmentID, assignmentTitle, dueDateTimestamp, closeDateTimestamp, isMemo, isFinished, isQuiz) || this;
        _this.courseID = courseID;
        return _this;
    }
    DisplayAssignmentEntry.getTimeRemain = function (remainTimestamp) {
        var day = Math.floor(remainTimestamp / (3600 * 24));
        var hours = Math.floor((remainTimestamp - day * 3600 * 24) / 3600);
        var minutes = Math.floor((remainTimestamp - (day * 3600 * 24 + hours * 3600)) / 60);
        return [day.toString(), hours.toString(), minutes.toString()];
    };
    DisplayAssignmentEntry.createTimeString = function (timestamp) {
        if (!timestamp)
            return chrome.i18n.getMessage("due_not_set");
        var timeRemain = DisplayAssignmentEntry.getTimeRemain((timestamp * 1000 - utils_1.nowTime) / 1000);
        return chrome.i18n.getMessage("remain_time", [timeRemain[0], timeRemain[1], timeRemain[2]]);
    };
    DisplayAssignmentEntry.createDateString = function (timestamp) {
        if (!timestamp)
            return "----/--/--";
        var date = new Date(timestamp * 1000);
        return date.toLocaleDateString() + " " + date.getHours() + ":" + ("00" + date.getMinutes()).slice(-2);
    };
    Object.defineProperty(DisplayAssignmentEntry.prototype, "remainTimeString", {
        get: function () {
            return DisplayAssignmentEntry.createTimeString(this.dueDateTimestamp);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(DisplayAssignmentEntry.prototype, "remainCloseTimeString", {
        get: function () {
            return DisplayAssignmentEntry.createTimeString(this.closeDateTimestamp);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(DisplayAssignmentEntry.prototype, "dueDateString", {
        get: function () {
            return DisplayAssignmentEntry.createDateString(this.dueDateTimestamp);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(DisplayAssignmentEntry.prototype, "dueCloseDateString", {
        get: function () {
            return DisplayAssignmentEntry.createDateString(this.closeDateTimestamp);
        },
        enumerable: false,
        configurable: true
    });
    return DisplayAssignmentEntry;
}(AssignmentEntry));
exports.DisplayAssignmentEntry = DisplayAssignmentEntry;
var DisplayAssignment = /** @class */ (function () {
    function DisplayAssignment(assignmentEntries, courseName, coursePage) {
        this.assignmentEntries = assignmentEntries;
        this.courseName = courseName;
        this.coursePage = coursePage;
    }
    return DisplayAssignment;
}());
exports.DisplayAssignment = DisplayAssignment;


/***/ }),

/***/ "./src/network.ts":
/*!************************!*\
  !*** ./src/network.ts ***!
  \************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getQuizFromCourseID = exports.getAssignmentByCourseID = exports.getCourseIDList = exports.getBaseURL = void 0;
var model_1 = __webpack_require__(/*! ./model */ "./src/model.ts");
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
/**
 * Get base URL of Sakai.
 */
function getBaseURL() {
    var baseURL = "";
    var match = location.href.match("(https?://[^/]+)/portal");
    if (match) {
        baseURL = match[1];
    }
    return baseURL;
}
exports.getBaseURL = getBaseURL;
/**
 * Fetch course site IDs.
 */
function getCourseIDList() {
    var elementCollection = document.getElementsByClassName("fav-sites-entry");
    var elements = Array.prototype.slice.call(elementCollection);
    var result = [];
    for (var _i = 0, elements_1 = elements; _i < elements_1.length; _i++) {
        var elem = elements_1[_i];
        var lectureInfo = new model_1.CourseSiteInfo("", "");
        var lecture = elem.getElementsByTagName("div")[0].getElementsByTagName("a")[0];
        var m = lecture.href.match("(https?://[^/]+)/portal/site-?[a-z]*/([^/]+)");
        if (m && m[2][0] !== "~") {
            lectureInfo.courseID = m[2];
            lectureInfo.courseName = lecture.title;
            result.push(lectureInfo);
        }
    }
    return result;
}
exports.getCourseIDList = getCourseIDList;
/**
 * Fetch assignments from Sakai REST API.
 * @param {string} baseURL
 * @param {string} courseID
 */
function getAssignmentByCourseID(baseURL, courseID) {
    var _this = this;
    var queryURL = baseURL + "/direct/assignment/site/" + courseID + ".json";
    return new Promise(function (resolve, reject) {
        fetch(queryURL, { cache: "no-cache" })
            .then(function (response) { return __awaiter(_this, void 0, void 0, function () {
            var res, courseSiteInfo, assignmentEntries;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!response.ok) return [3 /*break*/, 2];
                        return [4 /*yield*/, response.json()];
                    case 1:
                        res = _a.sent();
                        courseSiteInfo = new model_1.CourseSiteInfo(courseID, courseID);
                        assignmentEntries = convJsonToAssignmentEntries(res, baseURL, courseID);
                        resolve(new model_1.Assignment(courseSiteInfo, assignmentEntries, false));
                        return [3 /*break*/, 3];
                    case 2:
                        reject("Request failed: " + response.status);
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        }); })
            .catch(function (err) { return console.error(err); }); // Error: Request failed: 404
    });
}
exports.getAssignmentByCourseID = getAssignmentByCourseID;
/**
 * Fetch quizzes from Sakai REST API.
 * @param {string} baseURL
 * @param {string} courseID
 */
function getQuizFromCourseID(baseURL, courseID) {
    var _this = this;
    var queryURL = baseURL + "/direct/sam_pub/context/" + courseID + ".json";
    return new Promise(function (resolve, reject) {
        fetch(queryURL, { cache: "no-cache" })
            .then(function (response) { return __awaiter(_this, void 0, void 0, function () {
            var res, courseSiteInfo, assignmentEntries;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!response.ok) return [3 /*break*/, 2];
                        return [4 /*yield*/, response.json()];
                    case 1:
                        res = _a.sent();
                        courseSiteInfo = new model_1.CourseSiteInfo(courseID, courseID);
                        assignmentEntries = convJsonToQuizEntries(res, baseURL, courseID);
                        resolve(new model_1.Assignment(courseSiteInfo, assignmentEntries, false));
                        return [3 /*break*/, 3];
                    case 2:
                        reject("Request failed: " + response.status);
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        }); })
            .catch(function (err) { return console.error(err); }); // Error: Request failed: 404
    });
}
exports.getQuizFromCourseID = getQuizFromCourseID;
/**
 * Convert json response to AssignmentEntries.
 * @param data
 * @param baseURL
 * @param siteID
 */
function convJsonToAssignmentEntries(data, baseURL, siteID) {
    var assignment_collection = data.assignment_collection;
    return assignment_collection
        .filter(function (json) { return json.closeTime.epochSecond * 1000 >= utils_1.nowTime; })
        .map(function (json) {
        var assignmentID = json.id;
        var assignmentTitle = json.title;
        var assignmentDetail = json.instructions;
        var dueDateTimestamp = json.dueTime.epochSecond ? json.dueTime.epochSecond : null;
        var closeDateTimestamp = json.closeTime.epochSecond ? json.closeTime.epochSecond : null;
        var entry = new model_1.AssignmentEntry(assignmentID, assignmentTitle, dueDateTimestamp, closeDateTimestamp, false, false, false, assignmentDetail);
        entry.assignmentPage = baseURL + "/portal/site/" + siteID;
        return entry;
    });
}
/**
 * Convert json response to QuizEntries.
 * @param data
 * @param baseURL
 * @param siteID
 */
function convJsonToQuizEntries(data, baseURL, siteID) {
    return data.sam_pub_collection
        .filter(function (json) { return json.startDate < utils_1.nowTime && (json.dueDate >= utils_1.nowTime || json.dueDate == null); })
        .map(function (json) {
        var quizID = "q" + json.publishedAssessmentId;
        var quizTitle = json.title;
        var quizDetail = "";
        var quizDueEpoch = json.dueDate ? json.dueDate / 1000 : null;
        var entry = new model_1.AssignmentEntry(quizID, quizTitle, quizDueEpoch, quizDueEpoch, false, false, true, quizDetail);
        entry.assignmentPage = baseURL + "/portal/site/" + siteID;
        return entry;
    });
}


/***/ }),

/***/ "./src/settings.ts":
/*!*************************!*\
  !*** ./src/settings.ts ***!
  \*************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.loadConfigs = exports.loadSettings = exports.DefaultSettings = exports.Settings = void 0;
var storage_1 = __webpack_require__(/*! ./storage */ "./src/storage.ts");
var utils_1 = __webpack_require__(/*! ./utils */ "./src/utils.ts");
var network_1 = __webpack_require__(/*! ./network */ "./src/network.ts");
var Settings = /** @class */ (function () {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    function Settings() {
    }
    Object.defineProperty(Settings.prototype, "getAssignmentCacheInterval", {
        get: function () {
            return this.assignmentCacheInterval ? this.assignmentCacheInterval : DefaultSettings.assignmentCacheInterval;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getQuizCacheInterval", {
        get: function () {
            return this.quizCacheInterval ? this.quizCacheInterval : DefaultSettings.quizCacheInterval;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getDisplayCheckedAssignment", {
        get: function () {
            return this.displayCheckedAssignment !== undefined
                ? this.displayCheckedAssignment
                : DefaultSettings.displayCheckedAssignment;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getDisplayLateSubmitAssignment", {
        get: function () {
            return this.displayLateSubmitAssignment !== undefined
                ? this.displayLateSubmitAssignment
                : DefaultSettings.displayLateSubmitAssignment;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getTopColorDanger", {
        get: function () {
            return this.topColorDanger ? this.topColorDanger : DefaultSettings.topColorDanger;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getTopColorWarning", {
        get: function () {
            return this.topColorWarning ? this.topColorWarning : DefaultSettings.topColorWarning;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getTopColorSuccess", {
        get: function () {
            return this.topColorSuccess ? this.topColorSuccess : DefaultSettings.topColorSuccess;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getMiniColorDanger", {
        get: function () {
            return this.miniColorDanger ? this.miniColorDanger : DefaultSettings.miniColorDanger;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getMiniColorWarning", {
        get: function () {
            return this.miniColorWarning ? this.miniColorWarning : DefaultSettings.miniColorWarning;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Settings.prototype, "getMiniColorSuccess", {
        get: function () {
            return this.miniColorSuccess ? this.miniColorSuccess : DefaultSettings.miniColorSuccess;
        },
        enumerable: false,
        configurable: true
    });
    return Settings;
}());
exports.Settings = Settings;
var DefaultSettings = /** @class */ (function (_super) {
    __extends(DefaultSettings, _super);
    function DefaultSettings() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    DefaultSettings.assignmentCacheInterval = 120;
    DefaultSettings.quizCacheInterval = 600;
    DefaultSettings.displayCheckedAssignment = true;
    DefaultSettings.displayLateSubmitAssignment = false;
    DefaultSettings.topColorDanger = "#f78989";
    DefaultSettings.topColorWarning = "#fdd783";
    DefaultSettings.topColorSuccess = "#8bd48d";
    DefaultSettings.miniColorDanger = "#e85555";
    DefaultSettings.miniColorWarning = "#d7aa57";
    DefaultSettings.miniColorSuccess = "#62b665";
    return DefaultSettings;
}(Settings));
exports.DefaultSettings = DefaultSettings;
function loadSettings() {
    return __awaiter(this, void 0, void 0, function () {
        var settingsArr, CSsettings;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_Settings")];
                case 1:
                    settingsArr = _a.sent();
                    CSsettings = utils_1.convertArrayToSettings(settingsArr);
                    CSsettings.displayCheckedAssignment = CSsettings.getDisplayCheckedAssignment;
                    return [2 /*return*/, CSsettings];
            }
        });
    });
}
exports.loadSettings = loadSettings;
/**
 * Load configurations from local storage
 */
function loadConfigs() {
    return __awaiter(this, void 0, void 0, function () {
        var baseURL, VERSION, CSsettings, assignmentCacheInterval, quizCacheInterval, assignmentFetchedTime, quizFetchedTime;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    baseURL = network_1.getBaseURL();
                    VERSION = chrome.runtime.getManifest().version;
                    return [4 /*yield*/, loadSettings()];
                case 1:
                    CSsettings = _a.sent();
                    CSsettings.displayCheckedAssignment = CSsettings.getDisplayCheckedAssignment;
                    assignmentCacheInterval = CSsettings.getAssignmentCacheInterval;
                    quizCacheInterval = CSsettings.getQuizCacheInterval;
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_AssignmentFetchTime", "undefined")];
                case 2:
                    assignmentFetchedTime = _a.sent();
                    return [4 /*yield*/, storage_1.loadFromLocalStorage("CS_QuizFetchTime", "undefined")];
                case 3:
                    quizFetchedTime = _a.sent();
                    return [2 /*return*/, {
                            baseURL: baseURL,
                            version: VERSION,
                            CSsettings: CSsettings,
                            cacheInterval: {
                                assignment: assignmentCacheInterval,
                                quiz: quizCacheInterval,
                            },
                            fetchedTime: {
                                assignment: assignmentFetchedTime,
                                quiz: quizFetchedTime,
                            },
                        }];
            }
        });
    });
}
exports.loadConfigs = loadConfigs;


/***/ }),

/***/ "./src/storage.ts":
/*!************************!*\
  !*** ./src/storage.ts ***!
  \************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getKeys = exports.saveToLocalStorage = exports.loadFromLocalStorage2 = exports.loadFromLocalStorage = void 0;
/**
 * Get all keys in local storage
 */
function getKeys() {
    return new Promise(function (resolve, reject) {
        chrome.storage.local.get(null, function (keys) {
            resolve(Object.keys(keys));
        });
    });
}
exports.getKeys = getKeys;
/**
 * Load from local storage
 * @param {string} key
 * @param {string} ifUndefinedType Can specify response type if result was undefined
 */
function loadFromLocalStorage(key, ifUndefinedType) {
    if (ifUndefinedType === void 0) { ifUndefinedType = "array"; }
    var baseURL = window.location.hostname;
    return new Promise(function (resolve, reject) {
        chrome.storage.local.get(baseURL, function (items) {
            if (typeof items[baseURL] === "undefined" || typeof items[baseURL][key] === "undefined") {
                var res = void 0;
                switch (ifUndefinedType) {
                    case "number":
                        res = 0;
                        break;
                    case "string":
                        res = "";
                        break;
                    case "undefined":
                        res = undefined;
                        break;
                    default:
                        res = [];
                        break;
                }
                resolve(res);
            }
            else
                resolve(items[baseURL][key]);
        });
    });
}
exports.loadFromLocalStorage = loadFromLocalStorage;
/**
 * Load from local storage
 * FOR SubSakai since it might not be executed in SakaiLMS.
 * @param {string} baseURL
 * @param {string} key
 */
function loadFromLocalStorage2(baseURL, key) {
    return new Promise(function (resolve, reject) {
        chrome.storage.local.get(baseURL, function (items) {
            if (typeof items[baseURL] === "undefined" || typeof items[baseURL][key] === "undefined") {
                resolve([]);
            }
            else
                resolve(items[baseURL][key]);
        });
    });
}
exports.loadFromLocalStorage2 = loadFromLocalStorage2;
/**
 * Save to local storage
 * @param {string} key
 * @param {any} value
 */
function saveToLocalStorage(key, value) {
    var baseURL = window.location.hostname;
    var entity = {};
    entity[key] = value;
    return new Promise(function (resolve, reject) {
        chrome.storage.local.get(baseURL, function (items) {
            var _a;
            if (typeof items[baseURL] === "undefined") {
                items[baseURL] = {};
            }
            items[baseURL][key] = value;
            chrome.storage.local.set((_a = {}, _a[baseURL] = items[baseURL], _a), function () {
                resolve("saved");
            });
        });
    });
}
exports.saveToLocalStorage = saveToLocalStorage;


/***/ }),

/***/ "./src/utils.ts":
/*!**********************!*\
  !*** ./src/utils.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.sortAssignmentList = exports.mergeIntoAssignmentList = exports.genUniqueID = exports.isUsingCache = exports.compareAndMergeAssignmentList = exports.convertArrayToAssignment = exports.convertArrayToSettings = exports.miniSakaiReady = exports.isLoggedIn = exports.formatTimestamp = exports.createCourseIDMap = exports.getDaysUntil = exports.updateIsReadFlag = exports.getSiteCourseID = exports.getLoggedInInfoFromScript = exports.nowTime = void 0;
var model_1 = __webpack_require__(/*! ./model */ "./src/model.ts");
var settings_1 = __webpack_require__(/*! ./settings */ "./src/settings.ts");
exports.nowTime = new Date().getTime();
/**
 * Calculate category of assignment due date
 * @param {number} dt1 standard time
 * @param {number} dt2 target time
 */
function getDaysUntil(dt1, dt2) {
    var diff = (dt2 - dt1) / 1000;
    diff /= 3600 * 24;
    var category;
    if (diff > 0 && diff <= 1) {
        category = "due24h";
    }
    else if (diff > 1 && diff <= 5) {
        category = "due5d";
    }
    else if (diff > 5 && diff <= 14) {
        category = "due14d";
    }
    else if (diff > 14) {
        category = "dueOver14d";
    }
    else {
        category = "duePassed";
    }
    return category;
}
exports.getDaysUntil = getDaysUntil;
/**
 * Format timestamp for displaying
 * @param {number | undefined} timestamp
 */
function formatTimestamp(timestamp) {
    var date = new Date(timestamp ? timestamp : exports.nowTime);
    return (date.toLocaleDateString() +
        " " +
        date.getHours() +
        ":" +
        ("00" + date.getMinutes()).slice(-2) +
        ":" +
        ("00" + date.getSeconds()).slice(-2));
}
exports.formatTimestamp = formatTimestamp;
/**
 * Creates a Map of courseID and course name.
 * @param {CourseSiteInfo[]} courseSiteInfos
 */
function createCourseIDMap(courseSiteInfos) {
    var courseIDMap = new Map();
    for (var _i = 0, courseSiteInfos_1 = courseSiteInfos; _i < courseSiteInfos_1.length; _i++) {
        var courseSiteInfo = courseSiteInfos_1[_i];
        var courseName = void 0;
        if (courseSiteInfo.courseName === undefined)
            courseName = "";
        else
            courseName = courseSiteInfo.courseName;
        courseIDMap.set(courseSiteInfo.courseID, courseName);
    }
    return courseIDMap;
}
exports.createCourseIDMap = createCourseIDMap;
var getLoggedInInfoFromScript = function () {
    return Array.from(document.getElementsByTagName("script"));
};
exports.getLoggedInInfoFromScript = getLoggedInInfoFromScript;
/**
 * Check if user is loggend in to Sakai.
 */
function isLoggedIn() {
    var scripts = exports.getLoggedInInfoFromScript();
    var loggedIn = false;
    for (var _i = 0, scripts_1 = scripts; _i < scripts_1.length; _i++) {
        var script = scripts_1[_i];
        if (script.text.match('"loggedIn": true'))
            loggedIn = true;
    }
    return loggedIn;
}
exports.isLoggedIn = isLoggedIn;
/**
 * Get courseID of current site.
 */
var getSiteCourseID = function (url) {
    var _a;
    var courseID;
    var reg = new RegExp("(https?://[^/]+)/portal/site/([^/]+)");
    if (url.match(reg)) {
        courseID = (_a = url.match(reg)) === null || _a === void 0 ? void 0 : _a[2];
    }
    return courseID;
};
exports.getSiteCourseID = getSiteCourseID;
/**
 * Update new-assignment notification flags.
 * @param {Assignment[]} assignmentList
 */
var updateIsReadFlag = function (assignmentList) {
    var courseID = exports.getSiteCourseID(location.href);
    var updatedAssignmentList = [];
    // TODO: Review this process
    if (courseID && courseID.length >= 17) {
        for (var _i = 0, assignmentList_1 = assignmentList; _i < assignmentList_1.length; _i++) {
            var assignment = assignmentList_1[_i];
            if (assignment.courseSiteInfo.courseID === courseID) {
                updatedAssignmentList.push(new model_1.Assignment(assignment.courseSiteInfo, assignment.assignmentEntries, true));
            }
            else {
                updatedAssignmentList.push(assignment);
            }
        }
    }
    else {
        updatedAssignmentList = assignmentList;
    }
    return updatedAssignmentList;
};
exports.updateIsReadFlag = updateIsReadFlag;
/**
 * Change loading icon to hamburger button.
 */
function miniSakaiReady() {
    var loadingIcon = document.getElementsByClassName("cs-loading")[0];
    var hamburgerIcon = document.createElement("img");
    hamburgerIcon.src = chrome.runtime.getURL("img/miniSakaiBtn.png");
    hamburgerIcon.className = "cs-minisakai-btn";
    loadingIcon.className = "cs-minisakai-btn-div";
    loadingIcon.append(hamburgerIcon);
}
exports.miniSakaiReady = miniSakaiReady;
/**
 * Convert array to Settings class
 * @param {any} arr
 */
function convertArrayToSettings(arr) {
    var settings = new settings_1.Settings();
    settings.assignmentCacheInterval = arr.assignmentCacheInterval;
    settings.quizCacheInterval = arr.quizCacheInterval;
    settings.displayCheckedAssignment = arr.displayCheckedAssignment;
    settings.displayLateSubmitAssignment = arr.displayLateSubmitAssignment;
    settings.topColorDanger = arr.topColorDanger;
    settings.topColorWarning = arr.topColorWarning;
    settings.topColorSuccess = arr.topColorSuccess;
    settings.miniColorDanger = arr.miniColorDanger;
    settings.miniColorWarning = arr.miniColorWarning;
    settings.miniColorSuccess = arr.miniColorSuccess;
    return settings;
}
exports.convertArrayToSettings = convertArrayToSettings;
/**
 * Convert array to Assignment class
 * @param {any} arr
 */
function convertArrayToAssignment(arr) {
    var assignmentList = [];
    for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
        var i = arr_1[_i];
        var assignmentEntries = [];
        for (var _a = 0, _b = i.assignmentEntries; _a < _b.length; _a++) {
            var e = _b[_a];
            var entry = new model_1.AssignmentEntry(e.assignmentID, e.assignmentTitle, e.dueDateTimestamp, e.closeDateTimestamp, e.isMemo, e.isFinished, e.isQuiz, e.assignmentDetail);
            entry.assignmentPage = e.assignmentPage;
            if (entry.getCloseDateTimestamp * 1000 > exports.nowTime)
                assignmentEntries.push(entry);
        }
        assignmentList.push(new model_1.Assignment(new model_1.CourseSiteInfo(i.courseSiteInfo.courseID, i.courseSiteInfo.courseName), assignmentEntries, i.isRead));
    }
    return assignmentList;
}
exports.convertArrayToAssignment = convertArrayToAssignment;
/**
 * Compare old and new AssignmentList and merge them.
 * @param {Assignment[]} oldAssignmentiList
 * @param {Assignment[]} newAssignmentList
 */
function compareAndMergeAssignmentList(oldAssignmentiList, newAssignmentList) {
    var mergedAssignmentList = [];
    var _loop_1 = function (newAssignment) {
        var idx = oldAssignmentiList.findIndex(function (oldAssignment) {
            return oldAssignment.courseSiteInfo.courseID === newAssignment.courseSiteInfo.courseID;
        });
        // If this courseID is **NOT** in oldAssignmentList:
        if (idx === -1) {
            // Since this course site has a first assignment, set isRead flags to false.
            var isRead = newAssignment.assignmentEntries.length === 0;
            // Sort and add this to AssignmentList
            newAssignment.assignmentEntries.sort(function (a, b) {
                return a.getDueDateTimestamp - b.getDueDateTimestamp;
            });
            mergedAssignmentList.push(new model_1.Assignment(newAssignment.courseSiteInfo, newAssignment.assignmentEntries, isRead));
        }
        // If this courseID **IS** in oldAssignmentList:
        else {
            // Take over isRead flag
            var isRead = oldAssignmentiList[idx].isRead;
            // Just in case if AssignmentList is empty, set flag to true
            if (newAssignment.assignmentEntries.length === 0)
                isRead = true;
            var mergedAssignmentEntries = [];
            var _loop_2 = function (newAssignmentEntry) {
                // Find if this new assignment is in old AssignmentList
                var oldAssignment = oldAssignmentiList[idx];
                var q = oldAssignment.assignmentEntries.findIndex(function (oldAssignmentEntry) {
                    return oldAssignmentEntry.assignmentID === newAssignmentEntry.assignmentID;
                });
                // If there is same assignmentID, update it.
                if (q === -1) {
                    // Set isRead flag to false since there might be some updates in assignment.
                    isRead = false;
                    mergedAssignmentEntries.push(newAssignmentEntry);
                }
                // If there is not, create a new AssignmentEntry for the course site.
                else {
                    var entry = new model_1.AssignmentEntry(newAssignmentEntry.assignmentID, newAssignmentEntry.assignmentTitle, newAssignmentEntry.dueDateTimestamp, newAssignmentEntry.closeDateTimestamp, newAssignmentEntry.isMemo, oldAssignment.assignmentEntries[q].isFinished, newAssignmentEntry.isQuiz, newAssignmentEntry.assignmentDetail);
                    entry.assignmentPage = newAssignmentEntry.assignmentPage;
                    mergedAssignmentEntries.push(entry);
                }
            };
            for (var _a = 0, _b = newAssignment.assignmentEntries; _a < _b.length; _a++) {
                var newAssignmentEntry = _b[_a];
                _loop_2(newAssignmentEntry);
            }
            // Sort AssignmentList
            mergedAssignmentEntries.sort(function (a, b) {
                return a.getDueDateTimestamp - b.getDueDateTimestamp;
            });
            mergedAssignmentList.push(new model_1.Assignment(newAssignment.courseSiteInfo, mergedAssignmentEntries, isRead));
        }
    };
    // Merge Assignments based on newAssignmentList
    for (var _i = 0, newAssignmentList_1 = newAssignmentList; _i < newAssignmentList_1.length; _i++) {
        var newAssignment = newAssignmentList_1[_i];
        _loop_1(newAssignment);
    }
    return mergedAssignmentList;
}
exports.compareAndMergeAssignmentList = compareAndMergeAssignmentList;
/**
 * Merge Assignments, Quizzes, Memos together.
 * @param {Assignment[]} targetAssignmentList
 * @param {Assignment[]} newAssignmentList
 */
function mergeIntoAssignmentList(targetAssignmentList, newAssignmentList) {
    var mergedAssignmentList = [];
    for (var _i = 0, targetAssignmentList_1 = targetAssignmentList; _i < targetAssignmentList_1.length; _i++) {
        var assignment = targetAssignmentList_1[_i];
        mergedAssignmentList.push(new model_1.Assignment(assignment.courseSiteInfo, assignment.assignmentEntries, assignment.isRead));
    }
    var _loop_3 = function (newAssignment) {
        var idx = targetAssignmentList.findIndex(function (assignment) {
            return newAssignment.courseSiteInfo.courseID === assignment.courseSiteInfo.courseID;
        });
        var mergedAssignment = mergedAssignmentList[idx];
        if (idx !== -1) {
            mergedAssignment.assignmentEntries = mergedAssignment.assignmentEntries.concat(newAssignment.assignmentEntries);
        }
        else {
            mergedAssignmentList.push(new model_1.Assignment(newAssignment.courseSiteInfo, newAssignment.assignmentEntries, true));
        }
    };
    for (var _a = 0, newAssignmentList_2 = newAssignmentList; _a < newAssignmentList_2.length; _a++) {
        var newAssignment = newAssignmentList_2[_a];
        _loop_3(newAssignment);
    }
    return mergedAssignmentList;
}
exports.mergeIntoAssignmentList = mergeIntoAssignmentList;
/**
 * Function for sorting Assignments
 * @param {Assignment[]} assignmentList
 */
function sortAssignmentList(assignmentList) {
    return Array.from(assignmentList).sort(function (a, b) {
        if (a.closestDueDateTimestamp > b.closestDueDateTimestamp)
            return 1;
        if (a.closestDueDateTimestamp < b.closestDueDateTimestamp)
            return -1;
        return 0;
    });
}
exports.sortAssignmentList = sortAssignmentList;
/**
 * Decides whether to use cache
 * @param {number | undefined} fetchedTime
 * @param {number} cacheInterval
 */
function isUsingCache(fetchedTime, cacheInterval) {
    if (fetchedTime)
        return (exports.nowTime - fetchedTime) / 1000 <= cacheInterval;
    else
        return false;
}
exports.isUsingCache = isUsingCache;
/**
 * Generate unique ID
 * @param {string} prefix
 */
function genUniqueID(prefix) {
    return prefix + new Date().getTime().toString(16) + Math.floor(123456 * Math.random()).toString(16);
}
exports.genUniqueID = genUniqueID;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/content_script.ts");
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudF9zY3JpcHQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFDQSxFQUFFLEtBQTREO0FBQzlELEVBQUUsQ0FDc0Q7QUFDeEQsQ0FBQyxzQkFBc0I7O0FBRXZCO0FBQ0EsZ0NBQWdDLFdBQVc7QUFDM0M7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxvQ0FBb0M7QUFDcEM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGVBQWU7QUFDZixjQUFjO0FBQ2QsY0FBYztBQUNkLGdCQUFnQjtBQUNoQixlQUFlO0FBQ2YsZ0JBQWdCO0FBQ2hCLGdCQUFnQjtBQUNoQixnQkFBZ0I7QUFDaEI7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQjtBQUN0QiwyQkFBMkI7O0FBRTNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0MsU0FBUztBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkI7QUFDM0IsMkJBQTJCO0FBQzNCLDJCQUEyQjtBQUMzQiwyQkFBMkIsZ0JBQWdCLE1BQU07QUFDakQsMkJBQTJCO0FBQzNCLDJCQUEyQjtBQUMzQiwyQkFBMkI7O0FBRTNCO0FBQ0Esd0JBQXdCLE9BQU87QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsMERBQTBEO0FBQzFEOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0Esb0RBQW9ELGlCQUFpQjtBQUNyRTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBUSxvQkFBb0I7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLFFBQVE7QUFDUjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsUUFBUTtBQUNSO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsUUFBUSx1Q0FBdUM7QUFDL0M7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsK0NBQStDLGVBQWU7QUFDOUQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsK0NBQStDLGVBQWU7QUFDOUQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE1BQU07QUFDTjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLFVBQVU7QUFDVjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtFQUFrRSxXQUFXLFVBQVUsU0FBUyxLQUFLLG9CQUFvQjtBQUN6SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLCtDQUErQyxlQUFlO0FBQzlEO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBLGtEQUFrRCxpQkFBaUI7QUFDbkU7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBLE1BQU07QUFDTjtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLHdCQUF3QjtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZUFBZSxNQUFNO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQSxDQUFDOzs7Ozs7Ozs7Ozs7QUNud0JZO0FBQ2I7QUFDQSw0QkFBNEIsK0RBQStELGlCQUFpQjtBQUM1RztBQUNBLG9DQUFvQyxNQUFNLCtCQUErQixZQUFZO0FBQ3JGLG1DQUFtQyxNQUFNLG1DQUFtQyxZQUFZO0FBQ3hGLGdDQUFnQztBQUNoQztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsY0FBYyw2QkFBNkIsMEJBQTBCLGNBQWMscUJBQXFCO0FBQ3hHLGlCQUFpQixvREFBb0QscUVBQXFFLGNBQWM7QUFDeEosdUJBQXVCLHNCQUFzQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0M7QUFDeEMsbUNBQW1DLFNBQVM7QUFDNUMsbUNBQW1DLFdBQVcsVUFBVTtBQUN4RCwwQ0FBMEMsY0FBYztBQUN4RDtBQUNBLDhHQUE4RyxPQUFPO0FBQ3JILGlGQUFpRixpQkFBaUI7QUFDbEcseURBQXlELGdCQUFnQixRQUFRO0FBQ2pGLCtDQUErQyxnQkFBZ0IsZ0JBQWdCO0FBQy9FO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQSxVQUFVLFlBQVksYUFBYSxTQUFTLFVBQVU7QUFDdEQsb0NBQW9DLFNBQVM7QUFDN0M7QUFDQTtBQUNBLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RCxrQ0FBa0MsR0FBRyxrQ0FBa0MsR0FBRyw0QkFBNEIsR0FBRyxvQkFBb0I7QUFDN0gsZ0JBQWdCLG1CQUFPLENBQUMsbUNBQVc7QUFDbkMsZ0JBQWdCLG1CQUFPLENBQUMsbUNBQVc7QUFDbkMsa0JBQWtCLG1CQUFPLENBQUMsdUNBQWE7QUFDdkMsa0JBQWtCLG1CQUFPLENBQUMsdUNBQWE7QUFDdkMsY0FBYyxtQkFBTyxDQUFDLCtCQUFTO0FBQy9CLGlCQUFpQixtQkFBTyxDQUFDLHFDQUFZO0FBQ3JDO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxrQkFBa0I7QUFDN0IsV0FBVyxTQUFTO0FBQ3BCLFdBQVcsU0FBUztBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzRUFBc0UsK0JBQStCO0FBQ3JHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9EQUFvRCxzQkFBc0I7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0Isa0NBQWtDO0FBQ3RELG9CQUFvQiw0QkFBNEI7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0VBQXNFLCtCQUErQjtBQUNyRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvREFBb0Qsc0JBQXNCO0FBQzFFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsNEJBQTRCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsNEJBQTRCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLG9CQUFvQjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQiw0QkFBNEI7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBOzs7Ozs7Ozs7Ozs7QUN6TmE7QUFDYiw4Q0FBNkMsRUFBRSxhQUFhLEVBQUM7QUFDN0Qsc0JBQXNCLEdBQUcsaUJBQWlCLEdBQUcsa0JBQWtCLEdBQUcscUJBQXFCLEdBQUcsbUJBQW1CLEdBQUcsaUJBQWlCLEdBQUcscUJBQXFCLEdBQUcsaUJBQWlCO0FBQzdLLHNCQUFzQixtQkFBTyxDQUFDLCtDQUFpQjtBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEIsaUJBQWlCLHVCQUF1QixpQkFBaUI7QUFDekQ7QUFDQSxxQkFBcUIsdUJBQXVCLGdDQUFnQztBQUM1RSxpQkFBaUIsdUJBQXVCLHlCQUF5QixJQUFJLHdDQUF3QztBQUM3RztBQUNBO0FBQ0E7QUFDQSw4Q0FBOEMsMEJBQTBCO0FBQ3hFO0FBQ0Esc0NBQXNDLCtCQUErQjtBQUNyRTtBQUNBLGtEQUFrRCxrQkFBa0I7QUFDcEUsaURBQWlELGdCQUFnQjtBQUNqRSxrREFBa0Qsa0RBQWtEO0FBQ3BHLGlEQUFpRCxtREFBbUQ7QUFDcEcsNENBQTRDLHFDQUFxQztBQUNqRixDQUFDLGtDQUFrQztBQUNuQyxtQkFBbUI7Ozs7Ozs7Ozs7OztBQ25FTjtBQUNiO0FBQ0EsNEJBQTRCLCtEQUErRCxpQkFBaUI7QUFDNUc7QUFDQSxvQ0FBb0MsTUFBTSwrQkFBK0IsWUFBWTtBQUNyRixtQ0FBbUMsTUFBTSxtQ0FBbUMsWUFBWTtBQUN4RixnQ0FBZ0M7QUFDaEM7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLGNBQWMsNkJBQTZCLDBCQUEwQixjQUFjLHFCQUFxQjtBQUN4RyxpQkFBaUIsb0RBQW9ELHFFQUFxRSxjQUFjO0FBQ3hKLHVCQUF1QixzQkFBc0I7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDO0FBQ3hDLG1DQUFtQyxTQUFTO0FBQzVDLG1DQUFtQyxXQUFXLFVBQVU7QUFDeEQsMENBQTBDLGNBQWM7QUFDeEQ7QUFDQSw4R0FBOEcsT0FBTztBQUNySCxpRkFBaUYsaUJBQWlCO0FBQ2xHLHlEQUF5RCxnQkFBZ0IsUUFBUTtBQUNqRiwrQ0FBK0MsZ0JBQWdCLGdCQUFnQjtBQUMvRTtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0EsVUFBVSxZQUFZLGFBQWEsU0FBUyxVQUFVO0FBQ3RELG9DQUFvQyxTQUFTO0FBQzdDO0FBQ0E7QUFDQSw4Q0FBNkMsRUFBRSxhQUFhLEVBQUM7QUFDN0QsNEJBQTRCLEdBQUcsa0JBQWtCLEdBQUcsc0JBQXNCLEdBQUcsZUFBZSxHQUFHLDBCQUEwQixHQUFHLHFCQUFxQixHQUFHLHlCQUF5QixHQUFHLDJCQUEyQixHQUFHLHVCQUF1QjtBQUNyTyxZQUFZLG1CQUFPLENBQUMsMkJBQU87QUFDM0IsZ0JBQWdCLG1CQUFPLENBQUMsbUNBQVc7QUFDbkMsY0FBYyxtQkFBTyxDQUFDLCtCQUFTO0FBQy9CLGNBQWMsbUJBQU8sQ0FBQywrQkFBUztBQUMvQix1QkFBdUIsbUJBQU8sQ0FBQyxpREFBa0I7QUFDakQsaUJBQWlCLG1CQUFPLENBQUMscUNBQVk7QUFDckMsa0JBQWtCLG1CQUFPLENBQUMsdUNBQWE7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvRUFBb0UsOEJBQThCO0FBQ2xHO0FBQ0E7QUFDQSx3RUFBd0UsZ0JBQWdCO0FBQ3hGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhEQUE4RCx5QkFBeUI7QUFDdkY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0Esc0JBQXNCO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELHdCQUF3QjtBQUNoRjtBQUNBO0FBQ0Esa0VBQWtFLGdCQUFnQjtBQUNsRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdFQUFnRSw0QkFBNEI7QUFDNUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxzQkFBc0I7QUFDMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSw0QkFBNEI7QUFDNUI7QUFDQTtBQUNBLFdBQVcsa0JBQWtCO0FBQzdCLFdBQVcsU0FBUztBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDelphO0FBQ2IsOENBQTZDLEVBQUUsYUFBYSxFQUFDO0FBQzdELCtCQUErQjtBQUMvQixzQkFBc0IsbUJBQU8sQ0FBQywrQ0FBaUI7QUFDL0M7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsMEJBQTBCO0FBQ3BELEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2QyxnQkFBZ0I7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELG1CQUFtQjtBQUMzRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0REFBNEQsbUJBQW1CO0FBQy9FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUVBQXFFLGdCQUFnQjtBQUNyRjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLEtBQUs7QUFDTDtBQUNBLCtCQUErQjs7Ozs7Ozs7Ozs7O0FDekdsQjtBQUNiO0FBQ0EsNEJBQTRCLCtEQUErRCxpQkFBaUI7QUFDNUc7QUFDQSxvQ0FBb0MsTUFBTSwrQkFBK0IsWUFBWTtBQUNyRixtQ0FBbUMsTUFBTSxtQ0FBbUMsWUFBWTtBQUN4RixnQ0FBZ0M7QUFDaEM7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLGNBQWMsNkJBQTZCLDBCQUEwQixjQUFjLHFCQUFxQjtBQUN4RyxpQkFBaUIsb0RBQW9ELHFFQUFxRSxjQUFjO0FBQ3hKLHVCQUF1QixzQkFBc0I7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDO0FBQ3hDLG1DQUFtQyxTQUFTO0FBQzVDLG1DQUFtQyxXQUFXLFVBQVU7QUFDeEQsMENBQTBDLGNBQWM7QUFDeEQ7QUFDQSw4R0FBOEcsT0FBTztBQUNySCxpRkFBaUYsaUJBQWlCO0FBQ2xHLHlEQUF5RCxnQkFBZ0IsUUFBUTtBQUNqRiwrQ0FBK0MsZ0JBQWdCLGdCQUFnQjtBQUMvRTtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0EsVUFBVSxZQUFZLGFBQWEsU0FBUyxVQUFVO0FBQ3RELG9DQUFvQyxTQUFTO0FBQzdDO0FBQ0E7QUFDQTtBQUNBLDZDQUE2QztBQUM3QztBQUNBLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RCxzQ0FBc0MsR0FBRyxzQ0FBc0MsR0FBRyx3QkFBd0IsR0FBRyx1QkFBdUIsR0FBRywwQkFBMEIsR0FBRyxrQ0FBa0M7QUFDdE0sY0FBYyxtQkFBTyxDQUFDLCtCQUFTO0FBQy9CLGNBQWMsbUJBQU8sQ0FBQywrQkFBUztBQUMvQixZQUFZLG1CQUFPLENBQUMsMkJBQU87QUFDM0Isc0JBQXNCLG1CQUFPLENBQUMsK0NBQWlCO0FBQy9DO0FBQ0EsaUNBQWlDLG1CQUFPLENBQUMscURBQVU7QUFDbkQsaUJBQWlCLG1CQUFPLENBQUMscUNBQVk7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwRkFBMEYsc0JBQXNCO0FBQ2hIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUM7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0EsMkRBQTJEO0FBQzNEO0FBQ0E7QUFDQTtBQUNBLDJEQUEyRCxtRUFBbUUsaUNBQWlDO0FBQy9KO0FBQ0E7QUFDQSwyREFBMkQsbUVBQW1FLCtCQUErQjtBQUM3SjtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3RUFBd0UsOEJBQThCO0FBQ3RHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0EsK0NBQStDLG9CQUFvQjtBQUNuRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5RUFBeUUsd0JBQXdCLElBQUksMkJBQTJCLGlEQUFpRDtBQUNqTDtBQUNBO0FBQ0Esd0VBQXdFLHNCQUFzQixJQUFJLDJCQUEyQixrREFBa0Q7QUFDL0s7QUFDQTtBQUNBO0FBQ0EsNEVBQTRFLHNCQUFzQixJQUFJLDBCQUEwQixpREFBaUQ7QUFDakw7QUFDQTtBQUNBLDZFQUE2RSxzQkFBc0IsSUFBSSwyQkFBMkIsa0RBQWtEO0FBQ3BMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnSUFBZ0ksK0NBQStDO0FBQy9LLDhIQUE4SCw2Q0FBNkM7QUFDM0ssaUVBQWlFLG1EQUFtRCwrQ0FBK0MsSUFBSTtBQUN2Syw0SEFBNEgsMkNBQTJDO0FBQ3ZLLGtJQUFrSSx5Q0FBeUM7QUFDM0ssMkhBQTJILG1DQUFtQztBQUM5SixxRUFBcUUsa0RBQWtELHVDQUF1QyxJQUFJO0FBQ2xLO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLHdCQUF3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNFQUFzRSwrQkFBK0I7QUFDckc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELGVBQWU7QUFDdkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdEQUF3RCxlQUFlO0FBQ3ZFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3REFBd0QsZUFBZTtBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELGVBQWU7QUFDdkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLHFCQUFxQjtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLHNDQUFzQztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOENBQThDLHlCQUF5QjtBQUN2RTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MsaUJBQWlCO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxvQkFBb0I7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0Msb0JBQW9CO0FBQzVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDs7Ozs7Ozs7Ozs7O0FDdGVhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsZUFBZSxnQkFBZ0Isc0NBQXNDLGtCQUFrQjtBQUN2Riw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCO0FBQ3hCO0FBQ0E7QUFDQSxDQUFDO0FBQ0QsOENBQTZDLEVBQUUsYUFBYSxFQUFDO0FBQzdELHlCQUF5QixHQUFHLDhCQUE4QixHQUFHLHNCQUFzQixHQUFHLGtCQUFrQixHQUFHLHVCQUF1QjtBQUNsSSxjQUFjLG1CQUFPLENBQUMsK0JBQVM7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLENBQUM7QUFDRCx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBEQUEwRCxnQkFBZ0I7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMERBQTBELGdCQUFnQjtBQUMxRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxzREFBc0QsZ0JBQWdCO0FBQ3RFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNELGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Qsc0JBQXNCO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxDQUFDO0FBQ0QsOEJBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNELHlCQUF5Qjs7Ozs7Ozs7Ozs7O0FDdExaO0FBQ2I7QUFDQSw0QkFBNEIsK0RBQStELGlCQUFpQjtBQUM1RztBQUNBLG9DQUFvQyxNQUFNLCtCQUErQixZQUFZO0FBQ3JGLG1DQUFtQyxNQUFNLG1DQUFtQyxZQUFZO0FBQ3hGLGdDQUFnQztBQUNoQztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsY0FBYyw2QkFBNkIsMEJBQTBCLGNBQWMscUJBQXFCO0FBQ3hHLGlCQUFpQixvREFBb0QscUVBQXFFLGNBQWM7QUFDeEosdUJBQXVCLHNCQUFzQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0M7QUFDeEMsbUNBQW1DLFNBQVM7QUFDNUMsbUNBQW1DLFdBQVcsVUFBVTtBQUN4RCwwQ0FBMEMsY0FBYztBQUN4RDtBQUNBLDhHQUE4RyxPQUFPO0FBQ3JILGlGQUFpRixpQkFBaUI7QUFDbEcseURBQXlELGdCQUFnQixRQUFRO0FBQ2pGLCtDQUErQyxnQkFBZ0IsZ0JBQWdCO0FBQy9FO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQSxVQUFVLFlBQVksYUFBYSxTQUFTLFVBQVU7QUFDdEQsb0NBQW9DLFNBQVM7QUFDN0M7QUFDQTtBQUNBLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RCwyQkFBMkIsR0FBRywrQkFBK0IsR0FBRyx1QkFBdUIsR0FBRyxrQkFBa0I7QUFDNUcsY0FBYyxtQkFBTyxDQUFDLCtCQUFTO0FBQy9CLGNBQWMsbUJBQU8sQ0FBQywrQkFBUztBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNENBQTRDLHdCQUF3QjtBQUNwRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQixtQkFBbUI7QUFDN0Msd0NBQXdDO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUyxJQUFJO0FBQ2Isb0NBQW9DLDRCQUE0QixHQUFHO0FBQ25FLEtBQUs7QUFDTDtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CLFdBQVcsUUFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCLG1CQUFtQjtBQUM3Qyx3Q0FBd0M7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTLElBQUk7QUFDYixvQ0FBb0MsNEJBQTRCLEdBQUc7QUFDbkUsS0FBSztBQUNMO0FBQ0EsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyw4REFBOEQ7QUFDaEc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyx1R0FBdUc7QUFDekk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7Ozs7Ozs7Ozs7O0FDckxhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsZUFBZSxnQkFBZ0Isc0NBQXNDLGtCQUFrQjtBQUN2Riw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCO0FBQ3hCO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQSw0QkFBNEIsK0RBQStELGlCQUFpQjtBQUM1RztBQUNBLG9DQUFvQyxNQUFNLCtCQUErQixZQUFZO0FBQ3JGLG1DQUFtQyxNQUFNLG1DQUFtQyxZQUFZO0FBQ3hGLGdDQUFnQztBQUNoQztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsY0FBYyw2QkFBNkIsMEJBQTBCLGNBQWMscUJBQXFCO0FBQ3hHLGlCQUFpQixvREFBb0QscUVBQXFFLGNBQWM7QUFDeEosdUJBQXVCLHNCQUFzQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0M7QUFDeEMsbUNBQW1DLFNBQVM7QUFDNUMsbUNBQW1DLFdBQVcsVUFBVTtBQUN4RCwwQ0FBMEMsY0FBYztBQUN4RDtBQUNBLDhHQUE4RyxPQUFPO0FBQ3JILGlGQUFpRixpQkFBaUI7QUFDbEcseURBQXlELGdCQUFnQixRQUFRO0FBQ2pGLCtDQUErQyxnQkFBZ0IsZ0JBQWdCO0FBQy9FO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQSxVQUFVLFlBQVksYUFBYSxTQUFTLFVBQVU7QUFDdEQsb0NBQW9DLFNBQVM7QUFDN0M7QUFDQTtBQUNBLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RCxtQkFBbUIsR0FBRyxvQkFBb0IsR0FBRyx1QkFBdUIsR0FBRyxnQkFBZ0I7QUFDdkYsZ0JBQWdCLG1CQUFPLENBQUMsbUNBQVc7QUFDbkMsY0FBYyxtQkFBTyxDQUFDLCtCQUFTO0FBQy9CLGdCQUFnQixtQkFBTyxDQUFDLG1DQUFXO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLENBQUM7QUFDRCxnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0QsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSxvQkFBb0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QjtBQUM3Qix5QkFBeUI7QUFDekI7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0EsbUJBQW1COzs7Ozs7Ozs7Ozs7QUNwTk47QUFDYiw4Q0FBNkMsRUFBRSxhQUFhLEVBQUM7QUFDN0QsZUFBZSxHQUFHLDBCQUEwQixHQUFHLDZCQUE2QixHQUFHLDRCQUE0QjtBQUMzRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkI7QUFDQTtBQUNBLHNDQUFzQztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLDRCQUE0QjtBQUM1QjtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkIsV0FBVyxRQUFRO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSw2QkFBNkI7QUFDN0I7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLEtBQUs7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkNBQTZDO0FBQzdDO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSwwQkFBMEI7Ozs7Ozs7Ozs7OztBQ3hGYjtBQUNiLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RCwwQkFBMEIsR0FBRywrQkFBK0IsR0FBRyxtQkFBbUIsR0FBRyxvQkFBb0IsR0FBRyxxQ0FBcUMsR0FBRyxnQ0FBZ0MsR0FBRyw4QkFBOEIsR0FBRyxzQkFBc0IsR0FBRyxrQkFBa0IsR0FBRyx1QkFBdUIsR0FBRyx5QkFBeUIsR0FBRyxvQkFBb0IsR0FBRyx3QkFBd0IsR0FBRyx1QkFBdUIsR0FBRyxpQ0FBaUMsR0FBRyxlQUFlO0FBQzNiLGNBQWMsbUJBQU8sQ0FBQywrQkFBUztBQUMvQixpQkFBaUIsbUJBQU8sQ0FBQyxxQ0FBWTtBQUNyQyxlQUFlO0FBQ2Y7QUFDQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0I7QUFDcEI7QUFDQTtBQUNBLFdBQVcsb0JBQW9CO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBLFdBQVcsa0JBQWtCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBLDBEQUEwRCwrQkFBK0I7QUFDekY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQyx1QkFBdUI7QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0EsV0FBVyxjQUFjO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDREQUE0RCw4QkFBOEI7QUFDMUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCO0FBQ3RCO0FBQ0E7QUFDQSxXQUFXLEtBQUs7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCO0FBQzlCO0FBQ0E7QUFDQSxXQUFXLEtBQUs7QUFDaEI7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDLG1CQUFtQjtBQUNyRDtBQUNBO0FBQ0EsbURBQW1ELGdCQUFnQjtBQUNuRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQztBQUNoQztBQUNBO0FBQ0EsV0FBVyxjQUFjO0FBQ3pCLFdBQVcsY0FBYztBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUVBQW1FLGdCQUFnQjtBQUNuRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4REFBOEQsaUNBQWlDO0FBQy9GO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUM7QUFDckM7QUFDQTtBQUNBLFdBQVcsY0FBYztBQUN6QixXQUFXLGNBQWM7QUFDekI7QUFDQTtBQUNBO0FBQ0Esb0VBQW9FLG9DQUFvQztBQUN4RztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhEQUE4RCxpQ0FBaUM7QUFDL0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0EsV0FBVyxjQUFjO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBLFdBQVcsb0JBQW9CO0FBQy9CLFdBQVcsUUFBUTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQjtBQUNwQjtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1COzs7Ozs7O1VDaFRuQjtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOzs7O1VFdEJBO1VBQ0E7VUFDQTtVQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY29tZm9ydGFibGUtcGFuZGEvLi9ub2RlX21vZHVsZXMvbXVzdGFjaGUvbXVzdGFjaGUuanMiLCJ3ZWJwYWNrOi8vY29tZm9ydGFibGUtcGFuZGEvLi9zcmMvY29udGVudF9zY3JpcHQudHMiLCJ3ZWJwYWNrOi8vY29tZm9ydGFibGUtcGFuZGEvLi9zcmMvZG9tLnRzIiwid2VicGFjazovL2NvbWZvcnRhYmxlLXBhbmRhLy4vc3JjL2V2ZW50TGlzdGVuZXIudHMiLCJ3ZWJwYWNrOi8vY29tZm9ydGFibGUtcGFuZGEvLi9zcmMvZmF2b3JpdGVzLnRzIiwid2VicGFjazovL2NvbWZvcnRhYmxlLXBhbmRhLy4vc3JjL21pbmlzYWthaS50cyIsIndlYnBhY2s6Ly9jb21mb3J0YWJsZS1wYW5kYS8uL3NyYy9tb2RlbC50cyIsIndlYnBhY2s6Ly9jb21mb3J0YWJsZS1wYW5kYS8uL3NyYy9uZXR3b3JrLnRzIiwid2VicGFjazovL2NvbWZvcnRhYmxlLXBhbmRhLy4vc3JjL3NldHRpbmdzLnRzIiwid2VicGFjazovL2NvbWZvcnRhYmxlLXBhbmRhLy4vc3JjL3N0b3JhZ2UudHMiLCJ3ZWJwYWNrOi8vY29tZm9ydGFibGUtcGFuZGEvLi9zcmMvdXRpbHMudHMiLCJ3ZWJwYWNrOi8vY29tZm9ydGFibGUtcGFuZGEvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vY29tZm9ydGFibGUtcGFuZGEvd2VicGFjay9iZWZvcmUtc3RhcnR1cCIsIndlYnBhY2s6Ly9jb21mb3J0YWJsZS1wYW5kYS93ZWJwYWNrL3N0YXJ0dXAiLCJ3ZWJwYWNrOi8vY29tZm9ydGFibGUtcGFuZGEvd2VicGFjay9hZnRlci1zdGFydHVwIl0sInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiAoZ2xvYmFsLCBmYWN0b3J5KSB7XG4gIHR5cGVvZiBleHBvcnRzID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgbW9kdWxlICE9PSAndW5kZWZpbmVkJyA/IG1vZHVsZS5leHBvcnRzID0gZmFjdG9yeSgpIDpcbiAgdHlwZW9mIGRlZmluZSA9PT0gJ2Z1bmN0aW9uJyAmJiBkZWZpbmUuYW1kID8gZGVmaW5lKGZhY3RvcnkpIDpcbiAgKGdsb2JhbCA9IGdsb2JhbCB8fCBzZWxmLCBnbG9iYWwuTXVzdGFjaGUgPSBmYWN0b3J5KCkpO1xufSh0aGlzLCAoZnVuY3Rpb24gKCkgeyAndXNlIHN0cmljdCc7XG5cbiAgLyohXG4gICAqIG11c3RhY2hlLmpzIC0gTG9naWMtbGVzcyB7e211c3RhY2hlfX0gdGVtcGxhdGVzIHdpdGggSmF2YVNjcmlwdFxuICAgKiBodHRwOi8vZ2l0aHViLmNvbS9qYW5sL211c3RhY2hlLmpzXG4gICAqL1xuXG4gIHZhciBvYmplY3RUb1N0cmluZyA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmc7XG4gIHZhciBpc0FycmF5ID0gQXJyYXkuaXNBcnJheSB8fCBmdW5jdGlvbiBpc0FycmF5UG9seWZpbGwgKG9iamVjdCkge1xuICAgIHJldHVybiBvYmplY3RUb1N0cmluZy5jYWxsKG9iamVjdCkgPT09ICdbb2JqZWN0IEFycmF5XSc7XG4gIH07XG5cbiAgZnVuY3Rpb24gaXNGdW5jdGlvbiAob2JqZWN0KSB7XG4gICAgcmV0dXJuIHR5cGVvZiBvYmplY3QgPT09ICdmdW5jdGlvbic7XG4gIH1cblxuICAvKipcbiAgICogTW9yZSBjb3JyZWN0IHR5cGVvZiBzdHJpbmcgaGFuZGxpbmcgYXJyYXlcbiAgICogd2hpY2ggbm9ybWFsbHkgcmV0dXJucyB0eXBlb2YgJ29iamVjdCdcbiAgICovXG4gIGZ1bmN0aW9uIHR5cGVTdHIgKG9iaikge1xuICAgIHJldHVybiBpc0FycmF5KG9iaikgPyAnYXJyYXknIDogdHlwZW9mIG9iajtcbiAgfVxuXG4gIGZ1bmN0aW9uIGVzY2FwZVJlZ0V4cCAoc3RyaW5nKSB7XG4gICAgcmV0dXJuIHN0cmluZy5yZXBsYWNlKC9bXFwtXFxbXFxde30oKSorPy4sXFxcXFxcXiR8I1xcc10vZywgJ1xcXFwkJicpO1xuICB9XG5cbiAgLyoqXG4gICAqIE51bGwgc2FmZSB3YXkgb2YgY2hlY2tpbmcgd2hldGhlciBvciBub3QgYW4gb2JqZWN0LFxuICAgKiBpbmNsdWRpbmcgaXRzIHByb3RvdHlwZSwgaGFzIGEgZ2l2ZW4gcHJvcGVydHlcbiAgICovXG4gIGZ1bmN0aW9uIGhhc1Byb3BlcnR5IChvYmosIHByb3BOYW1lKSB7XG4gICAgcmV0dXJuIG9iaiAhPSBudWxsICYmIHR5cGVvZiBvYmogPT09ICdvYmplY3QnICYmIChwcm9wTmFtZSBpbiBvYmopO1xuICB9XG5cbiAgLyoqXG4gICAqIFNhZmUgd2F5IG9mIGRldGVjdGluZyB3aGV0aGVyIG9yIG5vdCB0aGUgZ2l2ZW4gdGhpbmcgaXMgYSBwcmltaXRpdmUgYW5kXG4gICAqIHdoZXRoZXIgaXQgaGFzIHRoZSBnaXZlbiBwcm9wZXJ0eVxuICAgKi9cbiAgZnVuY3Rpb24gcHJpbWl0aXZlSGFzT3duUHJvcGVydHkgKHByaW1pdGl2ZSwgcHJvcE5hbWUpIHtcbiAgICByZXR1cm4gKFxuICAgICAgcHJpbWl0aXZlICE9IG51bGxcbiAgICAgICYmIHR5cGVvZiBwcmltaXRpdmUgIT09ICdvYmplY3QnXG4gICAgICAmJiBwcmltaXRpdmUuaGFzT3duUHJvcGVydHlcbiAgICAgICYmIHByaW1pdGl2ZS5oYXNPd25Qcm9wZXJ0eShwcm9wTmFtZSlcbiAgICApO1xuICB9XG5cbiAgLy8gV29ya2Fyb3VuZCBmb3IgaHR0cHM6Ly9pc3N1ZXMuYXBhY2hlLm9yZy9qaXJhL2Jyb3dzZS9DT1VDSERCLTU3N1xuICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL2phbmwvbXVzdGFjaGUuanMvaXNzdWVzLzE4OVxuICB2YXIgcmVnRXhwVGVzdCA9IFJlZ0V4cC5wcm90b3R5cGUudGVzdDtcbiAgZnVuY3Rpb24gdGVzdFJlZ0V4cCAocmUsIHN0cmluZykge1xuICAgIHJldHVybiByZWdFeHBUZXN0LmNhbGwocmUsIHN0cmluZyk7XG4gIH1cblxuICB2YXIgbm9uU3BhY2VSZSA9IC9cXFMvO1xuICBmdW5jdGlvbiBpc1doaXRlc3BhY2UgKHN0cmluZykge1xuICAgIHJldHVybiAhdGVzdFJlZ0V4cChub25TcGFjZVJlLCBzdHJpbmcpO1xuICB9XG5cbiAgdmFyIGVudGl0eU1hcCA9IHtcbiAgICAnJic6ICcmYW1wOycsXG4gICAgJzwnOiAnJmx0OycsXG4gICAgJz4nOiAnJmd0OycsXG4gICAgJ1wiJzogJyZxdW90OycsXG4gICAgXCInXCI6ICcmIzM5OycsXG4gICAgJy8nOiAnJiN4MkY7JyxcbiAgICAnYCc6ICcmI3g2MDsnLFxuICAgICc9JzogJyYjeDNEOydcbiAgfTtcblxuICBmdW5jdGlvbiBlc2NhcGVIdG1sIChzdHJpbmcpIHtcbiAgICByZXR1cm4gU3RyaW5nKHN0cmluZykucmVwbGFjZSgvWyY8PlwiJ2A9XFwvXS9nLCBmdW5jdGlvbiBmcm9tRW50aXR5TWFwIChzKSB7XG4gICAgICByZXR1cm4gZW50aXR5TWFwW3NdO1xuICAgIH0pO1xuICB9XG5cbiAgdmFyIHdoaXRlUmUgPSAvXFxzKi87XG4gIHZhciBzcGFjZVJlID0gL1xccysvO1xuICB2YXIgZXF1YWxzUmUgPSAvXFxzKj0vO1xuICB2YXIgY3VybHlSZSA9IC9cXHMqXFx9LztcbiAgdmFyIHRhZ1JlID0gLyN8XFxefFxcL3w+fFxce3wmfD18IS87XG5cbiAgLyoqXG4gICAqIEJyZWFrcyB1cCB0aGUgZ2l2ZW4gYHRlbXBsYXRlYCBzdHJpbmcgaW50byBhIHRyZWUgb2YgdG9rZW5zLiBJZiB0aGUgYHRhZ3NgXG4gICAqIGFyZ3VtZW50IGlzIGdpdmVuIGhlcmUgaXQgbXVzdCBiZSBhbiBhcnJheSB3aXRoIHR3byBzdHJpbmcgdmFsdWVzOiB0aGVcbiAgICogb3BlbmluZyBhbmQgY2xvc2luZyB0YWdzIHVzZWQgaW4gdGhlIHRlbXBsYXRlIChlLmcuIFsgXCI8JVwiLCBcIiU+XCIgXSkuIE9mXG4gICAqIGNvdXJzZSwgdGhlIGRlZmF1bHQgaXMgdG8gdXNlIG11c3RhY2hlcyAoaS5lLiBtdXN0YWNoZS50YWdzKS5cbiAgICpcbiAgICogQSB0b2tlbiBpcyBhbiBhcnJheSB3aXRoIGF0IGxlYXN0IDQgZWxlbWVudHMuIFRoZSBmaXJzdCBlbGVtZW50IGlzIHRoZVxuICAgKiBtdXN0YWNoZSBzeW1ib2wgdGhhdCB3YXMgdXNlZCBpbnNpZGUgdGhlIHRhZywgZS5nLiBcIiNcIiBvciBcIiZcIi4gSWYgdGhlIHRhZ1xuICAgKiBkaWQgbm90IGNvbnRhaW4gYSBzeW1ib2wgKGkuZS4ge3tteVZhbHVlfX0pIHRoaXMgZWxlbWVudCBpcyBcIm5hbWVcIi4gRm9yXG4gICAqIGFsbCB0ZXh0IHRoYXQgYXBwZWFycyBvdXRzaWRlIGEgc3ltYm9sIHRoaXMgZWxlbWVudCBpcyBcInRleHRcIi5cbiAgICpcbiAgICogVGhlIHNlY29uZCBlbGVtZW50IG9mIGEgdG9rZW4gaXMgaXRzIFwidmFsdWVcIi4gRm9yIG11c3RhY2hlIHRhZ3MgdGhpcyBpc1xuICAgKiB3aGF0ZXZlciBlbHNlIHdhcyBpbnNpZGUgdGhlIHRhZyBiZXNpZGVzIHRoZSBvcGVuaW5nIHN5bWJvbC4gRm9yIHRleHQgdG9rZW5zXG4gICAqIHRoaXMgaXMgdGhlIHRleHQgaXRzZWxmLlxuICAgKlxuICAgKiBUaGUgdGhpcmQgYW5kIGZvdXJ0aCBlbGVtZW50cyBvZiB0aGUgdG9rZW4gYXJlIHRoZSBzdGFydCBhbmQgZW5kIGluZGljZXMsXG4gICAqIHJlc3BlY3RpdmVseSwgb2YgdGhlIHRva2VuIGluIHRoZSBvcmlnaW5hbCB0ZW1wbGF0ZS5cbiAgICpcbiAgICogVG9rZW5zIHRoYXQgYXJlIHRoZSByb290IG5vZGUgb2YgYSBzdWJ0cmVlIGNvbnRhaW4gdHdvIG1vcmUgZWxlbWVudHM6IDEpIGFuXG4gICAqIGFycmF5IG9mIHRva2VucyBpbiB0aGUgc3VidHJlZSBhbmQgMikgdGhlIGluZGV4IGluIHRoZSBvcmlnaW5hbCB0ZW1wbGF0ZSBhdFxuICAgKiB3aGljaCB0aGUgY2xvc2luZyB0YWcgZm9yIHRoYXQgc2VjdGlvbiBiZWdpbnMuXG4gICAqXG4gICAqIFRva2VucyBmb3IgcGFydGlhbHMgYWxzbyBjb250YWluIHR3byBtb3JlIGVsZW1lbnRzOiAxKSBhIHN0cmluZyB2YWx1ZSBvZlxuICAgKiBpbmRlbmRhdGlvbiBwcmlvciB0byB0aGF0IHRhZyBhbmQgMikgdGhlIGluZGV4IG9mIHRoYXQgdGFnIG9uIHRoYXQgbGluZSAtXG4gICAqIGVnIGEgdmFsdWUgb2YgMiBpbmRpY2F0ZXMgdGhlIHBhcnRpYWwgaXMgdGhlIHRoaXJkIHRhZyBvbiB0aGlzIGxpbmUuXG4gICAqL1xuICBmdW5jdGlvbiBwYXJzZVRlbXBsYXRlICh0ZW1wbGF0ZSwgdGFncykge1xuICAgIGlmICghdGVtcGxhdGUpXG4gICAgICByZXR1cm4gW107XG4gICAgdmFyIGxpbmVIYXNOb25TcGFjZSA9IGZhbHNlO1xuICAgIHZhciBzZWN0aW9ucyA9IFtdOyAgICAgLy8gU3RhY2sgdG8gaG9sZCBzZWN0aW9uIHRva2Vuc1xuICAgIHZhciB0b2tlbnMgPSBbXTsgICAgICAgLy8gQnVmZmVyIHRvIGhvbGQgdGhlIHRva2Vuc1xuICAgIHZhciBzcGFjZXMgPSBbXTsgICAgICAgLy8gSW5kaWNlcyBvZiB3aGl0ZXNwYWNlIHRva2VucyBvbiB0aGUgY3VycmVudCBsaW5lXG4gICAgdmFyIGhhc1RhZyA9IGZhbHNlOyAgICAvLyBJcyB0aGVyZSBhIHt7dGFnfX0gb24gdGhlIGN1cnJlbnQgbGluZT9cbiAgICB2YXIgbm9uU3BhY2UgPSBmYWxzZTsgIC8vIElzIHRoZXJlIGEgbm9uLXNwYWNlIGNoYXIgb24gdGhlIGN1cnJlbnQgbGluZT9cbiAgICB2YXIgaW5kZW50YXRpb24gPSAnJzsgIC8vIFRyYWNrcyBpbmRlbnRhdGlvbiBmb3IgdGFncyB0aGF0IHVzZSBpdFxuICAgIHZhciB0YWdJbmRleCA9IDA7ICAgICAgLy8gU3RvcmVzIGEgY291bnQgb2YgbnVtYmVyIG9mIHRhZ3MgZW5jb3VudGVyZWQgb24gYSBsaW5lXG5cbiAgICAvLyBTdHJpcHMgYWxsIHdoaXRlc3BhY2UgdG9rZW5zIGFycmF5IGZvciB0aGUgY3VycmVudCBsaW5lXG4gICAgLy8gaWYgdGhlcmUgd2FzIGEge3sjdGFnfX0gb24gaXQgYW5kIG90aGVyd2lzZSBvbmx5IHNwYWNlLlxuICAgIGZ1bmN0aW9uIHN0cmlwU3BhY2UgKCkge1xuICAgICAgaWYgKGhhc1RhZyAmJiAhbm9uU3BhY2UpIHtcbiAgICAgICAgd2hpbGUgKHNwYWNlcy5sZW5ndGgpXG4gICAgICAgICAgZGVsZXRlIHRva2Vuc1tzcGFjZXMucG9wKCldO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3BhY2VzID0gW107XG4gICAgICB9XG5cbiAgICAgIGhhc1RhZyA9IGZhbHNlO1xuICAgICAgbm9uU3BhY2UgPSBmYWxzZTtcbiAgICB9XG5cbiAgICB2YXIgb3BlbmluZ1RhZ1JlLCBjbG9zaW5nVGFnUmUsIGNsb3NpbmdDdXJseVJlO1xuICAgIGZ1bmN0aW9uIGNvbXBpbGVUYWdzICh0YWdzVG9Db21waWxlKSB7XG4gICAgICBpZiAodHlwZW9mIHRhZ3NUb0NvbXBpbGUgPT09ICdzdHJpbmcnKVxuICAgICAgICB0YWdzVG9Db21waWxlID0gdGFnc1RvQ29tcGlsZS5zcGxpdChzcGFjZVJlLCAyKTtcblxuICAgICAgaWYgKCFpc0FycmF5KHRhZ3NUb0NvbXBpbGUpIHx8IHRhZ3NUb0NvbXBpbGUubGVuZ3RoICE9PSAyKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgdGFnczogJyArIHRhZ3NUb0NvbXBpbGUpO1xuXG4gICAgICBvcGVuaW5nVGFnUmUgPSBuZXcgUmVnRXhwKGVzY2FwZVJlZ0V4cCh0YWdzVG9Db21waWxlWzBdKSArICdcXFxccyonKTtcbiAgICAgIGNsb3NpbmdUYWdSZSA9IG5ldyBSZWdFeHAoJ1xcXFxzKicgKyBlc2NhcGVSZWdFeHAodGFnc1RvQ29tcGlsZVsxXSkpO1xuICAgICAgY2xvc2luZ0N1cmx5UmUgPSBuZXcgUmVnRXhwKCdcXFxccyonICsgZXNjYXBlUmVnRXhwKCd9JyArIHRhZ3NUb0NvbXBpbGVbMV0pKTtcbiAgICB9XG5cbiAgICBjb21waWxlVGFncyh0YWdzIHx8IG11c3RhY2hlLnRhZ3MpO1xuXG4gICAgdmFyIHNjYW5uZXIgPSBuZXcgU2Nhbm5lcih0ZW1wbGF0ZSk7XG5cbiAgICB2YXIgc3RhcnQsIHR5cGUsIHZhbHVlLCBjaHIsIHRva2VuLCBvcGVuU2VjdGlvbjtcbiAgICB3aGlsZSAoIXNjYW5uZXIuZW9zKCkpIHtcbiAgICAgIHN0YXJ0ID0gc2Nhbm5lci5wb3M7XG5cbiAgICAgIC8vIE1hdGNoIGFueSB0ZXh0IGJldHdlZW4gdGFncy5cbiAgICAgIHZhbHVlID0gc2Nhbm5lci5zY2FuVW50aWwob3BlbmluZ1RhZ1JlKTtcblxuICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgIGZvciAodmFyIGkgPSAwLCB2YWx1ZUxlbmd0aCA9IHZhbHVlLmxlbmd0aDsgaSA8IHZhbHVlTGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICBjaHIgPSB2YWx1ZS5jaGFyQXQoaSk7XG5cbiAgICAgICAgICBpZiAoaXNXaGl0ZXNwYWNlKGNocikpIHtcbiAgICAgICAgICAgIHNwYWNlcy5wdXNoKHRva2Vucy5sZW5ndGgpO1xuICAgICAgICAgICAgaW5kZW50YXRpb24gKz0gY2hyO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBub25TcGFjZSA9IHRydWU7XG4gICAgICAgICAgICBsaW5lSGFzTm9uU3BhY2UgPSB0cnVlO1xuICAgICAgICAgICAgaW5kZW50YXRpb24gKz0gJyAnO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHRva2Vucy5wdXNoKFsgJ3RleHQnLCBjaHIsIHN0YXJ0LCBzdGFydCArIDEgXSk7XG4gICAgICAgICAgc3RhcnQgKz0gMTtcblxuICAgICAgICAgIC8vIENoZWNrIGZvciB3aGl0ZXNwYWNlIG9uIHRoZSBjdXJyZW50IGxpbmUuXG4gICAgICAgICAgaWYgKGNociA9PT0gJ1xcbicpIHtcbiAgICAgICAgICAgIHN0cmlwU3BhY2UoKTtcbiAgICAgICAgICAgIGluZGVudGF0aW9uID0gJyc7XG4gICAgICAgICAgICB0YWdJbmRleCA9IDA7XG4gICAgICAgICAgICBsaW5lSGFzTm9uU3BhY2UgPSBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gTWF0Y2ggdGhlIG9wZW5pbmcgdGFnLlxuICAgICAgaWYgKCFzY2FubmVyLnNjYW4ob3BlbmluZ1RhZ1JlKSlcbiAgICAgICAgYnJlYWs7XG5cbiAgICAgIGhhc1RhZyA9IHRydWU7XG5cbiAgICAgIC8vIEdldCB0aGUgdGFnIHR5cGUuXG4gICAgICB0eXBlID0gc2Nhbm5lci5zY2FuKHRhZ1JlKSB8fCAnbmFtZSc7XG4gICAgICBzY2FubmVyLnNjYW4od2hpdGVSZSk7XG5cbiAgICAgIC8vIEdldCB0aGUgdGFnIHZhbHVlLlxuICAgICAgaWYgKHR5cGUgPT09ICc9Jykge1xuICAgICAgICB2YWx1ZSA9IHNjYW5uZXIuc2NhblVudGlsKGVxdWFsc1JlKTtcbiAgICAgICAgc2Nhbm5lci5zY2FuKGVxdWFsc1JlKTtcbiAgICAgICAgc2Nhbm5lci5zY2FuVW50aWwoY2xvc2luZ1RhZ1JlKTtcbiAgICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ3snKSB7XG4gICAgICAgIHZhbHVlID0gc2Nhbm5lci5zY2FuVW50aWwoY2xvc2luZ0N1cmx5UmUpO1xuICAgICAgICBzY2FubmVyLnNjYW4oY3VybHlSZSk7XG4gICAgICAgIHNjYW5uZXIuc2NhblVudGlsKGNsb3NpbmdUYWdSZSk7XG4gICAgICAgIHR5cGUgPSAnJic7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YWx1ZSA9IHNjYW5uZXIuc2NhblVudGlsKGNsb3NpbmdUYWdSZSk7XG4gICAgICB9XG5cbiAgICAgIC8vIE1hdGNoIHRoZSBjbG9zaW5nIHRhZy5cbiAgICAgIGlmICghc2Nhbm5lci5zY2FuKGNsb3NpbmdUYWdSZSkpXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignVW5jbG9zZWQgdGFnIGF0ICcgKyBzY2FubmVyLnBvcyk7XG5cbiAgICAgIGlmICh0eXBlID09ICc+Jykge1xuICAgICAgICB0b2tlbiA9IFsgdHlwZSwgdmFsdWUsIHN0YXJ0LCBzY2FubmVyLnBvcywgaW5kZW50YXRpb24sIHRhZ0luZGV4LCBsaW5lSGFzTm9uU3BhY2UgXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRva2VuID0gWyB0eXBlLCB2YWx1ZSwgc3RhcnQsIHNjYW5uZXIucG9zIF07XG4gICAgICB9XG4gICAgICB0YWdJbmRleCsrO1xuICAgICAgdG9rZW5zLnB1c2godG9rZW4pO1xuXG4gICAgICBpZiAodHlwZSA9PT0gJyMnIHx8IHR5cGUgPT09ICdeJykge1xuICAgICAgICBzZWN0aW9ucy5wdXNoKHRva2VuKTtcbiAgICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJy8nKSB7XG4gICAgICAgIC8vIENoZWNrIHNlY3Rpb24gbmVzdGluZy5cbiAgICAgICAgb3BlblNlY3Rpb24gPSBzZWN0aW9ucy5wb3AoKTtcblxuICAgICAgICBpZiAoIW9wZW5TZWN0aW9uKVxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVW5vcGVuZWQgc2VjdGlvbiBcIicgKyB2YWx1ZSArICdcIiBhdCAnICsgc3RhcnQpO1xuXG4gICAgICAgIGlmIChvcGVuU2VjdGlvblsxXSAhPT0gdmFsdWUpXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmNsb3NlZCBzZWN0aW9uIFwiJyArIG9wZW5TZWN0aW9uWzFdICsgJ1wiIGF0ICcgKyBzdGFydCk7XG4gICAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICduYW1lJyB8fCB0eXBlID09PSAneycgfHwgdHlwZSA9PT0gJyYnKSB7XG4gICAgICAgIG5vblNwYWNlID0gdHJ1ZTtcbiAgICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJz0nKSB7XG4gICAgICAgIC8vIFNldCB0aGUgdGFncyBmb3IgdGhlIG5leHQgdGltZSBhcm91bmQuXG4gICAgICAgIGNvbXBpbGVUYWdzKHZhbHVlKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBzdHJpcFNwYWNlKCk7XG5cbiAgICAvLyBNYWtlIHN1cmUgdGhlcmUgYXJlIG5vIG9wZW4gc2VjdGlvbnMgd2hlbiB3ZSdyZSBkb25lLlxuICAgIG9wZW5TZWN0aW9uID0gc2VjdGlvbnMucG9wKCk7XG5cbiAgICBpZiAob3BlblNlY3Rpb24pXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuY2xvc2VkIHNlY3Rpb24gXCInICsgb3BlblNlY3Rpb25bMV0gKyAnXCIgYXQgJyArIHNjYW5uZXIucG9zKTtcblxuICAgIHJldHVybiBuZXN0VG9rZW5zKHNxdWFzaFRva2Vucyh0b2tlbnMpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb21iaW5lcyB0aGUgdmFsdWVzIG9mIGNvbnNlY3V0aXZlIHRleHQgdG9rZW5zIGluIHRoZSBnaXZlbiBgdG9rZW5zYCBhcnJheVxuICAgKiB0byBhIHNpbmdsZSB0b2tlbi5cbiAgICovXG4gIGZ1bmN0aW9uIHNxdWFzaFRva2VucyAodG9rZW5zKSB7XG4gICAgdmFyIHNxdWFzaGVkVG9rZW5zID0gW107XG5cbiAgICB2YXIgdG9rZW4sIGxhc3RUb2tlbjtcbiAgICBmb3IgKHZhciBpID0gMCwgbnVtVG9rZW5zID0gdG9rZW5zLmxlbmd0aDsgaSA8IG51bVRva2VuczsgKytpKSB7XG4gICAgICB0b2tlbiA9IHRva2Vuc1tpXTtcblxuICAgICAgaWYgKHRva2VuKSB7XG4gICAgICAgIGlmICh0b2tlblswXSA9PT0gJ3RleHQnICYmIGxhc3RUb2tlbiAmJiBsYXN0VG9rZW5bMF0gPT09ICd0ZXh0Jykge1xuICAgICAgICAgIGxhc3RUb2tlblsxXSArPSB0b2tlblsxXTtcbiAgICAgICAgICBsYXN0VG9rZW5bM10gPSB0b2tlblszXTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzcXVhc2hlZFRva2Vucy5wdXNoKHRva2VuKTtcbiAgICAgICAgICBsYXN0VG9rZW4gPSB0b2tlbjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBzcXVhc2hlZFRva2VucztcbiAgfVxuXG4gIC8qKlxuICAgKiBGb3JtcyB0aGUgZ2l2ZW4gYXJyYXkgb2YgYHRva2Vuc2AgaW50byBhIG5lc3RlZCB0cmVlIHN0cnVjdHVyZSB3aGVyZVxuICAgKiB0b2tlbnMgdGhhdCByZXByZXNlbnQgYSBzZWN0aW9uIGhhdmUgdHdvIGFkZGl0aW9uYWwgaXRlbXM6IDEpIGFuIGFycmF5IG9mXG4gICAqIGFsbCB0b2tlbnMgdGhhdCBhcHBlYXIgaW4gdGhhdCBzZWN0aW9uIGFuZCAyKSB0aGUgaW5kZXggaW4gdGhlIG9yaWdpbmFsXG4gICAqIHRlbXBsYXRlIHRoYXQgcmVwcmVzZW50cyB0aGUgZW5kIG9mIHRoYXQgc2VjdGlvbi5cbiAgICovXG4gIGZ1bmN0aW9uIG5lc3RUb2tlbnMgKHRva2Vucykge1xuICAgIHZhciBuZXN0ZWRUb2tlbnMgPSBbXTtcbiAgICB2YXIgY29sbGVjdG9yID0gbmVzdGVkVG9rZW5zO1xuICAgIHZhciBzZWN0aW9ucyA9IFtdO1xuXG4gICAgdmFyIHRva2VuLCBzZWN0aW9uO1xuICAgIGZvciAodmFyIGkgPSAwLCBudW1Ub2tlbnMgPSB0b2tlbnMubGVuZ3RoOyBpIDwgbnVtVG9rZW5zOyArK2kpIHtcbiAgICAgIHRva2VuID0gdG9rZW5zW2ldO1xuXG4gICAgICBzd2l0Y2ggKHRva2VuWzBdKSB7XG4gICAgICAgIGNhc2UgJyMnOlxuICAgICAgICBjYXNlICdeJzpcbiAgICAgICAgICBjb2xsZWN0b3IucHVzaCh0b2tlbik7XG4gICAgICAgICAgc2VjdGlvbnMucHVzaCh0b2tlbik7XG4gICAgICAgICAgY29sbGVjdG9yID0gdG9rZW5bNF0gPSBbXTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnLyc6XG4gICAgICAgICAgc2VjdGlvbiA9IHNlY3Rpb25zLnBvcCgpO1xuICAgICAgICAgIHNlY3Rpb25bNV0gPSB0b2tlblsyXTtcbiAgICAgICAgICBjb2xsZWN0b3IgPSBzZWN0aW9ucy5sZW5ndGggPiAwID8gc2VjdGlvbnNbc2VjdGlvbnMubGVuZ3RoIC0gMV1bNF0gOiBuZXN0ZWRUb2tlbnM7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgY29sbGVjdG9yLnB1c2godG9rZW4pO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuZXN0ZWRUb2tlbnM7XG4gIH1cblxuICAvKipcbiAgICogQSBzaW1wbGUgc3RyaW5nIHNjYW5uZXIgdGhhdCBpcyB1c2VkIGJ5IHRoZSB0ZW1wbGF0ZSBwYXJzZXIgdG8gZmluZFxuICAgKiB0b2tlbnMgaW4gdGVtcGxhdGUgc3RyaW5ncy5cbiAgICovXG4gIGZ1bmN0aW9uIFNjYW5uZXIgKHN0cmluZykge1xuICAgIHRoaXMuc3RyaW5nID0gc3RyaW5nO1xuICAgIHRoaXMudGFpbCA9IHN0cmluZztcbiAgICB0aGlzLnBvcyA9IDA7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHRhaWwgaXMgZW1wdHkgKGVuZCBvZiBzdHJpbmcpLlxuICAgKi9cbiAgU2Nhbm5lci5wcm90b3R5cGUuZW9zID0gZnVuY3Rpb24gZW9zICgpIHtcbiAgICByZXR1cm4gdGhpcy50YWlsID09PSAnJztcbiAgfTtcblxuICAvKipcbiAgICogVHJpZXMgdG8gbWF0Y2ggdGhlIGdpdmVuIHJlZ3VsYXIgZXhwcmVzc2lvbiBhdCB0aGUgY3VycmVudCBwb3NpdGlvbi5cbiAgICogUmV0dXJucyB0aGUgbWF0Y2hlZCB0ZXh0IGlmIGl0IGNhbiBtYXRjaCwgdGhlIGVtcHR5IHN0cmluZyBvdGhlcndpc2UuXG4gICAqL1xuICBTY2FubmVyLnByb3RvdHlwZS5zY2FuID0gZnVuY3Rpb24gc2NhbiAocmUpIHtcbiAgICB2YXIgbWF0Y2ggPSB0aGlzLnRhaWwubWF0Y2gocmUpO1xuXG4gICAgaWYgKCFtYXRjaCB8fCBtYXRjaC5pbmRleCAhPT0gMClcbiAgICAgIHJldHVybiAnJztcblxuICAgIHZhciBzdHJpbmcgPSBtYXRjaFswXTtcblxuICAgIHRoaXMudGFpbCA9IHRoaXMudGFpbC5zdWJzdHJpbmcoc3RyaW5nLmxlbmd0aCk7XG4gICAgdGhpcy5wb3MgKz0gc3RyaW5nLmxlbmd0aDtcblxuICAgIHJldHVybiBzdHJpbmc7XG4gIH07XG5cbiAgLyoqXG4gICAqIFNraXBzIGFsbCB0ZXh0IHVudGlsIHRoZSBnaXZlbiByZWd1bGFyIGV4cHJlc3Npb24gY2FuIGJlIG1hdGNoZWQuIFJldHVybnNcbiAgICogdGhlIHNraXBwZWQgc3RyaW5nLCB3aGljaCBpcyB0aGUgZW50aXJlIHRhaWwgaWYgbm8gbWF0Y2ggY2FuIGJlIG1hZGUuXG4gICAqL1xuICBTY2FubmVyLnByb3RvdHlwZS5zY2FuVW50aWwgPSBmdW5jdGlvbiBzY2FuVW50aWwgKHJlKSB7XG4gICAgdmFyIGluZGV4ID0gdGhpcy50YWlsLnNlYXJjaChyZSksIG1hdGNoO1xuXG4gICAgc3dpdGNoIChpbmRleCkge1xuICAgICAgY2FzZSAtMTpcbiAgICAgICAgbWF0Y2ggPSB0aGlzLnRhaWw7XG4gICAgICAgIHRoaXMudGFpbCA9ICcnO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgMDpcbiAgICAgICAgbWF0Y2ggPSAnJztcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBtYXRjaCA9IHRoaXMudGFpbC5zdWJzdHJpbmcoMCwgaW5kZXgpO1xuICAgICAgICB0aGlzLnRhaWwgPSB0aGlzLnRhaWwuc3Vic3RyaW5nKGluZGV4KTtcbiAgICB9XG5cbiAgICB0aGlzLnBvcyArPSBtYXRjaC5sZW5ndGg7XG5cbiAgICByZXR1cm4gbWF0Y2g7XG4gIH07XG5cbiAgLyoqXG4gICAqIFJlcHJlc2VudHMgYSByZW5kZXJpbmcgY29udGV4dCBieSB3cmFwcGluZyBhIHZpZXcgb2JqZWN0IGFuZFxuICAgKiBtYWludGFpbmluZyBhIHJlZmVyZW5jZSB0byB0aGUgcGFyZW50IGNvbnRleHQuXG4gICAqL1xuICBmdW5jdGlvbiBDb250ZXh0ICh2aWV3LCBwYXJlbnRDb250ZXh0KSB7XG4gICAgdGhpcy52aWV3ID0gdmlldztcbiAgICB0aGlzLmNhY2hlID0geyAnLic6IHRoaXMudmlldyB9O1xuICAgIHRoaXMucGFyZW50ID0gcGFyZW50Q29udGV4dDtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IGNvbnRleHQgdXNpbmcgdGhlIGdpdmVuIHZpZXcgd2l0aCB0aGlzIGNvbnRleHRcbiAgICogYXMgdGhlIHBhcmVudC5cbiAgICovXG4gIENvbnRleHQucHJvdG90eXBlLnB1c2ggPSBmdW5jdGlvbiBwdXNoICh2aWV3KSB7XG4gICAgcmV0dXJuIG5ldyBDb250ZXh0KHZpZXcsIHRoaXMpO1xuICB9O1xuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSB2YWx1ZSBvZiB0aGUgZ2l2ZW4gbmFtZSBpbiB0aGlzIGNvbnRleHQsIHRyYXZlcnNpbmdcbiAgICogdXAgdGhlIGNvbnRleHQgaGllcmFyY2h5IGlmIHRoZSB2YWx1ZSBpcyBhYnNlbnQgaW4gdGhpcyBjb250ZXh0J3Mgdmlldy5cbiAgICovXG4gIENvbnRleHQucHJvdG90eXBlLmxvb2t1cCA9IGZ1bmN0aW9uIGxvb2t1cCAobmFtZSkge1xuICAgIHZhciBjYWNoZSA9IHRoaXMuY2FjaGU7XG5cbiAgICB2YXIgdmFsdWU7XG4gICAgaWYgKGNhY2hlLmhhc093blByb3BlcnR5KG5hbWUpKSB7XG4gICAgICB2YWx1ZSA9IGNhY2hlW25hbWVdO1xuICAgIH0gZWxzZSB7XG4gICAgICB2YXIgY29udGV4dCA9IHRoaXMsIGludGVybWVkaWF0ZVZhbHVlLCBuYW1lcywgaW5kZXgsIGxvb2t1cEhpdCA9IGZhbHNlO1xuXG4gICAgICB3aGlsZSAoY29udGV4dCkge1xuICAgICAgICBpZiAobmFtZS5pbmRleE9mKCcuJykgPiAwKSB7XG4gICAgICAgICAgaW50ZXJtZWRpYXRlVmFsdWUgPSBjb250ZXh0LnZpZXc7XG4gICAgICAgICAgbmFtZXMgPSBuYW1lLnNwbGl0KCcuJyk7XG4gICAgICAgICAgaW5kZXggPSAwO1xuXG4gICAgICAgICAgLyoqXG4gICAgICAgICAgICogVXNpbmcgdGhlIGRvdCBub3Rpb24gcGF0aCBpbiBgbmFtZWAsIHdlIGRlc2NlbmQgdGhyb3VnaCB0aGVcbiAgICAgICAgICAgKiBuZXN0ZWQgb2JqZWN0cy5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIFRvIGJlIGNlcnRhaW4gdGhhdCB0aGUgbG9va3VwIGhhcyBiZWVuIHN1Y2Nlc3NmdWwsIHdlIGhhdmUgdG9cbiAgICAgICAgICAgKiBjaGVjayBpZiB0aGUgbGFzdCBvYmplY3QgaW4gdGhlIHBhdGggYWN0dWFsbHkgaGFzIHRoZSBwcm9wZXJ0eVxuICAgICAgICAgICAqIHdlIGFyZSBsb29raW5nIGZvci4gV2Ugc3RvcmUgdGhlIHJlc3VsdCBpbiBgbG9va3VwSGl0YC5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIFRoaXMgaXMgc3BlY2lhbGx5IG5lY2Vzc2FyeSBmb3Igd2hlbiB0aGUgdmFsdWUgaGFzIGJlZW4gc2V0IHRvXG4gICAgICAgICAgICogYHVuZGVmaW5lZGAgYW5kIHdlIHdhbnQgdG8gYXZvaWQgbG9va2luZyB1cCBwYXJlbnQgY29udGV4dHMuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBJbiB0aGUgY2FzZSB3aGVyZSBkb3Qgbm90YXRpb24gaXMgdXNlZCwgd2UgY29uc2lkZXIgdGhlIGxvb2t1cFxuICAgICAgICAgICAqIHRvIGJlIHN1Y2Nlc3NmdWwgZXZlbiBpZiB0aGUgbGFzdCBcIm9iamVjdFwiIGluIHRoZSBwYXRoIGlzXG4gICAgICAgICAgICogbm90IGFjdHVhbGx5IGFuIG9iamVjdCBidXQgYSBwcmltaXRpdmUgKGUuZy4sIGEgc3RyaW5nLCBvciBhblxuICAgICAgICAgICAqIGludGVnZXIpLCBiZWNhdXNlIGl0IGlzIHNvbWV0aW1lcyB1c2VmdWwgdG8gYWNjZXNzIGEgcHJvcGVydHlcbiAgICAgICAgICAgKiBvZiBhbiBhdXRvYm94ZWQgcHJpbWl0aXZlLCBzdWNoIGFzIHRoZSBsZW5ndGggb2YgYSBzdHJpbmcuXG4gICAgICAgICAgICoqL1xuICAgICAgICAgIHdoaWxlIChpbnRlcm1lZGlhdGVWYWx1ZSAhPSBudWxsICYmIGluZGV4IDwgbmFtZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoaW5kZXggPT09IG5hbWVzLmxlbmd0aCAtIDEpXG4gICAgICAgICAgICAgIGxvb2t1cEhpdCA9IChcbiAgICAgICAgICAgICAgICBoYXNQcm9wZXJ0eShpbnRlcm1lZGlhdGVWYWx1ZSwgbmFtZXNbaW5kZXhdKVxuICAgICAgICAgICAgICAgIHx8IHByaW1pdGl2ZUhhc093blByb3BlcnR5KGludGVybWVkaWF0ZVZhbHVlLCBuYW1lc1tpbmRleF0pXG4gICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgIGludGVybWVkaWF0ZVZhbHVlID0gaW50ZXJtZWRpYXRlVmFsdWVbbmFtZXNbaW5kZXgrK11dO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpbnRlcm1lZGlhdGVWYWx1ZSA9IGNvbnRleHQudmlld1tuYW1lXTtcblxuICAgICAgICAgIC8qKlxuICAgICAgICAgICAqIE9ubHkgY2hlY2tpbmcgYWdhaW5zdCBgaGFzUHJvcGVydHlgLCB3aGljaCBhbHdheXMgcmV0dXJucyBgZmFsc2VgIGlmXG4gICAgICAgICAgICogYGNvbnRleHQudmlld2AgaXMgbm90IGFuIG9iamVjdC4gRGVsaWJlcmF0ZWx5IG9taXR0aW5nIHRoZSBjaGVja1xuICAgICAgICAgICAqIGFnYWluc3QgYHByaW1pdGl2ZUhhc093blByb3BlcnR5YCBpZiBkb3Qgbm90YXRpb24gaXMgbm90IHVzZWQuXG4gICAgICAgICAgICpcbiAgICAgICAgICAgKiBDb25zaWRlciB0aGlzIGV4YW1wbGU6XG4gICAgICAgICAgICogYGBgXG4gICAgICAgICAgICogTXVzdGFjaGUucmVuZGVyKFwiVGhlIGxlbmd0aCBvZiBhIGZvb3RiYWxsIGZpZWxkIGlzIHt7I2xlbmd0aH19e3tsZW5ndGh9fXt7L2xlbmd0aH19LlwiLCB7bGVuZ3RoOiBcIjEwMCB5YXJkc1wifSlcbiAgICAgICAgICAgKiBgYGBcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIElmIHdlIHdlcmUgdG8gY2hlY2sgYWxzbyBhZ2FpbnN0IGBwcmltaXRpdmVIYXNPd25Qcm9wZXJ0eWAsIGFzIHdlIGRvXG4gICAgICAgICAgICogaW4gdGhlIGRvdCBub3RhdGlvbiBjYXNlLCB0aGVuIHJlbmRlciBjYWxsIHdvdWxkIHJldHVybjpcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIFwiVGhlIGxlbmd0aCBvZiBhIGZvb3RiYWxsIGZpZWxkIGlzIDkuXCJcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIHJhdGhlciB0aGFuIHRoZSBleHBlY3RlZDpcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIFwiVGhlIGxlbmd0aCBvZiBhIGZvb3RiYWxsIGZpZWxkIGlzIDEwMCB5YXJkcy5cIlxuICAgICAgICAgICAqKi9cbiAgICAgICAgICBsb29rdXBIaXQgPSBoYXNQcm9wZXJ0eShjb250ZXh0LnZpZXcsIG5hbWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGxvb2t1cEhpdCkge1xuICAgICAgICAgIHZhbHVlID0gaW50ZXJtZWRpYXRlVmFsdWU7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cblxuICAgICAgICBjb250ZXh0ID0gY29udGV4dC5wYXJlbnQ7XG4gICAgICB9XG5cbiAgICAgIGNhY2hlW25hbWVdID0gdmFsdWU7XG4gICAgfVxuXG4gICAgaWYgKGlzRnVuY3Rpb24odmFsdWUpKVxuICAgICAgdmFsdWUgPSB2YWx1ZS5jYWxsKHRoaXMudmlldyk7XG5cbiAgICByZXR1cm4gdmFsdWU7XG4gIH07XG5cbiAgLyoqXG4gICAqIEEgV3JpdGVyIGtub3dzIGhvdyB0byB0YWtlIGEgc3RyZWFtIG9mIHRva2VucyBhbmQgcmVuZGVyIHRoZW0gdG8gYVxuICAgKiBzdHJpbmcsIGdpdmVuIGEgY29udGV4dC4gSXQgYWxzbyBtYWludGFpbnMgYSBjYWNoZSBvZiB0ZW1wbGF0ZXMgdG9cbiAgICogYXZvaWQgdGhlIG5lZWQgdG8gcGFyc2UgdGhlIHNhbWUgdGVtcGxhdGUgdHdpY2UuXG4gICAqL1xuICBmdW5jdGlvbiBXcml0ZXIgKCkge1xuICAgIHRoaXMudGVtcGxhdGVDYWNoZSA9IHtcbiAgICAgIF9jYWNoZToge30sXG4gICAgICBzZXQ6IGZ1bmN0aW9uIHNldCAoa2V5LCB2YWx1ZSkge1xuICAgICAgICB0aGlzLl9jYWNoZVtrZXldID0gdmFsdWU7XG4gICAgICB9LFxuICAgICAgZ2V0OiBmdW5jdGlvbiBnZXQgKGtleSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fY2FjaGVba2V5XTtcbiAgICAgIH0sXG4gICAgICBjbGVhcjogZnVuY3Rpb24gY2xlYXIgKCkge1xuICAgICAgICB0aGlzLl9jYWNoZSA9IHt9O1xuICAgICAgfVxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogQ2xlYXJzIGFsbCBjYWNoZWQgdGVtcGxhdGVzIGluIHRoaXMgd3JpdGVyLlxuICAgKi9cbiAgV3JpdGVyLnByb3RvdHlwZS5jbGVhckNhY2hlID0gZnVuY3Rpb24gY2xlYXJDYWNoZSAoKSB7XG4gICAgaWYgKHR5cGVvZiB0aGlzLnRlbXBsYXRlQ2FjaGUgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICB0aGlzLnRlbXBsYXRlQ2FjaGUuY2xlYXIoKTtcbiAgICB9XG4gIH07XG5cbiAgLyoqXG4gICAqIFBhcnNlcyBhbmQgY2FjaGVzIHRoZSBnaXZlbiBgdGVtcGxhdGVgIGFjY29yZGluZyB0byB0aGUgZ2l2ZW4gYHRhZ3NgIG9yXG4gICAqIGBtdXN0YWNoZS50YWdzYCBpZiBgdGFnc2AgaXMgb21pdHRlZCwgIGFuZCByZXR1cm5zIHRoZSBhcnJheSBvZiB0b2tlbnNcbiAgICogdGhhdCBpcyBnZW5lcmF0ZWQgZnJvbSB0aGUgcGFyc2UuXG4gICAqL1xuICBXcml0ZXIucHJvdG90eXBlLnBhcnNlID0gZnVuY3Rpb24gcGFyc2UgKHRlbXBsYXRlLCB0YWdzKSB7XG4gICAgdmFyIGNhY2hlID0gdGhpcy50ZW1wbGF0ZUNhY2hlO1xuICAgIHZhciBjYWNoZUtleSA9IHRlbXBsYXRlICsgJzonICsgKHRhZ3MgfHwgbXVzdGFjaGUudGFncykuam9pbignOicpO1xuICAgIHZhciBpc0NhY2hlRW5hYmxlZCA9IHR5cGVvZiBjYWNoZSAhPT0gJ3VuZGVmaW5lZCc7XG4gICAgdmFyIHRva2VucyA9IGlzQ2FjaGVFbmFibGVkID8gY2FjaGUuZ2V0KGNhY2hlS2V5KSA6IHVuZGVmaW5lZDtcblxuICAgIGlmICh0b2tlbnMgPT0gdW5kZWZpbmVkKSB7XG4gICAgICB0b2tlbnMgPSBwYXJzZVRlbXBsYXRlKHRlbXBsYXRlLCB0YWdzKTtcbiAgICAgIGlzQ2FjaGVFbmFibGVkICYmIGNhY2hlLnNldChjYWNoZUtleSwgdG9rZW5zKTtcbiAgICB9XG4gICAgcmV0dXJuIHRva2VucztcbiAgfTtcblxuICAvKipcbiAgICogSGlnaC1sZXZlbCBtZXRob2QgdGhhdCBpcyB1c2VkIHRvIHJlbmRlciB0aGUgZ2l2ZW4gYHRlbXBsYXRlYCB3aXRoXG4gICAqIHRoZSBnaXZlbiBgdmlld2AuXG4gICAqXG4gICAqIFRoZSBvcHRpb25hbCBgcGFydGlhbHNgIGFyZ3VtZW50IG1heSBiZSBhbiBvYmplY3QgdGhhdCBjb250YWlucyB0aGVcbiAgICogbmFtZXMgYW5kIHRlbXBsYXRlcyBvZiBwYXJ0aWFscyB0aGF0IGFyZSB1c2VkIGluIHRoZSB0ZW1wbGF0ZS4gSXQgbWF5XG4gICAqIGFsc28gYmUgYSBmdW5jdGlvbiB0aGF0IGlzIHVzZWQgdG8gbG9hZCBwYXJ0aWFsIHRlbXBsYXRlcyBvbiB0aGUgZmx5XG4gICAqIHRoYXQgdGFrZXMgYSBzaW5nbGUgYXJndW1lbnQ6IHRoZSBuYW1lIG9mIHRoZSBwYXJ0aWFsLlxuICAgKlxuICAgKiBJZiB0aGUgb3B0aW9uYWwgYGNvbmZpZ2AgYXJndW1lbnQgaXMgZ2l2ZW4gaGVyZSwgdGhlbiBpdCBzaG91bGQgYmUgYW5cbiAgICogb2JqZWN0IHdpdGggYSBgdGFnc2AgYXR0cmlidXRlIG9yIGFuIGBlc2NhcGVgIGF0dHJpYnV0ZSBvciBib3RoLlxuICAgKiBJZiBhbiBhcnJheSBpcyBwYXNzZWQsIHRoZW4gaXQgd2lsbCBiZSBpbnRlcnByZXRlZCB0aGUgc2FtZSB3YXkgYXNcbiAgICogYSBgdGFnc2AgYXR0cmlidXRlIG9uIGEgYGNvbmZpZ2Agb2JqZWN0LlxuICAgKlxuICAgKiBUaGUgYHRhZ3NgIGF0dHJpYnV0ZSBvZiBhIGBjb25maWdgIG9iamVjdCBtdXN0IGJlIGFuIGFycmF5IHdpdGggdHdvXG4gICAqIHN0cmluZyB2YWx1ZXM6IHRoZSBvcGVuaW5nIGFuZCBjbG9zaW5nIHRhZ3MgdXNlZCBpbiB0aGUgdGVtcGxhdGUgKGUuZy5cbiAgICogWyBcIjwlXCIsIFwiJT5cIiBdKS4gVGhlIGRlZmF1bHQgaXMgdG8gbXVzdGFjaGUudGFncy5cbiAgICpcbiAgICogVGhlIGBlc2NhcGVgIGF0dHJpYnV0ZSBvZiBhIGBjb25maWdgIG9iamVjdCBtdXN0IGJlIGEgZnVuY3Rpb24gd2hpY2hcbiAgICogYWNjZXB0cyBhIHN0cmluZyBhcyBpbnB1dCBhbmQgb3V0cHV0cyBhIHNhZmVseSBlc2NhcGVkIHN0cmluZy5cbiAgICogSWYgYW4gYGVzY2FwZWAgZnVuY3Rpb24gaXMgbm90IHByb3ZpZGVkLCB0aGVuIGFuIEhUTUwtc2FmZSBzdHJpbmdcbiAgICogZXNjYXBpbmcgZnVuY3Rpb24gaXMgdXNlZCBhcyB0aGUgZGVmYXVsdC5cbiAgICovXG4gIFdyaXRlci5wcm90b3R5cGUucmVuZGVyID0gZnVuY3Rpb24gcmVuZGVyICh0ZW1wbGF0ZSwgdmlldywgcGFydGlhbHMsIGNvbmZpZykge1xuICAgIHZhciB0YWdzID0gdGhpcy5nZXRDb25maWdUYWdzKGNvbmZpZyk7XG4gICAgdmFyIHRva2VucyA9IHRoaXMucGFyc2UodGVtcGxhdGUsIHRhZ3MpO1xuICAgIHZhciBjb250ZXh0ID0gKHZpZXcgaW5zdGFuY2VvZiBDb250ZXh0KSA/IHZpZXcgOiBuZXcgQ29udGV4dCh2aWV3LCB1bmRlZmluZWQpO1xuICAgIHJldHVybiB0aGlzLnJlbmRlclRva2Vucyh0b2tlbnMsIGNvbnRleHQsIHBhcnRpYWxzLCB0ZW1wbGF0ZSwgY29uZmlnKTtcbiAgfTtcblxuICAvKipcbiAgICogTG93LWxldmVsIG1ldGhvZCB0aGF0IHJlbmRlcnMgdGhlIGdpdmVuIGFycmF5IG9mIGB0b2tlbnNgIHVzaW5nXG4gICAqIHRoZSBnaXZlbiBgY29udGV4dGAgYW5kIGBwYXJ0aWFsc2AuXG4gICAqXG4gICAqIE5vdGU6IFRoZSBgb3JpZ2luYWxUZW1wbGF0ZWAgaXMgb25seSBldmVyIHVzZWQgdG8gZXh0cmFjdCB0aGUgcG9ydGlvblxuICAgKiBvZiB0aGUgb3JpZ2luYWwgdGVtcGxhdGUgdGhhdCB3YXMgY29udGFpbmVkIGluIGEgaGlnaGVyLW9yZGVyIHNlY3Rpb24uXG4gICAqIElmIHRoZSB0ZW1wbGF0ZSBkb2Vzbid0IHVzZSBoaWdoZXItb3JkZXIgc2VjdGlvbnMsIHRoaXMgYXJndW1lbnQgbWF5XG4gICAqIGJlIG9taXR0ZWQuXG4gICAqL1xuICBXcml0ZXIucHJvdG90eXBlLnJlbmRlclRva2VucyA9IGZ1bmN0aW9uIHJlbmRlclRva2VucyAodG9rZW5zLCBjb250ZXh0LCBwYXJ0aWFscywgb3JpZ2luYWxUZW1wbGF0ZSwgY29uZmlnKSB7XG4gICAgdmFyIGJ1ZmZlciA9ICcnO1xuXG4gICAgdmFyIHRva2VuLCBzeW1ib2wsIHZhbHVlO1xuICAgIGZvciAodmFyIGkgPSAwLCBudW1Ub2tlbnMgPSB0b2tlbnMubGVuZ3RoOyBpIDwgbnVtVG9rZW5zOyArK2kpIHtcbiAgICAgIHZhbHVlID0gdW5kZWZpbmVkO1xuICAgICAgdG9rZW4gPSB0b2tlbnNbaV07XG4gICAgICBzeW1ib2wgPSB0b2tlblswXTtcblxuICAgICAgaWYgKHN5bWJvbCA9PT0gJyMnKSB2YWx1ZSA9IHRoaXMucmVuZGVyU2VjdGlvbih0b2tlbiwgY29udGV4dCwgcGFydGlhbHMsIG9yaWdpbmFsVGVtcGxhdGUsIGNvbmZpZyk7XG4gICAgICBlbHNlIGlmIChzeW1ib2wgPT09ICdeJykgdmFsdWUgPSB0aGlzLnJlbmRlckludmVydGVkKHRva2VuLCBjb250ZXh0LCBwYXJ0aWFscywgb3JpZ2luYWxUZW1wbGF0ZSwgY29uZmlnKTtcbiAgICAgIGVsc2UgaWYgKHN5bWJvbCA9PT0gJz4nKSB2YWx1ZSA9IHRoaXMucmVuZGVyUGFydGlhbCh0b2tlbiwgY29udGV4dCwgcGFydGlhbHMsIGNvbmZpZyk7XG4gICAgICBlbHNlIGlmIChzeW1ib2wgPT09ICcmJykgdmFsdWUgPSB0aGlzLnVuZXNjYXBlZFZhbHVlKHRva2VuLCBjb250ZXh0KTtcbiAgICAgIGVsc2UgaWYgKHN5bWJvbCA9PT0gJ25hbWUnKSB2YWx1ZSA9IHRoaXMuZXNjYXBlZFZhbHVlKHRva2VuLCBjb250ZXh0LCBjb25maWcpO1xuICAgICAgZWxzZSBpZiAoc3ltYm9sID09PSAndGV4dCcpIHZhbHVlID0gdGhpcy5yYXdWYWx1ZSh0b2tlbik7XG5cbiAgICAgIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKVxuICAgICAgICBidWZmZXIgKz0gdmFsdWU7XG4gICAgfVxuXG4gICAgcmV0dXJuIGJ1ZmZlcjtcbiAgfTtcblxuICBXcml0ZXIucHJvdG90eXBlLnJlbmRlclNlY3Rpb24gPSBmdW5jdGlvbiByZW5kZXJTZWN0aW9uICh0b2tlbiwgY29udGV4dCwgcGFydGlhbHMsIG9yaWdpbmFsVGVtcGxhdGUsIGNvbmZpZykge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICB2YXIgYnVmZmVyID0gJyc7XG4gICAgdmFyIHZhbHVlID0gY29udGV4dC5sb29rdXAodG9rZW5bMV0pO1xuXG4gICAgLy8gVGhpcyBmdW5jdGlvbiBpcyB1c2VkIHRvIHJlbmRlciBhbiBhcmJpdHJhcnkgdGVtcGxhdGVcbiAgICAvLyBpbiB0aGUgY3VycmVudCBjb250ZXh0IGJ5IGhpZ2hlci1vcmRlciBzZWN0aW9ucy5cbiAgICBmdW5jdGlvbiBzdWJSZW5kZXIgKHRlbXBsYXRlKSB7XG4gICAgICByZXR1cm4gc2VsZi5yZW5kZXIodGVtcGxhdGUsIGNvbnRleHQsIHBhcnRpYWxzLCBjb25maWcpO1xuICAgIH1cblxuICAgIGlmICghdmFsdWUpIHJldHVybjtcblxuICAgIGlmIChpc0FycmF5KHZhbHVlKSkge1xuICAgICAgZm9yICh2YXIgaiA9IDAsIHZhbHVlTGVuZ3RoID0gdmFsdWUubGVuZ3RoOyBqIDwgdmFsdWVMZW5ndGg7ICsraikge1xuICAgICAgICBidWZmZXIgKz0gdGhpcy5yZW5kZXJUb2tlbnModG9rZW5bNF0sIGNvbnRleHQucHVzaCh2YWx1ZVtqXSksIHBhcnRpYWxzLCBvcmlnaW5hbFRlbXBsYXRlLCBjb25maWcpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyB8fCB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHtcbiAgICAgIGJ1ZmZlciArPSB0aGlzLnJlbmRlclRva2Vucyh0b2tlbls0XSwgY29udGV4dC5wdXNoKHZhbHVlKSwgcGFydGlhbHMsIG9yaWdpbmFsVGVtcGxhdGUsIGNvbmZpZyk7XG4gICAgfSBlbHNlIGlmIChpc0Z1bmN0aW9uKHZhbHVlKSkge1xuICAgICAgaWYgKHR5cGVvZiBvcmlnaW5hbFRlbXBsYXRlICE9PSAnc3RyaW5nJylcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgdXNlIGhpZ2hlci1vcmRlciBzZWN0aW9ucyB3aXRob3V0IHRoZSBvcmlnaW5hbCB0ZW1wbGF0ZScpO1xuXG4gICAgICAvLyBFeHRyYWN0IHRoZSBwb3J0aW9uIG9mIHRoZSBvcmlnaW5hbCB0ZW1wbGF0ZSB0aGF0IHRoZSBzZWN0aW9uIGNvbnRhaW5zLlxuICAgICAgdmFsdWUgPSB2YWx1ZS5jYWxsKGNvbnRleHQudmlldywgb3JpZ2luYWxUZW1wbGF0ZS5zbGljZSh0b2tlblszXSwgdG9rZW5bNV0pLCBzdWJSZW5kZXIpO1xuXG4gICAgICBpZiAodmFsdWUgIT0gbnVsbClcbiAgICAgICAgYnVmZmVyICs9IHZhbHVlO1xuICAgIH0gZWxzZSB7XG4gICAgICBidWZmZXIgKz0gdGhpcy5yZW5kZXJUb2tlbnModG9rZW5bNF0sIGNvbnRleHQsIHBhcnRpYWxzLCBvcmlnaW5hbFRlbXBsYXRlLCBjb25maWcpO1xuICAgIH1cbiAgICByZXR1cm4gYnVmZmVyO1xuICB9O1xuXG4gIFdyaXRlci5wcm90b3R5cGUucmVuZGVySW52ZXJ0ZWQgPSBmdW5jdGlvbiByZW5kZXJJbnZlcnRlZCAodG9rZW4sIGNvbnRleHQsIHBhcnRpYWxzLCBvcmlnaW5hbFRlbXBsYXRlLCBjb25maWcpIHtcbiAgICB2YXIgdmFsdWUgPSBjb250ZXh0Lmxvb2t1cCh0b2tlblsxXSk7XG5cbiAgICAvLyBVc2UgSmF2YVNjcmlwdCdzIGRlZmluaXRpb24gb2YgZmFsc3kuIEluY2x1ZGUgZW1wdHkgYXJyYXlzLlxuICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vamFubC9tdXN0YWNoZS5qcy9pc3N1ZXMvMTg2XG4gICAgaWYgKCF2YWx1ZSB8fCAoaXNBcnJheSh2YWx1ZSkgJiYgdmFsdWUubGVuZ3RoID09PSAwKSlcbiAgICAgIHJldHVybiB0aGlzLnJlbmRlclRva2Vucyh0b2tlbls0XSwgY29udGV4dCwgcGFydGlhbHMsIG9yaWdpbmFsVGVtcGxhdGUsIGNvbmZpZyk7XG4gIH07XG5cbiAgV3JpdGVyLnByb3RvdHlwZS5pbmRlbnRQYXJ0aWFsID0gZnVuY3Rpb24gaW5kZW50UGFydGlhbCAocGFydGlhbCwgaW5kZW50YXRpb24sIGxpbmVIYXNOb25TcGFjZSkge1xuICAgIHZhciBmaWx0ZXJlZEluZGVudGF0aW9uID0gaW5kZW50YXRpb24ucmVwbGFjZSgvW14gXFx0XS9nLCAnJyk7XG4gICAgdmFyIHBhcnRpYWxCeU5sID0gcGFydGlhbC5zcGxpdCgnXFxuJyk7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwYXJ0aWFsQnlObC5sZW5ndGg7IGkrKykge1xuICAgICAgaWYgKHBhcnRpYWxCeU5sW2ldLmxlbmd0aCAmJiAoaSA+IDAgfHwgIWxpbmVIYXNOb25TcGFjZSkpIHtcbiAgICAgICAgcGFydGlhbEJ5TmxbaV0gPSBmaWx0ZXJlZEluZGVudGF0aW9uICsgcGFydGlhbEJ5TmxbaV07XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBwYXJ0aWFsQnlObC5qb2luKCdcXG4nKTtcbiAgfTtcblxuICBXcml0ZXIucHJvdG90eXBlLnJlbmRlclBhcnRpYWwgPSBmdW5jdGlvbiByZW5kZXJQYXJ0aWFsICh0b2tlbiwgY29udGV4dCwgcGFydGlhbHMsIGNvbmZpZykge1xuICAgIGlmICghcGFydGlhbHMpIHJldHVybjtcbiAgICB2YXIgdGFncyA9IHRoaXMuZ2V0Q29uZmlnVGFncyhjb25maWcpO1xuXG4gICAgdmFyIHZhbHVlID0gaXNGdW5jdGlvbihwYXJ0aWFscykgPyBwYXJ0aWFscyh0b2tlblsxXSkgOiBwYXJ0aWFsc1t0b2tlblsxXV07XG4gICAgaWYgKHZhbHVlICE9IG51bGwpIHtcbiAgICAgIHZhciBsaW5lSGFzTm9uU3BhY2UgPSB0b2tlbls2XTtcbiAgICAgIHZhciB0YWdJbmRleCA9IHRva2VuWzVdO1xuICAgICAgdmFyIGluZGVudGF0aW9uID0gdG9rZW5bNF07XG4gICAgICB2YXIgaW5kZW50ZWRWYWx1ZSA9IHZhbHVlO1xuICAgICAgaWYgKHRhZ0luZGV4ID09IDAgJiYgaW5kZW50YXRpb24pIHtcbiAgICAgICAgaW5kZW50ZWRWYWx1ZSA9IHRoaXMuaW5kZW50UGFydGlhbCh2YWx1ZSwgaW5kZW50YXRpb24sIGxpbmVIYXNOb25TcGFjZSk7XG4gICAgICB9XG4gICAgICB2YXIgdG9rZW5zID0gdGhpcy5wYXJzZShpbmRlbnRlZFZhbHVlLCB0YWdzKTtcbiAgICAgIHJldHVybiB0aGlzLnJlbmRlclRva2Vucyh0b2tlbnMsIGNvbnRleHQsIHBhcnRpYWxzLCBpbmRlbnRlZFZhbHVlLCBjb25maWcpO1xuICAgIH1cbiAgfTtcblxuICBXcml0ZXIucHJvdG90eXBlLnVuZXNjYXBlZFZhbHVlID0gZnVuY3Rpb24gdW5lc2NhcGVkVmFsdWUgKHRva2VuLCBjb250ZXh0KSB7XG4gICAgdmFyIHZhbHVlID0gY29udGV4dC5sb29rdXAodG9rZW5bMV0pO1xuICAgIGlmICh2YWx1ZSAhPSBudWxsKVxuICAgICAgcmV0dXJuIHZhbHVlO1xuICB9O1xuXG4gIFdyaXRlci5wcm90b3R5cGUuZXNjYXBlZFZhbHVlID0gZnVuY3Rpb24gZXNjYXBlZFZhbHVlICh0b2tlbiwgY29udGV4dCwgY29uZmlnKSB7XG4gICAgdmFyIGVzY2FwZSA9IHRoaXMuZ2V0Q29uZmlnRXNjYXBlKGNvbmZpZykgfHwgbXVzdGFjaGUuZXNjYXBlO1xuICAgIHZhciB2YWx1ZSA9IGNvbnRleHQubG9va3VwKHRva2VuWzFdKTtcbiAgICBpZiAodmFsdWUgIT0gbnVsbClcbiAgICAgIHJldHVybiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJyAmJiBlc2NhcGUgPT09IG11c3RhY2hlLmVzY2FwZSkgPyBTdHJpbmcodmFsdWUpIDogZXNjYXBlKHZhbHVlKTtcbiAgfTtcblxuICBXcml0ZXIucHJvdG90eXBlLnJhd1ZhbHVlID0gZnVuY3Rpb24gcmF3VmFsdWUgKHRva2VuKSB7XG4gICAgcmV0dXJuIHRva2VuWzFdO1xuICB9O1xuXG4gIFdyaXRlci5wcm90b3R5cGUuZ2V0Q29uZmlnVGFncyA9IGZ1bmN0aW9uIGdldENvbmZpZ1RhZ3MgKGNvbmZpZykge1xuICAgIGlmIChpc0FycmF5KGNvbmZpZykpIHtcbiAgICAgIHJldHVybiBjb25maWc7XG4gICAgfVxuICAgIGVsc2UgaWYgKGNvbmZpZyAmJiB0eXBlb2YgY29uZmlnID09PSAnb2JqZWN0Jykge1xuICAgICAgcmV0dXJuIGNvbmZpZy50YWdzO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICB9O1xuXG4gIFdyaXRlci5wcm90b3R5cGUuZ2V0Q29uZmlnRXNjYXBlID0gZnVuY3Rpb24gZ2V0Q29uZmlnRXNjYXBlIChjb25maWcpIHtcbiAgICBpZiAoY29uZmlnICYmIHR5cGVvZiBjb25maWcgPT09ICdvYmplY3QnICYmICFpc0FycmF5KGNvbmZpZykpIHtcbiAgICAgIHJldHVybiBjb25maWcuZXNjYXBlO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICB9O1xuXG4gIHZhciBtdXN0YWNoZSA9IHtcbiAgICBuYW1lOiAnbXVzdGFjaGUuanMnLFxuICAgIHZlcnNpb246ICc0LjIuMCcsXG4gICAgdGFnczogWyAne3snLCAnfX0nIF0sXG4gICAgY2xlYXJDYWNoZTogdW5kZWZpbmVkLFxuICAgIGVzY2FwZTogdW5kZWZpbmVkLFxuICAgIHBhcnNlOiB1bmRlZmluZWQsXG4gICAgcmVuZGVyOiB1bmRlZmluZWQsXG4gICAgU2Nhbm5lcjogdW5kZWZpbmVkLFxuICAgIENvbnRleHQ6IHVuZGVmaW5lZCxcbiAgICBXcml0ZXI6IHVuZGVmaW5lZCxcbiAgICAvKipcbiAgICAgKiBBbGxvd3MgYSB1c2VyIHRvIG92ZXJyaWRlIHRoZSBkZWZhdWx0IGNhY2hpbmcgc3RyYXRlZ3ksIGJ5IHByb3ZpZGluZyBhblxuICAgICAqIG9iamVjdCB3aXRoIHNldCwgZ2V0IGFuZCBjbGVhciBtZXRob2RzLiBUaGlzIGNhbiBhbHNvIGJlIHVzZWQgdG8gZGlzYWJsZVxuICAgICAqIHRoZSBjYWNoZSBieSBzZXR0aW5nIGl0IHRvIHRoZSBsaXRlcmFsIGB1bmRlZmluZWRgLlxuICAgICAqL1xuICAgIHNldCB0ZW1wbGF0ZUNhY2hlIChjYWNoZSkge1xuICAgICAgZGVmYXVsdFdyaXRlci50ZW1wbGF0ZUNhY2hlID0gY2FjaGU7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBHZXRzIHRoZSBkZWZhdWx0IG9yIG92ZXJyaWRkZW4gY2FjaGluZyBvYmplY3QgZnJvbSB0aGUgZGVmYXVsdCB3cml0ZXIuXG4gICAgICovXG4gICAgZ2V0IHRlbXBsYXRlQ2FjaGUgKCkge1xuICAgICAgcmV0dXJuIGRlZmF1bHRXcml0ZXIudGVtcGxhdGVDYWNoZTtcbiAgICB9XG4gIH07XG5cbiAgLy8gQWxsIGhpZ2gtbGV2ZWwgbXVzdGFjaGUuKiBmdW5jdGlvbnMgdXNlIHRoaXMgd3JpdGVyLlxuICB2YXIgZGVmYXVsdFdyaXRlciA9IG5ldyBXcml0ZXIoKTtcblxuICAvKipcbiAgICogQ2xlYXJzIGFsbCBjYWNoZWQgdGVtcGxhdGVzIGluIHRoZSBkZWZhdWx0IHdyaXRlci5cbiAgICovXG4gIG11c3RhY2hlLmNsZWFyQ2FjaGUgPSBmdW5jdGlvbiBjbGVhckNhY2hlICgpIHtcbiAgICByZXR1cm4gZGVmYXVsdFdyaXRlci5jbGVhckNhY2hlKCk7XG4gIH07XG5cbiAgLyoqXG4gICAqIFBhcnNlcyBhbmQgY2FjaGVzIHRoZSBnaXZlbiB0ZW1wbGF0ZSBpbiB0aGUgZGVmYXVsdCB3cml0ZXIgYW5kIHJldHVybnMgdGhlXG4gICAqIGFycmF5IG9mIHRva2VucyBpdCBjb250YWlucy4gRG9pbmcgdGhpcyBhaGVhZCBvZiB0aW1lIGF2b2lkcyB0aGUgbmVlZCB0b1xuICAgKiBwYXJzZSB0ZW1wbGF0ZXMgb24gdGhlIGZseSBhcyB0aGV5IGFyZSByZW5kZXJlZC5cbiAgICovXG4gIG11c3RhY2hlLnBhcnNlID0gZnVuY3Rpb24gcGFyc2UgKHRlbXBsYXRlLCB0YWdzKSB7XG4gICAgcmV0dXJuIGRlZmF1bHRXcml0ZXIucGFyc2UodGVtcGxhdGUsIHRhZ3MpO1xuICB9O1xuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBgdGVtcGxhdGVgIHdpdGggdGhlIGdpdmVuIGB2aWV3YCwgYHBhcnRpYWxzYCwgYW5kIGBjb25maWdgXG4gICAqIHVzaW5nIHRoZSBkZWZhdWx0IHdyaXRlci5cbiAgICovXG4gIG11c3RhY2hlLnJlbmRlciA9IGZ1bmN0aW9uIHJlbmRlciAodGVtcGxhdGUsIHZpZXcsIHBhcnRpYWxzLCBjb25maWcpIHtcbiAgICBpZiAodHlwZW9mIHRlbXBsYXRlICE9PSAnc3RyaW5nJykge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignSW52YWxpZCB0ZW1wbGF0ZSEgVGVtcGxhdGUgc2hvdWxkIGJlIGEgXCJzdHJpbmdcIiAnICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJ2J1dCBcIicgKyB0eXBlU3RyKHRlbXBsYXRlKSArICdcIiB3YXMgZ2l2ZW4gYXMgdGhlIGZpcnN0ICcgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnYXJndW1lbnQgZm9yIG11c3RhY2hlI3JlbmRlcih0ZW1wbGF0ZSwgdmlldywgcGFydGlhbHMpJyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGRlZmF1bHRXcml0ZXIucmVuZGVyKHRlbXBsYXRlLCB2aWV3LCBwYXJ0aWFscywgY29uZmlnKTtcbiAgfTtcblxuICAvLyBFeHBvcnQgdGhlIGVzY2FwaW5nIGZ1bmN0aW9uIHNvIHRoYXQgdGhlIHVzZXIgbWF5IG92ZXJyaWRlIGl0LlxuICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL2phbmwvbXVzdGFjaGUuanMvaXNzdWVzLzI0NFxuICBtdXN0YWNoZS5lc2NhcGUgPSBlc2NhcGVIdG1sO1xuXG4gIC8vIEV4cG9ydCB0aGVzZSBtYWlubHkgZm9yIHRlc3RpbmcsIGJ1dCBhbHNvIGZvciBhZHZhbmNlZCB1c2FnZS5cbiAgbXVzdGFjaGUuU2Nhbm5lciA9IFNjYW5uZXI7XG4gIG11c3RhY2hlLkNvbnRleHQgPSBDb250ZXh0O1xuICBtdXN0YWNoZS5Xcml0ZXIgPSBXcml0ZXI7XG5cbiAgcmV0dXJuIG11c3RhY2hlO1xuXG59KSkpO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XHJcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xyXG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufTtcclxudmFyIF9fZ2VuZXJhdG9yID0gKHRoaXMgJiYgdGhpcy5fX2dlbmVyYXRvcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59O1xyXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XHJcbmV4cG9ydHMubG9hZEFuZE1lcmdlQXNzaWdubWVudExpc3QgPSBleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0Tm9NZW1vID0gZXhwb3J0cy5tZXJnZWRBc3NpZ25tZW50TGlzdCA9IGV4cG9ydHMuY291cnNlSURMaXN0ID0gdm9pZCAwO1xyXG52YXIgc3RvcmFnZV8xID0gcmVxdWlyZShcIi4vc3RvcmFnZVwiKTtcclxudmFyIG5ldHdvcmtfMSA9IHJlcXVpcmUoXCIuL25ldHdvcmtcIik7XHJcbnZhciBtaW5pc2FrYWlfMSA9IHJlcXVpcmUoXCIuL21pbmlzYWthaVwiKTtcclxudmFyIGZhdm9yaXRlc18xID0gcmVxdWlyZShcIi4vZmF2b3JpdGVzXCIpO1xyXG52YXIgdXRpbHNfMSA9IHJlcXVpcmUoXCIuL3V0aWxzXCIpO1xyXG52YXIgc2V0dGluZ3NfMSA9IHJlcXVpcmUoXCIuL3NldHRpbmdzXCIpO1xyXG4vKipcclxuICogTG9hZCBvbGQgYXNzaWdubWVudHMvcXVpenplcyBmcm9tIHN0b3JhZ2UgYW5kIGZldGNoIG5ldyBhc3NpZ25tZW50cy9xdWl6emVzIGZyb20gU2FrYWkuXHJcbiAqIEBwYXJhbSB7Q29uZmlnfSBjb25maWdcclxuICogQHBhcmFtIHtDb3Vyc2VTaXRlSW5mb1tdfSBjb3Vyc2VTaXRlSW5mb3NcclxuICogQHBhcmFtIHtib29sZWFufSB1c2VBc3NpZ25tZW50Q2FjaGVcclxuICogQHBhcmFtIHtib29sZWFufSB1c2VRdWl6Q2FjaGVcclxuICovXHJcbmZ1bmN0aW9uIGxvYWRBbmRNZXJnZUFzc2lnbm1lbnRMaXN0KGNvbmZpZywgY291cnNlU2l0ZUluZm9zLCB1c2VBc3NpZ25tZW50Q2FjaGUsIHVzZVF1aXpDYWNoZSkge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBvbGRBc3NpZ25tZW50TGlzdCwgX2EsIG9sZFF1aXpMaXN0LCBfYiwgbmV3QXNzaWdubWVudExpc3QsIG5ld1F1aXpMaXN0LCBwZW5kaW5nTGlzdCwgX2ksIGNvdXJzZVNpdGVJbmZvc18xLCBpLCByZXN1bHQsIF9jLCByZXN1bHRfMSwgaywgcGVuZGluZ0xpc3QsIF9kLCBjb3Vyc2VTaXRlSW5mb3NfMiwgaSwgcmVzdWx0LCBfZSwgcmVzdWx0XzIsIGssIG1lcmdlZFF1aXpMaXN0LCBtZW1vTGlzdCwgX2Y7XHJcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfZykge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKF9nLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICAgICAgX2EgPSB1dGlsc18xLmNvbnZlcnRBcnJheVRvQXNzaWdubWVudDtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEubG9hZEZyb21Mb2NhbFN0b3JhZ2UoXCJDU19Bc3NpZ25tZW50TGlzdFwiKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgb2xkQXNzaWdubWVudExpc3QgPSBfYS5hcHBseSh2b2lkIDAsIFtfZy5zZW50KCldKTtcclxuICAgICAgICAgICAgICAgICAgICBfYiA9IHV0aWxzXzEuY29udmVydEFycmF5VG9Bc3NpZ25tZW50O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5sb2FkRnJvbUxvY2FsU3RvcmFnZShcIkNTX1F1aXpMaXN0XCIpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICBvbGRRdWl6TGlzdCA9IF9iLmFwcGx5KHZvaWQgMCwgW19nLnNlbnQoKV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIG5ld0Fzc2lnbm1lbnRMaXN0ID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3UXVpekxpc3QgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIXVzZUFzc2lnbm1lbnRDYWNoZSkgcmV0dXJuIFszIC8qYnJlYWsqLywgM107XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3QXNzaWdubWVudExpc3QgPSBvbGRBc3NpZ25tZW50TGlzdDtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzMgLypicmVhayovLCA2XTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkZldGNoaW5nIGFzc2lnbm1lbnRzLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHBlbmRpbmdMaXN0ID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gQWRkIGNvdXJzZSBzaXRlcyB0byBmZXRjaC1wZW5kaW5nIGxpc3RcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKF9pID0gMCwgY291cnNlU2l0ZUluZm9zXzEgPSBjb3Vyc2VTaXRlSW5mb3M7IF9pIDwgY291cnNlU2l0ZUluZm9zXzEubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGkgPSBjb3Vyc2VTaXRlSW5mb3NfMVtfaV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlbmRpbmdMaXN0LnB1c2gobmV0d29ya18xLmdldEFzc2lnbm1lbnRCeUNvdXJzZUlEKGNvbmZpZy5iYXNlVVJMLCBpLmNvdXJzZUlEKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIFByb21pc2UuYWxsU2V0dGxlZChwZW5kaW5nTGlzdCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OlxyXG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IF9nLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKF9jID0gMCwgcmVzdWx0XzEgPSByZXN1bHQ7IF9jIDwgcmVzdWx0XzEubGVuZ3RoOyBfYysrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGsgPSByZXN1bHRfMVtfY107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChrLnN0YXR1cyA9PT0gXCJmdWxmaWxsZWRcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5ld0Fzc2lnbm1lbnRMaXN0LnB1c2goay52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSBhc3NpZ25tZW50IGZldGNoIHRpbWVzdGFtcFxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5zYXZlVG9Mb2NhbFN0b3JhZ2UoXCJDU19Bc3NpZ25tZW50RmV0Y2hUaW1lXCIsIHV0aWxzXzEubm93VGltZSldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA1OlxyXG4gICAgICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSBhc3NpZ25tZW50IGZldGNoIHRpbWVzdGFtcFxyXG4gICAgICAgICAgICAgICAgICAgIF9nLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25maWcuZmV0Y2hlZFRpbWUuYXNzaWdubWVudCA9IHV0aWxzXzEubm93VGltZTtcclxuICAgICAgICAgICAgICAgICAgICBfZy5sYWJlbCA9IDY7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDY6XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gQ29tcGFyZSBhc3NpZ25tZW50cyB3aXRoIG9sZCBvbmVzXHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0cy5tZXJnZWRBc3NpZ25tZW50TGlzdE5vTWVtbyA9IHV0aWxzXzEuY29tcGFyZUFuZE1lcmdlQXNzaWdubWVudExpc3Qob2xkQXNzaWdubWVudExpc3QsIG5ld0Fzc2lnbm1lbnRMaXN0KTtcclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0ID0gdXRpbHNfMS5jb21wYXJlQW5kTWVyZ2VBc3NpZ25tZW50TGlzdChvbGRBc3NpZ25tZW50TGlzdCwgbmV3QXNzaWdubWVudExpc3QpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdXNlUXVpekNhY2hlKSByZXR1cm4gWzMgLypicmVhayovLCA3XTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG9sZFF1aXpMaXN0ICE9PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5ld1F1aXpMaXN0ID0gb2xkUXVpekxpc3Q7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDEwXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzpcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkZldGNoaW5nIHF1aXp6ZXMuLi5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgcGVuZGluZ0xpc3QgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBBZGQgY291cnNlIHNpdGVzIHRvIGZldGNoLXBlbmRpbmcgbGlzdFxyXG4gICAgICAgICAgICAgICAgICAgIGZvciAoX2QgPSAwLCBjb3Vyc2VTaXRlSW5mb3NfMiA9IGNvdXJzZVNpdGVJbmZvczsgX2QgPCBjb3Vyc2VTaXRlSW5mb3NfMi5sZW5ndGg7IF9kKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaSA9IGNvdXJzZVNpdGVJbmZvc18yW19kXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGVuZGluZ0xpc3QucHVzaChuZXR3b3JrXzEuZ2V0UXVpekZyb21Db3Vyc2VJRChjb25maWcuYmFzZVVSTCwgaS5jb3Vyc2VJRCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBQcm9taXNlLmFsbFNldHRsZWQocGVuZGluZ0xpc3QpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgODpcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBfZy5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChfZSA9IDAsIHJlc3VsdF8yID0gcmVzdWx0OyBfZSA8IHJlc3VsdF8yLmxlbmd0aDsgX2UrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrID0gcmVzdWx0XzJbX2VdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoay5zdGF0dXMgPT09IFwiZnVsZmlsbGVkXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuZXdRdWl6TGlzdC5wdXNoKGsudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvLyBVcGRhdGUgYXNzaWdubWVudCBmZXRjaCB0aW1lc3RhbXBcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEuc2F2ZVRvTG9jYWxTdG9yYWdlKFwiQ1NfUXVpekZldGNoVGltZVwiLCB1dGlsc18xLm5vd1RpbWUpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgOTpcclxuICAgICAgICAgICAgICAgICAgICAvLyBVcGRhdGUgYXNzaWdubWVudCBmZXRjaCB0aW1lc3RhbXBcclxuICAgICAgICAgICAgICAgICAgICBfZy5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlnLmZldGNoZWRUaW1lLnF1aXogPSB1dGlsc18xLm5vd1RpbWU7XHJcbiAgICAgICAgICAgICAgICAgICAgX2cubGFiZWwgPSAxMDtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTA6XHJcbiAgICAgICAgICAgICAgICAgICAgbWVyZ2VkUXVpekxpc3QgPSB1dGlsc18xLmNvbXBhcmVBbmRNZXJnZUFzc2lnbm1lbnRMaXN0KG9sZFF1aXpMaXN0LCBuZXdRdWl6TGlzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gTWVyZ2UgYXNzaWdubWVudHMgYW5kIHF1aXp6ZXNcclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0ID0gdXRpbHNfMS5tZXJnZUludG9Bc3NpZ25tZW50TGlzdChleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0LCBtZXJnZWRRdWl6TGlzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgX2YgPSB1dGlsc18xLmNvbnZlcnRBcnJheVRvQXNzaWdubWVudDtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEubG9hZEZyb21Mb2NhbFN0b3JhZ2UoXCJDU19NZW1vTGlzdFwiKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDExOlxyXG4gICAgICAgICAgICAgICAgICAgIG1lbW9MaXN0ID0gX2YuYXBwbHkodm9pZCAwLCBbX2cuc2VudCgpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gTWVyZ2UgbWVtb3NcclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0ID0gdXRpbHNfMS5zb3J0QXNzaWdubWVudExpc3QodXRpbHNfMS5tZXJnZUludG9Bc3NpZ25tZW50TGlzdChleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0LCBtZW1vTGlzdCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIFNhdmUgYXNzaWdubWVudHMgYW5kIHF1aXp6ZXMgdG8gbG9jYWwgc3RvcmFnZVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5zYXZlVG9Mb2NhbFN0b3JhZ2UoXCJDU19Bc3NpZ25tZW50TGlzdFwiLCBleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0Tm9NZW1vKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDEyOlxyXG4gICAgICAgICAgICAgICAgICAgIC8vIFNhdmUgYXNzaWdubWVudHMgYW5kIHF1aXp6ZXMgdG8gbG9jYWwgc3RvcmFnZVxyXG4gICAgICAgICAgICAgICAgICAgIF9nLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEuc2F2ZVRvTG9jYWxTdG9yYWdlKFwiQ1NfUXVpekxpc3RcIiwgbWVyZ2VkUXVpekxpc3QpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTM6XHJcbiAgICAgICAgICAgICAgICAgICAgX2cuc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovLCBleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0XTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuZXhwb3J0cy5sb2FkQW5kTWVyZ2VBc3NpZ25tZW50TGlzdCA9IGxvYWRBbmRNZXJnZUFzc2lnbm1lbnRMaXN0O1xyXG4vKipcclxuICogTG9hZCBjb3Vyc2Ugc2l0ZSBJRHNcclxuICovXHJcbmZ1bmN0aW9uIGxvYWRDb3Vyc2VJRExpc3QoKSB7XHJcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0cy5jb3Vyc2VJRExpc3QgPSBuZXR3b3JrXzEuZ2V0Q291cnNlSURMaXN0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLnNhdmVUb0xvY2FsU3RvcmFnZShcIkNTX0NvdXJzZUluZm9cIiwgZXhwb3J0cy5jb3Vyc2VJRExpc3QpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5mdW5jdGlvbiB1cGRhdGVSZWFkRmxhZygpIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgdXBkYXRlZEFzc2lnbm1lbnRMaXN0O1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRBc3NpZ25tZW50TGlzdCA9IHV0aWxzXzEudXBkYXRlSXNSZWFkRmxhZyhleHBvcnRzLm1lcmdlZEFzc2lnbm1lbnRMaXN0Tm9NZW1vKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEuc2F2ZVRvTG9jYWxTdG9yYWdlKFwiQ1NfQXNzaWdubWVudExpc3RcIiwgdXBkYXRlZEFzc2lnbm1lbnRMaXN0KV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuZnVuY3Rpb24gbWFpbigpIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgY29uZmlnO1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdXRpbHNfMS5pc0xvZ2dlZEluKCkpIHJldHVybiBbMyAvKmJyZWFrKi8sIDhdO1xyXG4gICAgICAgICAgICAgICAgICAgIG1pbmlzYWthaV8xLmNyZWF0ZU1pbmlTYWthaUJ0bigpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHNldHRpbmdzXzEubG9hZENvbmZpZ3MoKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlnID0gX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIGxvYWRDb3Vyc2VJRExpc3QoKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDI6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIGxvYWRBbmRNZXJnZUFzc2lnbm1lbnRMaXN0KGNvbmZpZywgZXhwb3J0cy5jb3Vyc2VJRExpc3QsIHV0aWxzXzEuaXNVc2luZ0NhY2hlKGNvbmZpZy5mZXRjaGVkVGltZS5hc3NpZ25tZW50LCBjb25maWcuY2FjaGVJbnRlcnZhbC5hc3NpZ25tZW50KSwgdXRpbHNfMS5pc1VzaW5nQ2FjaGUoY29uZmlnLmZldGNoZWRUaW1lLnF1aXosIGNvbmZpZy5jYWNoZUludGVydmFsLnF1aXopKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDM6XHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0cy5tZXJnZWRBc3NpZ25tZW50TGlzdCA9IF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBmYXZvcml0ZXNfMS5hZGRGYXZvcml0ZWRDb3Vyc2VTaXRlcyhjb25maWcuYmFzZVVSTCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OlxyXG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBtaW5pc2FrYWlfMS5kaXNwbGF5TWluaVNha2FpKGV4cG9ydHMubWVyZ2VkQXNzaWdubWVudExpc3QsIGV4cG9ydHMuY291cnNlSURMaXN0KV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDU6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIG1pbmlzYWthaV8xLmNyZWF0ZUZhdm9yaXRlc0Jhck5vdGlmaWNhdGlvbihleHBvcnRzLmNvdXJzZUlETGlzdCwgZXhwb3J0cy5tZXJnZWRBc3NpZ25tZW50TGlzdCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA2OlxyXG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCB1cGRhdGVSZWFkRmxhZygpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzpcclxuICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgX2EubGFiZWwgPSA4O1xyXG4gICAgICAgICAgICAgICAgY2FzZSA4OiByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbm1haW4oKTtcclxuIiwiXCJ1c2Ugc3RyaWN0XCI7XHJcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcclxuZXhwb3J0cy5hcHBlbmRDaGlsZEFsbCA9IGV4cG9ydHMuY2xvbmVFbGVtID0gZXhwb3J0cy5jcmVhdGVFbGVtID0gZXhwb3J0cy5hZGRBdHRyaWJ1dGVzID0gZXhwb3J0cy5TZXR0aW5nc0RvbSA9IGV4cG9ydHMuaGFtYnVyZ2VyID0gZXhwb3J0cy5hc3NpZ25tZW50RGl2ID0gZXhwb3J0cy5taW5pU2FrYWkgPSB2b2lkIDA7XHJcbnZhciBldmVudExpc3RlbmVyXzEgPSByZXF1aXJlKFwiLi9ldmVudExpc3RlbmVyXCIpO1xyXG4vKipcclxuICogQ3JlYXRlIERPTSBlbGVtZW50c1xyXG4gKi9cclxuZnVuY3Rpb24gY3JlYXRlRWxlbSh0YWcsIGRpY3QsIGV2ZW50TGlzdGVuZXIpIHtcclxuICAgIHZhciBlbGVtID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0YWcpO1xyXG4gICAgYWRkQXR0cmlidXRlcyhlbGVtLCBkaWN0LCBldmVudExpc3RlbmVyKTtcclxuICAgIHJldHVybiBlbGVtO1xyXG59XHJcbmV4cG9ydHMuY3JlYXRlRWxlbSA9IGNyZWF0ZUVsZW07XHJcbi8qKlxyXG4gKiBDbG9uZSBET00gZWxlbWVudHNcclxuICovXHJcbmZ1bmN0aW9uIGNsb25lRWxlbShlbGVtLCBkaWN0LCBldmVudExpc3RlbmVyKSB7XHJcbiAgICB2YXIgY2xvbmUgPSBlbGVtLmNsb25lTm9kZSh0cnVlKTtcclxuICAgIGFkZEF0dHJpYnV0ZXMoY2xvbmUsIGRpY3QsIGV2ZW50TGlzdGVuZXIpO1xyXG4gICAgcmV0dXJuIGNsb25lO1xyXG59XHJcbmV4cG9ydHMuY2xvbmVFbGVtID0gY2xvbmVFbGVtO1xyXG4vKipcclxuICogQWRkIGF0dHJpYnV0ZXMgdG8gRE9NIGVsZW1lbnRzXHJcbiAqL1xyXG5mdW5jdGlvbiBhZGRBdHRyaWJ1dGVzKGVsZW0sIGRpY3QsIGV2ZW50TGlzdGVuZXIpIHtcclxuICAgIGZvciAodmFyIGtleSBpbiBkaWN0KSB7XHJcbiAgICAgICAgaWYgKGtleSA9PT0gXCJzdHlsZVwiKVxyXG4gICAgICAgICAgICBlbGVtW2tleV0uZGlzcGxheSA9IGRpY3Rba2V5XTtcclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgICAgICAgICBlbGVtW2tleV0gPSBkaWN0W2tleV07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgZm9yICh2YXIga2V5IGluIGV2ZW50TGlzdGVuZXIpIHtcclxuICAgICAgICBlbGVtLmFkZEV2ZW50TGlzdGVuZXIoa2V5LCBldmVudExpc3RlbmVyW2tleV0pO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGVsZW07XHJcbn1cclxuZXhwb3J0cy5hZGRBdHRyaWJ1dGVzID0gYWRkQXR0cmlidXRlcztcclxuLyoqXHJcbiAqIEFwcGVuZCBhbGwgZWxlbWVudHMgYXMgY2hpbGQgb2YgMXN0IGFyZ1xyXG4gKi9cclxuZnVuY3Rpb24gYXBwZW5kQ2hpbGRBbGwodG8sIGFycikge1xyXG4gICAgZm9yICh2YXIgb2JqIGluIGFycikge1xyXG4gICAgICAgIHRvLmFwcGVuZENoaWxkKGFycltvYmpdKTtcclxuICAgIH1cclxuICAgIHJldHVybiB0bztcclxufVxyXG5leHBvcnRzLmFwcGVuZENoaWxkQWxsID0gYXBwZW5kQ2hpbGRBbGw7XHJcbmV4cG9ydHMubWluaVNha2FpID0gY3JlYXRlRWxlbShcImRpdlwiLCB7IGlkOiBcIm1pbmlTYWthaVwiIH0pO1xyXG5leHBvcnRzLm1pbmlTYWthaS5jbGFzc0xpc3QuYWRkKFwiY3MtbWluaXNha2FpXCIsIFwiY3MtdGFiXCIpO1xyXG5leHBvcnRzLmFzc2lnbm1lbnREaXYgPSBjcmVhdGVFbGVtKFwiZGl2XCIsIHsgY2xhc3NOYW1lOiBcImNzLWFzc2lnbm1lbnQtdGFiXCIgfSk7XHJcbmV4cG9ydHMuaGFtYnVyZ2VyID0gY3JlYXRlRWxlbShcImRpdlwiLCB7IGNsYXNzTmFtZTogXCJjcy1sb2FkaW5nXCIgfSwgeyBjbGljazogZXZlbnRMaXN0ZW5lcl8xLnRvZ2dsZU1pbmlTYWthaSB9KTtcclxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1uYW1lc3BhY2VcclxudmFyIFNldHRpbmdzRG9tO1xyXG4oZnVuY3Rpb24gKFNldHRpbmdzRG9tKSB7XHJcbiAgICBTZXR0aW5nc0RvbS5tYWluRGl2ID0gY3JlYXRlRWxlbShcImRpdlwiLCB7IGNsYXNzTmFtZTogXCJjcC1zZXR0aW5nc1wiIH0pO1xyXG4gICAgU2V0dGluZ3NEb20uZGl2ID0gY3JlYXRlRWxlbShcImRpdlwiKTtcclxuICAgIFNldHRpbmdzRG9tLnAgPSBjcmVhdGVFbGVtKFwicFwiLCB7IGNsYXNzTmFtZTogXCJjcC1zZXR0aW5ncy10ZXh0XCIgfSk7XHJcbiAgICBTZXR0aW5nc0RvbS5sYWJlbCA9IGNyZWF0ZUVsZW0oXCJsYWJlbFwiKTtcclxuICAgIFNldHRpbmdzRG9tLnRvZ2dsZUJ0biA9IGNyZWF0ZUVsZW0oXCJpbnB1dFwiLCB7IHR5cGU6IFwiY2hlY2tib3hcIiB9KTtcclxuICAgIFNldHRpbmdzRG9tLnJlc2V0QnRuID0gY3JlYXRlRWxlbShcImlucHV0XCIsIHsgdHlwZTogXCJidXR0b25cIiB9KTtcclxuICAgIFNldHRpbmdzRG9tLnN0cmluZ0JveCA9IGNyZWF0ZUVsZW0oXCJpbnB1dFwiLCB7IHR5cGU6IFwiY29sb3JcIiwgY2xhc3NOYW1lOiBcImNwLXNldHRpbmdzLWlucHV0Ym94XCIgfSk7XHJcbiAgICBTZXR0aW5nc0RvbS5pbnB1dEJveCA9IGNyZWF0ZUVsZW0oXCJpbnB1dFwiLCB7IHR5cGU6IFwibnVtYmVyXCIsIGNsYXNzTmFtZTogXCJjcC1zZXR0aW5ncy1pbnB1dGJveFwiIH0pO1xyXG4gICAgU2V0dGluZ3NEb20uc3BhbiA9IGNyZWF0ZUVsZW0oXCJzcGFuXCIsIHsgY2xhc3NOYW1lOiBcImNzLXRvZ2dsZS1zbGlkZXIgcm91bmRcIiB9KTtcclxufSkoU2V0dGluZ3NEb20gfHwgKFNldHRpbmdzRG9tID0ge30pKTtcclxuZXhwb3J0cy5TZXR0aW5nc0RvbSA9IFNldHRpbmdzRG9tO1xyXG4iLCJcInVzZSBzdHJpY3RcIjtcclxudmFyIF9fYXdhaXRlciA9ICh0aGlzICYmIHRoaXMuX19hd2FpdGVyKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XHJcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cclxuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xyXG4gICAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvci5uZXh0KHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cclxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cclxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxyXG4gICAgICAgIHN0ZXAoKGdlbmVyYXRvciA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSkubmV4dCgpKTtcclxuICAgIH0pO1xyXG59O1xyXG52YXIgX19nZW5lcmF0b3IgPSAodGhpcyAmJiB0aGlzLl9fZ2VuZXJhdG9yKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgYm9keSkge1xyXG4gICAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbigpIHsgaWYgKHRbMF0gJiAxKSB0aHJvdyB0WzFdOyByZXR1cm4gdFsxXTsgfSwgdHJ5czogW10sIG9wczogW10gfSwgZiwgeSwgdCwgZztcclxuICAgIHJldHVybiBnID0geyBuZXh0OiB2ZXJiKDApLCBcInRocm93XCI6IHZlcmIoMSksIFwicmV0dXJuXCI6IHZlcmIoMikgfSwgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIChnW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbigpIHsgcmV0dXJuIHRoaXM7IH0pLCBnO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IHJldHVybiBmdW5jdGlvbiAodikgeyByZXR1cm4gc3RlcChbbiwgdl0pOyB9OyB9XHJcbiAgICBmdW5jdGlvbiBzdGVwKG9wKSB7XHJcbiAgICAgICAgaWYgKGYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJHZW5lcmF0b3IgaXMgYWxyZWFkeSBleGVjdXRpbmcuXCIpO1xyXG4gICAgICAgIHdoaWxlIChfKSB0cnkge1xyXG4gICAgICAgICAgICBpZiAoZiA9IDEsIHkgJiYgKHQgPSBvcFswXSAmIDIgPyB5W1wicmV0dXJuXCJdIDogb3BbMF0gPyB5W1widGhyb3dcIl0gfHwgKCh0ID0geVtcInJldHVyblwiXSkgJiYgdC5jYWxsKHkpLCAwKSA6IHkubmV4dCkgJiYgISh0ID0gdC5jYWxsKHksIG9wWzFdKSkuZG9uZSkgcmV0dXJuIHQ7XHJcbiAgICAgICAgICAgIGlmICh5ID0gMCwgdCkgb3AgPSBbb3BbMF0gJiAyLCB0LnZhbHVlXTtcclxuICAgICAgICAgICAgc3dpdGNoIChvcFswXSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiBjYXNlIDE6IHQgPSBvcDsgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ6IF8ubGFiZWwrKzsgcmV0dXJuIHsgdmFsdWU6IG9wWzFdLCBkb25lOiBmYWxzZSB9O1xyXG4gICAgICAgICAgICAgICAgY2FzZSA1OiBfLmxhYmVsKys7IHkgPSBvcFsxXTsgb3AgPSBbMF07IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA3OiBvcCA9IF8ub3BzLnBvcCgpOyBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICBpZiAoISh0ID0gXy50cnlzLCB0ID0gdC5sZW5ndGggPiAwICYmIHRbdC5sZW5ndGggLSAxXSkgJiYgKG9wWzBdID09PSA2IHx8IG9wWzBdID09PSAyKSkgeyBfID0gMDsgY29udGludWU7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDMgJiYgKCF0IHx8IChvcFsxXSA+IHRbMF0gJiYgb3BbMV0gPCB0WzNdKSkpIHsgXy5sYWJlbCA9IG9wWzFdOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gNiAmJiBfLmxhYmVsIDwgdFsxXSkgeyBfLmxhYmVsID0gdFsxXTsgdCA9IG9wOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0ICYmIF8ubGFiZWwgPCB0WzJdKSB7IF8ubGFiZWwgPSB0WzJdOyBfLm9wcy5wdXNoKG9wKTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodFsyXSkgXy5vcHMucG9wKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvcCA9IGJvZHkuY2FsbCh0aGlzQXJnLCBfKTtcclxuICAgICAgICB9IGNhdGNoIChlKSB7IG9wID0gWzYsIGVdOyB5ID0gMDsgfSBmaW5hbGx5IHsgZiA9IHQgPSAwOyB9XHJcbiAgICAgICAgaWYgKG9wWzBdICYgNSkgdGhyb3cgb3BbMV07IHJldHVybiB7IHZhbHVlOiBvcFswXSA/IG9wWzFdIDogdm9pZCAwLCBkb25lOiB0cnVlIH07XHJcbiAgICB9XHJcbn07XHJcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcclxuZXhwb3J0cy5lZGl0RmF2b3JpdGVzTWVzc2FnZSA9IGV4cG9ydHMuZGVsZXRlTWVtbyA9IGV4cG9ydHMudXBkYXRlU2V0dGluZ3MgPSBleHBvcnRzLmFkZE1lbW8gPSBleHBvcnRzLnRvZ2dsZUZpbmlzaGVkRmxhZyA9IGV4cG9ydHMudG9nZ2xlTWVtb0JveCA9IGV4cG9ydHMudG9nZ2xlU2V0dGluZ3NUYWIgPSBleHBvcnRzLnRvZ2dsZUFzc2lnbm1lbnRUYWIgPSBleHBvcnRzLnRvZ2dsZU1pbmlTYWthaSA9IHZvaWQgMDtcclxudmFyIGRvbV8xID0gcmVxdWlyZShcIi4vZG9tXCIpO1xyXG52YXIgc3RvcmFnZV8xID0gcmVxdWlyZShcIi4vc3RvcmFnZVwiKTtcclxudmFyIG1vZGVsXzEgPSByZXF1aXJlKFwiLi9tb2RlbFwiKTtcclxudmFyIHV0aWxzXzEgPSByZXF1aXJlKFwiLi91dGlsc1wiKTtcclxudmFyIGNvbnRlbnRfc2NyaXB0XzEgPSByZXF1aXJlKFwiLi9jb250ZW50X3NjcmlwdFwiKTtcclxudmFyIHNldHRpbmdzXzEgPSByZXF1aXJlKFwiLi9zZXR0aW5nc1wiKTtcclxudmFyIG1pbmlzYWthaV8xID0gcmVxdWlyZShcIi4vbWluaXNha2FpXCIpO1xyXG52YXIgdG9nZ2xlID0gZmFsc2U7XHJcbi8qKlxyXG4gKiBDaGFuZ2UgdmlzaWJpbGl0eSBvZiBtaW5pU2FrYWlcclxuICovXHJcbmZ1bmN0aW9uIHRvZ2dsZU1pbmlTYWthaSgpIHtcclxuICAgIHZhciBfYTtcclxuICAgIGlmICh0b2dnbGUpIHtcclxuICAgICAgICAvLyBIaWRlIG1pbmlTYWthaVxyXG4gICAgICAgIGRvbV8xLm1pbmlTYWthaS5zdHlsZS53aWR0aCA9IFwiMHB4XCI7XHJcbiAgICAgICAgKF9hID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjcy1jb3ZlclwiKSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLnJlbW92ZSgpO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgICAgLy8gRGlzcGxheSBtaW5pU2FrYWlcclxuICAgICAgICBkb21fMS5taW5pU2FrYWkuc3R5bGUud2lkdGggPSBcIjMwMHB4XCI7XHJcbiAgICAgICAgdmFyIGNvdmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcclxuICAgICAgICBjb3Zlci5pZCA9IFwiY3MtY292ZXJcIjtcclxuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImJvZHlcIilbMF0uYXBwZW5kQ2hpbGQoY292ZXIpO1xyXG4gICAgICAgIGNvdmVyLm9uY2xpY2sgPSB0b2dnbGVNaW5pU2FrYWk7XHJcbiAgICB9XHJcbiAgICB0b2dnbGUgPSAhdG9nZ2xlO1xyXG59XHJcbmV4cG9ydHMudG9nZ2xlTWluaVNha2FpID0gdG9nZ2xlTWluaVNha2FpO1xyXG4vKipcclxuICogQ2hhbmdlIHZpc2liaWxpdHkgb2YgQXNzaWdubWVudCB0YWJcclxuICovXHJcbmZ1bmN0aW9uIHRvZ2dsZUFzc2lnbm1lbnRUYWIoKSB7XHJcbiAgICB2YXIgYXNzaWdubWVudFRhYiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuY3MtYXNzaWdubWVudC10YWJcIik7XHJcbiAgICBhc3NpZ25tZW50VGFiLnN0eWxlLmRpc3BsYXkgPSBcIlwiO1xyXG4gICAgdmFyIHNldHRpbmdzVGFiID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5jcy1zZXR0aW5ncy10YWJcIik7XHJcbiAgICBzZXR0aW5nc1RhYi5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XHJcbiAgICB2YXIgYWRkTWVtb0J1dHRvbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjY3MtYWRkLW1lbW8tYnRuXCIpO1xyXG4gICAgYWRkTWVtb0J1dHRvbi5zdHlsZS5kaXNwbGF5ID0gXCJcIjtcclxuICAgIHZhciBhc3NpZ25tZW50RmV0Y2hlZFRpbWUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmNzLWFzc2lnbm1lbnQtdGltZVwiKTtcclxuICAgIGFzc2lnbm1lbnRGZXRjaGVkVGltZS5zdHlsZS5kaXNwbGF5ID0gXCJcIjtcclxuICAgIHZhciBxdWl6RmV0Y2hlZFRpbWUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmNzLXF1aXotdGltZVwiKTtcclxuICAgIHF1aXpGZXRjaGVkVGltZS5zdHlsZS5kaXNwbGF5ID0gXCJcIjtcclxufVxyXG5leHBvcnRzLnRvZ2dsZUFzc2lnbm1lbnRUYWIgPSB0b2dnbGVBc3NpZ25tZW50VGFiO1xyXG4vKipcclxuICogQ2hhbmdlIHZpc2liaWxpdHkgb2YgU2V0dGluZ3MgdGFiXHJcbiAqL1xyXG5mdW5jdGlvbiB0b2dnbGVTZXR0aW5nc1RhYigpIHtcclxuICAgIHZhciBhc3NpZ25tZW50VGFiID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5jcy1hc3NpZ25tZW50LXRhYlwiKTtcclxuICAgIGFzc2lnbm1lbnRUYWIuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xyXG4gICAgdmFyIHNldHRpbmdzVGFiID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5jcy1zZXR0aW5ncy10YWJcIik7XHJcbiAgICBzZXR0aW5nc1RhYi5zdHlsZS5kaXNwbGF5ID0gXCJcIjtcclxuICAgIHZhciBhZGRNZW1vQnV0dG9uID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNjcy1hZGQtbWVtby1idG5cIik7XHJcbiAgICBhZGRNZW1vQnV0dG9uLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcclxuICAgIHZhciBhc3NpZ25tZW50RmV0Y2hlZFRpbWUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmNzLWFzc2lnbm1lbnQtdGltZVwiKTtcclxuICAgIGFzc2lnbm1lbnRGZXRjaGVkVGltZS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XHJcbiAgICB2YXIgcXVpekZldGNoZWRUaW1lID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5jcy1xdWl6LXRpbWVcIik7XHJcbiAgICBxdWl6RmV0Y2hlZFRpbWUuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xyXG59XHJcbmV4cG9ydHMudG9nZ2xlU2V0dGluZ3NUYWIgPSB0b2dnbGVTZXR0aW5nc1RhYjtcclxuLyoqXHJcbiAqIENoYW5nZSB2aXNpYmlsaXR5IG9mIE1lbW8gYm94XHJcbiAqL1xyXG5mdW5jdGlvbiB0b2dnbGVNZW1vQm94KCkge1xyXG4gICAgdmFyIGFkZE1lbW9Cb3ggPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmFkZE1lbW9Cb3hcIik7XHJcbiAgICB2YXIgdG9nZ2xlU3RhdHVzID0gYWRkTWVtb0JveC5zdHlsZS5kaXNwbGF5O1xyXG4gICAgaWYgKHRvZ2dsZVN0YXR1cyA9PT0gXCJcIikge1xyXG4gICAgICAgIGFkZE1lbW9Cb3guc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgICAgYWRkTWVtb0JveC5zdHlsZS5kaXNwbGF5ID0gXCJcIjtcclxuICAgIH1cclxufVxyXG5leHBvcnRzLnRvZ2dsZU1lbW9Cb3ggPSB0b2dnbGVNZW1vQm94O1xyXG4vKipcclxuICogVG9nZ2xlIGZpbmlzaGVkIGNoZWNrYm94IGZvciBhc3NpZ25tZW50L3F1aXpcclxuICovXHJcbmZ1bmN0aW9uIHRvZ2dsZUZpbmlzaGVkRmxhZyhldmVudCkge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBhc3NpZ25tZW50SUQsIGFzc2lnbm1lbnRMaXN0LCBfYSwgX2IsIF9jLCB1cGRhdGVkQXNzaWdubWVudExpc3QsIF9pLCBhc3NpZ25tZW50TGlzdF8xLCBhc3NpZ25tZW50LCB1cGRhdGVkQXNzaWdubWVudEVudHJpZXMsIF9kLCBfZSwgYXNzaWdubWVudEVudHJ5LCBpc0ZpbmlzaGVkLCBpc1F1aXo7XHJcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfZikge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKF9mLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudElEID0gZXZlbnQudGFyZ2V0LmlkO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghKGFzc2lnbm1lbnRJRFswXSA9PT0gXCJtXCIpKSByZXR1cm4gWzMgLypicmVhayovLCAyXTtcclxuICAgICAgICAgICAgICAgICAgICBfYSA9IHV0aWxzXzEuY29udmVydEFycmF5VG9Bc3NpZ25tZW50O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5sb2FkRnJvbUxvY2FsU3RvcmFnZShcIkNTX01lbW9MaXN0XCIpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50TGlzdCA9IF9hLmFwcGx5KHZvaWQgMCwgW19mLnNlbnQoKV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDZdO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghKGFzc2lnbm1lbnRJRFswXSA9PT0gXCJxXCIpKSByZXR1cm4gWzMgLypicmVhayovLCA0XTtcclxuICAgICAgICAgICAgICAgICAgICBfYiA9IHV0aWxzXzEuY29udmVydEFycmF5VG9Bc3NpZ25tZW50O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5sb2FkRnJvbUxvY2FsU3RvcmFnZShcIkNTX1F1aXpMaXN0XCIpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50TGlzdCA9IF9iLmFwcGx5KHZvaWQgMCwgW19mLnNlbnQoKV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDZdO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OlxyXG4gICAgICAgICAgICAgICAgICAgIF9jID0gdXRpbHNfMS5jb252ZXJ0QXJyYXlUb0Fzc2lnbm1lbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLmxvYWRGcm9tTG9jYWxTdG9yYWdlKFwiQ1NfQXNzaWdubWVudExpc3RcIildO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA1OlxyXG4gICAgICAgICAgICAgICAgICAgIGFzc2lnbm1lbnRMaXN0ID0gX2MuYXBwbHkodm9pZCAwLCBbX2Yuc2VudCgpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgX2YubGFiZWwgPSA2O1xyXG4gICAgICAgICAgICAgICAgY2FzZSA2OlxyXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRBc3NpZ25tZW50TGlzdCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAoX2kgPSAwLCBhc3NpZ25tZW50TGlzdF8xID0gYXNzaWdubWVudExpc3Q7IF9pIDwgYXNzaWdubWVudExpc3RfMS5sZW5ndGg7IF9pKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudCA9IGFzc2lnbm1lbnRMaXN0XzFbX2ldO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkQXNzaWdubWVudEVudHJpZXMgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChfZCA9IDAsIF9lID0gYXNzaWdubWVudC5hc3NpZ25tZW50RW50cmllczsgX2QgPCBfZS5sZW5ndGg7IF9kKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzc2lnbm1lbnRFbnRyeSA9IF9lW19kXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhc3NpZ25tZW50RW50cnkuYXNzaWdubWVudElEID09PSBhc3NpZ25tZW50SUQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0ZpbmlzaGVkID0gYXNzaWdubWVudEVudHJ5LmlzRmluaXNoZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNRdWl6ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBhc3NpZ25tZW50RW50cnkuaXNRdWl6ICE9PSBcInVuZGVmaW5lZFwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1F1aXogPSBhc3NpZ25tZW50RW50cnkuaXNRdWl6O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRBc3NpZ25tZW50RW50cmllcy5wdXNoKG5ldyBtb2RlbF8xLkFzc2lnbm1lbnRFbnRyeShhc3NpZ25tZW50RW50cnkuYXNzaWdubWVudElELCBhc3NpZ25tZW50RW50cnkuYXNzaWdubWVudFRpdGxlLCBhc3NpZ25tZW50RW50cnkuZHVlRGF0ZVRpbWVzdGFtcCwgYXNzaWdubWVudEVudHJ5LmNsb3NlRGF0ZVRpbWVzdGFtcCwgYXNzaWdubWVudEVudHJ5LmlzTWVtbywgIWlzRmluaXNoZWQsIGlzUXVpeiwgYXNzaWdubWVudEVudHJ5LmFzc2lnbm1lbnREZXRhaWwpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRBc3NpZ25tZW50RW50cmllcy5wdXNoKGFzc2lnbm1lbnRFbnRyeSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEFzc2lnbm1lbnRMaXN0LnB1c2gobmV3IG1vZGVsXzEuQXNzaWdubWVudChhc3NpZ25tZW50LmNvdXJzZVNpdGVJbmZvLCB1cGRhdGVkQXNzaWdubWVudEVudHJpZXMsIGFzc2lnbm1lbnQuaXNSZWFkKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghKGFzc2lnbm1lbnRJRFswXSA9PT0gXCJtXCIpKSByZXR1cm4gWzMgLypicmVhayovLCA4XTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEuc2F2ZVRvTG9jYWxTdG9yYWdlKFwiQ1NfTWVtb0xpc3RcIiwgdXBkYXRlZEFzc2lnbm1lbnRMaXN0KV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDc6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Yuc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDEyXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgODpcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIShhc3NpZ25tZW50SURbMF0gPT09IFwicVwiKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgMTBdO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5zYXZlVG9Mb2NhbFN0b3JhZ2UoXCJDU19RdWl6TGlzdFwiLCB1cGRhdGVkQXNzaWdubWVudExpc3QpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgOTpcclxuICAgICAgICAgICAgICAgICAgICBfZi5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgMTJdO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxMDogcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLnNhdmVUb0xvY2FsU3RvcmFnZShcIkNTX0Fzc2lnbm1lbnRMaXN0XCIsIHVwZGF0ZWRBc3NpZ25tZW50TGlzdCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxMTpcclxuICAgICAgICAgICAgICAgICAgICBfZi5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgX2YubGFiZWwgPSAxMjtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTI6IHJldHVybiBbNCAvKnlpZWxkKi8sIHJlZHJhd0Zhdm9yaXRlc0Jhcihjb250ZW50X3NjcmlwdF8xLmNvdXJzZUlETGlzdCwgdHJ1ZSldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxMzpcclxuICAgICAgICAgICAgICAgICAgICBfZi5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLnRvZ2dsZUZpbmlzaGVkRmxhZyA9IHRvZ2dsZUZpbmlzaGVkRmxhZztcclxuLyoqXHJcbiAqIFVwZGF0ZSBTZXR0aW5ncyBwYXJhbWV0ZXJcclxuICovXHJcbmZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKGV2ZW50LCB0eXBlKSB7XHJcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIHNldHRpbmdzSUQsIHNldHRpbmdzVmFsdWUsIGNvbmZpZywgQ1NzZXR0aW5ncywgY29sb3JMaXN0LCBfaSwgY29sb3JMaXN0XzEsIGssIHE7XHJcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0dGluZ3NJRCA9IGV2ZW50LnRhcmdldC5pZDtcclxuICAgICAgICAgICAgICAgICAgICBzZXR0aW5nc1ZhbHVlID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHNldHRpbmdzXzEubG9hZENvbmZpZ3MoKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlnID0gX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIENTc2V0dGluZ3MgPSBjb25maWcuQ1NzZXR0aW5ncztcclxuICAgICAgICAgICAgICAgICAgICAvLyBUeXBlIG9mIFNldHRpbmdzXHJcbiAgICAgICAgICAgICAgICAgICAgc3dpdGNoICh0eXBlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJjaGVja1wiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0dGluZ3NWYWx1ZSA9IGV2ZW50LnRhcmdldC5jaGVja2VkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJudW1iZXJcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldHRpbmdzVmFsdWUgPSBwYXJzZUludChldmVudC50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJzdHJpbmdcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZSA9PT0gXCJyZXNldFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yTGlzdCA9IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidG9wQ29sb3JEYW5nZXJcIiwgXCJ0b3BDb2xvcldhcm5pbmdcIiwgXCJ0b3BDb2xvclN1Y2Nlc3NcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwibWluaUNvbG9yRGFuZ2VyXCIsIFwibWluaUNvbG9yV2FybmluZ1wiLCBcIm1pbmlDb2xvclN1Y2Nlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKF9pID0gMCwgY29sb3JMaXN0XzEgPSBjb2xvckxpc3Q7IF9pIDwgY29sb3JMaXN0XzEubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrID0gY29sb3JMaXN0XzFbX2ldO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ1NzZXR0aW5nc1trXSA9IHNldHRpbmdzXzEuRGVmYXVsdFNldHRpbmdzW2tdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGspO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBAdHMtaWdub3JlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcS52YWx1ZSA9IHNldHRpbmdzXzEuRGVmYXVsdFNldHRpbmdzW2tdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBAdHMtaWdub3JlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENTc2V0dGluZ3Nbc2V0dGluZ3NJRF0gPSBzZXR0aW5nc1ZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEuc2F2ZVRvTG9jYWxTdG9yYWdlKFwiQ1NfU2V0dGluZ3NcIiwgQ1NzZXR0aW5ncyldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCByZWRyYXdGYXZvcml0ZXNCYXIoY29udGVudF9zY3JpcHRfMS5jb3Vyc2VJRExpc3QsIHRydWUpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMzpcclxuICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLnVwZGF0ZVNldHRpbmdzID0gdXBkYXRlU2V0dGluZ3M7XHJcbi8qKlxyXG4gKiBBZGQgTWVtbyB0byBtaW5pU2FrYWkgYW5kIHNhdmUuXHJcbiAqL1xyXG5mdW5jdGlvbiBhZGRNZW1vKCkge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBzZWxlY3RlZElkeCwgY291cnNlSUQsIG1lbW9UaXRsZSwgbWVtb0R1ZURhdGVUaW1lc3RhbXAsIG1lbW9MaXN0LCBtZW1vRW50cnksIG1lbW8sIGlkeCwgYXNzaWdubWVudExpc3QsIHF1aXpMaXN0O1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkSWR4ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi50b2RvTGVjTmFtZVwiKS5zZWxlY3RlZEluZGV4O1xyXG4gICAgICAgICAgICAgICAgICAgIGNvdXJzZUlEID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi50b2RvTGVjTmFtZVwiKS5vcHRpb25zW3NlbGVjdGVkSWR4XS5pZDtcclxuICAgICAgICAgICAgICAgICAgICBtZW1vVGl0bGUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnRvZG9Db250ZW50XCIpLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIG1lbW9EdWVEYXRlVGltZXN0YW1wID0gbmV3IERhdGUoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi50b2RvRHVlXCIpLnZhbHVlKS5nZXRUaW1lKCkgLyAxMDAwO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5sb2FkRnJvbUxvY2FsU3RvcmFnZShcIkNTX01lbW9MaXN0XCIpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBtZW1vTGlzdCA9IF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICBtZW1vRW50cnkgPSBuZXcgbW9kZWxfMS5Bc3NpZ25tZW50RW50cnkodXRpbHNfMS5nZW5VbmlxdWVJRChcIm1cIiksIG1lbW9UaXRsZSwgbWVtb0R1ZURhdGVUaW1lc3RhbXAsIG1lbW9EdWVEYXRlVGltZXN0YW1wLCB0cnVlLCBmYWxzZSwgZmFsc2UsIFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIG1lbW8gPSBuZXcgbW9kZWxfMS5Bc3NpZ25tZW50KG5ldyBtb2RlbF8xLkNvdXJzZVNpdGVJbmZvKGNvdXJzZUlELCBjb3Vyc2VJRCksIFttZW1vRW50cnldLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lbW9MaXN0ICE9PSBcInVuZGVmaW5lZFwiICYmIG1lbW9MaXN0Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVtb0xpc3QgPSB1dGlsc18xLmNvbnZlcnRBcnJheVRvQXNzaWdubWVudChtZW1vTGlzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkeCA9IG1lbW9MaXN0LmZpbmRJbmRleChmdW5jdGlvbiAob2xkTWVtbykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9sZE1lbW8uY291cnNlU2l0ZUluZm8uY291cnNlSUQgPT09IGNvdXJzZUlEO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlkeCAhPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lbW9MaXN0W2lkeF0uYXNzaWdubWVudEVudHJpZXMucHVzaChtZW1vRW50cnkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVtb0xpc3QucHVzaChtZW1vKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVtb0xpc3QgPSBbbWVtb107XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHN0b3JhZ2VfMS5zYXZlVG9Mb2NhbFN0b3JhZ2UoXCJDU19NZW1vTGlzdFwiLCBtZW1vTGlzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudExpc3QgPSB1dGlsc18xLm1lcmdlSW50b0Fzc2lnbm1lbnRMaXN0KGNvbnRlbnRfc2NyaXB0XzEubWVyZ2VkQXNzaWdubWVudExpc3ROb01lbW8sIG1lbW9MaXN0KTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEubG9hZEZyb21Mb2NhbFN0b3JhZ2UoXCJDU19RdWl6TGlzdFwiKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDI6XHJcbiAgICAgICAgICAgICAgICAgICAgcXVpekxpc3QgPSBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVkcmF3TWluaVNha2FpKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgbWluaXNha2FpXzEuZGlzcGxheU1pbmlTYWthaSh1dGlsc18xLm1lcmdlSW50b0Fzc2lnbm1lbnRMaXN0KGFzc2lnbm1lbnRMaXN0LCBxdWl6TGlzdCksIGNvbnRlbnRfc2NyaXB0XzEuY291cnNlSURMaXN0KV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDM6XHJcbiAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHJlZHJhd0Zhdm9yaXRlc0Jhcihjb250ZW50X3NjcmlwdF8xLmNvdXJzZUlETGlzdCwgdHJ1ZSldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OlxyXG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMuYWRkTWVtbyA9IGFkZE1lbW87XHJcbi8qKlxyXG4gKiBEZWxldGUgTWVtbyBmcm9tIG1pbmlTYWthaSBhbmQgc3RvcmFnZS5cclxuICovXHJcbmZ1bmN0aW9uIGRlbGV0ZU1lbW8oZXZlbnQpIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgbWVtb0lELCBtZW1vTGlzdCwgX2EsIGRlbGV0ZWRNZW1vTGlzdCwgX2ksIG1lbW9MaXN0XzEsIG1lbW8sIG1lbW9FbnRyaWVzLCBfYiwgX2MsIG1lbW9FbnRyeSwgYXNzaWdubWVudExpc3QsIHF1aXpMaXN0O1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2QpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfZC5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgICAgIG1lbW9JRCA9IGV2ZW50LnRhcmdldC5pZDtcclxuICAgICAgICAgICAgICAgICAgICBfYSA9IHV0aWxzXzEuY29udmVydEFycmF5VG9Bc3NpZ25tZW50O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHN0b3JhZ2VfMS5sb2FkRnJvbUxvY2FsU3RvcmFnZShcIkNTX01lbW9MaXN0XCIpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBtZW1vTGlzdCA9IF9hLmFwcGx5KHZvaWQgMCwgW19kLnNlbnQoKV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGRlbGV0ZWRNZW1vTGlzdCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAoX2kgPSAwLCBtZW1vTGlzdF8xID0gbWVtb0xpc3Q7IF9pIDwgbWVtb0xpc3RfMS5sZW5ndGg7IF9pKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVtbyA9IG1lbW9MaXN0XzFbX2ldO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZW1vRW50cmllcyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKF9iID0gMCwgX2MgPSBtZW1vLmFzc2lnbm1lbnRFbnRyaWVzOyBfYiA8IF9jLmxlbmd0aDsgX2IrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVtb0VudHJ5ID0gX2NbX2JdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1lbW9FbnRyeS5hc3NpZ25tZW50SUQgIT09IG1lbW9JRClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZW1vRW50cmllcy5wdXNoKG1lbW9FbnRyeSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlZE1lbW9MaXN0LnB1c2gobmV3IG1vZGVsXzEuQXNzaWdubWVudChtZW1vLmNvdXJzZVNpdGVJbmZvLCBtZW1vRW50cmllcywgbWVtby5pc1JlYWQpKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgc3RvcmFnZV8xLnNhdmVUb0xvY2FsU3RvcmFnZShcIkNTX01lbW9MaXN0XCIsIGRlbGV0ZWRNZW1vTGlzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudExpc3QgPSB1dGlsc18xLm1lcmdlSW50b0Fzc2lnbm1lbnRMaXN0KGNvbnRlbnRfc2NyaXB0XzEubWVyZ2VkQXNzaWdubWVudExpc3ROb01lbW8sIGRlbGV0ZWRNZW1vTGlzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLmxvYWRGcm9tTG9jYWxTdG9yYWdlKFwiQ1NfUXVpekxpc3RcIildO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgICAgIHF1aXpMaXN0ID0gX2Quc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJlZHJhd01pbmlTYWthaSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIG1pbmlzYWthaV8xLmRpc3BsYXlNaW5pU2FrYWkodXRpbHNfMS5tZXJnZUludG9Bc3NpZ25tZW50TGlzdChhc3NpZ25tZW50TGlzdCwgcXVpekxpc3QpLCBjb250ZW50X3NjcmlwdF8xLmNvdXJzZUlETGlzdCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAzOlxyXG4gICAgICAgICAgICAgICAgICAgIF9kLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCByZWRyYXdGYXZvcml0ZXNCYXIoY29udGVudF9zY3JpcHRfMS5jb3Vyc2VJRExpc3QsIHRydWUpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNDpcclxuICAgICAgICAgICAgICAgICAgICBfZC5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLmRlbGV0ZU1lbW8gPSBkZWxldGVNZW1vO1xyXG4vKipcclxuICogRWRpdCBkZWZhdWx0IG1lc3NhZ2Ugb2YgZmF2b3JpdGVzIHRhYi5cclxuICovXHJcbmZ1bmN0aW9uIGVkaXRGYXZvcml0ZXNNZXNzYWdlKCkge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBtZXNzYWdlLCBsZWN0dXJlVGFicywgbGVjdHVyZVRhYnNDb3VudCwgaTtcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogXHJcbiAgICAgICAgICAgICAgICAvLyBXYWl0IDIwMG1zIHVudGlsIGpRdWVyeSBmaW5pc2hlZCBnZW5lcmF0aW5nIG1lc3NhZ2UuXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBuZXcgUHJvbWlzZShmdW5jdGlvbiAocikgeyByZXR1cm4gc2V0VGltZW91dChyLCAyMDApOyB9KV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gV2FpdCAyMDBtcyB1bnRpbCBqUXVlcnkgZmluaXNoZWQgZ2VuZXJhdGluZyBtZXNzYWdlLlxyXG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImZhdm9yaXRlcy1tYXgtbWFya2VyXCIpWzBdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmlubmVySFRNTCA9IFwiPGkgY2xhc3M9XFxcImZhIGZhLWJlbGwgd2FybmluZy1pY29uXFxcIj48L2k+XCIgKyBjaHJvbWUucnVudGltZS5nZXRNYW5pZmVzdCgpLm5hbWUgKyBcIlxcdTMwNkJcXHUzMDg4XFx1MzA2M1xcdTMwNjZcXHUzMDRBXFx1NkMxN1xcdTMwNkJcXHU1MTY1XFx1MzA4QVxcdTc2N0JcXHU5MzMyXFx1MzA1N1xcdTMwNUY8YnI+XFx1MzBCNVxcdTMwQTRcXHUzMEM4XFx1MzA0Q1xcdTUxNjhcXHUzMDY2XFx1MzBEMFxcdTMwRkNcXHUzMDZCXFx1OEZGRFxcdTUyQTBcXHUzMDU1XFx1MzA4Q1xcdTMwN0VcXHUzMDU3XFx1MzA1RlxcdTMwMDJcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGVjdHVyZVRhYnMgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiZmF2LXNpdGVzLWVudHJ5XCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZWN0dXJlVGFic0NvdW50ID0gbGVjdHVyZVRhYnMubGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGkgPSAwOyBpIDwgbGVjdHVyZVRhYnNDb3VudDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWN0dXJlVGFic1tpXS5jbGFzc0xpc3QucmVtb3ZlKFwic2l0ZS1mYXZvcml0ZS1pcy1wYXN0LW1heFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImNvdWxkIG5vdCBlZGl0IG1lc3NhZ2VcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuZXhwb3J0cy5lZGl0RmF2b3JpdGVzTWVzc2FnZSA9IGVkaXRGYXZvcml0ZXNNZXNzYWdlO1xyXG4vKipcclxuICogUmVkcmF3IGZhdm9yaXRlcyBiYXJcclxuICogQHBhcmFtIHtDb3Vyc2VTaXRlSW5mb1tdfSBjb3Vyc2VJRExpc3RcclxuICogQHBhcmFtIHtib29sZWFufSB1c2VDYWNoZVxyXG4gKi9cclxuZnVuY3Rpb24gcmVkcmF3RmF2b3JpdGVzQmFyKGNvdXJzZUlETGlzdCwgdXNlQ2FjaGUpIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgY29uZmlnLCBuZXdBc3NpZ25tZW50TGlzdDtcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICBtaW5pc2FrYWlfMS5kZWxldGVGYXZvcml0ZXNCYXJOb3RpZmljYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzZXR0aW5nc18xLmxvYWRDb25maWdzKCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbmZpZyA9IF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBjb250ZW50X3NjcmlwdF8xLmxvYWRBbmRNZXJnZUFzc2lnbm1lbnRMaXN0KGNvbmZpZywgY291cnNlSURMaXN0LCB1c2VDYWNoZSwgdXNlQ2FjaGUpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICBuZXdBc3NpZ25tZW50TGlzdCA9IF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBtaW5pc2FrYWlfMS5jcmVhdGVGYXZvcml0ZXNCYXJOb3RpZmljYXRpb24oY291cnNlSURMaXN0LCBuZXdBc3NpZ25tZW50TGlzdCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAzOlxyXG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbi8qKlxyXG4gKiBSZWRyYXcgbWluaVNha2FpXHJcbiAqL1xyXG5mdW5jdGlvbiByZWRyYXdNaW5pU2FrYWkoKSB7XHJcbiAgICB3aGlsZSAoZG9tXzEubWluaVNha2FpLmZpcnN0Q2hpbGQpIHtcclxuICAgICAgICBkb21fMS5taW5pU2FrYWkucmVtb3ZlQ2hpbGQoZG9tXzEubWluaVNha2FpLmZpcnN0Q2hpbGQpO1xyXG4gICAgfVxyXG4gICAgd2hpbGUgKGRvbV8xLmFzc2lnbm1lbnREaXYuZmlyc3RDaGlsZCkge1xyXG4gICAgICAgIGRvbV8xLmFzc2lnbm1lbnREaXYucmVtb3ZlQ2hpbGQoZG9tXzEuYXNzaWdubWVudERpdi5maXJzdENoaWxkKTtcclxuICAgIH1cclxuICAgIGRvbV8xLm1pbmlTYWthaS5yZW1vdmUoKTtcclxuICAgIGRvbV8xLmFzc2lnbm1lbnREaXYucmVtb3ZlKCk7XHJcbn1cclxuIiwiXCJ1c2Ugc3RyaWN0XCI7XHJcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcclxuZXhwb3J0cy5hZGRGYXZvcml0ZWRDb3Vyc2VTaXRlcyA9IHZvaWQgMDtcclxudmFyIGV2ZW50TGlzdGVuZXJfMSA9IHJlcXVpcmUoXCIuL2V2ZW50TGlzdGVuZXJcIik7XHJcbi8qKlxyXG4gKiBMaW1pdCBtYXhpbXVtIG51bWJlciBvZiBjb3Vyc2Ugc2l0ZXNcclxuICogQHR5cGUge2ludH1cclxuICovXHJcbnZhciBNQVhfRkFWT1JJVEVTID0gMjA7XHJcbmZ1bmN0aW9uIGdldFNpdGVJZEFuZEhyZWZTaXRlTmFtZU1hcCgpIHtcclxuICAgIHZhciBzaXRlcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuZmF2LXNpdGVzLWVudHJ5XCIpO1xyXG4gICAgdmFyIG1hcCA9IG5ldyBNYXAoKTtcclxuICAgIHNpdGVzLmZvckVhY2goZnVuY3Rpb24gKHNpdGUpIHtcclxuICAgICAgICB2YXIgX2EsIF9iLCBfYztcclxuICAgICAgICB2YXIgc2l0ZUlkID0gKF9hID0gc2l0ZS5xdWVyeVNlbGVjdG9yKFwiLnNpdGUtZmF2b3JpdGUtYnRuXCIpKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuZ2V0QXR0cmlidXRlKFwiZGF0YS1zaXRlLWlkXCIpO1xyXG4gICAgICAgIGlmIChzaXRlSWQgPT0gbnVsbClcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIHZhciBocmVmID0gKChfYiA9IHNpdGUucXVlcnlTZWxlY3RvcihcIi5mYXYtdGl0bGVcIikpID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYi5jaGlsZE5vZGVzWzFdKS5ocmVmO1xyXG4gICAgICAgIHZhciB0aXRsZSA9ICgoX2MgPSBzaXRlLnF1ZXJ5U2VsZWN0b3IoXCIuZmF2LXRpdGxlXCIpKSA9PT0gbnVsbCB8fCBfYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2MuY2hpbGROb2Rlc1sxXSkudGl0bGU7XHJcbiAgICAgICAgbWFwLnNldChzaXRlSWQsIHsgaHJlZjogaHJlZiwgdGl0bGU6IHRpdGxlIH0pO1xyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gbWFwO1xyXG59XHJcbi8qKlxyXG4gKiBDaGVjayBpZiBjdXJyZW50IHNpdGUtaWQgaXMgZ2l2ZW4gc2l0ZS1pZFxyXG4gKiBAcGFyYW0ge3N0cmluZ30gc2l0ZUlkXHJcbiAqL1xyXG5mdW5jdGlvbiBpc0N1cnJlbnRTaXRlKHNpdGVJZCkge1xyXG4gICAgdmFyIGN1cnJlbnRTaXRlSWRNID0gd2luZG93LmxvY2F0aW9uLmhyZWYubWF0Y2goL2h0dHBzPzpcXC9cXC9bXlxcL10rXFwvcG9ydGFsXFwvc2l0ZVxcLyhbXlxcL10rKS8pO1xyXG4gICAgaWYgKGN1cnJlbnRTaXRlSWRNID09IG51bGwpXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgcmV0dXJuIGN1cnJlbnRTaXRlSWRNWzFdID09IHNpdGVJZDtcclxufVxyXG4vKipcclxuICogR2V0IGhyZWZzIG9mIHNpdGVzIGluIGZhdm9yaXRlIGJhclxyXG4gKi9cclxuZnVuY3Rpb24gZ2V0Q3VycmVudEZhdm9yaXRlc1NpdGUoKSB7XHJcbiAgICB2YXIgdG9wbmF2ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiN0b3BuYXZcIik7XHJcbiAgICBpZiAodG9wbmF2ID09IG51bGwpXHJcbiAgICAgICAgcmV0dXJuIG5ldyBBcnJheSgpO1xyXG4gICAgdmFyIHNpdGVzID0gdG9wbmF2LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuTXJwaHMtc2l0ZXNOYXZfX21lbnVpdGVtXCIpO1xyXG4gICAgdmFyIGhyZWZzID0gW107XHJcbiAgICBmb3IgKHZhciBfaSA9IDAsIF9hID0gQXJyYXkuZnJvbShzaXRlcyk7IF9pIDwgX2EubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgdmFyIHNpdGUgPSBfYVtfaV07XHJcbiAgICAgICAgdmFyIGhyZWYgPSBzaXRlLmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJsaW5rLWNvbnRhaW5lclwiKVswXS5ocmVmO1xyXG4gICAgICAgIGhyZWZzLnB1c2goaHJlZik7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaHJlZnM7XHJcbn1cclxuLyoqXHJcbiAqIEFkZCBjb3Vyc2Ugc2l0ZXMgdG8gZmF2b3JpdGVzIGJhciAobW9yZSB0aGFuIFNha2FpIGNvbmZpZylcclxuICogQHBhcmFtIHtzdHJpbmd9IGJhc2VVUkxcclxuICovXHJcbmZ1bmN0aW9uIGFkZEZhdm9yaXRlZENvdXJzZVNpdGVzKGJhc2VVUkwpIHtcclxuICAgIHZhciBfYTtcclxuICAgIHZhciB0b3BuYXYgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3RvcG5hdlwiKTtcclxuICAgIGlmICh0b3BuYXYgPT0gbnVsbClcclxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkgeyByZXR1cm4gcmVzb2x2ZSgpOyB9KTtcclxuICAgIHZhciByZXF1ZXN0ID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XHJcbiAgICByZXF1ZXN0Lm9wZW4oXCJHRVRcIiwgYmFzZVVSTCArIFwiL3BvcnRhbC9mYXZvcml0ZXMvbGlzdFwiKTtcclxuICAgIHJlcXVlc3QucmVzcG9uc2VUeXBlID0gXCJqc29uXCI7XHJcbiAgICAoX2EgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLm9yZ2FuaXplRmF2b3JpdGVzXCIpKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGV2ZW50TGlzdGVuZXJfMS5lZGl0RmF2b3JpdGVzTWVzc2FnZSk7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xyXG4gICAgICAgIHJlcXVlc3QuYWRkRXZlbnRMaXN0ZW5lcihcImxvYWRcIiwgZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICAgICAgdmFyIHJlcyA9IHJlcXVlc3QucmVzcG9uc2U7XHJcbiAgICAgICAgICAgIGlmIChyZXMgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJmYWlsZWQgdG8gZmV0Y2ggZmF2b3JpdGVzIGxpc3RcIik7XHJcbiAgICAgICAgICAgICAgICByZWplY3QoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB2YXIgZmF2b3JpdGVzID0gcmVzLmZhdm9yaXRlU2l0ZUlkcztcclxuICAgICAgICAgICAgdmFyIHNpdGVzSW5mbyA9IGdldFNpdGVJZEFuZEhyZWZTaXRlTmFtZU1hcCgpO1xyXG4gICAgICAgICAgICB2YXIgY3VycmVudEZhdm9yaXRlU2l0ZSA9IGdldEN1cnJlbnRGYXZvcml0ZXNTaXRlKCk7XHJcbiAgICAgICAgICAgIHZhciBfbG9vcF8xID0gZnVuY3Rpb24gKGZhdm9yaXRlKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBza2lwIGlmIGZhdm9yaXRlIGlzIHRoZSBjdXJyZW50IHNpdGVcclxuICAgICAgICAgICAgICAgIGlmIChpc0N1cnJlbnRTaXRlKGZhdm9yaXRlKSlcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJjb250aW51ZVwiO1xyXG4gICAgICAgICAgICAgICAgdmFyIHNpdGVJbmZvID0gc2l0ZXNJbmZvLmdldChmYXZvcml0ZSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoc2l0ZUluZm8gPT0gdW5kZWZpbmVkKVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcImNvbnRpbnVlXCI7XHJcbiAgICAgICAgICAgICAgICB2YXIgaHJlZiA9IHNpdGVJbmZvLmhyZWY7XHJcbiAgICAgICAgICAgICAgICB2YXIgdGl0bGUgPSBzaXRlSW5mby50aXRsZTtcclxuICAgICAgICAgICAgICAgIC8vIHNraXAgaWYgdGhlIHNpdGUgaXMgYWxyZWFkeSBzaG93blxyXG4gICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRGYXZvcml0ZVNpdGUuZmluZChmdW5jdGlvbiAoYykgeyByZXR1cm4gYyA9PSBocmVmOyB9KSAhPSBudWxsKVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcImNvbnRpbnVlXCI7XHJcbiAgICAgICAgICAgICAgICB2YXIgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlcIik7XHJcbiAgICAgICAgICAgICAgICBsaS5jbGFzc0xpc3QuYWRkKFwiTXJwaHMtc2l0ZXNOYXZfX21lbnVpdGVtXCIpO1xyXG4gICAgICAgICAgICAgICAgdmFyIGFuY2hvciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhXCIpO1xyXG4gICAgICAgICAgICAgICAgYW5jaG9yLmNsYXNzTGlzdC5hZGQoXCJsaW5rLWNvbnRhaW5lclwiKTtcclxuICAgICAgICAgICAgICAgIGFuY2hvci5ocmVmID0gaHJlZjtcclxuICAgICAgICAgICAgICAgIGFuY2hvci50aXRsZSA9IHRpdGxlO1xyXG4gICAgICAgICAgICAgICAgdmFyIHNwYW4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcclxuICAgICAgICAgICAgICAgIHNwYW4uaW5uZXJUZXh0ID0gdGl0bGU7XHJcbiAgICAgICAgICAgICAgICBhbmNob3IuYXBwZW5kQ2hpbGQoc3Bhbik7XHJcbiAgICAgICAgICAgICAgICBsaS5hcHBlbmRDaGlsZChhbmNob3IpO1xyXG4gICAgICAgICAgICAgICAgdG9wbmF2LmFwcGVuZENoaWxkKGxpKTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IGZhdm9yaXRlcy5zbGljZSgwLCBNQVhfRkFWT1JJVEVTKTsgX2kgPCBfYS5sZW5ndGg7IF9pKyspIHtcclxuICAgICAgICAgICAgICAgIHZhciBmYXZvcml0ZSA9IF9hW19pXTtcclxuICAgICAgICAgICAgICAgIF9sb29wXzEoZmF2b3JpdGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXF1ZXN0LnNlbmQoKTtcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMuYWRkRmF2b3JpdGVkQ291cnNlU2l0ZXMgPSBhZGRGYXZvcml0ZWRDb3Vyc2VTaXRlcztcclxuIiwiXCJ1c2Ugc3RyaWN0XCI7XHJcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xyXG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufTtcclxudmFyIF9fZ2VuZXJhdG9yID0gKHRoaXMgJiYgdGhpcy5fX2dlbmVyYXRvcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59O1xyXG52YXIgX19pbXBvcnREZWZhdWx0ID0gKHRoaXMgJiYgdGhpcy5fX2ltcG9ydERlZmF1bHQpIHx8IGZ1bmN0aW9uIChtb2QpIHtcclxuICAgIHJldHVybiAobW9kICYmIG1vZC5fX2VzTW9kdWxlKSA/IG1vZCA6IHsgXCJkZWZhdWx0XCI6IG1vZCB9O1xyXG59O1xyXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XHJcbmV4cG9ydHMuY3JlYXRlRmF2b3JpdGVzQmFyTm90aWZpY2F0aW9uID0gZXhwb3J0cy5kZWxldGVGYXZvcml0ZXNCYXJOb3RpZmljYXRpb24gPSBleHBvcnRzLmRpc3BsYXlNaW5pU2FrYWkgPSBleHBvcnRzLmNyZWF0ZU1pbmlTYWthaSA9IGV4cG9ydHMuY3JlYXRlTWluaVNha2FpQnRuID0gZXhwb3J0cy5jcmVhdGVNaW5pU2FrYWlHZW5lcmFsaXplZCA9IHZvaWQgMDtcclxudmFyIG1vZGVsXzEgPSByZXF1aXJlKFwiLi9tb2RlbFwiKTtcclxudmFyIHV0aWxzXzEgPSByZXF1aXJlKFwiLi91dGlsc1wiKTtcclxudmFyIGRvbV8xID0gcmVxdWlyZShcIi4vZG9tXCIpO1xyXG52YXIgZXZlbnRMaXN0ZW5lcl8xID0gcmVxdWlyZShcIi4vZXZlbnRMaXN0ZW5lclwiKTtcclxuLy8gQHRzLWlnbm9yZVxyXG52YXIgbXVzdGFjaGVfMSA9IF9faW1wb3J0RGVmYXVsdChyZXF1aXJlKFwibXVzdGFjaGVcIikpO1xyXG52YXIgc2V0dGluZ3NfMSA9IHJlcXVpcmUoXCIuL3NldHRpbmdzXCIpO1xyXG4vKipcclxuICogQ3JlYXRlIGEgYnV0dG9uIHRvIG9wZW4gbWluaVNha2FpXHJcbiAqL1xyXG5mdW5jdGlvbiBjcmVhdGVNaW5pU2FrYWlCdG4oKSB7XHJcbiAgICB2YXIgdG9wYmFyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJtYXN0TG9naW5cIik7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHRvcGJhciA9PT0gbnVsbCB8fCB0b3BiYXIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHRvcGJhci5hcHBlbmRDaGlsZChkb21fMS5oYW1idXJnZXIpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcImNvdWxkIG5vdCBsYXVuY2ggbWluaVNha2FpLlwiKTtcclxuICAgIH1cclxufVxyXG5leHBvcnRzLmNyZWF0ZU1pbmlTYWthaUJ0biA9IGNyZWF0ZU1pbmlTYWthaUJ0bjtcclxuLyoqXHJcbiAqIFVzaW5nIHRlbXBsYXRlIGVuZ2luZSB0byBnZW5lcmF0ZSBtaW5pU2FrYWkgbGlzdC5cclxuICovXHJcbmZ1bmN0aW9uIGNyZWF0ZU1pbmlTYWthaUdlbmVyYWxpemVkKHJvb3QsIGFzc2lnbm1lbnRMaXN0LCBjb3Vyc2VTaXRlSW5mb3MsIHN1YnNldCwgaW5zZXJ0aW9uUHJvY2Vzcykge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBjb25maWcsIGFzc2lnbm1lbnRGZXRjaGVkVGltZVN0cmluZywgcXVpekZldGNoZWRUaW1lU3RyaW5nLCBjb3Vyc2VTaXRlTGlzdCwgY291cnNlSURNYXAsIGRhbmdlckVsZW1lbnRzLCB3YXJuaW5nRWxlbWVudHMsIHN1Y2Nlc3NFbGVtZW50cywgb3RoZXJFbGVtZW50cywgbGF0ZVN1Ym1pdEVsZW1lbnRzLCBzb3J0RWxlbWVudHMsIG5vQXNzaWdubWVudEltZywgYXNzaWdubWVudENudCwgX2ksIGFzc2lnbm1lbnRMaXN0XzEsIGFzc2lnbm1lbnQsIHRlbXBsYXRlVmFycztcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogcmV0dXJuIFs0IC8qeWllbGQqLywgc2V0dGluZ3NfMS5sb2FkQ29uZmlncygpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBjb25maWcgPSBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudEZldGNoZWRUaW1lU3RyaW5nID0gdXRpbHNfMS5mb3JtYXRUaW1lc3RhbXAoY29uZmlnLmZldGNoZWRUaW1lLmFzc2lnbm1lbnQpO1xyXG4gICAgICAgICAgICAgICAgICAgIHF1aXpGZXRjaGVkVGltZVN0cmluZyA9IHV0aWxzXzEuZm9ybWF0VGltZXN0YW1wKGNvbmZpZy5mZXRjaGVkVGltZS5xdWl6KTtcclxuICAgICAgICAgICAgICAgICAgICBjb3Vyc2VTaXRlTGlzdCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvdXJzZUlETWFwID0gdXRpbHNfMS5jcmVhdGVDb3Vyc2VJRE1hcChjb3Vyc2VTaXRlSW5mb3MpO1xyXG4gICAgICAgICAgICAgICAgICAgIGRhbmdlckVsZW1lbnRzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgd2FybmluZ0VsZW1lbnRzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgc3VjY2Vzc0VsZW1lbnRzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgb3RoZXJFbGVtZW50cyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIGxhdGVTdWJtaXRFbGVtZW50cyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGl0ZXJhdGUgb3ZlciBjb3Vyc2VTaXRlXHJcbiAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudExpc3QuZm9yRWFjaChmdW5jdGlvbiAoYXNzaWdubWVudCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgY291cnNlTmFtZSA9IGNvdXJzZUlETWFwLmdldChhc3NpZ25tZW50LmNvdXJzZVNpdGVJbmZvLmNvdXJzZUlEKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaXRlcmF0ZSBvdmVyIGFzc2lnbm1lbnQgZW50cmllc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzLmZvckVhY2goZnVuY3Rpb24gKGFzc2lnbm1lbnRFbnRyeSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGRheXNVbnRpbER1ZSA9IHV0aWxzXzEuZ2V0RGF5c1VudGlsKHV0aWxzXzEubm93VGltZSwgYXNzaWdubWVudEVudHJ5LmdldER1ZURhdGVUaW1lc3RhbXAgKiAxMDAwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBkaXNwbGF5QXNzaWdubWVudEVudHJ5ID0gbmV3IG1vZGVsXzEuRGlzcGxheUFzc2lnbm1lbnRFbnRyeShhc3NpZ25tZW50LmNvdXJzZVNpdGVJbmZvLmNvdXJzZUlELCBhc3NpZ25tZW50RW50cnkuYXNzaWdubWVudElELCBhc3NpZ25tZW50RW50cnkuYXNzaWdubWVudFRpdGxlLCBhc3NpZ25tZW50RW50cnkuZHVlRGF0ZVRpbWVzdGFtcCwgYXNzaWdubWVudEVudHJ5LmNsb3NlRGF0ZVRpbWVzdGFtcCwgYXNzaWdubWVudEVudHJ5LmlzRmluaXNoZWQsIGFzc2lnbm1lbnRFbnRyeS5pc1F1aXosIGFzc2lnbm1lbnRFbnRyeS5pc01lbW8pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGRpc3BsYXlBc3NpZ25tZW50ID0gbmV3IG1vZGVsXzEuRGlzcGxheUFzc2lnbm1lbnQoW2Rpc3BsYXlBc3NpZ25tZW50RW50cnldLCBjb3Vyc2VOYW1lLCBhc3NpZ25tZW50LmdldFRvcFNpdGUoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgYXBwZW5kRWxlbWVudCA9IGZ1bmN0aW9uIChjb3Vyc2VOYW1lLCBkaXNwbGF5QXNzaWdubWVudHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgY291cnNlTmFtZU1hcCA9IGRpc3BsYXlBc3NpZ25tZW50cy5tYXAoZnVuY3Rpb24gKGUpIHsgcmV0dXJuIGUuY291cnNlTmFtZTsgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvdXJzZU5hbWVNYXAuaW5jbHVkZXMoY291cnNlTmFtZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlkeCA9IGNvdXJzZU5hbWVNYXAuaW5kZXhPZihjb3Vyc2VOYW1lKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheUFzc2lnbm1lbnRzW2lkeF0uYXNzaWdubWVudEVudHJpZXMucHVzaChkaXNwbGF5QXNzaWdubWVudEVudHJ5KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheUFzc2lnbm1lbnRzW2lkeF0uYXNzaWdubWVudEVudHJpZXMuc29ydChmdW5jdGlvbiAoYSwgYikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGEuZ2V0RHVlRGF0ZVRpbWVzdGFtcCAtIGIuZ2V0RHVlRGF0ZVRpbWVzdGFtcDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5QXNzaWdubWVudHMucHVzaChkaXNwbGF5QXNzaWdubWVudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFwcGVuZCBlbGVtZW50cyBhY2NvcmRpbmcgdG8gZHVlIGRhdGUgY2F0ZWdvcnlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN3aXRjaCAoZGF5c1VudGlsRHVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcImR1ZTI0aFwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcHBlbmRFbGVtZW50KGNvdXJzZU5hbWUsIGRhbmdlckVsZW1lbnRzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcImR1ZTVkXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwcGVuZEVsZW1lbnQoY291cnNlTmFtZSwgd2FybmluZ0VsZW1lbnRzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcImR1ZTE0ZFwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcHBlbmRFbGVtZW50KGNvdXJzZU5hbWUsIHN1Y2Nlc3NFbGVtZW50cyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJkdWVPdmVyMTRkXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwcGVuZEVsZW1lbnQoY291cnNlTmFtZSwgb3RoZXJFbGVtZW50cyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJkdWVQYXNzZWRcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNhc2UtZGVjbGFyYXRpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBzaG93TGF0ZVN1Ym1pdEFzc2lnbm1lbnQgPSBjb25maWcuQ1NzZXR0aW5ncyA/IGNvbmZpZy5DU3NldHRpbmdzLmdldERpc3BsYXlMYXRlU3VibWl0QXNzaWdubWVudCA6IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2hvd0xhdGVTdWJtaXRBc3NpZ25tZW50ICYmIHV0aWxzXzEuZ2V0RGF5c1VudGlsKHV0aWxzXzEubm93VGltZSwgYXNzaWdubWVudEVudHJ5LmdldENsb3NlRGF0ZVRpbWVzdGFtcCAqIDEwMDApICE9PSBcImR1ZVBhc3NlZFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcHBlbmRFbGVtZW50KGNvdXJzZU5hbWUsIGxhdGVTdWJtaXRFbGVtZW50cyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3Vyc2VTaXRlTGlzdC5wdXNoKG5ldyBtb2RlbF8xLkNvdXJzZVNpdGVJbmZvKGFzc2lnbm1lbnQuY291cnNlU2l0ZUluZm8uY291cnNlSUQsIGNvdXJzZU5hbWUpKTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBzb3J0RWxlbWVudHMgPSBmdW5jdGlvbiAoZWxlbWVudHMsIGlzTGF0ZVN1Ym1pc3Npb24pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzTGF0ZVN1Ym1pc3Npb24gPT09IHZvaWQgMCkgeyBpc0xhdGVTdWJtaXNzaW9uID0gZmFsc2U7IH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudHMuc29ydChmdW5jdGlvbiAoYSwgYikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHRpbWVzdGFtcDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc0xhdGVTdWJtaXNzaW9uKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZXN0YW1wID0gZnVuY3Rpb24gKG8pIHsgcmV0dXJuIE1hdGgubWluLmFwcGx5KE1hdGgsIG8uYXNzaWdubWVudEVudHJpZXMubWFwKGZ1bmN0aW9uIChwKSB7IHJldHVybiBwLmdldENsb3NlRGF0ZVRpbWVzdGFtcDsgfSkpOyB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZXN0YW1wID0gZnVuY3Rpb24gKG8pIHsgcmV0dXJuIE1hdGgubWluLmFwcGx5KE1hdGgsIG8uYXNzaWdubWVudEVudHJpZXMubWFwKGZ1bmN0aW9uIChwKSB7IHJldHVybiBwLmdldER1ZURhdGVUaW1lc3RhbXA7IH0pKTsgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aW1lc3RhbXAoYSkgLSB0aW1lc3RhbXAoYik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZWxlbWVudHM7XHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICBub0Fzc2lnbm1lbnRJbWcgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgIGFzc2lnbm1lbnRDbnQgPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChhc3NpZ25tZW50TGlzdC5sZW5ndGggIT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChfaSA9IDAsIGFzc2lnbm1lbnRMaXN0XzEgPSBhc3NpZ25tZW50TGlzdDsgX2kgPCBhc3NpZ25tZW50TGlzdF8xLmxlbmd0aDsgX2krKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudCA9IGFzc2lnbm1lbnRMaXN0XzFbX2ldO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudENudCArPSBhc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzLmxlbmd0aDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAoYXNzaWdubWVudExpc3QubGVuZ3RoID09PSAwIHx8IGFzc2lnbm1lbnRDbnQgPT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbm9Bc3NpZ25tZW50SW1nID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW1nOiBjaHJvbWUucnVudGltZS5nZXRVUkwoXCJpbWcvbm9Bc3NpZ25tZW50LnBuZ1wiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVWYXJzID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmZXRjaGVkVGltZToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudDogYXNzaWdubWVudEZldGNoZWRUaW1lU3RyaW5nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVpejogcXVpekZldGNoZWRUaW1lU3RyaW5nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW5pU2FrYWlMb2dvOiBjaHJvbWUucnVudGltZS5nZXRVUkwoXCJpbWcvbG9nby5wbmdcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFZFUlNJT046IGNvbmZpZy52ZXJzaW9uLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdWJzZXQ6IHN1YnNldCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbm9Bc3NpZ25tZW50OiBub0Fzc2lnbm1lbnRJbWcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnRzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYW5nZXI6IHNvcnRFbGVtZW50cyhkYW5nZXJFbGVtZW50cyksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3YXJuaW5nOiBzb3J0RWxlbWVudHMod2FybmluZ0VsZW1lbnRzKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3M6IHNvcnRFbGVtZW50cyhzdWNjZXNzRWxlbWVudHMpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3RoZXI6IHNvcnRFbGVtZW50cyhvdGhlckVsZW1lbnRzKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhdGVTdWJtaXQ6IHNvcnRFbGVtZW50cyhsYXRlU3VibWl0RWxlbWVudHMsIHRydWUpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYW5nZXI6IGRhbmdlckVsZW1lbnRzLmxlbmd0aCA+IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3YXJuaW5nOiB3YXJuaW5nRWxlbWVudHMubGVuZ3RoID4gMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3M6IHN1Y2Nlc3NFbGVtZW50cy5sZW5ndGggPiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3RoZXI6IG90aGVyRWxlbWVudHMubGVuZ3RoID4gMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhdGVTdWJtaXQ6IGxhdGVTdWJtaXRFbGVtZW50cy5sZW5ndGggPiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZXM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzc2lnbm1lbnRUYWI6IGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJ0YWJfYXNzaWdubWVudHNcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXR0aW5nc1RhYjogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcInRhYl9zZXR0aW5nc1wiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFzc2lnbm1lbnRGZXRjaGVkVGltZTogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcImFzc2lnbm1lbnRfYWNxdWlzaXRpb25fZGF0ZVwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1aXpGZXRjaGVkVGltZTogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcInRlc3RxdWl6X2FjcXVpc2l0aW9uX2RhdGVcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkdWUyNGg6IGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJkdWUyNGhcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkdWU1ZDogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcImR1ZTVkXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZHVlMTRkOiBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKFwiZHVlMTRkXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZHVlT3ZlcjE0ZDogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcImR1ZU92ZXIxNGRcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkdWVQYXNzZWQ6IGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJkdWVQYXNzZWRcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBub0Fzc2lnbm1lbnQ6IGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJub19hdmFpbGFibGVfYXNzaWdubWVudHNcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvZG9Cb3g6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZU5hbWU6IGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJ0b2RvX2JveF9jb3Vyc2VfbmFtZVwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lbW9MYWJlbDogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcInRvZG9fYm94X21lbW9cIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkdWVEYXRlOiBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKFwidG9kb19ib3hfZHVlX2RhdGVcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRCdG5MYWJlbDogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcInRvZG9fYm94X2FkZFwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZVNpdGVMaXN0OiBjb3Vyc2VTaXRlTGlzdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmFkZ2U6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lbW86IGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJtZW1vXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVpejogY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcInF1aXpcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBMb2FkIG11c3RhY2hlXHJcbiAgICAgICAgICAgICAgICAgICAgZmV0Y2goY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKFwidmlld3MvbWluaXNha2FpLm11c3RhY2hlXCIpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzKSB7IHJldHVybiByZXMudGV4dCgpOyB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAodGVtcGxhdGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlbmRlcmVkID0gbXVzdGFjaGVfMS5kZWZhdWx0LnJlbmRlcih0ZW1wbGF0ZSwgdGVtcGxhdGVWYXJzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW5zZXJ0aW9uUHJvY2VzcyhyZW5kZXJlZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZ2lzdGVyRXZlbnRIYW5kbGVycyhyb290KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFzdWJzZXQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjcmVhdGVTZXR0aW5nc1RhYihyb290KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW5pdFN0YXRlKHJvb3QpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuZXhwb3J0cy5jcmVhdGVNaW5pU2FrYWlHZW5lcmFsaXplZCA9IGNyZWF0ZU1pbmlTYWthaUdlbmVyYWxpemVkO1xyXG4vKipcclxuICogSW5zZXJ0IG1pbmlTYWthaSBpbnRvIFNha2FpLlxyXG4gKi9cclxuZnVuY3Rpb24gY3JlYXRlTWluaVNha2FpKGFzc2lnbm1lbnRMaXN0LCBjb3Vyc2VTaXRlSW5mb3MpIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogcmV0dXJuIFs0IC8qeWllbGQqLywgY3JlYXRlTWluaVNha2FpR2VuZXJhbGl6ZWQoZG9tXzEubWluaVNha2FpLCBhc3NpZ25tZW50TGlzdCwgY291cnNlU2l0ZUluZm9zLCBmYWxzZSwgZnVuY3Rpb24gKHJlbmRlcmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRvbV8xLm1pbmlTYWthaS5pbm5lckhUTUwgPSByZW5kZXJlZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBhcmVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicGFnZUJvZHlcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZWYgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRvb2xNZW51V3JhcFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyZW50ID09PSBudWxsIHx8IHBhcmVudCA9PT0gdm9pZCAwID8gdm9pZCAwIDogcGFyZW50Lmluc2VydEJlZm9yZShkb21fMS5taW5pU2FrYWksIHJlZik7XHJcbiAgICAgICAgICAgICAgICAgICAgfSldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMuY3JlYXRlTWluaVNha2FpID0gY3JlYXRlTWluaVNha2FpO1xyXG4vKipcclxuICogSW5pdGlhbGl6ZSBTZXR0aW5ncyB0YWIuXHJcbiAqL1xyXG5mdW5jdGlvbiBjcmVhdGVTZXR0aW5nc1RhYihyb290KSB7XHJcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIGNvbmZpZztcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogcmV0dXJuIFs0IC8qeWllbGQqLywgc2V0dGluZ3NfMS5sb2FkQ29uZmlncygpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBjb25maWcgPSBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlU2V0dGluZ0l0ZW0ocm9vdCwgY2hyb21lLmkxOG4uZ2V0TWVzc2FnZSgnc2V0dGluZ3NfY29sb3JfY2hlY2tlZF9pdGVtJyksIGNvbmZpZy5DU3NldHRpbmdzLmdldERpc3BsYXlDaGVja2VkQXNzaWdubWVudCwgXCJkaXNwbGF5Q2hlY2tlZEFzc2lnbm1lbnRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlU2V0dGluZ0l0ZW0ocm9vdCwgY2hyb21lLmkxOG4uZ2V0TWVzc2FnZSgnc2V0dGluZ3NfZGlzcGxheV9sYXRlX3N1Ym1pdF9hc3NpZ25tZW50JyksIGNvbmZpZy5DU3NldHRpbmdzLmdldERpc3BsYXlMYXRlU3VibWl0QXNzaWdubWVudCwgXCJkaXNwbGF5TGF0ZVN1Ym1pdEFzc2lnbm1lbnRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlU2V0dGluZ0l0ZW0ocm9vdCwgY2hyb21lLmkxOG4uZ2V0TWVzc2FnZSgnc2V0dGluZ3NfYXNzaWdubWVudF9jYWNoZScpLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRBc3NpZ25tZW50Q2FjaGVJbnRlcnZhbCwgXCJhc3NpZ25tZW50Q2FjaGVJbnRlcnZhbFwiKTtcclxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVTZXR0aW5nSXRlbShyb290LCBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKCdzZXR0aW5nc19xdWl6emVzX2NhY2hlJyksIGNvbmZpZy5DU3NldHRpbmdzLmdldFF1aXpDYWNoZUludGVydmFsLCBcInF1aXpDYWNoZUludGVydmFsXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZVNldHRpbmdJdGVtKHJvb3QsIGNocm9tZS5pMThuLmdldE1lc3NhZ2UoJ3NldHRpbmdzX2NvbG9yc19ob3VyJywgWydUYWIgQmFyJywgJzI0J10pLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRUb3BDb2xvckRhbmdlciwgXCJ0b3BDb2xvckRhbmdlclwiKTtcclxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVTZXR0aW5nSXRlbShyb290LCBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKCdzZXR0aW5nc19jb2xvcnNfZGF5JywgWydUYWIgQmFyJywgJzUnXSksIGNvbmZpZy5DU3NldHRpbmdzLmdldFRvcENvbG9yV2FybmluZywgXCJ0b3BDb2xvcldhcm5pbmdcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlU2V0dGluZ0l0ZW0ocm9vdCwgY2hyb21lLmkxOG4uZ2V0TWVzc2FnZSgnc2V0dGluZ3NfY29sb3JzX2RheScsIFsnVGFiIEJhcicsICcxNCddKSwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0VG9wQ29sb3JTdWNjZXNzLCBcInRvcENvbG9yU3VjY2Vzc1wiKTtcclxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVTZXR0aW5nSXRlbShyb290LCBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKCdzZXR0aW5nc19jb2xvcnNfaG91cicsIFsnbWluaVBhbmRBJywgJzI0J10pLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRNaW5pQ29sb3JEYW5nZXIsIFwibWluaUNvbG9yRGFuZ2VyXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZVNldHRpbmdJdGVtKHJvb3QsIGNocm9tZS5pMThuLmdldE1lc3NhZ2UoJ3NldHRpbmdzX2NvbG9yc19kYXknLCBbJ21pbmlQYW5kQScsICc1J10pLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRNaW5pQ29sb3JXYXJuaW5nLCBcIm1pbmlDb2xvcldhcm5pbmdcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlU2V0dGluZ0l0ZW0ocm9vdCwgY2hyb21lLmkxOG4uZ2V0TWVzc2FnZSgnc2V0dGluZ3NfY29sb3JzX2RheScsIFsnbWluaVBhbmRBJywgJzE0J10pLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRNaW5pQ29sb3JTdWNjZXNzLCBcIm1pbmlDb2xvclN1Y2Nlc3NcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlU2V0dGluZ0l0ZW0ocm9vdCwgY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcInNldHRpbmdzX3Jlc2V0X2NvbG9yc1wiKSwgXCJyZXNldFwiLCBcInJlc2V0XCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIEB0cy1pZ25vcmVcclxuICAgICAgICAgICAgICAgICAgICByb290LnF1ZXJ5U2VsZWN0b3IoXCIuY3Mtc2V0dGluZ3MtdGFiXCIpLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbi8qKlxyXG4gKiBDcmVhdGUgU2V0dGluZ3MgdGFiIGl0ZW0uXHJcbiAqL1xyXG5mdW5jdGlvbiBjcmVhdGVTZXR0aW5nSXRlbShyb290LCBpdGVtRGVzY3JpcHRpb24sIHZhbHVlLCBpZCwgZGlzcGxheSkge1xyXG4gICAgaWYgKGRpc3BsYXkgPT09IHZvaWQgMCkgeyBkaXNwbGF5ID0gdHJ1ZTsgfVxyXG4gICAgdmFyIHNldHRpbmdzRGl2ID0gcm9vdC5xdWVyeVNlbGVjdG9yKFwiLmNzLXNldHRpbmdzLXRhYlwiKTtcclxuICAgIGlmIChzZXR0aW5nc0RpdiA9PSBudWxsKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCIuY3Mtc2V0dGluZ3MtdGFiIG5vdCBmb3VuZFwiKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICB2YXIgbWFpbkRpdiA9IGRvbV8xLlNldHRpbmdzRG9tLm1haW5EaXYuY2xvbmVOb2RlKHRydWUpO1xyXG4gICAgdmFyIGxhYmVsID0gZG9tXzEuU2V0dGluZ3NEb20ubGFiZWwuY2xvbmVOb2RlKHRydWUpO1xyXG4gICAgdmFyIHAgPSBkb21fMS5TZXR0aW5nc0RvbS5wLmNsb25lTm9kZSh0cnVlKTtcclxuICAgIHAuaW5uZXJUZXh0ID0gaXRlbURlc2NyaXB0aW9uO1xyXG4gICAgaWYgKCFkaXNwbGF5KVxyXG4gICAgICAgIG1haW5EaXYuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xyXG4gICAgdmFyIHNldHRpbmdJdGVtO1xyXG4gICAgdmFyIHNwYW4gPSBkb21fMS5TZXR0aW5nc0RvbS5zcGFuLmNsb25lTm9kZSh0cnVlKTtcclxuICAgIHN3aXRjaCAodHlwZW9mIHZhbHVlKSB7XHJcbiAgICAgICAgY2FzZSBcImJvb2xlYW5cIjpcclxuICAgICAgICAgICAgbGFiZWwuY2xhc3NMaXN0LmFkZChcImNzLXRvZ2dsZS1idG5cIik7XHJcbiAgICAgICAgICAgIHNldHRpbmdJdGVtID0gZG9tXzEuY2xvbmVFbGVtKGRvbV8xLlNldHRpbmdzRG9tLnRvZ2dsZUJ0biwgeyBjaGVja2VkOiB2YWx1ZSwgaWQ6IGlkIH0sIHsgXCJjaGFuZ2VcIjogZnVuY3Rpb24gKHJlcykgeyBldmVudExpc3RlbmVyXzEudXBkYXRlU2V0dGluZ3MocmVzLCBcImNoZWNrXCIpOyB9IH0pO1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlIFwibnVtYmVyXCI6XHJcbiAgICAgICAgICAgIHNldHRpbmdJdGVtID0gZG9tXzEuY2xvbmVFbGVtKGRvbV8xLlNldHRpbmdzRG9tLmlucHV0Qm94LCB7IHZhbHVlOiB2YWx1ZSwgaWQ6IGlkIH0sIHsgXCJjaGFuZ2VcIjogZnVuY3Rpb24gKHJlcykgeyBldmVudExpc3RlbmVyXzEudXBkYXRlU2V0dGluZ3MocmVzLCBcIm51bWJlclwiKTsgfSB9KTtcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSBcInN0cmluZ1wiOlxyXG4gICAgICAgICAgICBpZiAoaWQgPT09IFwicmVzZXRcIikge1xyXG4gICAgICAgICAgICAgICAgc2V0dGluZ0l0ZW0gPSBkb21fMS5jbG9uZUVsZW0oZG9tXzEuU2V0dGluZ3NEb20ucmVzZXRCdG4sIHsgdmFsdWU6IHZhbHVlLCBpZDogaWQgfSwgeyBcImNsaWNrXCI6IGZ1bmN0aW9uIChyZXMpIHsgZXZlbnRMaXN0ZW5lcl8xLnVwZGF0ZVNldHRpbmdzKHJlcywgXCJyZXNldFwiKTsgfSB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHNldHRpbmdJdGVtID0gZG9tXzEuY2xvbmVFbGVtKGRvbV8xLlNldHRpbmdzRG9tLnN0cmluZ0JveCwgeyB2YWx1ZTogdmFsdWUsIGlkOiBpZCB9LCB7IFwiY2hhbmdlXCI6IGZ1bmN0aW9uIChyZXMpIHsgZXZlbnRMaXN0ZW5lcl8xLnVwZGF0ZVNldHRpbmdzKHJlcywgXCJzdHJpbmdcIik7IH0gfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcImJvb2xlYW5cIilcclxuICAgICAgICBkb21fMS5hcHBlbmRDaGlsZEFsbChsYWJlbCwgW3NldHRpbmdJdGVtLCBzcGFuXSk7XHJcbiAgICBlbHNlXHJcbiAgICAgICAgZG9tXzEuYXBwZW5kQ2hpbGRBbGwobGFiZWwsIFtzZXR0aW5nSXRlbV0pO1xyXG4gICAgZG9tXzEuYXBwZW5kQ2hpbGRBbGwobWFpbkRpdiwgW3AsIGxhYmVsXSk7XHJcbiAgICBzZXR0aW5nc0Rpdi5hcHBlbmRDaGlsZChtYWluRGl2KTtcclxufVxyXG4vKipcclxuICogQWRkIGV2ZW50IGxpc3RlbmVyIHRvIGVhY2ggU2V0dGluZ3MgaXRlbVxyXG4gKi9cclxuZnVuY3Rpb24gcmVnaXN0ZXJFdmVudEhhbmRsZXJzKHJvb3QpIHtcclxuICAgIHZhciBfYSwgX2IsIF9jLCBfZCwgX2U7XHJcbiAgICAoX2EgPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIjYXNzaWdubWVudFRhYlwiKSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbiAoKSB7IHJldHVybiBldmVudExpc3RlbmVyXzEudG9nZ2xlQXNzaWdubWVudFRhYigpOyB9KTtcclxuICAgIChfYiA9IHJvb3QucXVlcnlTZWxlY3RvcihcIiNzZXR0aW5nc1RhYlwiKSkgPT09IG51bGwgfHwgX2IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9iLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbiAoKSB7IHJldHVybiBldmVudExpc3RlbmVyXzEudG9nZ2xlU2V0dGluZ3NUYWIoKTsgfSk7XHJcbiAgICByb290LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuY3MtY2hlY2tib3hcIikuZm9yRWFjaChmdW5jdGlvbiAoYykgeyByZXR1cm4gYy5hZGRFdmVudExpc3RlbmVyKFwiY2hhbmdlXCIsIGZ1bmN0aW9uIChlKSB7IHJldHVybiBldmVudExpc3RlbmVyXzEudG9nZ2xlRmluaXNoZWRGbGFnKGUpOyB9KTsgfSk7XHJcbiAgICAoX2MgPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIjY2xvc2VfYnRuXCIpKSA9PT0gbnVsbCB8fCBfYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2MuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIGV2ZW50TGlzdGVuZXJfMS50b2dnbGVNaW5pU2FrYWkoKTsgfSk7XHJcbiAgICAoX2QgPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIjY3MtYWRkLW1lbW8tYnRuXCIpKSA9PT0gbnVsbCB8fCBfZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2QuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIGV2ZW50TGlzdGVuZXJfMS50b2dnbGVNZW1vQm94KCk7IH0pO1xyXG4gICAgKF9lID0gcm9vdC5xdWVyeVNlbGVjdG9yKFwiI3RvZG8tYWRkXCIpKSA9PT0gbnVsbCB8fCBfZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2UuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIGV2ZW50TGlzdGVuZXJfMS5hZGRNZW1vKCk7IH0pO1xyXG4gICAgcm9vdC5xdWVyeVNlbGVjdG9yQWxsKFwiLmNzLWRlbC1tZW1vLWJ0blwiKS5mb3JFYWNoKGZ1bmN0aW9uIChiKSB7IHJldHVybiBiLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbiAoZSkgeyByZXR1cm4gZXZlbnRMaXN0ZW5lcl8xLmRlbGV0ZU1lbW8oZSk7IH0pOyB9KTtcclxufVxyXG4vKipcclxuICogSW5pdGlhbGl6ZSBzdGF0ZXNcclxuICovXHJcbmZ1bmN0aW9uIGluaXRTdGF0ZShyb290KSB7XHJcbiAgICAvLyBAdHMtaWdub3JlXHJcbiAgICByb290LnF1ZXJ5U2VsZWN0b3IoXCIjYXNzaWdubWVudFRhYlwiKS5jaGVja2VkID0gdHJ1ZTtcclxuICAgIC8vIEB0cy1pZ25vcmVcclxuICAgIHJvb3QucXVlcnlTZWxlY3RvcihcIi50b2RvRHVlXCIpLnZhbHVlID0gbmV3IERhdGUobmV3IERhdGUoKS50b0lTT1N0cmluZygpLnN1YnN0cigwLCAxNikgKyBcIi0xMDowMFwiKVxyXG4gICAgICAgIC50b0lTT1N0cmluZygpXHJcbiAgICAgICAgLnN1YnN0cigwLCAxNik7XHJcbn1cclxuLyoqXHJcbiAqIERpc3BsYXkgbWluaVNha2FpXHJcbiAqL1xyXG5mdW5jdGlvbiBkaXNwbGF5TWluaVNha2FpKG1lcmdlZEFzc2lnbm1lbnRMaXN0LCBjb3Vyc2VTaXRlSW5mb3MpIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogcmV0dXJuIFs0IC8qeWllbGQqLywgY3JlYXRlTWluaVNha2FpKG1lcmdlZEFzc2lnbm1lbnRMaXN0LCBjb3Vyc2VTaXRlSW5mb3MpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdXRpbHNfMS5taW5pU2FrYWlSZWFkeSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuZXhwb3J0cy5kaXNwbGF5TWluaVNha2FpID0gZGlzcGxheU1pbmlTYWthaTtcclxuLyoqXHJcbiAqIEFkZCBub3RpZmljYXRpb24gYmFkZ2UgZm9yIG5ldyBBc3NpZ25tZW50L1F1aXpcclxuICovXHJcbmZ1bmN0aW9uIGNyZWF0ZUZhdm9yaXRlc0Jhck5vdGlmaWNhdGlvbihjb3Vyc2VTaXRlSW5mb3MsIGFzc2lnbm1lbnRMaXN0KSB7XHJcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIGNvbmZpZywgZGVmYXVsdFRhYiwgZGVmYXVsdFRhYkNvdW50LCBfaSwgY291cnNlU2l0ZUluZm9zXzEsIGNvdXJzZVNpdGVJbmZvLCBfbG9vcF8xLCBqO1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBzZXR0aW5nc18xLmxvYWRDb25maWdzKCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbmZpZyA9IF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VGFiID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5NcnBocy1zaXRlc05hdl9fbWVudWl0ZW1cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFRhYkNvdW50ID0gT2JqZWN0LmtleXMoZGVmYXVsdFRhYikubGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAoX2kgPSAwLCBjb3Vyc2VTaXRlSW5mb3NfMSA9IGNvdXJzZVNpdGVJbmZvczsgX2kgPCBjb3Vyc2VTaXRlSW5mb3NfMS5sZW5ndGg7IF9pKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291cnNlU2l0ZUluZm8gPSBjb3Vyc2VTaXRlSW5mb3NfMVtfaV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9sb29wXzEgPSBmdW5jdGlvbiAoaikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNvdXJzZUlEID0gZGVmYXVsdFRhYltqXS5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwibGluay1jb250YWluZXJcIilbMF0uaHJlZi5tYXRjaChcIihodHRwcz86Ly9bXi9dKykvcG9ydGFsL3NpdGUtP1thLXpdKi8oW14vXSspXCIpWzJdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHEgPSBhc3NpZ25tZW50TGlzdC5maW5kSW5kZXgoZnVuY3Rpb24gKGFzc2lnbm1lbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYXNzaWdubWVudC5jb3Vyc2VTaXRlSW5mby5jb3Vyc2VJRCA9PT0gY291cnNlSUQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChxICE9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjbG9zZXN0VGltZSA9IChjb25maWcuQ1NzZXR0aW5ncy5kaXNwbGF5Q2hlY2tlZEFzc2lnbm1lbnQpID8gYXNzaWdubWVudExpc3RbcV0uY2xvc2VzdER1ZURhdGVUaW1lc3RhbXAgOiBhc3NpZ25tZW50TGlzdFtxXS5jbG9zZXN0RHVlRGF0ZVRpbWVzdGFtcEV4Y2x1ZGVGaW5pc2hlZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWFzc2lnbm1lbnRMaXN0W3FdLmlzUmVhZCAmJiBjbG9zZXN0VGltZSAhPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFRhYltqXS5jbGFzc0xpc3QuYWRkKFwiY3Mtbm90aWZpY2F0aW9uLWJhZGdlXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGF5c1VudGlsRHVlID0gdXRpbHNfMS5nZXREYXlzVW50aWwodXRpbHNfMS5ub3dUaW1lLCBjbG9zZXN0VGltZSAqIDEwMDApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBhVGFnQ291bnQgPSBkZWZhdWx0VGFiW2pdLmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiYVwiKS5sZW5ndGg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoIChkYXlzVW50aWxEdWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcImR1ZTI0aFwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFRhYltqXS5jbGFzc0xpc3QuYWRkKFwiY3MtdGFiLWRhbmdlclwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYVRhZ0NvdW50OyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VGFiW2pdLmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiYVwiKVtpXS5jbGFzc0xpc3QuYWRkKFwiY3MtdGFiLWRhbmdlclwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiZHVlNWRcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRUYWJbal0uY2xhc3NMaXN0LmFkZChcImNzLXRhYi13YXJuaW5nXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhVGFnQ291bnQ7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRUYWJbal0uZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJhXCIpW2ldLmNsYXNzTGlzdC5hZGQoXCJjcy10YWItd2FybmluZ1wiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiZHVlMTRkXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VGFiW2pdLmNsYXNzTGlzdC5hZGQoXCJjcy10YWItc3VjY2Vzc1wiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYVRhZ0NvdW50OyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VGFiW2pdLmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiYVwiKVtpXS5jbGFzc0xpc3QuYWRkKFwiY3MtdGFiLXN1Y2Nlc3NcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcImR1ZU92ZXIxNGRcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRUYWJbal0uY2xhc3NMaXN0LmFkZChcImNzLXRhYi1vdGhlclwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYVRhZ0NvdW50OyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VGFiW2pdLmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiYVwiKVtpXS5jbGFzc0xpc3QuYWRkKFwiY3MtdGFiLW90aGVyXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGogPSAyOyBqIDwgZGVmYXVsdFRhYkNvdW50OyBqKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9sb29wXzEoaik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgb3ZlcnJpZGVDU1NDb2xvcigpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLmNyZWF0ZUZhdm9yaXRlc0Jhck5vdGlmaWNhdGlvbiA9IGNyZWF0ZUZhdm9yaXRlc0Jhck5vdGlmaWNhdGlvbjtcclxuLyoqXHJcbiAqIERlbGV0ZSBub3RpZmljYXRpb24gYmFkZ2UgZm9yIG5ldyBBc3NpZ25tZW50L1F1aXpcclxuICovXHJcbmZ1bmN0aW9uIGRlbGV0ZUZhdm9yaXRlc0Jhck5vdGlmaWNhdGlvbigpIHtcclxuICAgIHZhciBjbGFzc2xpc3QgPSBbXCJjcy1ub3RpZmljYXRpb24tYmFkZ2VcIiwgXCJjcy10YWItZGFuZ2VyXCIsIFwiY3MtdGFiLXdhcm5pbmdcIiwgXCJjcy10YWItc3VjY2Vzc1wiXTtcclxuICAgIGZvciAodmFyIF9pID0gMCwgY2xhc3NsaXN0XzEgPSBjbGFzc2xpc3Q7IF9pIDwgY2xhc3NsaXN0XzEubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgdmFyIGMgPSBjbGFzc2xpc3RfMVtfaV07XHJcbiAgICAgICAgdmFyIHEgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLlwiICsgYyk7XHJcbiAgICAgICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgICAgIGZvciAodmFyIF9hID0gMCwgcV8xID0gcTsgX2EgPCBxXzEubGVuZ3RoOyBfYSsrKSB7XHJcbiAgICAgICAgICAgIHZhciBfMSA9IHFfMVtfYV07XHJcbiAgICAgICAgICAgIF8xLmNsYXNzTGlzdC5yZW1vdmUoXCJcIiArIGMpO1xyXG4gICAgICAgICAgICBfMS5zdHlsZSA9IFwiXCI7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbmV4cG9ydHMuZGVsZXRlRmF2b3JpdGVzQmFyTm90aWZpY2F0aW9uID0gZGVsZXRlRmF2b3JpdGVzQmFyTm90aWZpY2F0aW9uO1xyXG4vKipcclxuICogT3ZlcnJpZGUgQ1NTIG9mIGZhdm9yaXRlcyBiYXIgYW5kIG1pbmlTYWthaS5cclxuICovXHJcbmZ1bmN0aW9uIG92ZXJyaWRlQ1NTQ29sb3IoKSB7XHJcbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdmFyIGNvbmZpZywgb3ZlcndyaXRlYm9yZGVyLCBvdmVyd3JpdGViYWNrZ3JvdW5kO1xyXG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcclxuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBzZXR0aW5nc18xLmxvYWRDb25maWdzKCldO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbmZpZyA9IF9hLnNlbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICBvdmVyd3JpdGVib3JkZXIgPSBmdW5jdGlvbiAoY2xhc3NOYW1lLCBjb2xvcikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoY2xhc3NOYW1lKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBlbGVtZW50Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZWxlbSA9IGVsZW1lbnRbaV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgYXR0ciA9IFwic29saWQgMnB4IFwiICsgY29sb3I7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtLnN0eWxlW1wiYm9yZGVyLXRvcFwiXSA9IGF0dHI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtLnN0eWxlW1wiYm9yZGVyLWxlZnRcIl0gPSBhdHRyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbS5zdHlsZVtcImJvcmRlci1ib3R0b21cIl0gPSBhdHRyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbS5zdHlsZVtcImJvcmRlci1yaWdodFwiXSA9IGF0dHI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgIG92ZXJ3cml0ZWJhY2tncm91bmQgPSBmdW5jdGlvbiAoY2xhc3NOYW1lLCBjb2xvcikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoY2xhc3NOYW1lKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBlbGVtZW50Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZWxlbSA9IGVsZW1lbnRbaV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtLnNldEF0dHJpYnV0ZShcInN0eWxlXCIsIFwiYmFja2dyb3VuZDpcIiArIGNvbG9yICsgXCIhaW1wb3J0YW50XCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBPdmVyd3JpdGUgY29sb3JzXHJcbiAgICAgICAgICAgICAgICAgICAgb3ZlcndyaXRlYmFja2dyb3VuZChcImNzLWNvdXJzZS1kYW5nZXJcIiwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0TWluaUNvbG9yRGFuZ2VyKTtcclxuICAgICAgICAgICAgICAgICAgICBvdmVyd3JpdGViYWNrZ3JvdW5kKFwiY3MtY291cnNlLXdhcm5pbmdcIiwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0TWluaUNvbG9yV2FybmluZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgb3ZlcndyaXRlYmFja2dyb3VuZChcImNzLWNvdXJzZS1zdWNjZXNzXCIsIGNvbmZpZy5DU3NldHRpbmdzLmdldE1pbmlDb2xvclN1Y2Nlc3MpO1xyXG4gICAgICAgICAgICAgICAgICAgIG92ZXJ3cml0ZWJhY2tncm91bmQoXCJjcy10YWItZGFuZ2VyXCIsIGNvbmZpZy5DU3NldHRpbmdzLmdldFRvcENvbG9yRGFuZ2VyKTtcclxuICAgICAgICAgICAgICAgICAgICBvdmVyd3JpdGViYWNrZ3JvdW5kKFwiY3MtdGFiLXdhcm5pbmdcIiwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0VG9wQ29sb3JXYXJuaW5nKTtcclxuICAgICAgICAgICAgICAgICAgICBvdmVyd3JpdGViYWNrZ3JvdW5kKFwiY3MtdGFiLXN1Y2Nlc3NcIiwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0VG9wQ29sb3JTdWNjZXNzKTtcclxuICAgICAgICAgICAgICAgICAgICBvdmVyd3JpdGVib3JkZXIoXCJjcy1hc3NpZ25tZW50LWRhbmdlclwiLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRNaW5pQ29sb3JEYW5nZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgIG92ZXJ3cml0ZWJvcmRlcihcImNzLWFzc2lnbm1lbnQtd2FybmluZ1wiLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRNaW5pQ29sb3JXYXJuaW5nKTtcclxuICAgICAgICAgICAgICAgICAgICBvdmVyd3JpdGVib3JkZXIoXCJjcy1hc3NpZ25tZW50LXN1Y2Nlc3NcIiwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0TWluaUNvbG9yU3VjY2Vzcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgb3ZlcndyaXRlYm9yZGVyKFwiY3MtdGFiLWRhbmdlclwiLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRUb3BDb2xvckRhbmdlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgb3ZlcndyaXRlYm9yZGVyKFwiY3MtdGFiLXdhcm5pbmdcIiwgY29uZmlnLkNTc2V0dGluZ3MuZ2V0VG9wQ29sb3JXYXJuaW5nKTtcclxuICAgICAgICAgICAgICAgICAgICBvdmVyd3JpdGVib3JkZXIoXCJjcy10YWItc3VjY2Vzc1wiLCBjb25maWcuQ1NzZXR0aW5ncy5nZXRUb3BDb2xvclN1Y2Nlc3MpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuIiwiXCJ1c2Ugc3RyaWN0XCI7XHJcbnZhciBfX2V4dGVuZHMgPSAodGhpcyAmJiB0aGlzLl9fZXh0ZW5kcykgfHwgKGZ1bmN0aW9uICgpIHtcclxuICAgIHZhciBleHRlbmRTdGF0aWNzID0gZnVuY3Rpb24gKGQsIGIpIHtcclxuICAgICAgICBleHRlbmRTdGF0aWNzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8XHJcbiAgICAgICAgICAgICh7IF9fcHJvdG9fXzogW10gfSBpbnN0YW5jZW9mIEFycmF5ICYmIGZ1bmN0aW9uIChkLCBiKSB7IGQuX19wcm90b19fID0gYjsgfSkgfHxcclxuICAgICAgICAgICAgZnVuY3Rpb24gKGQsIGIpIHsgZm9yICh2YXIgcCBpbiBiKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGIsIHApKSBkW3BdID0gYltwXTsgfTtcclxuICAgICAgICByZXR1cm4gZXh0ZW5kU3RhdGljcyhkLCBiKTtcclxuICAgIH07XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKGQsIGIpIHtcclxuICAgICAgICBpZiAodHlwZW9mIGIgIT09IFwiZnVuY3Rpb25cIiAmJiBiICE9PSBudWxsKVxyXG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2xhc3MgZXh0ZW5kcyB2YWx1ZSBcIiArIFN0cmluZyhiKSArIFwiIGlzIG5vdCBhIGNvbnN0cnVjdG9yIG9yIG51bGxcIik7XHJcbiAgICAgICAgZXh0ZW5kU3RhdGljcyhkLCBiKTtcclxuICAgICAgICBmdW5jdGlvbiBfXygpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7IH1cclxuICAgICAgICBkLnByb3RvdHlwZSA9IGIgPT09IG51bGwgPyBPYmplY3QuY3JlYXRlKGIpIDogKF9fLnByb3RvdHlwZSA9IGIucHJvdG90eXBlLCBuZXcgX18oKSk7XHJcbiAgICB9O1xyXG59KSgpO1xyXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XHJcbmV4cG9ydHMuRGlzcGxheUFzc2lnbm1lbnQgPSBleHBvcnRzLkRpc3BsYXlBc3NpZ25tZW50RW50cnkgPSBleHBvcnRzLkNvdXJzZVNpdGVJbmZvID0gZXhwb3J0cy5Bc3NpZ25tZW50ID0gZXhwb3J0cy5Bc3NpZ25tZW50RW50cnkgPSB2b2lkIDA7XHJcbnZhciB1dGlsc18xID0gcmVxdWlyZShcIi4vdXRpbHNcIik7XHJcbnZhciBNQVhfVElNRVNUQU1QID0gOTk5OTk5OTk5OTk5OTk7XHJcbnZhciBBc3NpZ25tZW50RW50cnkgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XHJcbiAgICBmdW5jdGlvbiBBc3NpZ25tZW50RW50cnkoYXNzaWdubWVudElELCBhc3NpZ25tZW50VGl0bGUsIGR1ZURhdGVUaW1lc3RhbXAsIGNsb3NlRGF0ZVRpbWVzdGFtcCwgaXNNZW1vLCBpc0ZpbmlzaGVkLCBpc1F1aXosIGFzc2lnbm1lbnREZXRhaWwsIGFzc2lnbm1lbnRQYWdlKSB7XHJcbiAgICAgICAgdGhpcy5hc3NpZ25tZW50SUQgPSBhc3NpZ25tZW50SUQ7XHJcbiAgICAgICAgdGhpcy5hc3NpZ25tZW50VGl0bGUgPSBhc3NpZ25tZW50VGl0bGU7XHJcbiAgICAgICAgdGhpcy5hc3NpZ25tZW50RGV0YWlsID0gYXNzaWdubWVudERldGFpbDtcclxuICAgICAgICB0aGlzLmR1ZURhdGVUaW1lc3RhbXAgPSBkdWVEYXRlVGltZXN0YW1wO1xyXG4gICAgICAgIHRoaXMuY2xvc2VEYXRlVGltZXN0YW1wID0gY2xvc2VEYXRlVGltZXN0YW1wO1xyXG4gICAgICAgIHRoaXMuaXNNZW1vID0gaXNNZW1vO1xyXG4gICAgICAgIHRoaXMuaXNGaW5pc2hlZCA9IGlzRmluaXNoZWQ7XHJcbiAgICAgICAgdGhpcy5pc1F1aXogPSBpc1F1aXo7XHJcbiAgICAgICAgdGhpcy5hc3NpZ25tZW50UGFnZSA9IGFzc2lnbm1lbnRQYWdlO1xyXG4gICAgfVxyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KEFzc2lnbm1lbnRFbnRyeS5wcm90b3R5cGUsIFwiZ2V0RHVlRGF0ZVRpbWVzdGFtcFwiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmR1ZURhdGVUaW1lc3RhbXAgPyB0aGlzLmR1ZURhdGVUaW1lc3RhbXAgOiBNQVhfVElNRVNUQU1QO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShBc3NpZ25tZW50RW50cnkucHJvdG90eXBlLCBcImdldENsb3NlRGF0ZVRpbWVzdGFtcFwiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNsb3NlRGF0ZVRpbWVzdGFtcCA/IHRoaXMuY2xvc2VEYXRlVGltZXN0YW1wIDogTUFYX1RJTUVTVEFNUDtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gQXNzaWdubWVudEVudHJ5O1xyXG59KCkpO1xyXG5leHBvcnRzLkFzc2lnbm1lbnRFbnRyeSA9IEFzc2lnbm1lbnRFbnRyeTtcclxudmFyIEFzc2lnbm1lbnQgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XHJcbiAgICBmdW5jdGlvbiBBc3NpZ25tZW50KGNvdXJzZVNpdGVJbmZvLCBhc3NpZ25tZW50RW50cmllcywgaXNSZWFkKSB7XHJcbiAgICAgICAgdGhpcy5jb3Vyc2VTaXRlSW5mbyA9IGNvdXJzZVNpdGVJbmZvO1xyXG4gICAgICAgIHRoaXMuYXNzaWdubWVudEVudHJpZXMgPSBhc3NpZ25tZW50RW50cmllcztcclxuICAgICAgICB0aGlzLmlzUmVhZCA9IGlzUmVhZDtcclxuICAgIH1cclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShBc3NpZ25tZW50LnByb3RvdHlwZSwgXCJjbG9zZXN0RHVlRGF0ZVRpbWVzdGFtcFwiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmFzc2lnbm1lbnRFbnRyaWVzLmxlbmd0aCA9PSAwKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIC0xO1xyXG4gICAgICAgICAgICB2YXIgbWluID0gTUFYX1RJTUVTVEFNUDtcclxuICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IHRoaXMuYXNzaWdubWVudEVudHJpZXM7IF9pIDwgX2EubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgICAgICAgICB2YXIgZW50cnkgPSBfYVtfaV07XHJcbiAgICAgICAgICAgICAgICBpZiAobWluID4gZW50cnkuZ2V0RHVlRGF0ZVRpbWVzdGFtcCAmJiBlbnRyeS5nZXREdWVEYXRlVGltZXN0YW1wICogMTAwMCA+PSB1dGlsc18xLm5vd1RpbWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBtaW4gPSBlbnRyeS5nZXREdWVEYXRlVGltZXN0YW1wO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChtaW4gPT09IE1BWF9USU1FU1RBTVApXHJcbiAgICAgICAgICAgICAgICBtaW4gPSAtMTtcclxuICAgICAgICAgICAgcmV0dXJuIG1pbjtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoQXNzaWdubWVudC5wcm90b3R5cGUsIFwiY2xvc2VzdER1ZURhdGVUaW1lc3RhbXBFeGNsdWRlRmluaXNoZWRcIiwge1xyXG4gICAgICAgIC8vIOWujOS6hua4iOOBv+S7peWkluOBi+OCiWNsb3Nlc3RUaW1l44KS5Y+W5b6X44GZ44KLXHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmFzc2lnbm1lbnRFbnRyaWVzLmxlbmd0aCA9PSAwKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIC0xO1xyXG4gICAgICAgICAgICB2YXIgbWluID0gTUFYX1RJTUVTVEFNUDtcclxuICAgICAgICAgICAgdmFyIGV4Y2x1ZGVDb3VudCA9IDA7XHJcbiAgICAgICAgICAgIGZvciAodmFyIF9pID0gMCwgX2EgPSB0aGlzLmFzc2lnbm1lbnRFbnRyaWVzOyBfaSA8IF9hLmxlbmd0aDsgX2krKykge1xyXG4gICAgICAgICAgICAgICAgdmFyIGVudHJ5ID0gX2FbX2ldO1xyXG4gICAgICAgICAgICAgICAgaWYgKGVudHJ5LmlzRmluaXNoZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBleGNsdWRlQ291bnQrKztcclxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChtaW4gPiBlbnRyeS5nZXREdWVEYXRlVGltZXN0YW1wICYmIGVudHJ5LmdldER1ZURhdGVUaW1lc3RhbXAgKiAxMDAwID49IHV0aWxzXzEubm93VGltZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIG1pbiA9IGVudHJ5LmdldER1ZURhdGVUaW1lc3RhbXA7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGV4Y2x1ZGVDb3VudCA9PT0gdGhpcy5hc3NpZ25tZW50RW50cmllcy5sZW5ndGgpXHJcbiAgICAgICAgICAgICAgICBtaW4gPSAtMTtcclxuICAgICAgICAgICAgaWYgKG1pbiA9PT0gTUFYX1RJTUVTVEFNUClcclxuICAgICAgICAgICAgICAgIG1pbiA9IC0xO1xyXG4gICAgICAgICAgICByZXR1cm4gbWluO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIEFzc2lnbm1lbnQucHJvdG90eXBlLmdldFRvcFNpdGUgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IHRoaXMuYXNzaWdubWVudEVudHJpZXM7IF9pIDwgX2EubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgICAgIHZhciBlbnRyeSA9IF9hW19pXTtcclxuICAgICAgICAgICAgaWYgKGVudHJ5LmFzc2lnbm1lbnRQYWdlICE9IG51bGwpXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZW50cnkuYXNzaWdubWVudFBhZ2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBcIlwiO1xyXG4gICAgfTtcclxuICAgIHJldHVybiBBc3NpZ25tZW50O1xyXG59KCkpO1xyXG5leHBvcnRzLkFzc2lnbm1lbnQgPSBBc3NpZ25tZW50O1xyXG52YXIgQ291cnNlU2l0ZUluZm8gPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XHJcbiAgICBmdW5jdGlvbiBDb3Vyc2VTaXRlSW5mbyhjb3Vyc2VJRCwgY291cnNlTmFtZSkge1xyXG4gICAgICAgIHRoaXMuY291cnNlSUQgPSBjb3Vyc2VJRDtcclxuICAgICAgICB0aGlzLmNvdXJzZU5hbWUgPSBjb3Vyc2VOYW1lO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIENvdXJzZVNpdGVJbmZvO1xyXG59KCkpO1xyXG5leHBvcnRzLkNvdXJzZVNpdGVJbmZvID0gQ291cnNlU2l0ZUluZm87XHJcbnZhciBEaXNwbGF5QXNzaWdubWVudEVudHJ5ID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKF9zdXBlcikge1xyXG4gICAgX19leHRlbmRzKERpc3BsYXlBc3NpZ25tZW50RW50cnksIF9zdXBlcik7XHJcbiAgICBmdW5jdGlvbiBEaXNwbGF5QXNzaWdubWVudEVudHJ5KGNvdXJzZUlELCBhc3NpZ25tZW50SUQsIGFzc2lnbm1lbnRUaXRsZSwgZHVlRGF0ZVRpbWVzdGFtcCwgY2xvc2VEYXRlVGltZXN0YW1wLCBpc0ZpbmlzaGVkLCBpc1F1aXosIGlzTWVtbykge1xyXG4gICAgICAgIHZhciBfdGhpcyA9IF9zdXBlci5jYWxsKHRoaXMsIGFzc2lnbm1lbnRJRCwgYXNzaWdubWVudFRpdGxlLCBkdWVEYXRlVGltZXN0YW1wLCBjbG9zZURhdGVUaW1lc3RhbXAsIGlzTWVtbywgaXNGaW5pc2hlZCwgaXNRdWl6KSB8fCB0aGlzO1xyXG4gICAgICAgIF90aGlzLmNvdXJzZUlEID0gY291cnNlSUQ7XHJcbiAgICAgICAgcmV0dXJuIF90aGlzO1xyXG4gICAgfVxyXG4gICAgRGlzcGxheUFzc2lnbm1lbnRFbnRyeS5nZXRUaW1lUmVtYWluID0gZnVuY3Rpb24gKHJlbWFpblRpbWVzdGFtcCkge1xyXG4gICAgICAgIHZhciBkYXkgPSBNYXRoLmZsb29yKHJlbWFpblRpbWVzdGFtcCAvICgzNjAwICogMjQpKTtcclxuICAgICAgICB2YXIgaG91cnMgPSBNYXRoLmZsb29yKChyZW1haW5UaW1lc3RhbXAgLSBkYXkgKiAzNjAwICogMjQpIC8gMzYwMCk7XHJcbiAgICAgICAgdmFyIG1pbnV0ZXMgPSBNYXRoLmZsb29yKChyZW1haW5UaW1lc3RhbXAgLSAoZGF5ICogMzYwMCAqIDI0ICsgaG91cnMgKiAzNjAwKSkgLyA2MCk7XHJcbiAgICAgICAgcmV0dXJuIFtkYXkudG9TdHJpbmcoKSwgaG91cnMudG9TdHJpbmcoKSwgbWludXRlcy50b1N0cmluZygpXTtcclxuICAgIH07XHJcbiAgICBEaXNwbGF5QXNzaWdubWVudEVudHJ5LmNyZWF0ZVRpbWVTdHJpbmcgPSBmdW5jdGlvbiAodGltZXN0YW1wKSB7XHJcbiAgICAgICAgaWYgKCF0aW1lc3RhbXApXHJcbiAgICAgICAgICAgIHJldHVybiBjaHJvbWUuaTE4bi5nZXRNZXNzYWdlKFwiZHVlX25vdF9zZXRcIik7XHJcbiAgICAgICAgdmFyIHRpbWVSZW1haW4gPSBEaXNwbGF5QXNzaWdubWVudEVudHJ5LmdldFRpbWVSZW1haW4oKHRpbWVzdGFtcCAqIDEwMDAgLSB1dGlsc18xLm5vd1RpbWUpIC8gMTAwMCk7XHJcbiAgICAgICAgcmV0dXJuIGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJyZW1haW5fdGltZVwiLCBbdGltZVJlbWFpblswXSwgdGltZVJlbWFpblsxXSwgdGltZVJlbWFpblsyXV0pO1xyXG4gICAgfTtcclxuICAgIERpc3BsYXlBc3NpZ25tZW50RW50cnkuY3JlYXRlRGF0ZVN0cmluZyA9IGZ1bmN0aW9uICh0aW1lc3RhbXApIHtcclxuICAgICAgICBpZiAoIXRpbWVzdGFtcClcclxuICAgICAgICAgICAgcmV0dXJuIFwiLS0tLS8tLS8tLVwiO1xyXG4gICAgICAgIHZhciBkYXRlID0gbmV3IERhdGUodGltZXN0YW1wICogMTAwMCk7XHJcbiAgICAgICAgcmV0dXJuIGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKCkgKyBcIiBcIiArIGRhdGUuZ2V0SG91cnMoKSArIFwiOlwiICsgKFwiMDBcIiArIGRhdGUuZ2V0TWludXRlcygpKS5zbGljZSgtMik7XHJcbiAgICB9O1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KERpc3BsYXlBc3NpZ25tZW50RW50cnkucHJvdG90eXBlLCBcInJlbWFpblRpbWVTdHJpbmdcIiwge1xyXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gRGlzcGxheUFzc2lnbm1lbnRFbnRyeS5jcmVhdGVUaW1lU3RyaW5nKHRoaXMuZHVlRGF0ZVRpbWVzdGFtcCk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KERpc3BsYXlBc3NpZ25tZW50RW50cnkucHJvdG90eXBlLCBcInJlbWFpbkNsb3NlVGltZVN0cmluZ1wiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBEaXNwbGF5QXNzaWdubWVudEVudHJ5LmNyZWF0ZVRpbWVTdHJpbmcodGhpcy5jbG9zZURhdGVUaW1lc3RhbXApO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShEaXNwbGF5QXNzaWdubWVudEVudHJ5LnByb3RvdHlwZSwgXCJkdWVEYXRlU3RyaW5nXCIsIHtcclxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIERpc3BsYXlBc3NpZ25tZW50RW50cnkuY3JlYXRlRGF0ZVN0cmluZyh0aGlzLmR1ZURhdGVUaW1lc3RhbXApO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShEaXNwbGF5QXNzaWdubWVudEVudHJ5LnByb3RvdHlwZSwgXCJkdWVDbG9zZURhdGVTdHJpbmdcIiwge1xyXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gRGlzcGxheUFzc2lnbm1lbnRFbnRyeS5jcmVhdGVEYXRlU3RyaW5nKHRoaXMuY2xvc2VEYXRlVGltZXN0YW1wKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gRGlzcGxheUFzc2lnbm1lbnRFbnRyeTtcclxufShBc3NpZ25tZW50RW50cnkpKTtcclxuZXhwb3J0cy5EaXNwbGF5QXNzaWdubWVudEVudHJ5ID0gRGlzcGxheUFzc2lnbm1lbnRFbnRyeTtcclxudmFyIERpc3BsYXlBc3NpZ25tZW50ID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xyXG4gICAgZnVuY3Rpb24gRGlzcGxheUFzc2lnbm1lbnQoYXNzaWdubWVudEVudHJpZXMsIGNvdXJzZU5hbWUsIGNvdXJzZVBhZ2UpIHtcclxuICAgICAgICB0aGlzLmFzc2lnbm1lbnRFbnRyaWVzID0gYXNzaWdubWVudEVudHJpZXM7XHJcbiAgICAgICAgdGhpcy5jb3Vyc2VOYW1lID0gY291cnNlTmFtZTtcclxuICAgICAgICB0aGlzLmNvdXJzZVBhZ2UgPSBjb3Vyc2VQYWdlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIERpc3BsYXlBc3NpZ25tZW50O1xyXG59KCkpO1xyXG5leHBvcnRzLkRpc3BsYXlBc3NpZ25tZW50ID0gRGlzcGxheUFzc2lnbm1lbnQ7XHJcbiIsIlwidXNlIHN0cmljdFwiO1xyXG52YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcclxuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxyXG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogYWRvcHQocmVzdWx0LnZhbHVlKS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XHJcbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xyXG4gICAgfSk7XHJcbn07XHJcbnZhciBfX2dlbmVyYXRvciA9ICh0aGlzICYmIHRoaXMuX19nZW5lcmF0b3IpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBib2R5KSB7XHJcbiAgICB2YXIgXyA9IHsgbGFiZWw6IDAsIHNlbnQ6IGZ1bmN0aW9uKCkgeyBpZiAodFswXSAmIDEpIHRocm93IHRbMV07IHJldHVybiB0WzFdOyB9LCB0cnlzOiBbXSwgb3BzOiBbXSB9LCBmLCB5LCB0LCBnO1xyXG4gICAgcmV0dXJuIGcgPSB7IG5leHQ6IHZlcmIoMCksIFwidGhyb3dcIjogdmVyYigxKSwgXCJyZXR1cm5cIjogdmVyYigyKSB9LCB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgKGdbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uKCkgeyByZXR1cm4gdGhpczsgfSksIGc7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBzdGVwKFtuLCB2XSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAob3ApIHtcclxuICAgICAgICBpZiAoZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkdlbmVyYXRvciBpcyBhbHJlYWR5IGV4ZWN1dGluZy5cIik7XHJcbiAgICAgICAgd2hpbGUgKF8pIHRyeSB7XHJcbiAgICAgICAgICAgIGlmIChmID0gMSwgeSAmJiAodCA9IG9wWzBdICYgMiA/IHlbXCJyZXR1cm5cIl0gOiBvcFswXSA/IHlbXCJ0aHJvd1wiXSB8fCAoKHQgPSB5W1wicmV0dXJuXCJdKSAmJiB0LmNhbGwoeSksIDApIDogeS5uZXh0KSAmJiAhKHQgPSB0LmNhbGwoeSwgb3BbMV0pKS5kb25lKSByZXR1cm4gdDtcclxuICAgICAgICAgICAgaWYgKHkgPSAwLCB0KSBvcCA9IFtvcFswXSAmIDIsIHQudmFsdWVdO1xyXG4gICAgICAgICAgICBzd2l0Y2ggKG9wWzBdKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IGNhc2UgMTogdCA9IG9wOyBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgNDogXy5sYWJlbCsrOyByZXR1cm4geyB2YWx1ZTogb3BbMV0sIGRvbmU6IGZhbHNlIH07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDU6IF8ubGFiZWwrKzsgeSA9IG9wWzFdOyBvcCA9IFswXTsgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDc6IG9wID0gXy5vcHMucG9wKCk7IF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghKHQgPSBfLnRyeXMsIHQgPSB0Lmxlbmd0aCA+IDAgJiYgdFt0Lmxlbmd0aCAtIDFdKSAmJiAob3BbMF0gPT09IDYgfHwgb3BbMF0gPT09IDIpKSB7IF8gPSAwOyBjb250aW51ZTsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gMyAmJiAoIXQgfHwgKG9wWzFdID4gdFswXSAmJiBvcFsxXSA8IHRbM10pKSkgeyBfLmxhYmVsID0gb3BbMV07IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSA2ICYmIF8ubGFiZWwgPCB0WzFdKSB7IF8ubGFiZWwgPSB0WzFdOyB0ID0gb3A7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHQgJiYgXy5sYWJlbCA8IHRbMl0pIHsgXy5sYWJlbCA9IHRbMl07IF8ub3BzLnB1c2gob3ApOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0WzJdKSBfLm9wcy5wb3AoKTtcclxuICAgICAgICAgICAgICAgICAgICBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG9wID0gYm9keS5jYWxsKHRoaXNBcmcsIF8pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHsgb3AgPSBbNiwgZV07IHkgPSAwOyB9IGZpbmFsbHkgeyBmID0gdCA9IDA7IH1cclxuICAgICAgICBpZiAob3BbMF0gJiA1KSB0aHJvdyBvcFsxXTsgcmV0dXJuIHsgdmFsdWU6IG9wWzBdID8gb3BbMV0gOiB2b2lkIDAsIGRvbmU6IHRydWUgfTtcclxuICAgIH1cclxufTtcclxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xyXG5leHBvcnRzLmdldFF1aXpGcm9tQ291cnNlSUQgPSBleHBvcnRzLmdldEFzc2lnbm1lbnRCeUNvdXJzZUlEID0gZXhwb3J0cy5nZXRDb3Vyc2VJRExpc3QgPSBleHBvcnRzLmdldEJhc2VVUkwgPSB2b2lkIDA7XHJcbnZhciBtb2RlbF8xID0gcmVxdWlyZShcIi4vbW9kZWxcIik7XHJcbnZhciB1dGlsc18xID0gcmVxdWlyZShcIi4vdXRpbHNcIik7XHJcbi8qKlxyXG4gKiBHZXQgYmFzZSBVUkwgb2YgU2FrYWkuXHJcbiAqL1xyXG5mdW5jdGlvbiBnZXRCYXNlVVJMKCkge1xyXG4gICAgdmFyIGJhc2VVUkwgPSBcIlwiO1xyXG4gICAgdmFyIG1hdGNoID0gbG9jYXRpb24uaHJlZi5tYXRjaChcIihodHRwcz86Ly9bXi9dKykvcG9ydGFsXCIpO1xyXG4gICAgaWYgKG1hdGNoKSB7XHJcbiAgICAgICAgYmFzZVVSTCA9IG1hdGNoWzFdO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGJhc2VVUkw7XHJcbn1cclxuZXhwb3J0cy5nZXRCYXNlVVJMID0gZ2V0QmFzZVVSTDtcclxuLyoqXHJcbiAqIEZldGNoIGNvdXJzZSBzaXRlIElEcy5cclxuICovXHJcbmZ1bmN0aW9uIGdldENvdXJzZUlETGlzdCgpIHtcclxuICAgIHZhciBlbGVtZW50Q29sbGVjdGlvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJmYXYtc2l0ZXMtZW50cnlcIik7XHJcbiAgICB2YXIgZWxlbWVudHMgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChlbGVtZW50Q29sbGVjdGlvbik7XHJcbiAgICB2YXIgcmVzdWx0ID0gW107XHJcbiAgICBmb3IgKHZhciBfaSA9IDAsIGVsZW1lbnRzXzEgPSBlbGVtZW50czsgX2kgPCBlbGVtZW50c18xLmxlbmd0aDsgX2krKykge1xyXG4gICAgICAgIHZhciBlbGVtID0gZWxlbWVudHNfMVtfaV07XHJcbiAgICAgICAgdmFyIGxlY3R1cmVJbmZvID0gbmV3IG1vZGVsXzEuQ291cnNlU2l0ZUluZm8oXCJcIiwgXCJcIik7XHJcbiAgICAgICAgdmFyIGxlY3R1cmUgPSBlbGVtLmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiZGl2XCIpWzBdLmdldEVsZW1lbnRzQnlUYWdOYW1lKFwiYVwiKVswXTtcclxuICAgICAgICB2YXIgbSA9IGxlY3R1cmUuaHJlZi5tYXRjaChcIihodHRwcz86Ly9bXi9dKykvcG9ydGFsL3NpdGUtP1thLXpdKi8oW14vXSspXCIpO1xyXG4gICAgICAgIGlmIChtICYmIG1bMl1bMF0gIT09IFwiflwiKSB7XHJcbiAgICAgICAgICAgIGxlY3R1cmVJbmZvLmNvdXJzZUlEID0gbVsyXTtcclxuICAgICAgICAgICAgbGVjdHVyZUluZm8uY291cnNlTmFtZSA9IGxlY3R1cmUudGl0bGU7XHJcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGxlY3R1cmVJbmZvKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG59XHJcbmV4cG9ydHMuZ2V0Q291cnNlSURMaXN0ID0gZ2V0Q291cnNlSURMaXN0O1xyXG4vKipcclxuICogRmV0Y2ggYXNzaWdubWVudHMgZnJvbSBTYWthaSBSRVNUIEFQSS5cclxuICogQHBhcmFtIHtzdHJpbmd9IGJhc2VVUkxcclxuICogQHBhcmFtIHtzdHJpbmd9IGNvdXJzZUlEXHJcbiAqL1xyXG5mdW5jdGlvbiBnZXRBc3NpZ25tZW50QnlDb3Vyc2VJRChiYXNlVVJMLCBjb3Vyc2VJRCkge1xyXG4gICAgdmFyIF90aGlzID0gdGhpcztcclxuICAgIHZhciBxdWVyeVVSTCA9IGJhc2VVUkwgKyBcIi9kaXJlY3QvYXNzaWdubWVudC9zaXRlL1wiICsgY291cnNlSUQgKyBcIi5qc29uXCI7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xyXG4gICAgICAgIGZldGNoKHF1ZXJ5VVJMLCB7IGNhY2hlOiBcIm5vLWNhY2hlXCIgfSlcclxuICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7IHJldHVybiBfX2F3YWl0ZXIoX3RoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHZhciByZXMsIGNvdXJzZVNpdGVJbmZvLCBhc3NpZ25tZW50RW50cmllcztcclxuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIFszIC8qYnJlYWsqLywgMl07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHJlc3BvbnNlLmpzb24oKV07XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXMgPSBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZVNpdGVJbmZvID0gbmV3IG1vZGVsXzEuQ291cnNlU2l0ZUluZm8oY291cnNlSUQsIGNvdXJzZUlEKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudEVudHJpZXMgPSBjb252SnNvblRvQXNzaWdubWVudEVudHJpZXMocmVzLCBiYXNlVVJMLCBjb3Vyc2VJRCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUobmV3IG1vZGVsXzEuQXNzaWdubWVudChjb3Vyc2VTaXRlSW5mbywgYXNzaWdubWVudEVudHJpZXMsIGZhbHNlKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDNdO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KFwiUmVxdWVzdCBmYWlsZWQ6IFwiICsgcmVzcG9uc2Uuc3RhdHVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2EubGFiZWwgPSAzO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMzogcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTsgfSlcclxuICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uIChlcnIpIHsgcmV0dXJuIGNvbnNvbGUuZXJyb3IoZXJyKTsgfSk7IC8vIEVycm9yOiBSZXF1ZXN0IGZhaWxlZDogNDA0XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLmdldEFzc2lnbm1lbnRCeUNvdXJzZUlEID0gZ2V0QXNzaWdubWVudEJ5Q291cnNlSUQ7XHJcbi8qKlxyXG4gKiBGZXRjaCBxdWl6emVzIGZyb20gU2FrYWkgUkVTVCBBUEkuXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSBiYXNlVVJMXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSBjb3Vyc2VJRFxyXG4gKi9cclxuZnVuY3Rpb24gZ2V0UXVpekZyb21Db3Vyc2VJRChiYXNlVVJMLCBjb3Vyc2VJRCkge1xyXG4gICAgdmFyIF90aGlzID0gdGhpcztcclxuICAgIHZhciBxdWVyeVVSTCA9IGJhc2VVUkwgKyBcIi9kaXJlY3Qvc2FtX3B1Yi9jb250ZXh0L1wiICsgY291cnNlSUQgKyBcIi5qc29uXCI7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xyXG4gICAgICAgIGZldGNoKHF1ZXJ5VVJMLCB7IGNhY2hlOiBcIm5vLWNhY2hlXCIgfSlcclxuICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7IHJldHVybiBfX2F3YWl0ZXIoX3RoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHZhciByZXMsIGNvdXJzZVNpdGVJbmZvLCBhc3NpZ25tZW50RW50cmllcztcclxuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xyXG4gICAgICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIFszIC8qYnJlYWsqLywgMl07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHJlc3BvbnNlLmpzb24oKV07XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXMgPSBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdXJzZVNpdGVJbmZvID0gbmV3IG1vZGVsXzEuQ291cnNlU2l0ZUluZm8oY291cnNlSUQsIGNvdXJzZUlEKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudEVudHJpZXMgPSBjb252SnNvblRvUXVpekVudHJpZXMocmVzLCBiYXNlVVJMLCBjb3Vyc2VJRCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUobmV3IG1vZGVsXzEuQXNzaWdubWVudChjb3Vyc2VTaXRlSW5mbywgYXNzaWdubWVudEVudHJpZXMsIGZhbHNlKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDNdO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KFwiUmVxdWVzdCBmYWlsZWQ6IFwiICsgcmVzcG9uc2Uuc3RhdHVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2EubGFiZWwgPSAzO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMzogcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTsgfSlcclxuICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uIChlcnIpIHsgcmV0dXJuIGNvbnNvbGUuZXJyb3IoZXJyKTsgfSk7IC8vIEVycm9yOiBSZXF1ZXN0IGZhaWxlZDogNDA0XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLmdldFF1aXpGcm9tQ291cnNlSUQgPSBnZXRRdWl6RnJvbUNvdXJzZUlEO1xyXG4vKipcclxuICogQ29udmVydCBqc29uIHJlc3BvbnNlIHRvIEFzc2lnbm1lbnRFbnRyaWVzLlxyXG4gKiBAcGFyYW0gZGF0YVxyXG4gKiBAcGFyYW0gYmFzZVVSTFxyXG4gKiBAcGFyYW0gc2l0ZUlEXHJcbiAqL1xyXG5mdW5jdGlvbiBjb252SnNvblRvQXNzaWdubWVudEVudHJpZXMoZGF0YSwgYmFzZVVSTCwgc2l0ZUlEKSB7XHJcbiAgICB2YXIgYXNzaWdubWVudF9jb2xsZWN0aW9uID0gZGF0YS5hc3NpZ25tZW50X2NvbGxlY3Rpb247XHJcbiAgICByZXR1cm4gYXNzaWdubWVudF9jb2xsZWN0aW9uXHJcbiAgICAgICAgLmZpbHRlcihmdW5jdGlvbiAoanNvbikgeyByZXR1cm4ganNvbi5jbG9zZVRpbWUuZXBvY2hTZWNvbmQgKiAxMDAwID49IHV0aWxzXzEubm93VGltZTsgfSlcclxuICAgICAgICAubWFwKGZ1bmN0aW9uIChqc29uKSB7XHJcbiAgICAgICAgdmFyIGFzc2lnbm1lbnRJRCA9IGpzb24uaWQ7XHJcbiAgICAgICAgdmFyIGFzc2lnbm1lbnRUaXRsZSA9IGpzb24udGl0bGU7XHJcbiAgICAgICAgdmFyIGFzc2lnbm1lbnREZXRhaWwgPSBqc29uLmluc3RydWN0aW9ucztcclxuICAgICAgICB2YXIgZHVlRGF0ZVRpbWVzdGFtcCA9IGpzb24uZHVlVGltZS5lcG9jaFNlY29uZCA/IGpzb24uZHVlVGltZS5lcG9jaFNlY29uZCA6IG51bGw7XHJcbiAgICAgICAgdmFyIGNsb3NlRGF0ZVRpbWVzdGFtcCA9IGpzb24uY2xvc2VUaW1lLmVwb2NoU2Vjb25kID8ganNvbi5jbG9zZVRpbWUuZXBvY2hTZWNvbmQgOiBudWxsO1xyXG4gICAgICAgIHZhciBlbnRyeSA9IG5ldyBtb2RlbF8xLkFzc2lnbm1lbnRFbnRyeShhc3NpZ25tZW50SUQsIGFzc2lnbm1lbnRUaXRsZSwgZHVlRGF0ZVRpbWVzdGFtcCwgY2xvc2VEYXRlVGltZXN0YW1wLCBmYWxzZSwgZmFsc2UsIGZhbHNlLCBhc3NpZ25tZW50RGV0YWlsKTtcclxuICAgICAgICBlbnRyeS5hc3NpZ25tZW50UGFnZSA9IGJhc2VVUkwgKyBcIi9wb3J0YWwvc2l0ZS9cIiArIHNpdGVJRDtcclxuICAgICAgICByZXR1cm4gZW50cnk7XHJcbiAgICB9KTtcclxufVxyXG4vKipcclxuICogQ29udmVydCBqc29uIHJlc3BvbnNlIHRvIFF1aXpFbnRyaWVzLlxyXG4gKiBAcGFyYW0gZGF0YVxyXG4gKiBAcGFyYW0gYmFzZVVSTFxyXG4gKiBAcGFyYW0gc2l0ZUlEXHJcbiAqL1xyXG5mdW5jdGlvbiBjb252SnNvblRvUXVpekVudHJpZXMoZGF0YSwgYmFzZVVSTCwgc2l0ZUlEKSB7XHJcbiAgICByZXR1cm4gZGF0YS5zYW1fcHViX2NvbGxlY3Rpb25cclxuICAgICAgICAuZmlsdGVyKGZ1bmN0aW9uIChqc29uKSB7IHJldHVybiBqc29uLnN0YXJ0RGF0ZSA8IHV0aWxzXzEubm93VGltZSAmJiAoanNvbi5kdWVEYXRlID49IHV0aWxzXzEubm93VGltZSB8fCBqc29uLmR1ZURhdGUgPT0gbnVsbCk7IH0pXHJcbiAgICAgICAgLm1hcChmdW5jdGlvbiAoanNvbikge1xyXG4gICAgICAgIHZhciBxdWl6SUQgPSBcInFcIiArIGpzb24ucHVibGlzaGVkQXNzZXNzbWVudElkO1xyXG4gICAgICAgIHZhciBxdWl6VGl0bGUgPSBqc29uLnRpdGxlO1xyXG4gICAgICAgIHZhciBxdWl6RGV0YWlsID0gXCJcIjtcclxuICAgICAgICB2YXIgcXVpekR1ZUVwb2NoID0ganNvbi5kdWVEYXRlID8ganNvbi5kdWVEYXRlIC8gMTAwMCA6IG51bGw7XHJcbiAgICAgICAgdmFyIGVudHJ5ID0gbmV3IG1vZGVsXzEuQXNzaWdubWVudEVudHJ5KHF1aXpJRCwgcXVpelRpdGxlLCBxdWl6RHVlRXBvY2gsIHF1aXpEdWVFcG9jaCwgZmFsc2UsIGZhbHNlLCB0cnVlLCBxdWl6RGV0YWlsKTtcclxuICAgICAgICBlbnRyeS5hc3NpZ25tZW50UGFnZSA9IGJhc2VVUkwgKyBcIi9wb3J0YWwvc2l0ZS9cIiArIHNpdGVJRDtcclxuICAgICAgICByZXR1cm4gZW50cnk7XHJcbiAgICB9KTtcclxufVxyXG4iLCJcInVzZSBzdHJpY3RcIjtcclxudmFyIF9fZXh0ZW5kcyA9ICh0aGlzICYmIHRoaXMuX19leHRlbmRzKSB8fCAoZnVuY3Rpb24gKCkge1xyXG4gICAgdmFyIGV4dGVuZFN0YXRpY3MgPSBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGV4dGVuZFN0YXRpY3MgPSBPYmplY3Quc2V0UHJvdG90eXBlT2YgfHxcclxuICAgICAgICAgICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxyXG4gICAgICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYiwgcCkpIGRbcF0gPSBiW3BdOyB9O1xyXG4gICAgICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgfTtcclxuICAgIHJldHVybiBmdW5jdGlvbiAoZCwgYikge1xyXG4gICAgICAgIGlmICh0eXBlb2YgYiAhPT0gXCJmdW5jdGlvblwiICYmIGIgIT09IG51bGwpXHJcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDbGFzcyBleHRlbmRzIHZhbHVlIFwiICsgU3RyaW5nKGIpICsgXCIgaXMgbm90IGEgY29uc3RydWN0b3Igb3IgbnVsbFwiKTtcclxuICAgICAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgICAgIGZ1bmN0aW9uIF9fKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gZDsgfVxyXG4gICAgICAgIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcclxuICAgIH07XHJcbn0pKCk7XHJcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xyXG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufTtcclxudmFyIF9fZ2VuZXJhdG9yID0gKHRoaXMgJiYgdGhpcy5fX2dlbmVyYXRvcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59O1xyXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XHJcbmV4cG9ydHMubG9hZENvbmZpZ3MgPSBleHBvcnRzLmxvYWRTZXR0aW5ncyA9IGV4cG9ydHMuRGVmYXVsdFNldHRpbmdzID0gZXhwb3J0cy5TZXR0aW5ncyA9IHZvaWQgMDtcclxudmFyIHN0b3JhZ2VfMSA9IHJlcXVpcmUoXCIuL3N0b3JhZ2VcIik7XHJcbnZhciB1dGlsc18xID0gcmVxdWlyZShcIi4vdXRpbHNcIik7XHJcbnZhciBuZXR3b3JrXzEgPSByZXF1aXJlKFwiLi9uZXR3b3JrXCIpO1xyXG52YXIgU2V0dGluZ3MgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XHJcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWVtcHR5LWZ1bmN0aW9uXHJcbiAgICBmdW5jdGlvbiBTZXR0aW5ncygpIHtcclxuICAgIH1cclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShTZXR0aW5ncy5wcm90b3R5cGUsIFwiZ2V0QXNzaWdubWVudENhY2hlSW50ZXJ2YWxcIiwge1xyXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5hc3NpZ25tZW50Q2FjaGVJbnRlcnZhbCA/IHRoaXMuYXNzaWdubWVudENhY2hlSW50ZXJ2YWwgOiBEZWZhdWx0U2V0dGluZ3MuYXNzaWdubWVudENhY2hlSW50ZXJ2YWw7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFNldHRpbmdzLnByb3RvdHlwZSwgXCJnZXRRdWl6Q2FjaGVJbnRlcnZhbFwiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnF1aXpDYWNoZUludGVydmFsID8gdGhpcy5xdWl6Q2FjaGVJbnRlcnZhbCA6IERlZmF1bHRTZXR0aW5ncy5xdWl6Q2FjaGVJbnRlcnZhbDtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU2V0dGluZ3MucHJvdG90eXBlLCBcImdldERpc3BsYXlDaGVja2VkQXNzaWdubWVudFwiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRpc3BsYXlDaGVja2VkQXNzaWdubWVudCAhPT0gdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICA/IHRoaXMuZGlzcGxheUNoZWNrZWRBc3NpZ25tZW50XHJcbiAgICAgICAgICAgICAgICA6IERlZmF1bHRTZXR0aW5ncy5kaXNwbGF5Q2hlY2tlZEFzc2lnbm1lbnQ7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFNldHRpbmdzLnByb3RvdHlwZSwgXCJnZXREaXNwbGF5TGF0ZVN1Ym1pdEFzc2lnbm1lbnRcIiwge1xyXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5kaXNwbGF5TGF0ZVN1Ym1pdEFzc2lnbm1lbnQgIT09IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgPyB0aGlzLmRpc3BsYXlMYXRlU3VibWl0QXNzaWdubWVudFxyXG4gICAgICAgICAgICAgICAgOiBEZWZhdWx0U2V0dGluZ3MuZGlzcGxheUxhdGVTdWJtaXRBc3NpZ25tZW50O1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShTZXR0aW5ncy5wcm90b3R5cGUsIFwiZ2V0VG9wQ29sb3JEYW5nZXJcIiwge1xyXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy50b3BDb2xvckRhbmdlciA/IHRoaXMudG9wQ29sb3JEYW5nZXIgOiBEZWZhdWx0U2V0dGluZ3MudG9wQ29sb3JEYW5nZXI7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFNldHRpbmdzLnByb3RvdHlwZSwgXCJnZXRUb3BDb2xvcldhcm5pbmdcIiwge1xyXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy50b3BDb2xvcldhcm5pbmcgPyB0aGlzLnRvcENvbG9yV2FybmluZyA6IERlZmF1bHRTZXR0aW5ncy50b3BDb2xvcldhcm5pbmc7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFNldHRpbmdzLnByb3RvdHlwZSwgXCJnZXRUb3BDb2xvclN1Y2Nlc3NcIiwge1xyXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy50b3BDb2xvclN1Y2Nlc3MgPyB0aGlzLnRvcENvbG9yU3VjY2VzcyA6IERlZmF1bHRTZXR0aW5ncy50b3BDb2xvclN1Y2Nlc3M7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFNldHRpbmdzLnByb3RvdHlwZSwgXCJnZXRNaW5pQ29sb3JEYW5nZXJcIiwge1xyXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5taW5pQ29sb3JEYW5nZXIgPyB0aGlzLm1pbmlDb2xvckRhbmdlciA6IERlZmF1bHRTZXR0aW5ncy5taW5pQ29sb3JEYW5nZXI7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcclxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcclxuICAgIH0pO1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFNldHRpbmdzLnByb3RvdHlwZSwgXCJnZXRNaW5pQ29sb3JXYXJuaW5nXCIsIHtcclxuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMubWluaUNvbG9yV2FybmluZyA/IHRoaXMubWluaUNvbG9yV2FybmluZyA6IERlZmF1bHRTZXR0aW5ncy5taW5pQ29sb3JXYXJuaW5nO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXHJcbiAgICB9KTtcclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShTZXR0aW5ncy5wcm90b3R5cGUsIFwiZ2V0TWluaUNvbG9yU3VjY2Vzc1wiLCB7XHJcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLm1pbmlDb2xvclN1Y2Nlc3MgPyB0aGlzLm1pbmlDb2xvclN1Y2Nlc3MgOiBEZWZhdWx0U2V0dGluZ3MubWluaUNvbG9yU3VjY2VzcztcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxyXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gU2V0dGluZ3M7XHJcbn0oKSk7XHJcbmV4cG9ydHMuU2V0dGluZ3MgPSBTZXR0aW5ncztcclxudmFyIERlZmF1bHRTZXR0aW5ncyA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcclxuICAgIF9fZXh0ZW5kcyhEZWZhdWx0U2V0dGluZ3MsIF9zdXBlcik7XHJcbiAgICBmdW5jdGlvbiBEZWZhdWx0U2V0dGluZ3MoKSB7XHJcbiAgICAgICAgcmV0dXJuIF9zdXBlciAhPT0gbnVsbCAmJiBfc3VwZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKSB8fCB0aGlzO1xyXG4gICAgfVxyXG4gICAgRGVmYXVsdFNldHRpbmdzLmFzc2lnbm1lbnRDYWNoZUludGVydmFsID0gMTIwO1xyXG4gICAgRGVmYXVsdFNldHRpbmdzLnF1aXpDYWNoZUludGVydmFsID0gNjAwO1xyXG4gICAgRGVmYXVsdFNldHRpbmdzLmRpc3BsYXlDaGVja2VkQXNzaWdubWVudCA9IHRydWU7XHJcbiAgICBEZWZhdWx0U2V0dGluZ3MuZGlzcGxheUxhdGVTdWJtaXRBc3NpZ25tZW50ID0gZmFsc2U7XHJcbiAgICBEZWZhdWx0U2V0dGluZ3MudG9wQ29sb3JEYW5nZXIgPSBcIiNmNzg5ODlcIjtcclxuICAgIERlZmF1bHRTZXR0aW5ncy50b3BDb2xvcldhcm5pbmcgPSBcIiNmZGQ3ODNcIjtcclxuICAgIERlZmF1bHRTZXR0aW5ncy50b3BDb2xvclN1Y2Nlc3MgPSBcIiM4YmQ0OGRcIjtcclxuICAgIERlZmF1bHRTZXR0aW5ncy5taW5pQ29sb3JEYW5nZXIgPSBcIiNlODU1NTVcIjtcclxuICAgIERlZmF1bHRTZXR0aW5ncy5taW5pQ29sb3JXYXJuaW5nID0gXCIjZDdhYTU3XCI7XHJcbiAgICBEZWZhdWx0U2V0dGluZ3MubWluaUNvbG9yU3VjY2VzcyA9IFwiIzYyYjY2NVwiO1xyXG4gICAgcmV0dXJuIERlZmF1bHRTZXR0aW5ncztcclxufShTZXR0aW5ncykpO1xyXG5leHBvcnRzLkRlZmF1bHRTZXR0aW5ncyA9IERlZmF1bHRTZXR0aW5ncztcclxuZnVuY3Rpb24gbG9hZFNldHRpbmdzKCkge1xyXG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIHZhciBzZXR0aW5nc0FyciwgQ1NzZXR0aW5ncztcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLmxvYWRGcm9tTG9jYWxTdG9yYWdlKFwiQ1NfU2V0dGluZ3NcIildO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgICAgIHNldHRpbmdzQXJyID0gX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIENTc2V0dGluZ3MgPSB1dGlsc18xLmNvbnZlcnRBcnJheVRvU2V0dGluZ3Moc2V0dGluZ3NBcnIpO1xyXG4gICAgICAgICAgICAgICAgICAgIENTc2V0dGluZ3MuZGlzcGxheUNoZWNrZWRBc3NpZ25tZW50ID0gQ1NzZXR0aW5ncy5nZXREaXNwbGF5Q2hlY2tlZEFzc2lnbm1lbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi8sIENTc2V0dGluZ3NdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLmxvYWRTZXR0aW5ncyA9IGxvYWRTZXR0aW5ncztcclxuLyoqXHJcbiAqIExvYWQgY29uZmlndXJhdGlvbnMgZnJvbSBsb2NhbCBzdG9yYWdlXHJcbiAqL1xyXG5mdW5jdGlvbiBsb2FkQ29uZmlncygpIHtcclxuICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICB2YXIgYmFzZVVSTCwgVkVSU0lPTiwgQ1NzZXR0aW5ncywgYXNzaWdubWVudENhY2hlSW50ZXJ2YWwsIHF1aXpDYWNoZUludGVydmFsLCBhc3NpZ25tZW50RmV0Y2hlZFRpbWUsIHF1aXpGZXRjaGVkVGltZTtcclxuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDpcclxuICAgICAgICAgICAgICAgICAgICBiYXNlVVJMID0gbmV0d29ya18xLmdldEJhc2VVUkwoKTtcclxuICAgICAgICAgICAgICAgICAgICBWRVJTSU9OID0gY2hyb21lLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9uO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIGxvYWRTZXR0aW5ncygpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgICAgICBDU3NldHRpbmdzID0gX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIENTc2V0dGluZ3MuZGlzcGxheUNoZWNrZWRBc3NpZ25tZW50ID0gQ1NzZXR0aW5ncy5nZXREaXNwbGF5Q2hlY2tlZEFzc2lnbm1lbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudENhY2hlSW50ZXJ2YWwgPSBDU3NldHRpbmdzLmdldEFzc2lnbm1lbnRDYWNoZUludGVydmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIHF1aXpDYWNoZUludGVydmFsID0gQ1NzZXR0aW5ncy5nZXRRdWl6Q2FjaGVJbnRlcnZhbDtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzdG9yYWdlXzEubG9hZEZyb21Mb2NhbFN0b3JhZ2UoXCJDU19Bc3NpZ25tZW50RmV0Y2hUaW1lXCIsIFwidW5kZWZpbmVkXCIpXTtcclxuICAgICAgICAgICAgICAgIGNhc2UgMjpcclxuICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50RmV0Y2hlZFRpbWUgPSBfYS5zZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc3RvcmFnZV8xLmxvYWRGcm9tTG9jYWxTdG9yYWdlKFwiQ1NfUXVpekZldGNoVGltZVwiLCBcInVuZGVmaW5lZFwiKV07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDM6XHJcbiAgICAgICAgICAgICAgICAgICAgcXVpekZldGNoZWRUaW1lID0gX2Euc2VudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYXNlVVJMOiBiYXNlVVJMLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmVyc2lvbjogVkVSU0lPTixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENTc2V0dGluZ3M6IENTc2V0dGluZ3MsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYWNoZUludGVydmFsOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudDogYXNzaWdubWVudENhY2hlSW50ZXJ2YWwsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVpejogcXVpekNhY2hlSW50ZXJ2YWwsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmV0Y2hlZFRpbWU6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50OiBhc3NpZ25tZW50RmV0Y2hlZFRpbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVpejogcXVpekZldGNoZWRUaW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMubG9hZENvbmZpZ3MgPSBsb2FkQ29uZmlncztcclxuIiwiXCJ1c2Ugc3RyaWN0XCI7XHJcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcclxuZXhwb3J0cy5nZXRLZXlzID0gZXhwb3J0cy5zYXZlVG9Mb2NhbFN0b3JhZ2UgPSBleHBvcnRzLmxvYWRGcm9tTG9jYWxTdG9yYWdlMiA9IGV4cG9ydHMubG9hZEZyb21Mb2NhbFN0b3JhZ2UgPSB2b2lkIDA7XHJcbi8qKlxyXG4gKiBHZXQgYWxsIGtleXMgaW4gbG9jYWwgc3RvcmFnZVxyXG4gKi9cclxuZnVuY3Rpb24gZ2V0S2V5cygpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KG51bGwsIGZ1bmN0aW9uIChrZXlzKSB7XHJcbiAgICAgICAgICAgIHJlc29sdmUoT2JqZWN0LmtleXMoa2V5cykpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuZXhwb3J0cy5nZXRLZXlzID0gZ2V0S2V5cztcclxuLyoqXHJcbiAqIExvYWQgZnJvbSBsb2NhbCBzdG9yYWdlXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSBrZXlcclxuICogQHBhcmFtIHtzdHJpbmd9IGlmVW5kZWZpbmVkVHlwZSBDYW4gc3BlY2lmeSByZXNwb25zZSB0eXBlIGlmIHJlc3VsdCB3YXMgdW5kZWZpbmVkXHJcbiAqL1xyXG5mdW5jdGlvbiBsb2FkRnJvbUxvY2FsU3RvcmFnZShrZXksIGlmVW5kZWZpbmVkVHlwZSkge1xyXG4gICAgaWYgKGlmVW5kZWZpbmVkVHlwZSA9PT0gdm9pZCAwKSB7IGlmVW5kZWZpbmVkVHlwZSA9IFwiYXJyYXlcIjsgfVxyXG4gICAgdmFyIGJhc2VVUkwgPSB3aW5kb3cubG9jYXRpb24uaG9zdG5hbWU7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xyXG4gICAgICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChiYXNlVVJMLCBmdW5jdGlvbiAoaXRlbXMpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVtc1tiYXNlVVJMXSA9PT0gXCJ1bmRlZmluZWRcIiB8fCB0eXBlb2YgaXRlbXNbYmFzZVVSTF1ba2V5XSA9PT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgICAgICAgICAgdmFyIHJlcyA9IHZvaWQgMDtcclxuICAgICAgICAgICAgICAgIHN3aXRjaCAoaWZVbmRlZmluZWRUeXBlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcIm51bWJlclwiOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXMgPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBjYXNlIFwic3RyaW5nXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcyA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgXCJ1bmRlZmluZWRcIjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzID0gdW5kZWZpbmVkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXMgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKHJlcyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgcmVzb2x2ZShpdGVtc1tiYXNlVVJMXVtrZXldKTtcclxuICAgICAgICB9KTtcclxuICAgIH0pO1xyXG59XHJcbmV4cG9ydHMubG9hZEZyb21Mb2NhbFN0b3JhZ2UgPSBsb2FkRnJvbUxvY2FsU3RvcmFnZTtcclxuLyoqXHJcbiAqIExvYWQgZnJvbSBsb2NhbCBzdG9yYWdlXHJcbiAqIEZPUiBTdWJTYWthaSBzaW5jZSBpdCBtaWdodCBub3QgYmUgZXhlY3V0ZWQgaW4gU2FrYWlMTVMuXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSBiYXNlVVJMXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSBrZXlcclxuICovXHJcbmZ1bmN0aW9uIGxvYWRGcm9tTG9jYWxTdG9yYWdlMihiYXNlVVJMLCBrZXkpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KGJhc2VVUkwsIGZ1bmN0aW9uIChpdGVtcykge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZW1zW2Jhc2VVUkxdID09PSBcInVuZGVmaW5lZFwiIHx8IHR5cGVvZiBpdGVtc1tiYXNlVVJMXVtrZXldID09PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKFtdKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKGl0ZW1zW2Jhc2VVUkxdW2tleV0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSk7XHJcbn1cclxuZXhwb3J0cy5sb2FkRnJvbUxvY2FsU3RvcmFnZTIgPSBsb2FkRnJvbUxvY2FsU3RvcmFnZTI7XHJcbi8qKlxyXG4gKiBTYXZlIHRvIGxvY2FsIHN0b3JhZ2VcclxuICogQHBhcmFtIHtzdHJpbmd9IGtleVxyXG4gKiBAcGFyYW0ge2FueX0gdmFsdWVcclxuICovXHJcbmZ1bmN0aW9uIHNhdmVUb0xvY2FsU3RvcmFnZShrZXksIHZhbHVlKSB7XHJcbiAgICB2YXIgYmFzZVVSTCA9IHdpbmRvdy5sb2NhdGlvbi5ob3N0bmFtZTtcclxuICAgIHZhciBlbnRpdHkgPSB7fTtcclxuICAgIGVudGl0eVtrZXldID0gdmFsdWU7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xyXG4gICAgICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChiYXNlVVJMLCBmdW5jdGlvbiAoaXRlbXMpIHtcclxuICAgICAgICAgICAgdmFyIF9hO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZW1zW2Jhc2VVUkxdID09PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgICAgICAgICBpdGVtc1tiYXNlVVJMXSA9IHt9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGl0ZW1zW2Jhc2VVUkxdW2tleV0gPSB2YWx1ZTtcclxuICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KChfYSA9IHt9LCBfYVtiYXNlVVJMXSA9IGl0ZW1zW2Jhc2VVUkxdLCBfYSksIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIHJlc29sdmUoXCJzYXZlZFwiKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9KTtcclxufVxyXG5leHBvcnRzLnNhdmVUb0xvY2FsU3RvcmFnZSA9IHNhdmVUb0xvY2FsU3RvcmFnZTtcclxuIiwiXCJ1c2Ugc3RyaWN0XCI7XHJcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcclxuZXhwb3J0cy5zb3J0QXNzaWdubWVudExpc3QgPSBleHBvcnRzLm1lcmdlSW50b0Fzc2lnbm1lbnRMaXN0ID0gZXhwb3J0cy5nZW5VbmlxdWVJRCA9IGV4cG9ydHMuaXNVc2luZ0NhY2hlID0gZXhwb3J0cy5jb21wYXJlQW5kTWVyZ2VBc3NpZ25tZW50TGlzdCA9IGV4cG9ydHMuY29udmVydEFycmF5VG9Bc3NpZ25tZW50ID0gZXhwb3J0cy5jb252ZXJ0QXJyYXlUb1NldHRpbmdzID0gZXhwb3J0cy5taW5pU2FrYWlSZWFkeSA9IGV4cG9ydHMuaXNMb2dnZWRJbiA9IGV4cG9ydHMuZm9ybWF0VGltZXN0YW1wID0gZXhwb3J0cy5jcmVhdGVDb3Vyc2VJRE1hcCA9IGV4cG9ydHMuZ2V0RGF5c1VudGlsID0gZXhwb3J0cy51cGRhdGVJc1JlYWRGbGFnID0gZXhwb3J0cy5nZXRTaXRlQ291cnNlSUQgPSBleHBvcnRzLmdldExvZ2dlZEluSW5mb0Zyb21TY3JpcHQgPSBleHBvcnRzLm5vd1RpbWUgPSB2b2lkIDA7XHJcbnZhciBtb2RlbF8xID0gcmVxdWlyZShcIi4vbW9kZWxcIik7XHJcbnZhciBzZXR0aW5nc18xID0gcmVxdWlyZShcIi4vc2V0dGluZ3NcIik7XHJcbmV4cG9ydHMubm93VGltZSA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xyXG4vKipcclxuICogQ2FsY3VsYXRlIGNhdGVnb3J5IG9mIGFzc2lnbm1lbnQgZHVlIGRhdGVcclxuICogQHBhcmFtIHtudW1iZXJ9IGR0MSBzdGFuZGFyZCB0aW1lXHJcbiAqIEBwYXJhbSB7bnVtYmVyfSBkdDIgdGFyZ2V0IHRpbWVcclxuICovXHJcbmZ1bmN0aW9uIGdldERheXNVbnRpbChkdDEsIGR0Mikge1xyXG4gICAgdmFyIGRpZmYgPSAoZHQyIC0gZHQxKSAvIDEwMDA7XHJcbiAgICBkaWZmIC89IDM2MDAgKiAyNDtcclxuICAgIHZhciBjYXRlZ29yeTtcclxuICAgIGlmIChkaWZmID4gMCAmJiBkaWZmIDw9IDEpIHtcclxuICAgICAgICBjYXRlZ29yeSA9IFwiZHVlMjRoXCI7XHJcbiAgICB9XHJcbiAgICBlbHNlIGlmIChkaWZmID4gMSAmJiBkaWZmIDw9IDUpIHtcclxuICAgICAgICBjYXRlZ29yeSA9IFwiZHVlNWRcIjtcclxuICAgIH1cclxuICAgIGVsc2UgaWYgKGRpZmYgPiA1ICYmIGRpZmYgPD0gMTQpIHtcclxuICAgICAgICBjYXRlZ29yeSA9IFwiZHVlMTRkXCI7XHJcbiAgICB9XHJcbiAgICBlbHNlIGlmIChkaWZmID4gMTQpIHtcclxuICAgICAgICBjYXRlZ29yeSA9IFwiZHVlT3ZlcjE0ZFwiO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgICAgY2F0ZWdvcnkgPSBcImR1ZVBhc3NlZFwiO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGNhdGVnb3J5O1xyXG59XHJcbmV4cG9ydHMuZ2V0RGF5c1VudGlsID0gZ2V0RGF5c1VudGlsO1xyXG4vKipcclxuICogRm9ybWF0IHRpbWVzdGFtcCBmb3IgZGlzcGxheWluZ1xyXG4gKiBAcGFyYW0ge251bWJlciB8IHVuZGVmaW5lZH0gdGltZXN0YW1wXHJcbiAqL1xyXG5mdW5jdGlvbiBmb3JtYXRUaW1lc3RhbXAodGltZXN0YW1wKSB7XHJcbiAgICB2YXIgZGF0ZSA9IG5ldyBEYXRlKHRpbWVzdGFtcCA/IHRpbWVzdGFtcCA6IGV4cG9ydHMubm93VGltZSk7XHJcbiAgICByZXR1cm4gKGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKCkgK1xyXG4gICAgICAgIFwiIFwiICtcclxuICAgICAgICBkYXRlLmdldEhvdXJzKCkgK1xyXG4gICAgICAgIFwiOlwiICtcclxuICAgICAgICAoXCIwMFwiICsgZGF0ZS5nZXRNaW51dGVzKCkpLnNsaWNlKC0yKSArXHJcbiAgICAgICAgXCI6XCIgK1xyXG4gICAgICAgIChcIjAwXCIgKyBkYXRlLmdldFNlY29uZHMoKSkuc2xpY2UoLTIpKTtcclxufVxyXG5leHBvcnRzLmZvcm1hdFRpbWVzdGFtcCA9IGZvcm1hdFRpbWVzdGFtcDtcclxuLyoqXHJcbiAqIENyZWF0ZXMgYSBNYXAgb2YgY291cnNlSUQgYW5kIGNvdXJzZSBuYW1lLlxyXG4gKiBAcGFyYW0ge0NvdXJzZVNpdGVJbmZvW119IGNvdXJzZVNpdGVJbmZvc1xyXG4gKi9cclxuZnVuY3Rpb24gY3JlYXRlQ291cnNlSURNYXAoY291cnNlU2l0ZUluZm9zKSB7XHJcbiAgICB2YXIgY291cnNlSURNYXAgPSBuZXcgTWFwKCk7XHJcbiAgICBmb3IgKHZhciBfaSA9IDAsIGNvdXJzZVNpdGVJbmZvc18xID0gY291cnNlU2l0ZUluZm9zOyBfaSA8IGNvdXJzZVNpdGVJbmZvc18xLmxlbmd0aDsgX2krKykge1xyXG4gICAgICAgIHZhciBjb3Vyc2VTaXRlSW5mbyA9IGNvdXJzZVNpdGVJbmZvc18xW19pXTtcclxuICAgICAgICB2YXIgY291cnNlTmFtZSA9IHZvaWQgMDtcclxuICAgICAgICBpZiAoY291cnNlU2l0ZUluZm8uY291cnNlTmFtZSA9PT0gdW5kZWZpbmVkKVxyXG4gICAgICAgICAgICBjb3Vyc2VOYW1lID0gXCJcIjtcclxuICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgIGNvdXJzZU5hbWUgPSBjb3Vyc2VTaXRlSW5mby5jb3Vyc2VOYW1lO1xyXG4gICAgICAgIGNvdXJzZUlETWFwLnNldChjb3Vyc2VTaXRlSW5mby5jb3Vyc2VJRCwgY291cnNlTmFtZSk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gY291cnNlSURNYXA7XHJcbn1cclxuZXhwb3J0cy5jcmVhdGVDb3Vyc2VJRE1hcCA9IGNyZWF0ZUNvdXJzZUlETWFwO1xyXG52YXIgZ2V0TG9nZ2VkSW5JbmZvRnJvbVNjcmlwdCA9IGZ1bmN0aW9uICgpIHtcclxuICAgIHJldHVybiBBcnJheS5mcm9tKGRvY3VtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwic2NyaXB0XCIpKTtcclxufTtcclxuZXhwb3J0cy5nZXRMb2dnZWRJbkluZm9Gcm9tU2NyaXB0ID0gZ2V0TG9nZ2VkSW5JbmZvRnJvbVNjcmlwdDtcclxuLyoqXHJcbiAqIENoZWNrIGlmIHVzZXIgaXMgbG9nZ2VuZCBpbiB0byBTYWthaS5cclxuICovXHJcbmZ1bmN0aW9uIGlzTG9nZ2VkSW4oKSB7XHJcbiAgICB2YXIgc2NyaXB0cyA9IGV4cG9ydHMuZ2V0TG9nZ2VkSW5JbmZvRnJvbVNjcmlwdCgpO1xyXG4gICAgdmFyIGxvZ2dlZEluID0gZmFsc2U7XHJcbiAgICBmb3IgKHZhciBfaSA9IDAsIHNjcmlwdHNfMSA9IHNjcmlwdHM7IF9pIDwgc2NyaXB0c18xLmxlbmd0aDsgX2krKykge1xyXG4gICAgICAgIHZhciBzY3JpcHQgPSBzY3JpcHRzXzFbX2ldO1xyXG4gICAgICAgIGlmIChzY3JpcHQudGV4dC5tYXRjaCgnXCJsb2dnZWRJblwiOiB0cnVlJykpXHJcbiAgICAgICAgICAgIGxvZ2dlZEluID0gdHJ1ZTtcclxuICAgIH1cclxuICAgIHJldHVybiBsb2dnZWRJbjtcclxufVxyXG5leHBvcnRzLmlzTG9nZ2VkSW4gPSBpc0xvZ2dlZEluO1xyXG4vKipcclxuICogR2V0IGNvdXJzZUlEIG9mIGN1cnJlbnQgc2l0ZS5cclxuICovXHJcbnZhciBnZXRTaXRlQ291cnNlSUQgPSBmdW5jdGlvbiAodXJsKSB7XHJcbiAgICB2YXIgX2E7XHJcbiAgICB2YXIgY291cnNlSUQ7XHJcbiAgICB2YXIgcmVnID0gbmV3IFJlZ0V4cChcIihodHRwcz86Ly9bXi9dKykvcG9ydGFsL3NpdGUvKFteL10rKVwiKTtcclxuICAgIGlmICh1cmwubWF0Y2gocmVnKSkge1xyXG4gICAgICAgIGNvdXJzZUlEID0gKF9hID0gdXJsLm1hdGNoKHJlZykpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYVsyXTtcclxuICAgIH1cclxuICAgIHJldHVybiBjb3Vyc2VJRDtcclxufTtcclxuZXhwb3J0cy5nZXRTaXRlQ291cnNlSUQgPSBnZXRTaXRlQ291cnNlSUQ7XHJcbi8qKlxyXG4gKiBVcGRhdGUgbmV3LWFzc2lnbm1lbnQgbm90aWZpY2F0aW9uIGZsYWdzLlxyXG4gKiBAcGFyYW0ge0Fzc2lnbm1lbnRbXX0gYXNzaWdubWVudExpc3RcclxuICovXHJcbnZhciB1cGRhdGVJc1JlYWRGbGFnID0gZnVuY3Rpb24gKGFzc2lnbm1lbnRMaXN0KSB7XHJcbiAgICB2YXIgY291cnNlSUQgPSBleHBvcnRzLmdldFNpdGVDb3Vyc2VJRChsb2NhdGlvbi5ocmVmKTtcclxuICAgIHZhciB1cGRhdGVkQXNzaWdubWVudExpc3QgPSBbXTtcclxuICAgIC8vIFRPRE86IFJldmlldyB0aGlzIHByb2Nlc3NcclxuICAgIGlmIChjb3Vyc2VJRCAmJiBjb3Vyc2VJRC5sZW5ndGggPj0gMTcpIHtcclxuICAgICAgICBmb3IgKHZhciBfaSA9IDAsIGFzc2lnbm1lbnRMaXN0XzEgPSBhc3NpZ25tZW50TGlzdDsgX2kgPCBhc3NpZ25tZW50TGlzdF8xLmxlbmd0aDsgX2krKykge1xyXG4gICAgICAgICAgICB2YXIgYXNzaWdubWVudCA9IGFzc2lnbm1lbnRMaXN0XzFbX2ldO1xyXG4gICAgICAgICAgICBpZiAoYXNzaWdubWVudC5jb3Vyc2VTaXRlSW5mby5jb3Vyc2VJRCA9PT0gY291cnNlSUQpIHtcclxuICAgICAgICAgICAgICAgIHVwZGF0ZWRBc3NpZ25tZW50TGlzdC5wdXNoKG5ldyBtb2RlbF8xLkFzc2lnbm1lbnQoYXNzaWdubWVudC5jb3Vyc2VTaXRlSW5mbywgYXNzaWdubWVudC5hc3NpZ25tZW50RW50cmllcywgdHJ1ZSkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdXBkYXRlZEFzc2lnbm1lbnRMaXN0LnB1c2goYXNzaWdubWVudCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgICB1cGRhdGVkQXNzaWdubWVudExpc3QgPSBhc3NpZ25tZW50TGlzdDtcclxuICAgIH1cclxuICAgIHJldHVybiB1cGRhdGVkQXNzaWdubWVudExpc3Q7XHJcbn07XHJcbmV4cG9ydHMudXBkYXRlSXNSZWFkRmxhZyA9IHVwZGF0ZUlzUmVhZEZsYWc7XHJcbi8qKlxyXG4gKiBDaGFuZ2UgbG9hZGluZyBpY29uIHRvIGhhbWJ1cmdlciBidXR0b24uXHJcbiAqL1xyXG5mdW5jdGlvbiBtaW5pU2FrYWlSZWFkeSgpIHtcclxuICAgIHZhciBsb2FkaW5nSWNvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJjcy1sb2FkaW5nXCIpWzBdO1xyXG4gICAgdmFyIGhhbWJ1cmdlckljb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaW1nXCIpO1xyXG4gICAgaGFtYnVyZ2VySWNvbi5zcmMgPSBjaHJvbWUucnVudGltZS5nZXRVUkwoXCJpbWcvbWluaVNha2FpQnRuLnBuZ1wiKTtcclxuICAgIGhhbWJ1cmdlckljb24uY2xhc3NOYW1lID0gXCJjcy1taW5pc2FrYWktYnRuXCI7XHJcbiAgICBsb2FkaW5nSWNvbi5jbGFzc05hbWUgPSBcImNzLW1pbmlzYWthaS1idG4tZGl2XCI7XHJcbiAgICBsb2FkaW5nSWNvbi5hcHBlbmQoaGFtYnVyZ2VySWNvbik7XHJcbn1cclxuZXhwb3J0cy5taW5pU2FrYWlSZWFkeSA9IG1pbmlTYWthaVJlYWR5O1xyXG4vKipcclxuICogQ29udmVydCBhcnJheSB0byBTZXR0aW5ncyBjbGFzc1xyXG4gKiBAcGFyYW0ge2FueX0gYXJyXHJcbiAqL1xyXG5mdW5jdGlvbiBjb252ZXJ0QXJyYXlUb1NldHRpbmdzKGFycikge1xyXG4gICAgdmFyIHNldHRpbmdzID0gbmV3IHNldHRpbmdzXzEuU2V0dGluZ3MoKTtcclxuICAgIHNldHRpbmdzLmFzc2lnbm1lbnRDYWNoZUludGVydmFsID0gYXJyLmFzc2lnbm1lbnRDYWNoZUludGVydmFsO1xyXG4gICAgc2V0dGluZ3MucXVpekNhY2hlSW50ZXJ2YWwgPSBhcnIucXVpekNhY2hlSW50ZXJ2YWw7XHJcbiAgICBzZXR0aW5ncy5kaXNwbGF5Q2hlY2tlZEFzc2lnbm1lbnQgPSBhcnIuZGlzcGxheUNoZWNrZWRBc3NpZ25tZW50O1xyXG4gICAgc2V0dGluZ3MuZGlzcGxheUxhdGVTdWJtaXRBc3NpZ25tZW50ID0gYXJyLmRpc3BsYXlMYXRlU3VibWl0QXNzaWdubWVudDtcclxuICAgIHNldHRpbmdzLnRvcENvbG9yRGFuZ2VyID0gYXJyLnRvcENvbG9yRGFuZ2VyO1xyXG4gICAgc2V0dGluZ3MudG9wQ29sb3JXYXJuaW5nID0gYXJyLnRvcENvbG9yV2FybmluZztcclxuICAgIHNldHRpbmdzLnRvcENvbG9yU3VjY2VzcyA9IGFyci50b3BDb2xvclN1Y2Nlc3M7XHJcbiAgICBzZXR0aW5ncy5taW5pQ29sb3JEYW5nZXIgPSBhcnIubWluaUNvbG9yRGFuZ2VyO1xyXG4gICAgc2V0dGluZ3MubWluaUNvbG9yV2FybmluZyA9IGFyci5taW5pQ29sb3JXYXJuaW5nO1xyXG4gICAgc2V0dGluZ3MubWluaUNvbG9yU3VjY2VzcyA9IGFyci5taW5pQ29sb3JTdWNjZXNzO1xyXG4gICAgcmV0dXJuIHNldHRpbmdzO1xyXG59XHJcbmV4cG9ydHMuY29udmVydEFycmF5VG9TZXR0aW5ncyA9IGNvbnZlcnRBcnJheVRvU2V0dGluZ3M7XHJcbi8qKlxyXG4gKiBDb252ZXJ0IGFycmF5IHRvIEFzc2lnbm1lbnQgY2xhc3NcclxuICogQHBhcmFtIHthbnl9IGFyclxyXG4gKi9cclxuZnVuY3Rpb24gY29udmVydEFycmF5VG9Bc3NpZ25tZW50KGFycikge1xyXG4gICAgdmFyIGFzc2lnbm1lbnRMaXN0ID0gW107XHJcbiAgICBmb3IgKHZhciBfaSA9IDAsIGFycl8xID0gYXJyOyBfaSA8IGFycl8xLmxlbmd0aDsgX2krKykge1xyXG4gICAgICAgIHZhciBpID0gYXJyXzFbX2ldO1xyXG4gICAgICAgIHZhciBhc3NpZ25tZW50RW50cmllcyA9IFtdO1xyXG4gICAgICAgIGZvciAodmFyIF9hID0gMCwgX2IgPSBpLmFzc2lnbm1lbnRFbnRyaWVzOyBfYSA8IF9iLmxlbmd0aDsgX2ErKykge1xyXG4gICAgICAgICAgICB2YXIgZSA9IF9iW19hXTtcclxuICAgICAgICAgICAgdmFyIGVudHJ5ID0gbmV3IG1vZGVsXzEuQXNzaWdubWVudEVudHJ5KGUuYXNzaWdubWVudElELCBlLmFzc2lnbm1lbnRUaXRsZSwgZS5kdWVEYXRlVGltZXN0YW1wLCBlLmNsb3NlRGF0ZVRpbWVzdGFtcCwgZS5pc01lbW8sIGUuaXNGaW5pc2hlZCwgZS5pc1F1aXosIGUuYXNzaWdubWVudERldGFpbCk7XHJcbiAgICAgICAgICAgIGVudHJ5LmFzc2lnbm1lbnRQYWdlID0gZS5hc3NpZ25tZW50UGFnZTtcclxuICAgICAgICAgICAgaWYgKGVudHJ5LmdldENsb3NlRGF0ZVRpbWVzdGFtcCAqIDEwMDAgPiBleHBvcnRzLm5vd1RpbWUpXHJcbiAgICAgICAgICAgICAgICBhc3NpZ25tZW50RW50cmllcy5wdXNoKGVudHJ5KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgYXNzaWdubWVudExpc3QucHVzaChuZXcgbW9kZWxfMS5Bc3NpZ25tZW50KG5ldyBtb2RlbF8xLkNvdXJzZVNpdGVJbmZvKGkuY291cnNlU2l0ZUluZm8uY291cnNlSUQsIGkuY291cnNlU2l0ZUluZm8uY291cnNlTmFtZSksIGFzc2lnbm1lbnRFbnRyaWVzLCBpLmlzUmVhZCkpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGFzc2lnbm1lbnRMaXN0O1xyXG59XHJcbmV4cG9ydHMuY29udmVydEFycmF5VG9Bc3NpZ25tZW50ID0gY29udmVydEFycmF5VG9Bc3NpZ25tZW50O1xyXG4vKipcclxuICogQ29tcGFyZSBvbGQgYW5kIG5ldyBBc3NpZ25tZW50TGlzdCBhbmQgbWVyZ2UgdGhlbS5cclxuICogQHBhcmFtIHtBc3NpZ25tZW50W119IG9sZEFzc2lnbm1lbnRpTGlzdFxyXG4gKiBAcGFyYW0ge0Fzc2lnbm1lbnRbXX0gbmV3QXNzaWdubWVudExpc3RcclxuICovXHJcbmZ1bmN0aW9uIGNvbXBhcmVBbmRNZXJnZUFzc2lnbm1lbnRMaXN0KG9sZEFzc2lnbm1lbnRpTGlzdCwgbmV3QXNzaWdubWVudExpc3QpIHtcclxuICAgIHZhciBtZXJnZWRBc3NpZ25tZW50TGlzdCA9IFtdO1xyXG4gICAgdmFyIF9sb29wXzEgPSBmdW5jdGlvbiAobmV3QXNzaWdubWVudCkge1xyXG4gICAgICAgIHZhciBpZHggPSBvbGRBc3NpZ25tZW50aUxpc3QuZmluZEluZGV4KGZ1bmN0aW9uIChvbGRBc3NpZ25tZW50KSB7XHJcbiAgICAgICAgICAgIHJldHVybiBvbGRBc3NpZ25tZW50LmNvdXJzZVNpdGVJbmZvLmNvdXJzZUlEID09PSBuZXdBc3NpZ25tZW50LmNvdXJzZVNpdGVJbmZvLmNvdXJzZUlEO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vIElmIHRoaXMgY291cnNlSUQgaXMgKipOT1QqKiBpbiBvbGRBc3NpZ25tZW50TGlzdDpcclxuICAgICAgICBpZiAoaWR4ID09PSAtMSkge1xyXG4gICAgICAgICAgICAvLyBTaW5jZSB0aGlzIGNvdXJzZSBzaXRlIGhhcyBhIGZpcnN0IGFzc2lnbm1lbnQsIHNldCBpc1JlYWQgZmxhZ3MgdG8gZmFsc2UuXHJcbiAgICAgICAgICAgIHZhciBpc1JlYWQgPSBuZXdBc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzLmxlbmd0aCA9PT0gMDtcclxuICAgICAgICAgICAgLy8gU29ydCBhbmQgYWRkIHRoaXMgdG8gQXNzaWdubWVudExpc3RcclxuICAgICAgICAgICAgbmV3QXNzaWdubWVudC5hc3NpZ25tZW50RW50cmllcy5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYS5nZXREdWVEYXRlVGltZXN0YW1wIC0gYi5nZXREdWVEYXRlVGltZXN0YW1wO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgbWVyZ2VkQXNzaWdubWVudExpc3QucHVzaChuZXcgbW9kZWxfMS5Bc3NpZ25tZW50KG5ld0Fzc2lnbm1lbnQuY291cnNlU2l0ZUluZm8sIG5ld0Fzc2lnbm1lbnQuYXNzaWdubWVudEVudHJpZXMsIGlzUmVhZCkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBJZiB0aGlzIGNvdXJzZUlEICoqSVMqKiBpbiBvbGRBc3NpZ25tZW50TGlzdDpcclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgLy8gVGFrZSBvdmVyIGlzUmVhZCBmbGFnXHJcbiAgICAgICAgICAgIHZhciBpc1JlYWQgPSBvbGRBc3NpZ25tZW50aUxpc3RbaWR4XS5pc1JlYWQ7XHJcbiAgICAgICAgICAgIC8vIEp1c3QgaW4gY2FzZSBpZiBBc3NpZ25tZW50TGlzdCBpcyBlbXB0eSwgc2V0IGZsYWcgdG8gdHJ1ZVxyXG4gICAgICAgICAgICBpZiAobmV3QXNzaWdubWVudC5hc3NpZ25tZW50RW50cmllcy5sZW5ndGggPT09IDApXHJcbiAgICAgICAgICAgICAgICBpc1JlYWQgPSB0cnVlO1xyXG4gICAgICAgICAgICB2YXIgbWVyZ2VkQXNzaWdubWVudEVudHJpZXMgPSBbXTtcclxuICAgICAgICAgICAgdmFyIF9sb29wXzIgPSBmdW5jdGlvbiAobmV3QXNzaWdubWVudEVudHJ5KSB7XHJcbiAgICAgICAgICAgICAgICAvLyBGaW5kIGlmIHRoaXMgbmV3IGFzc2lnbm1lbnQgaXMgaW4gb2xkIEFzc2lnbm1lbnRMaXN0XHJcbiAgICAgICAgICAgICAgICB2YXIgb2xkQXNzaWdubWVudCA9IG9sZEFzc2lnbm1lbnRpTGlzdFtpZHhdO1xyXG4gICAgICAgICAgICAgICAgdmFyIHEgPSBvbGRBc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzLmZpbmRJbmRleChmdW5jdGlvbiAob2xkQXNzaWdubWVudEVudHJ5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9sZEFzc2lnbm1lbnRFbnRyeS5hc3NpZ25tZW50SUQgPT09IG5ld0Fzc2lnbm1lbnRFbnRyeS5hc3NpZ25tZW50SUQ7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIC8vIElmIHRoZXJlIGlzIHNhbWUgYXNzaWdubWVudElELCB1cGRhdGUgaXQuXHJcbiAgICAgICAgICAgICAgICBpZiAocSA9PT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBTZXQgaXNSZWFkIGZsYWcgdG8gZmFsc2Ugc2luY2UgdGhlcmUgbWlnaHQgYmUgc29tZSB1cGRhdGVzIGluIGFzc2lnbm1lbnQuXHJcbiAgICAgICAgICAgICAgICAgICAgaXNSZWFkID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVyZ2VkQXNzaWdubWVudEVudHJpZXMucHVzaChuZXdBc3NpZ25tZW50RW50cnkpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gSWYgdGhlcmUgaXMgbm90LCBjcmVhdGUgYSBuZXcgQXNzaWdubWVudEVudHJ5IGZvciB0aGUgY291cnNlIHNpdGUuXHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgZW50cnkgPSBuZXcgbW9kZWxfMS5Bc3NpZ25tZW50RW50cnkobmV3QXNzaWdubWVudEVudHJ5LmFzc2lnbm1lbnRJRCwgbmV3QXNzaWdubWVudEVudHJ5LmFzc2lnbm1lbnRUaXRsZSwgbmV3QXNzaWdubWVudEVudHJ5LmR1ZURhdGVUaW1lc3RhbXAsIG5ld0Fzc2lnbm1lbnRFbnRyeS5jbG9zZURhdGVUaW1lc3RhbXAsIG5ld0Fzc2lnbm1lbnRFbnRyeS5pc01lbW8sIG9sZEFzc2lnbm1lbnQuYXNzaWdubWVudEVudHJpZXNbcV0uaXNGaW5pc2hlZCwgbmV3QXNzaWdubWVudEVudHJ5LmlzUXVpeiwgbmV3QXNzaWdubWVudEVudHJ5LmFzc2lnbm1lbnREZXRhaWwpO1xyXG4gICAgICAgICAgICAgICAgICAgIGVudHJ5LmFzc2lnbm1lbnRQYWdlID0gbmV3QXNzaWdubWVudEVudHJ5LmFzc2lnbm1lbnRQYWdlO1xyXG4gICAgICAgICAgICAgICAgICAgIG1lcmdlZEFzc2lnbm1lbnRFbnRyaWVzLnB1c2goZW50cnkpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBmb3IgKHZhciBfYSA9IDAsIF9iID0gbmV3QXNzaWdubWVudC5hc3NpZ25tZW50RW50cmllczsgX2EgPCBfYi5sZW5ndGg7IF9hKyspIHtcclxuICAgICAgICAgICAgICAgIHZhciBuZXdBc3NpZ25tZW50RW50cnkgPSBfYltfYV07XHJcbiAgICAgICAgICAgICAgICBfbG9vcF8yKG5ld0Fzc2lnbm1lbnRFbnRyeSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy8gU29ydCBBc3NpZ25tZW50TGlzdFxyXG4gICAgICAgICAgICBtZXJnZWRBc3NpZ25tZW50RW50cmllcy5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYS5nZXREdWVEYXRlVGltZXN0YW1wIC0gYi5nZXREdWVEYXRlVGltZXN0YW1wO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgbWVyZ2VkQXNzaWdubWVudExpc3QucHVzaChuZXcgbW9kZWxfMS5Bc3NpZ25tZW50KG5ld0Fzc2lnbm1lbnQuY291cnNlU2l0ZUluZm8sIG1lcmdlZEFzc2lnbm1lbnRFbnRyaWVzLCBpc1JlYWQpKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG4gICAgLy8gTWVyZ2UgQXNzaWdubWVudHMgYmFzZWQgb24gbmV3QXNzaWdubWVudExpc3RcclxuICAgIGZvciAodmFyIF9pID0gMCwgbmV3QXNzaWdubWVudExpc3RfMSA9IG5ld0Fzc2lnbm1lbnRMaXN0OyBfaSA8IG5ld0Fzc2lnbm1lbnRMaXN0XzEubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgdmFyIG5ld0Fzc2lnbm1lbnQgPSBuZXdBc3NpZ25tZW50TGlzdF8xW19pXTtcclxuICAgICAgICBfbG9vcF8xKG5ld0Fzc2lnbm1lbnQpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG1lcmdlZEFzc2lnbm1lbnRMaXN0O1xyXG59XHJcbmV4cG9ydHMuY29tcGFyZUFuZE1lcmdlQXNzaWdubWVudExpc3QgPSBjb21wYXJlQW5kTWVyZ2VBc3NpZ25tZW50TGlzdDtcclxuLyoqXHJcbiAqIE1lcmdlIEFzc2lnbm1lbnRzLCBRdWl6emVzLCBNZW1vcyB0b2dldGhlci5cclxuICogQHBhcmFtIHtBc3NpZ25tZW50W119IHRhcmdldEFzc2lnbm1lbnRMaXN0XHJcbiAqIEBwYXJhbSB7QXNzaWdubWVudFtdfSBuZXdBc3NpZ25tZW50TGlzdFxyXG4gKi9cclxuZnVuY3Rpb24gbWVyZ2VJbnRvQXNzaWdubWVudExpc3QodGFyZ2V0QXNzaWdubWVudExpc3QsIG5ld0Fzc2lnbm1lbnRMaXN0KSB7XHJcbiAgICB2YXIgbWVyZ2VkQXNzaWdubWVudExpc3QgPSBbXTtcclxuICAgIGZvciAodmFyIF9pID0gMCwgdGFyZ2V0QXNzaWdubWVudExpc3RfMSA9IHRhcmdldEFzc2lnbm1lbnRMaXN0OyBfaSA8IHRhcmdldEFzc2lnbm1lbnRMaXN0XzEubGVuZ3RoOyBfaSsrKSB7XHJcbiAgICAgICAgdmFyIGFzc2lnbm1lbnQgPSB0YXJnZXRBc3NpZ25tZW50TGlzdF8xW19pXTtcclxuICAgICAgICBtZXJnZWRBc3NpZ25tZW50TGlzdC5wdXNoKG5ldyBtb2RlbF8xLkFzc2lnbm1lbnQoYXNzaWdubWVudC5jb3Vyc2VTaXRlSW5mbywgYXNzaWdubWVudC5hc3NpZ25tZW50RW50cmllcywgYXNzaWdubWVudC5pc1JlYWQpKTtcclxuICAgIH1cclxuICAgIHZhciBfbG9vcF8zID0gZnVuY3Rpb24gKG5ld0Fzc2lnbm1lbnQpIHtcclxuICAgICAgICB2YXIgaWR4ID0gdGFyZ2V0QXNzaWdubWVudExpc3QuZmluZEluZGV4KGZ1bmN0aW9uIChhc3NpZ25tZW50KSB7XHJcbiAgICAgICAgICAgIHJldHVybiBuZXdBc3NpZ25tZW50LmNvdXJzZVNpdGVJbmZvLmNvdXJzZUlEID09PSBhc3NpZ25tZW50LmNvdXJzZVNpdGVJbmZvLmNvdXJzZUlEO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHZhciBtZXJnZWRBc3NpZ25tZW50ID0gbWVyZ2VkQXNzaWdubWVudExpc3RbaWR4XTtcclxuICAgICAgICBpZiAoaWR4ICE9PSAtMSkge1xyXG4gICAgICAgICAgICBtZXJnZWRBc3NpZ25tZW50LmFzc2lnbm1lbnRFbnRyaWVzID0gbWVyZ2VkQXNzaWdubWVudC5hc3NpZ25tZW50RW50cmllcy5jb25jYXQobmV3QXNzaWdubWVudC5hc3NpZ25tZW50RW50cmllcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBtZXJnZWRBc3NpZ25tZW50TGlzdC5wdXNoKG5ldyBtb2RlbF8xLkFzc2lnbm1lbnQobmV3QXNzaWdubWVudC5jb3Vyc2VTaXRlSW5mbywgbmV3QXNzaWdubWVudC5hc3NpZ25tZW50RW50cmllcywgdHJ1ZSkpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcbiAgICBmb3IgKHZhciBfYSA9IDAsIG5ld0Fzc2lnbm1lbnRMaXN0XzIgPSBuZXdBc3NpZ25tZW50TGlzdDsgX2EgPCBuZXdBc3NpZ25tZW50TGlzdF8yLmxlbmd0aDsgX2ErKykge1xyXG4gICAgICAgIHZhciBuZXdBc3NpZ25tZW50ID0gbmV3QXNzaWdubWVudExpc3RfMltfYV07XHJcbiAgICAgICAgX2xvb3BfMyhuZXdBc3NpZ25tZW50KTtcclxuICAgIH1cclxuICAgIHJldHVybiBtZXJnZWRBc3NpZ25tZW50TGlzdDtcclxufVxyXG5leHBvcnRzLm1lcmdlSW50b0Fzc2lnbm1lbnRMaXN0ID0gbWVyZ2VJbnRvQXNzaWdubWVudExpc3Q7XHJcbi8qKlxyXG4gKiBGdW5jdGlvbiBmb3Igc29ydGluZyBBc3NpZ25tZW50c1xyXG4gKiBAcGFyYW0ge0Fzc2lnbm1lbnRbXX0gYXNzaWdubWVudExpc3RcclxuICovXHJcbmZ1bmN0aW9uIHNvcnRBc3NpZ25tZW50TGlzdChhc3NpZ25tZW50TGlzdCkge1xyXG4gICAgcmV0dXJuIEFycmF5LmZyb20oYXNzaWdubWVudExpc3QpLnNvcnQoZnVuY3Rpb24gKGEsIGIpIHtcclxuICAgICAgICBpZiAoYS5jbG9zZXN0RHVlRGF0ZVRpbWVzdGFtcCA+IGIuY2xvc2VzdER1ZURhdGVUaW1lc3RhbXApXHJcbiAgICAgICAgICAgIHJldHVybiAxO1xyXG4gICAgICAgIGlmIChhLmNsb3Nlc3REdWVEYXRlVGltZXN0YW1wIDwgYi5jbG9zZXN0RHVlRGF0ZVRpbWVzdGFtcClcclxuICAgICAgICAgICAgcmV0dXJuIC0xO1xyXG4gICAgICAgIHJldHVybiAwO1xyXG4gICAgfSk7XHJcbn1cclxuZXhwb3J0cy5zb3J0QXNzaWdubWVudExpc3QgPSBzb3J0QXNzaWdubWVudExpc3Q7XHJcbi8qKlxyXG4gKiBEZWNpZGVzIHdoZXRoZXIgdG8gdXNlIGNhY2hlXHJcbiAqIEBwYXJhbSB7bnVtYmVyIHwgdW5kZWZpbmVkfSBmZXRjaGVkVGltZVxyXG4gKiBAcGFyYW0ge251bWJlcn0gY2FjaGVJbnRlcnZhbFxyXG4gKi9cclxuZnVuY3Rpb24gaXNVc2luZ0NhY2hlKGZldGNoZWRUaW1lLCBjYWNoZUludGVydmFsKSB7XHJcbiAgICBpZiAoZmV0Y2hlZFRpbWUpXHJcbiAgICAgICAgcmV0dXJuIChleHBvcnRzLm5vd1RpbWUgLSBmZXRjaGVkVGltZSkgLyAxMDAwIDw9IGNhY2hlSW50ZXJ2YWw7XHJcbiAgICBlbHNlXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG59XHJcbmV4cG9ydHMuaXNVc2luZ0NhY2hlID0gaXNVc2luZ0NhY2hlO1xyXG4vKipcclxuICogR2VuZXJhdGUgdW5pcXVlIElEXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSBwcmVmaXhcclxuICovXHJcbmZ1bmN0aW9uIGdlblVuaXF1ZUlEKHByZWZpeCkge1xyXG4gICAgcmV0dXJuIHByZWZpeCArIG5ldyBEYXRlKCkuZ2V0VGltZSgpLnRvU3RyaW5nKDE2KSArIE1hdGguZmxvb3IoMTIzNDU2ICogTWF0aC5yYW5kb20oKSkudG9TdHJpbmcoMTYpO1xyXG59XHJcbmV4cG9ydHMuZ2VuVW5pcXVlSUQgPSBnZW5VbmlxdWVJRDtcclxuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgaXMgcmVmZXJlbmNlZCBieSBvdGhlciBtb2R1bGVzIHNvIGl0IGNhbid0IGJlIGlubGluZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXyhcIi4vc3JjL2NvbnRlbnRfc2NyaXB0LnRzXCIpO1xuIiwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9